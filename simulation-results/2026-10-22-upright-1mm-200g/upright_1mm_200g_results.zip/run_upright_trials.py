#!/usr/bin/env python3
"""Isolated, continuous 1 ms upright-rod trials; frozen evaluator is untouched.

The external adaptations below are explicit: one vertical initial reset, a
visible 0.5 s pause, a two-second approach, and the original trajectory's
physical duration preserved when reducing the integration step to 1 ms.
"""
from __future__ import annotations

import argparse
from concurrent.futures import ThreadPoolExecutor
import hashlib
import importlib.util
import json
import math
from pathlib import Path
import subprocess
import sys
import traceback
from types import MethodType
import xml.etree.ElementTree as ET

import mujoco
import numpy as np

ROOT = Path(__file__).resolve().parent
FIXTURE_SOURCE = ROOT / "fixtures/fixture_scene.py"
FROZEN_SOURCE = ROOT.parent / "evaluate_lifts.py"
HAND_XML = Path("/workspace/Dexonomy/assets/hand/shadow/right.xml")
EXPECTED_FROZEN_SHA = "164fd4e4eab1472a7cf4eb92bf5abf88747f78c1df58b19a0667ce8ce75f5d50"
DEFAULT_IDS = ["vertical_center", "vertical_x_plus", "vertical_x_minus", "vertical_y_plus", "vertical_y_minus", "vertical_close_slow", "vertical_close_slower"]
DIAG_FIELDS = ["time_s", "phase_id", "rod_tilt_deg", "hand_object_contacts", "object_fixture_contacts", "object_plane_contacts", "hand_fixture_contacts", "hand_object_max_penetration_m", "object_fixture_max_penetration_m", "hand_fixture_max_penetration_m", "normal_hand_contact_force_sum_N", "normal_fixture_contact_force_sum_N", "normal_plane_contact_force_sum_N", "normal_hand_fixture_contact_force_sum_N", "object_z_m", "hand_root_z_m", "object_external_force_norm_N", "object_external_torque_norm_Nm"]


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def write_json(path, value):
    Path(path).write_text(json.dumps(value, ensure_ascii=False, indent=2,
        default=lambda x: x.tolist() if isinstance(x, np.ndarray) else x.item() if isinstance(x, np.generic) else str(x)) + "\n")


def load_fixture():
    name = "_upright_runner_fixture"
    if name not in sys.modules:
        spec = importlib.util.spec_from_file_location(name, FIXTURE_SOURCE)
        module = importlib.util.module_from_spec(spec)
        sys.modules[name] = module
        spec.loader.exec_module(module)
    return sys.modules[name]


def geometry_ids(env):
    model = env._model
    hand, obj, fixture, plane = set(), set(), set(), set()
    for i in range(model.ngeom):
        body = model.body(int(model.geom_bodyid[i])).name
        name = model.geom(i).name
        collision = bool(model.geom_contype[i] or model.geom_conaffinity[i])
        if body.startswith("hand-") and collision:
            hand.add(i)
        if body.startswith("obj-") and collision:
            obj.add(i)
        if name.startswith("fixture-"):
            fixture.add(i)
        if body == "world" and i not in fixture and collision:
            plane.add(i)
    return hand, obj, fixture, plane


def closest_geometry(env, left, right):
    model, data = env._model, env._data
    best, pair, points = math.inf, None, None
    for a in sorted(left):
        for b in sorted(right):
            if not ((model.geom_contype[a] & model.geom_conaffinity[b]) or (model.geom_contype[b] & model.geom_conaffinity[a])):
                continue
            segment = np.zeros(6)
            distance = float(mujoco.mj_geomDistance(model, data, a, b, 1.0, segment))
            if distance < best:
                best, pair, points = distance, [model.geom(a).name, model.geom(b).name], segment.tolist()
    return {"distance_m": best if math.isfinite(best) else None, "geom_names": pair, "closest_points_world_m": points,
            "method": "mj_geomDistance over all collision-enabled hand/object geom pairs; distmax=1 m"}


def root_joint(env):
    model = env._model
    candidates = [i for i in range(model.njnt) if model.jnt_type[i] == mujoco.mjtJoint.mjJNT_FREE and model.body(int(model.jnt_bodyid[i])).name.startswith("hand-")]
    if len(candidates) != 1:
        raise RuntimeError(f"Expected one actual free hand root, got {candidates}")
    jid = candidates[0]
    return {"joint_id": jid, "joint_name": model.joint(jid).name,
            "body_id": int(model.jnt_bodyid[jid]), "body_name": model.body(int(model.jnt_bodyid[jid])).name,
            "qpos_address": int(model.jnt_qposadr[jid])}


def make_diagnostic(env, phase_id, ids, root):
    hand, obj, fixture, plane = ids
    counts = np.zeros(4, dtype=int)
    penetrations = np.zeros(3)
    forces = np.zeros(4)
    for index, contact in enumerate(env._data.contact):
        a, b = int(contact.geom1), int(contact.geom2)
        pair = {a, b}
        kind = None
        if pair & hand and pair & obj:
            kind = 0
            penetrations[0] = max(penetrations[0], -float(contact.dist))
        elif pair & obj and pair & fixture:
            kind = 1
            penetrations[1] = max(penetrations[1], -float(contact.dist))
        elif pair & obj and pair & plane:
            kind = 2
        elif pair & hand and pair & fixture:
            kind = 3
            penetrations[2] = max(penetrations[2], -float(contact.dist))
        if kind is not None:
            counts[kind] += 1
            force = np.zeros(6)
            mujoco.mj_contactForce(env._model, env._data, index, force)
            forces[kind] += abs(float(force[0]))
    pose = env.get_active_obj_pose()
    q = pose[3:7] / np.linalg.norm(pose[3:7])
    axis_z = 1 - 2 * (q[1] ** 2 + q[2] ** 2)
    tilt = math.degrees(math.acos(float(np.clip(abs(axis_z), 0, 1))))
    force = env._data.xfrc_applied[env._obj_active_bodyid]
    return np.asarray([env._data.time, phase_id, tilt, *counts, *penetrations, *forces,
                       pose[2], env._data.qpos[root["qpos_address"] + 2], np.linalg.norm(force[:3]), np.linalg.norm(force[3:])], dtype=np.float64)


def make_observer_class(frozen):
    base = frozen.TrialObserver

    class UprightObserver(base):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)
            self.geometry_sets = geometry_ids(self.env)
            self.actual_root = root_joint(self.env)
            self.diagnostics = []
            self.sample_diagnostics = []
            self.phase_distance_checks = []
            self.initial_gap = closest_geometry(self.env, *self.geometry_sets[:2])
            self.first_hand_contact = None

        def begin_phase(self, phase):
            super().begin_phase(phase)
            self.phase_distance_checks.append({"phase": phase, "time_s": float(self.env._data.time),
                "hand_object": closest_geometry(self.env, *self.geometry_sets[:2])})

        def observe(self):
            diagnostic = make_diagnostic(self.env, frozen.PHASES.index(self.phase), self.geometry_sets, self.actual_root)
            self.diagnostics.append(diagnostic)
            if diagnostic[3] > 0 and self.first_hand_contact is None:
                self.first_hand_contact = {"time_s": float(diagnostic[0]), "phase": self.phase,
                    "rod_tilt_deg": float(diagnostic[2]), "object_z_m": float(diagnostic[14]),
                    "contact_count": int(diagnostic[3]), "normal_force_sum_N": float(diagnostic[10])}
            super().observe()

        def capture_trace(self, force=False):
            previous = len(self.trace)
            super().capture_trace(force=force)
            if len(self.trace) != previous:
                self.sample_diagnostics.append(make_diagnostic(self.env, frozen.PHASES.index(self.phase), self.geometry_sets, self.actual_root))

        def finish(self):
            super().finish()
            array = np.asarray(self.diagnostics, dtype=np.float64)
            np.savez_compressed(self.output / "diagnostics.npz", **{name: array[:, i] for i, name in enumerate(DIAG_FIELDS)}, phase_names=np.asarray(frozen.PHASES))
            # Preserve micro-scale state precision and attach synchronized contact data.
            columns = ["time_s", "phase_id", "qpos", "ctrl", "object_pose", "mocap_pos", "mocap_quat", "hand_object_contacts", "object_table_contacts", "normal_hand_contact_force_sum_N"]
            trace = {name: np.asarray([row[i] for row in self.trace], dtype=np.int16 if name in ("phase_id", "hand_object_contacts", "object_table_contacts") else np.float64)
                     for i, name in enumerate(columns)}
            sampled = np.asarray(self.sample_diagnostics)
            for i, name in enumerate(DIAG_FIELDS):
                if name not in trace:
                    trace[name] = sampled[:, i]
            trace["phase_names"] = np.asarray(frozen.PHASES)
            np.savez_compressed(self.output / "trace.npz", **trace)
            self.env.last_upright_observer = self

    return UprightObserver


def run_trial(job):
    output = Path(job["output"])
    output.mkdir(parents=True, exist_ok=True)
    provenance = {"runner_sha256": sha(__file__), "fixture_source_sha256": sha(FIXTURE_SOURCE), "frozen_evaluator_sha256": sha(FROZEN_SOURCE),
                  "input_sha256": sha(job["variant"]["input"]), "hand_xml_sha256": sha(HAND_XML)}
    if provenance["frozen_evaluator_sha256"] != EXPECTED_FROZEN_SHA:
        raise RuntimeError("Frozen evaluator was changed; refusing to run")
    metrics_path = output / "metrics.json"
    if job.get("resume") and metrics_path.exists():
        cached = json.loads(metrics_path.read_text())
        if cached.get("upright_provenance") == provenance and (output / "diagnostics.npz").exists() and cached.get("upright_protocol", {}).get("closure_duration_scale") == job["variant"]["closure_duration_scale"]:
            return {"fixture": job["fixture"], "variant": job["variant"]["id"], "metrics": str(metrics_path), "reused": True,
                    "full_sequence_passed": cached["full_sequence_passed"], "measured_object_lift_mm": cached["measured_object_lift_mm"]}
    fixture = load_fixture()
    frozen = fixture.frozen_module()
    grasp, scene = frozen.prepare_scene(job["variant"]["input"], .2)
    env = fixture.make_env(scene, HAND_XML, fixture=job["fixture"], mass_kg=.2, timestep=.001)
    for i in range(env._model.ngeom):
        if env._model.body(int(env._model.geom_bodyid[i])).name.startswith("hand-"):
            env._model.geom_matid[i] = -1
            env._model.geom_rgba[i] = [.863157, .0865002, .0802199, 1]
    controls, types, forces, target = frozen.get_planner(scene["task"].copy()).plan_trajectory(
        env._obj_init_qpos[-7:].copy(), grasp["pregrasp_qpos"], grasp["grasp_qpos"], grasp["squeeze_qpos"], grasp.get("robot_pose"))
    if any(force is not None for force in forces):
        raise RuntimeError("External object force requested by trajectory")
    actual_start = np.asarray(controls[0]).copy()
    actual_start[:3] += [0, 0, .1]
    original_reset, original_run = env.reset_qpos, env.run_trajectory
    original_move, original_observer, original_phases = frozen.move_control, frozen.TrialObserver, frozen.PHASES
    reset_log, move_log, trajectory_log = [], [], []
    scale = float(job["variant"]["closure_duration_scale"])
    substeps = round(20 * scale)
    if abs(substeps - 20 * scale) > 1e-10:
        raise ValueError("Closure scale cannot be represented exactly at 1 ms")
    frozen.PHASES = ["start_pause"] + list(original_phases)
    frozen.TrialObserver = make_observer_class(frozen)

    def reset_once(self, unused_computed_start, *args, **kwargs):
        if reset_log:
            raise RuntimeError("Second reset in trial rejected")
        reset_log.append({"requested_by_frozen_evaluator": np.asarray(unused_computed_start).tolist(), "actual_vertical_start": actual_start.tolist()})
        return original_reset(actual_start, *args, **kwargs)

    def run_original_duration(self, ctrl_qpos, ctrl_type, ext_fdir, *args, **kwargs):
        trajectory_log.append({"step": 5, "substep": substeps, "dt_s": .001, "closure_duration_scale": scale,
                               "segments": len(ctrl_qpos) - 1, "duration_s": (len(ctrl_qpos) - 1) * 5 * substeps * .001})
        return original_run(ctrl_qpos, ctrl_type, ext_fdir, step=5, substep=substeps)

    def vertical_first_move(local_env, start, end, seconds):
        move_log.append({"time_s": float(local_env._data.time), "duration_s": seconds})
        if len(move_log) == 1:
            observer = local_env.observer
            observer.phase_boundaries.clear()
            observer.phase_distance_checks.clear()
            observer.trace.clear()
            observer.sample_diagnostics.clear()
            observer.next_trace = 0.
            observer.begin_phase("start_pause")
            if frozen.contact_stats(local_env)[0] != 0 or observer.initial_gap["distance_m"] is None or observer.initial_gap["distance_m"] <= 0:
                raise RuntimeError("Initial hand is already touching/intersecting the rod")
            local_env.set_ctrl(actual_start, "ee_pose")
            local_env.step_sim(500)
            observer.begin_phase("approach")
            return original_move(local_env, actual_start, end, 2.)
        return original_move(local_env, start, end, seconds)

    env.reset_qpos = MethodType(reset_once, env)
    env.run_trajectory = MethodType(run_original_duration, env)
    frozen.move_control = vertical_first_move
    config = frozen.TestConfig(mass_kg=.2, trace_fps=25)
    try:
        metrics = frozen.evaluate_candidate(env, job["variant"]["input"], output, config, render=False)
    finally:
        frozen.move_control, frozen.TrialObserver, frozen.PHASES = original_move, original_observer, original_phases
    observer = env.last_upright_observer
    diag = np.asarray(observer.diagnostics)
    phase_names = ["start_pause"] + list(original_phases)
    phase_stats = {}
    for phase_id, phase in enumerate(phase_names):
        rows = diag[diag[:, 1] == phase_id]
        if len(rows):
            phase_stats[phase] = {"samples": len(rows), "first_time_s": rows[0, 0], "last_time_s": rows[-1, 0],
                "minimum_rod_tilt_deg": np.min(rows[:, 2]), "maximum_rod_tilt_deg": np.max(rows[:, 2]), "final_rod_tilt_deg": rows[-1, 2],
                "maximum_hand_object_contacts": int(np.max(rows[:, 3])), "maximum_object_fixture_contacts": int(np.max(rows[:, 4])),
                "maximum_object_plane_contacts": int(np.max(rows[:, 5])), "maximum_hand_fixture_contacts": int(np.max(rows[:, 6])),
                "maximum_hand_object_penetration_m": np.max(rows[:, 7]), "maximum_object_fixture_penetration_m": np.max(rows[:, 8]),
                "maximum_hand_fixture_penetration_m": np.max(rows[:, 9]), "normal_hand_contact_force_sum_max_N": np.max(rows[:, 10]),
                "final_object_z_m": rows[-1, 14]}
    hold = diag[diag[:, 1] == phase_names.index("postlift_hold")]
    pause = diag[diag[:, 1] == phase_names.index("start_pause")]
    protocol_checks = {"start_root_vertical_offset_100mm": bool(np.allclose(actual_start[:3] - np.asarray(controls[0])[:3], [0, 0, .1], atol=1e-12)),
        "initial_positive_true_hand_object_gap": observer.initial_gap["distance_m"] > 0,
        "pause_has_no_hand_object_contact": bool(np.max(pause[:, 3]) == 0), "completed_500ms_pause": len(pause) == 500,
        "one_initial_reset_only": len(reset_log) == 1, "object_never_externally_forced": bool(np.max(diag[:, 16:18]) == 0),
        "no_fixture_or_plane_support_throughout_five_second_hold": bool(np.max(hold[:, 4:6]) == 0),
        "closure_duration_preserved": True}
    # Archive the *actual compiled* runtime model, including the one initial key.
    mujoco.mj_saveModel(env._model, str(output / "model.mjb"))
    # MjSpec.compile does not populate mj_saveLastXML's global XML cache.
    # Export the source spec with its deliberate runtime gravity/key/color edits;
    # the binary above is the authoritative exact compiled playback model.
    xml_root = ET.fromstring(env._spec.to_xml())
    option = xml_root.find("option")
    if option is None:
        option = ET.SubElement(xml_root, "option")
    option.set("gravity", " ".join(format(v, ".17g") for v in env._model.opt.gravity))
    option.set("timestep", format(float(env._model.opt.timestep), ".17g"))
    flag = option.find("flag")
    if flag is None:
        flag = ET.SubElement(option, "flag")
    flag.set("gravity", "enable")
    key = xml_root.find("keyframe/key")
    if key is not None:
        for name, values in (("qpos", env._model.key_qpos[0]), ("qvel", env._model.key_qvel[0]),
                             ("ctrl", env._model.key_ctrl[0]), ("mpos", env._model.key_mpos[0].ravel()), ("mquat", env._model.key_mquat[0].ravel())):
            key.set(name, " ".join(format(float(v), ".17g") for v in values))
    for element in xml_root.iter("geom"):
        name = element.get("name")
        if name:
            gid = mujoco.mj_name2id(env._model, mujoco.mjtObj.mjOBJ_GEOM, name)
            if gid >= 0 and env._model.body(int(env._model.geom_bodyid[gid])).name.startswith("hand-"):
                element.attrib.pop("material", None)
                element.set("rgba", " ".join(format(float(v), ".9g") for v in env._model.geom_rgba[gid]))
    ET.indent(xml_root)
    (output / "model.xml").write_text(ET.tostring(xml_root, encoding="unicode") + "\n")
    metrics["frozen_computed_approach_initial_root_offset_m"] = metrics["approach_initial_root_offset_m"]
    metrics["approach_initial_root_offset_m"] = [0., 0., .1]
    metrics["upright_provenance"] = provenance
    metrics["fixture"] = job["fixture"]
    metrics["variant"] = job["variant"]["id"]
    metrics["fixture_definition"] = env.fixture_definition
    metrics["upright_protocol"] = {"initial_visible_pause_s": .5, "approach_world_direction": [0, 0, 1], "approach_root_offset_m": .1,
        "approach_s": 2., "closure_duration_scale": scale, "native_trajectory_execution": trajectory_log,
        "initial_minimum_hand_object_geom_distance": observer.initial_gap, "actual_hand_root_joint": observer.actual_root,
        "first_hand_object_contact": observer.first_hand_contact, "phase_distance_checks": observer.phase_distance_checks,
        "phase_statistics": phase_stats, "checks": protocol_checks, "passed": all(protocol_checks.values()),
        "diagnostic_resolution_s": .001, "diagnostics": str((output / "diagnostics.npz").resolve()),
        "model_xml": str((output / "model.xml").resolve()), "model_mjb": str((output / "model.mjb").resolve()),
        "model_xml_sha256": sha(output / "model.xml"), "model_mjb_sha256": sha(output / "model.mjb"),
        "interventions": {"reset": reset_log, "move_calls": move_log, "native_trajectory": trajectory_log,
                         "object_pose_writes_within_trial": 0, "gravity_changes_within_trial": 0, "added_object_forces": False},
        "status": "Continuous gravity-on physical evaluation of an unverified control proposal; no native-certification claim",
        "penetration_policy": "Recorded every integration step; no unreported geometry/force/margin changes. Review relative to rod radius 0.5 mm."}
    metrics["frozen_lift_hold_passed"] = metrics["lift_hold_passed"]
    metrics["full_sequence_passed"] = bool(metrics["full_sequence_passed"] and all(protocol_checks.values()))
    metrics["trace_source"] += "; explicit external vertical-start/pause/duration adapter; diagnostics every 1 ms"
    if provenance["frozen_evaluator_sha256"] != sha(FROZEN_SOURCE) or provenance["fixture_source_sha256"] != sha(FIXTURE_SOURCE):
        raise RuntimeError("Source changed during physics execution")
    write_json(metrics_path, metrics)
    result = {"fixture": job["fixture"], "variant": job["variant"]["id"], "metrics": str(metrics_path), "trace": str(output / "trace.npz"),
              "diagnostics": str(output / "diagnostics.npz"), "reused": False, "lift_hold_passed": metrics["lift_hold_passed"],
              "release_passed": metrics["release_passed"], "full_sequence_passed": metrics["full_sequence_passed"],
              "measured_object_lift_mm": metrics["measured_object_lift_mm"], "first_hand_object_contact": observer.first_hand_contact,
              "initial_minimum_hand_object_gap_mm": observer.initial_gap["distance_m"] * 1000,
              "maximum_hand_object_penetration_mm": float(np.max(diag[:, 7])) * 1000,
              "maximum_hand_fixture_penetration_mm": float(np.max(diag[:, 9])) * 1000}
    write_json(output / "result.json", result)
    print(json.dumps(result, ensure_ascii=False), flush=True)
    return result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--manifest", type=Path, default=ROOT / "grasp_search/candidates.json")
    parser.add_argument("--outdir", type=Path, default=ROOT / "trials")
    parser.add_argument("--candidates", nargs="+", default=DEFAULT_IDS)
    parser.add_argument("--conditions", nargs="+", choices=["plain", "shallow", "deep"], default=["plain", "shallow"])
    parser.add_argument("--workers", type=int, default=1)
    parser.add_argument("--resume", action="store_true")
    parser.add_argument("--worker-job", type=Path)
    args = parser.parse_args()
    if args.worker_job:
        job = json.loads(args.worker_job.read_text())
        try:
            run_trial(job)
        except Exception:
            Path(job["output"]).mkdir(parents=True, exist_ok=True)
            write_json(Path(job["output"]) / "error.json", {"traceback": traceback.format_exc(), "job": job})
            raise
        return
    manifest = json.loads(args.manifest.read_text())
    variants = {v["id"]: v for v in manifest["variants"]}
    missing = set(args.candidates) - variants.keys()
    if missing:
        parser.error(f"Unknown variants: {sorted(missing)}")
    jobs = []
    for name in args.candidates:
        for condition in args.conditions:
            job = {"variant": variants[name], "fixture": condition, "output": str((args.outdir / condition / name).resolve()), "resume": args.resume}
            path = args.outdir / "jobs" / f"{condition}__{name}.json"
            path.parent.mkdir(parents=True, exist_ok=True)
            write_json(path, job)
            jobs.append(path)
    def execute(path):
        result = subprocess.run([sys.executable, str(Path(__file__).resolve()), "--worker-job", str(path)], text=True, capture_output=True)
        if result.stdout:
            print(result.stdout, end="", flush=True)
        if result.stderr:
            print(result.stderr, end="", file=sys.stderr, flush=True)
        job = json.loads(path.read_text())
        metrics = Path(job["output"]) / "metrics.json"
        return {"fixture": job["fixture"], "variant": job["variant"]["id"], "exit_code": result.returncode,
                "metrics": str(metrics), "full_sequence_passed": json.loads(metrics.read_text()).get("full_sequence_passed", False) if result.returncode == 0 else False}
    with ThreadPoolExecutor(max_workers=args.workers) as pool:
        results = list(pool.map(execute, jobs))
    summary = {"runner_sha256": sha(__file__), "fixture_source_sha256": sha(FIXTURE_SOURCE), "frozen_evaluator_sha256": sha(FROZEN_SOURCE),
               "manifest": str(args.manifest.resolve()), "manifest_sha256": sha(args.manifest), "conditions": args.conditions,
               "candidates": args.candidates, "tested": len(results), "exceptions": sum(r["exit_code"] != 0 for r in results),
               "full_sequence_passed": sum(r["full_sequence_passed"] for r in results), "results": results}
    args.outdir.mkdir(parents=True, exist_ok=True)
    write_json(args.outdir / "summary.json", summary)
    if summary["exceptions"]:
        raise SystemExit(1)


if __name__ == "__main__":
    main()
