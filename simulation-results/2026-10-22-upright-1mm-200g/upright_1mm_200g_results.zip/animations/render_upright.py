#!/usr/bin/env python3
"""Original upright-trial MJB/state replay. No physics is integrated here."""
from __future__ import annotations

import argparse
from concurrent.futures import ThreadPoolExecutor
import csv
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys

os.environ.setdefault("MUJOCO_GL", "egl")
os.environ.setdefault("LP_NUM_THREADS", "2")
sys.path.insert(0, "/workspace/shadow-reproduction")

import mujoco
import numpy as np
from PIL import Image, ImageDraw, ImageFont
from video_writer import VideoWriter

OUT = Path(__file__).resolve().parent
ROOT = OUT.parent
FPS, WIDTH, HEIGHT, TOL = 10, 640, 480, 1e-5
PHASES = {"start_pause":"远离物体静置 0.5 s", "initial_hover":"远离物体静置 0.5 s", "approach":"垂直接近 2 s", "approach_close_squeeze":"闭合 / 夹紧", "loaded_hold":"受力保持 1 s", "lift":"抬升 100 mm / 5 s", "postlift_hold":"抬升后持握 5 s", "release_open":"松开手指", "release_retreat":"手部退离", "release_settle":"释放后观察"}


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def write_json(path, value):
    Path(path).write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n")


def font(size):
    return ImageFont.truetype("/usr/share/fonts/opentype/noto/NotoSansCJK-Regular.ttc", size)


def pick(record, keys, default=None):
    for key in keys:
        if key in record:
            return record[key]
    return default


def fixture_of(record, path):
    value = pick(record, ["fixture_name", "fixture", "condition"])
    if isinstance(value, dict):
        value = value.get("name")
    if value in ("plain", "shallow", "deep"):
        return value
    for name in ("plain", "shallow", "deep"):
        if name in str(path):
            return name
    raise ValueError(f"Fixture not declared: {path}")


def variant_of(record, path):
    value = pick(record, ["variant_id", "candidate_id", "variant", "candidate"])
    if isinstance(value, dict):
        value = value.get("id", value.get("name"))
    return str(value or path.parent.name)


def profile_of(record):
    return record.get('hand_controller_intervention',{}).get('profile','baseline')


def identifier_of(record,path):
    base=f'{fixture_of(record,path)}__{variant_of(record,path)}'
    profile=profile_of(record)
    if profile!='baseline':
        return f'{profile}__{base}'
    # Any future physical proposal outside the original14 has its own prefix.
    relative=path.resolve().relative_to(ROOT).parts
    return base if relative[0]=='trials' else f'{relative[0]}__{base}'


def replay(model, data, trace, index):
    data.qpos[:] = trace["qpos"][index]
    data.qvel[:] = 0
    data.ctrl[:] = trace["ctrl"][index]
    data.mocap_pos[:] = trace["mocap_pos"][index]
    data.mocap_quat[:] = trace["mocap_quat"][index]
    data.time = float(trace["time_s"][index])
    mujoco.mj_forward(model, data)


def frame_indices(times):
    times = np.asarray(times, dtype=float)
    assert np.all(np.diff(times) >= -1e-7), "Time reset in physical trace"
    grid = np.arange(0, float(times[-1]) + .5 / FPS, 1 / FPS)
    indices = np.clip(np.searchsorted(times, grid + TOL, side="right") - 1, 0, len(times) - 1)
    indices[-1] = len(times) - 1
    return grid, indices


def sampled_column(trace, index, names):
    for name in names:
        if name in trace:
            return float(trace[name][index])
    return None


def numerical_row(trace, index, frame, initial_z):
    pose=np.asarray(trace['object_pose'][index],dtype=float)
    quaternion=pose[3:7]/np.linalg.norm(pose[3:7])
    matrix=np.empty(9);mujoco.mju_quat2Mat(matrix,quaternion)
    axis_z=float(matrix.reshape(3,3)[2,2])
    bottom=float(pose[2]-(.002*abs(axis_z)+.0005*np.sqrt(max(0.,1-axis_z**2))))
    return {"frame":frame, "video_time_s":frame/FPS, "trace_index":int(index), "recorded_time_s":float(trace["time_s"][index]), "phase":str(trace["phase_names"][int(trace["phase_id"][index])]), "object_rise_mm":float((trace["object_pose"][index,2]-initial_z)*1000), "object_bottom_z_mm":bottom*1000, "hand_object_contacts":sampled_column(trace,index,["hand_object_contacts", "hand_object_contact_points", "ho_contacts"]), "object_fixture_contacts":sampled_column(trace,index,["object_fixture_contacts", "fixture_contacts", "rod_fixture_contacts", "rod_fixture_contact_points"]), "object_table_contacts":sampled_column(trace,index,["object_plane_contacts", "object_table_contacts", "rod_plane_contacts", "rod_plane_contact_points"]), "hand_fixture_contacts":sampled_column(trace,index,["hand_fixture_contacts", "hand_fixture_contact_points"]), "normal_hand_force_N":sampled_column(trace,index,["normal_hand_contact_force_sum_N", "hand_object_normal_force_N"]), "normal_fixture_force_N":sampled_column(trace,index,["normal_fixture_contact_force_sum_N", "fixture_normal_force_N", "rod_fixture_normal_force_N"]), "rod_tilt_deg":sampled_column(trace,index,["rod_tilt_deg", "object_tilt_deg", "tilt_deg"])}


def fit_camera(model, data, trace):
    camera = mujoco.MjvCamera()
    mujoco.mjv_defaultCamera(camera)
    ids = [i for i in range(model.ngeom) if model.body(int(model.geom_bodyid[i])).name.startswith(("hand-", "obj-"))]
    cloud = []
    for index in np.unique(np.linspace(0, len(trace["time_s"])-1, min(24,len(trace["time_s"]))).astype(int)):
        replay(model,data,trace,index)
        p = data.geom_xpos[ids]
        r = model.geom_rbound[ids,None]
        cloud.extend([p-r,p+r])
    cloud = np.concatenate(cloud)
    lo, hi = cloud.min(axis=0), cloud.max(axis=0)
    lo[2] = min(0,lo[2])
    camera.lookat[:] = (lo+hi)/2
    # Keep the full hand above the reserved 106px footer; only camera framing
    # changes, never the recorded model state.
    camera.lookat[2] -= .04
    camera.distance = max(.48,float(np.max(hi-lo))*2.0)
    camera.azimuth, camera.elevation = 135,-20
    return camera


def format_number(value, precision=0):
    return "?" if value is None else f"{value:.{precision}f}"


def support_text(row, fixture):
    points = row["object_fixture_contacts"]
    table = row["object_table_contacts"]
    if fixture == "plain":
        return "已离开桌面" if table == 0 and row['object_bottom_z_mm']>.05 else "桌面接触 / 未净空" if table is not None else "支持状态未记录"
    return "已离开托座" if points == 0 and table == 0 and row['object_bottom_z_mm']>.80 else "托座接触 / 未净空" if points is not None and table is not None else "支持状态未记录"


def render_one(metrics_path, encode):
    metrics_path = Path(metrics_path).resolve()
    record = json.loads(metrics_path.read_text())
    folder = metrics_path.parent
    fixture = fixture_of(record,metrics_path)
    variant = variant_of(record,metrics_path)
    trace_path = Path(record.get("trace",folder/"trace.npz"))
    model_path = Path(pick(record,["model_mjb", "model_binary", "mjb"],folder/"model.mjb"))
    model_xml = Path(record.get("model_xml",folder/"model.xml"))
    protocol=record.get('upright_protocol',{})
    assert sha(model_path)==protocol['model_mjb_sha256']
    assert sha(model_xml)==protocol['model_xml_sha256']
    assert protocol['initial_visible_pause_s']==.5 and protocol['approach_root_offset_m']==.1
    model = mujoco.MjModel.from_binary_path(str(model_path))
    assert abs(float(model.opt.timestep)-.001)<1e-12
    assert np.allclose(model.opt.gravity,[0,0,-9.81],atol=1e-12)
    object_bodies = [i for i in range(model.nbody) if model.body(i).name.startswith("obj-") and int(model.body_jntnum[i])>0]
    assert len(object_bodies)==1,object_bodies
    object_body = object_bodies[0]
    assert abs(float(model.body_subtreemass[object_body])-.2)<1e-6
    fixture_ids = [i for i in range(model.ngeom) if model.geom(i).name.startswith("fixture-")]
    assert bool(fixture_ids) == (fixture != "plain")
    if fixture_ids:
        assert np.all(model.geom_priority[fixture_ids]==1)
    with np.load(trace_path,allow_pickle=False) as archive:
        trace = {key:archive[key].copy() for key in archive.files}
    saved_hz=float(record['trace_fps'])
    assert trace["qpos"].shape[1]==model.nq and np.isfinite(trace["qpos"]).all()
    grid, indices = frame_indices(trace["time_s"])
    initial_z = float(record.get("initial_object_pose",trace["object_pose"][0])[2])
    rows = [numerical_row(trace,index,frame,initial_z) for frame,index in enumerate(indices)]
    pause_rows = [row for row in rows if row["recorded_time_s"] < .5-TOL]
    assert pause_rows and all(row["hand_object_contacts"]==0 for row in pause_rows), "Initial hover must have no hand/object contact"
    data = mujoco.MjData(model)
    model.vis.global_.offwidth=max(WIDTH,model.vis.global_.offwidth)
    model.vis.global_.offheight=max(HEIGHT,model.vis.global_.offheight)
    renderer = mujoco.Renderer(model,height=HEIGHT,width=WIDTH)
    camera = fit_camera(model,data,trace)
    near = mujoco.MjvCamera()
    mujoco.mjv_defaultCamera(near)
    near.distance,near.azimuth,near.elevation=.023,135,-12
    option = mujoco.MjvOption()
    option.flags[mujoco.mjtVisFlag.mjVIS_CONTACTPOINT]=False
    label = "无托座" if fixture=="plain" else "浅托座"
    identifier=identifier_of(record,metrics_path)
    controller_profile=profile_of(record)
    target_folder=OUT/identifier
    target_folder.mkdir(parents=True,exist_ok=True)
    target=target_folder/"full_sequence.mp4"
    good=bool(record.get("full_sequence_passed",False))
    status="全流程通过" if good else "未通过；保留真实失败过程"
    color=(69,216,135) if good else (255,148,132)

    def image_for(frame):
        row=rows[frame]
        replay(model,data,trace,int(indices[frame]))
        renderer.update_scene(data,camera=camera,scene_option=option)
        image=Image.fromarray(renderer.render().copy())
        near.lookat[:]=data.xpos[object_body]
        renderer.update_scene(data,camera=near,scene_option=option)
        inset=Image.fromarray(renderer.render().copy()).resize((224,168),Image.Resampling.LANCZOS)
        image.paste(inset,(404,81))
        draw=ImageDraw.Draw(image)
        draw.rectangle((0,0,WIDTH,72),fill=(17,24,34))
        draw.text((10,2),f"Ø1 × 4 mm · 200 g · {label} · {PHASES.get(row['phase'],row['phase'])}",font=font(19),fill=(239,244,248))
        profile_label='' if controller_profile=='baseline' else f' [{controller_profile}]'
        draw.text((10,27),f"{variant}{profile_label}  |  {status}",font=font(16),fill=color)
        draw.text((10,50),"先远离静置 → 垂直接近 → 闭合 → 受力 → 提升/持握 → 释放",font=font(15),fill=(175,192,208))
        draw.rectangle((404,81,628,107),fill=(17,24,34))
        draw.text((409,83),"同一记录状态 · 物体跟踪近景",font=font(14),fill=(237,241,245))
        draw.rectangle((0,374,WIDTH,HEIGHT),fill=(17,24,34))
        draw.text((10,377),f"记录 t={row['recorded_time_s']:.2f}s   升高 {row['object_rise_mm']:.3f}mm   杆倾角 {format_number(row['rod_tilt_deg'],1)}°",font=font(17),fill=(239,244,248))
        draw.text((10,402),f"接触点 手/托/桌={format_number(row['hand_object_contacts'])}/{format_number(row['object_fixture_contacts'])}/{format_number(row['object_table_contacts'])}   {support_text(row,fixture)}",font=font(17),fill=(224,231,238))
        draw.text((10,427),f"手部法向力 {format_number(row['normal_hand_force_N'],3)}N   托座法向力 {format_number(row['normal_fixture_force_N'],3)}N",font=font(17),fill=(224,231,238))
        draw.text((10,453),f"实际状态回放 · 原保存{saved_hz:g}Hz / 视频10fps · 无插值",font=font(16),fill=(168,187,204))
        return image

    preview_frames={0,len(indices)-1}
    for phase in ("approach","approach_close_squeeze","lift","postlift_hold"):
        matching=[i for i,row in enumerate(rows) if row["phase"]==phase]
        if matching:
            preview_frames.add(matching[0])
    previews=[]
    for frame in sorted(preview_frames):
        path=target_folder/f"preview_{frame:03d}.png"
        image_for(frame).save(path)
        previews.append({"path":str(path),"sha256":sha(path),"frame":frame,"recorded_time_s":rows[frame]["recorded_time_s"]})
    if encode:
        with VideoWriter(target,fps=FPS) as writer:
            for frame in range(len(indices)):
                writer.append_data(np.asarray(image_for(frame)))
    renderer.close()
    csv_path=target_folder/"per_frame.csv"
    with csv_path.open("w",newline="") as file:
        writer=csv.DictWriter(file,fieldnames=list(rows[0]));writer.writeheader();writer.writerows(rows)
    source={"trial_id":identifier,"fixture":fixture,"variant":variant,"input":record.get("input"),"metrics":str(metrics_path),"trace":str(trace_path),"model_mjb":str(model_path),"model_xml":str(model_xml),"source_sha256":{"metrics":sha(metrics_path),"trace":sha(trace_path),"model_mjb":sha(model_path),"model_xml":sha(model_xml)},"mass_kg":float(model.body_subtreemass[object_body]),"physics_timestep_s":float(model.opt.timestep),"fixture_priority":1 if fixture_ids else None,"initial_hover_no_hand_contact":True,"final_trace_index":int(indices[-1]),"final_recorded_time_s":float(trace['time_s'][indices[-1]]),"full_sequence_passed":good,"lift_hold_passed":bool(record.get('lift_hold_passed',record.get('passed',False))),"measured_object_lift_mm":record.get('measured_object_lift_mm'),"phase_names":trace['phase_names'].tolist(),"video_frames":len(indices),"previews":previews,"numerical_output":{"path":str(csv_path),"sha256":sha(csv_path)}}
    if source['input']:
        source['source_sha256']['input']=sha(source['input'])
    source['diagnostics']=str(Path(protocol['diagnostics']))
    source['source_sha256']['diagnostics']=sha(source['diagnostics'])
    source['original_trace_hz']=saved_hz
    source['camera']={'lookat':camera.lookat.tolist(),'distance':float(camera.distance),'azimuth':float(camera.azimuth),'elevation':float(camera.elevation)}
    source['upright_provenance']=record['upright_provenance']
    source['controller_profile']=controller_profile
    source['controller_intervention']=record.get('hand_controller_intervention')
    source['renderer_sha256']=sha(__file__)
    source['upright_protocol_checks']=protocol['checks']
    source['support_clearance_policy']='No fixture/plane contacts and lowest oriented cylinder point above0.80mm(shallow) or0.05mm(plain); bottom uses radius0.5mm/halfheight2mm and original observed pose.'
    if encode:
        source['video']={"path":str(target),"width":WIDTH,"height":HEIGHT,"frames":len(indices),"fps":FPS,"duration_s":len(indices)/FPS,"sha256":sha(target),"source_trial_id":identifier}
    write_json(target_folder/"render-index.json",source)
    return source


def probe(path, frames):
    subprocess.run(["ffmpeg","-nostdin","-v","error","-xerror","-threads","1","-i",str(path),"-f","null","-"],check=True,capture_output=True)
    info=json.loads(subprocess.check_output(["ffprobe","-v","error","-count_frames","-show_entries","stream=width,height,r_frame_rate,avg_frame_rate,nb_read_frames,nb_frames","-show_entries","format=duration","-of","json",str(path)],text=True))
    stream=info['streams'][0]
    assert stream['r_frame_rate']==stream['avg_frame_rate']=='10/1'
    assert int(stream['nb_read_frames'])==int(stream['nb_frames'])==frames
    assert abs(float(info['format']['duration'])-frames/FPS)<1e-6
    return info


def make_overview(sources,name):
    target=OUT/name
    frames=max(row['video']['frames'] for row in sources)
    args=['ffmpeg','-hide_banner','-loglevel','error','-y','-filter_complex_threads','1']
    for row in sources:
        args.extend(['-threads','1','-i',row['video']['path']])
    filters=[]
    for index in range(len(sources)):
        filters.append(f'[{index}:v]fps=10,tpad=stop_mode=clone:stop={frames+2},trim=end_frame={frames+2},settb=AVTB,setpts=N/(10*TB)[v{index}]')
    filters.append(f'[v0][v1]hstack=inputs=2,pad=1280:720:0:120:color=0x111822,trim=end_frame={frames},settb=AVTB,setpts=N/(10*TB)[out]')
    args.extend(['-filter_complex',';'.join(filters),'-map','[out]','-an','-r','10','-fps_mode','cfr','-frames:v',str(frames),'-c:v','libx264','-preset','fast','-crf','20','-pix_fmt','yuv420p','-threads','2','-movflags','+faststart',str(target)])
    subprocess.run(args,check=True)
    info=probe(target,frames)
    return {'path':str(target),'width':1280,'height':720,'frames':frames,'fps':FPS,'duration_s':frames/FPS,'sha256':sha(target),'source_trial_ids':[row['trial_id'] for row in sources],'rendering':'Side by side original aspect. If different sequence durations, completed trial final recorded state is held until longest video ends.','probe':info,'full_decode_passed':True}


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--trials-root',type=Path,default=ROOT/'trials')
    parser.add_argument('--metrics',type=Path,action='append')
    parser.add_argument('--render',action='store_true')
    parser.add_argument('--reuse',action='store_true',help='Reuse only source/hash-identical already-rendered files')
    parser.add_argument('--append-index',action='store_true',help='Retain existing sources when adding explicit new trial metrics')
    parser.add_argument('--worker',type=Path,help=argparse.SUPPRESS)
    args=parser.parse_args()
    if args.worker:
        return render_one(args.worker,args.render)
    paths=args.metrics or sorted(args.trials_root.rglob('metrics.json'))
    assert paths,'No completed trials found'
    def execute(path):
        record=json.loads(Path(path).read_text())
        cached=OUT/identifier_of(record,Path(path))/'render-index.json'
        if args.render and args.reuse and cached.exists():
            prior=json.loads(cached.read_text())
            if (prior.get('renderer_sha256')==sha(__file__) and prior['source_sha256']['metrics']==sha(path)
                    and prior['source_sha256']['trace']==sha(prior['trace'])
                    and prior['source_sha256']['model_mjb']==sha(prior['model_mjb'])
                    and prior.get('video') and Path(prior['video']['path']).exists()
                    and sha(prior['video']['path'])==prior['video']['sha256']):
                return prior
        cmd=[sys.executable,str(Path(__file__).resolve()),'--worker',str(path)]
        if args.render:
            cmd.append('--render')
        subprocess.run(cmd,check=True)
        return json.loads(cached.read_text())
    with ThreadPoolExecutor(max_workers=2) as pool:
        sources=list(pool.map(execute,paths))
    if args.append_index and (OUT/'index.json').exists():
        prior=json.loads((OUT/'index.json').read_text()).get('sources',[])
        merged={row['trial_id']:row for row in prior}
        merged.update({row['trial_id']:row for row in sources})
        sources=list(merged.values())
    videos=[]
    if args.render:
        for source in sources:
            source['video']['probe']=probe(source['video']['path'],source['video']['frames'])
            source['video']['full_decode_passed']=True
            videos.append(source['video'])
        centers=[next((row for row in sources if row['fixture']==condition and row['variant']=='vertical_center' and row.get('controller_profile','baseline')=='baseline' and row['trial_id']==f'{condition}__vertical_center'),None) for condition in ('plain','shallow')]
        if all(centers):
            videos.append(make_overview(centers,'plain_vs_shallow_center.mp4'))
    dependencies={str(ROOT/'fixtures/fixture_scene.py'):sha(ROOT/'fixtures/fixture_scene.py'),str(ROOT.parent/'evaluate_lifts.py'):sha(ROOT.parent/'evaluate_lifts.py')}
    driver=ROOT/'run_upright_trials.py'
    if driver.exists():
        dependencies[str(driver)]=sha(driver)
    index={'schema_version':1,'benchmark':'upright D1mm H4mm 200g','rendering':'Exact original compiled MJB models and recorded qpos/ctrl/mocap state replay with mj_forward only; no mj_step, no state interpolation. Context and tracking closeup are views of the same recorded state.','start_policy':'Native pregrasp +100mm worldZ, no-hand-contact visible pause0.5s, vertical approach2s, then original close/squeeze, loaded hold1s, lift100mm5s, hold5s, release.','renderer':str(Path(__file__).resolve()),'renderer_sha256':sha(__file__),'dependencies':dependencies,'timestamp_matching_tolerance_s':TOL,'sources':sources,'videos':videos,'previews':[p for source in sources for p in source['previews']],'numerical_outputs':[row['numerical_output'] for row in sources]}
    write_json(OUT/'index.json',index)
    print(json.dumps({'index':str(OUT/'index.json'),'trials':len(sources),'videos':len(videos)},indent=2),flush=True)


if __name__=='__main__':
    main()
