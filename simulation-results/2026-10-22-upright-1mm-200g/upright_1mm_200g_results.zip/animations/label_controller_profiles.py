#!/usr/bin/env python3
"""Add explicit Chinese labels to controller sensitivity clips only.

Original labelled videos are retained beside each final clip. Only the second
header line changes; physical frames, source states and clocks are untouched.
"""
from __future__ import annotations

import hashlib
import json
from pathlib import Path
import shutil
import subprocess

from PIL import Image, ImageDraw, ImageFont

ROOT=Path(__file__).resolve().parent
FONT='/usr/share/fonts/opentype/noto/NotoSansCJK-Regular.ttc'
LABELS={'root_5ms':'根5ms','root_5ms_kp10':'根5ms+增益×10'}


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def write(path,value):
    Path(path).write_text(json.dumps(value,ensure_ascii=False,indent=2)+'\n')


def probe(path,expected):
    subprocess.run(['ffmpeg','-nostdin','-v','error','-xerror','-threads','1','-i',str(path),'-f','null','-'],check=True,capture_output=True)
    data=json.loads(subprocess.check_output(['ffprobe','-v','error','-count_frames','-show_entries','stream=width,height,r_frame_rate,avg_frame_rate,nb_frames,nb_read_frames','-show_entries','format=duration','-of','json',str(path)],text=True))
    s=data['streams'][0]
    assert s['width']==640 and s['height']==480
    assert s['r_frame_rate']==s['avg_frame_rate']=='10/1'
    assert int(s['nb_read_frames'])==int(s['nb_frames'])==expected['frames']
    assert abs(float(data['format']['duration'])-expected['duration_s'])<1e-6
    return data


def main():
    path=ROOT/'index.json'
    index=json.loads(path.read_text())
    processor_sha=sha(__file__)
    updates={}
    changed=[]
    for source in index['sources']:
        profile=source.get('controller_profile','baseline')
        if profile not in LABELS:
            continue
        video=source['video']
        target=Path(video['path'])
        label=f"{source['variant']} · 控制：{LABELS[profile]} · 未通过"
        if source.get('controller_caption',{}).get('processor_sha256')==processor_sha and video['sha256']==sha(target):
            updates[str(target)]=video
            continue
        assert not source['full_sequence_passed'],'Update caption status for a passed controller trial'
        assert sha(target)==video['sha256']
        original=target.with_name('full_sequence_original_labels.mp4')
        assert not original.exists(),'Original intermediate already exists; inspect before rerun'
        shutil.copy2(target,original)
        temp=target.with_name('full_sequence_profile_caption.tmp.mp4')
        filter_text=f'drawbox=x=0:y=26:w=640:h=23:color=0x111822:t=fill,drawtext=fontfile={FONT}:text={label}:fontcolor=0xff9484:fontsize=16:x=10:y=27'
        subprocess.run(['ffmpeg','-nostdin','-v','error','-y','-threads','1','-i',str(original),'-vf',filter_text,'-an','-r','10','-fps_mode','cfr','-frames:v',str(video['frames']),'-c:v','libx264','-preset','fast','-crf','20','-pix_fmt','yuv420p','-threads','2','-movflags','+faststart',str(temp)],check=True)
        actual_probe=probe(temp,video)
        temp.replace(target)
        original_sha=sha(original)
        video.update({'sha256':sha(target),'probe':actual_probe,'full_decode_passed':True,'controller_profile_label':LABELS[profile],'original_caption_video':str(original),'original_caption_video_sha256':original_sha,'caption_processor_sha256':processor_sha})
        source['controller_caption']={'label':label,'processor':str(Path(__file__).resolve()),'processor_sha256':processor_sha,'original_video':str(original),'original_video_sha256':original_sha,'modified_region_pixels':[0,26,640,49],'physical_states_and_timestamps_changed':False}
        intervention=source['controller_intervention']
        adapter=intervention['adapter_source']
        assert sha(adapter)==intervention['adapter_sha256']
        index['dependencies'][adapter]=intervention['adapter_sha256']
        for preview in source['previews']:
            im=Image.open(preview['path']).convert('RGB')
            draw=ImageDraw.Draw(im)
            draw.rectangle((0,26,640,49),fill=(17,24,34))
            draw.text((10,27),label,font=ImageFont.truetype(FONT,16),fill=(255,148,132))
            im.save(preview['path'])
            preview['sha256']=sha(preview['path'])
        write(target.parent/'render-index.json',source)
        updates[str(target)]=video
        changed.append(source['trial_id'])
    index['videos']=[updates.get(row['path'],row) for row in index['videos']]
    index['previews']=[preview for source in index['sources'] for preview in source['previews']]
    index['postprocessors']=[{'path':str(Path(__file__).resolve()),'sha256':processor_sha,'purpose':'Chinese controller-profile caption only; raw original-label intermediate retained and hashed. No changed physics or state timing.'}]
    write(path,index)
    print(json.dumps({'index':str(path),'controller_clips_updated':changed},ensure_ascii=False,indent=2))


if __name__=='__main__':
    main()
