#!/usr/bin/env python3
"""Explicit hand-controller ablations using the unchanged continuous runner.

Only hand tracking is changed before the trial. The rod, gravity, fixture and
hand/object contact material retain the baseline definitions.
"""
from __future__ import annotations
import argparse
from concurrent.futures import ThreadPoolExecutor
import json
from pathlib import Path
import subprocess
import sys

import mujoco
import numpy as np

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT))
import run_upright_trials as runner


def run_profile(job):
    fixture = runner.load_fixture()
    original = fixture.make_env
    record = {}

    def make_env(*args, **kwargs):
        env = original(*args, **kwargs)
        model = env._model
        root_eq = []
        for i in range(model.neq):
            names = [model.body(int(model.eq_obj1id[i])).name,
                     model.body(int(model.eq_obj2id[i])).name]
            if model.eq_type[i] == mujoco.mjtEq.mjEQ_WELD and "mocap_body" in names and any(n.startswith("hand-") for n in names):
                root_eq.append(i)
        if len(root_eq) != 1:
            raise RuntimeError(f"Expected exactly one hand-mocap weld, found {root_eq}")
        i = root_eq[0]
        record.update(profile=job["profile"], equality_id=i,
                      original_eq_solref=model.eq_solref[i].copy().tolist(),
                      original_eq_solimp=model.eq_solimp[i].copy().tolist(),
                      original_position_gains=model.actuator_gainprm[:, 0].copy().tolist(),
                      original_actuator_force_ranges=model.actuator_forcerange.copy().tolist())
        model.eq_solref[i] = [.005, 1.]
        list(env._spec.equalities)[i].solref = [.005, 1.]
        factor = 10. if job["profile"] == "root_5ms_kp10" else 1.
        model.actuator_gainprm[:, 0] *= factor
        model.actuator_biasprm[:, 1] *= factor
        for actuator_id, actuator in enumerate(env._spec.actuators):
            actuator.gainprm[:] = model.actuator_gainprm[actuator_id]
            actuator.biasprm[:] = model.actuator_biasprm[actuator_id]
        record.update(applied_eq_solref=model.eq_solref[i].copy().tolist(),
                      applied_eq_solimp=model.eq_solimp[i].copy().tolist(),
                      applied_position_gains=model.actuator_gainprm[:, 0].copy().tolist(),
                      applied_actuator_force_ranges=model.actuator_forcerange.copy().tolist(),
                      position_gain_multiplier=factor,
                      object_or_fixture_parameters_changed=False,
                      rod_force_or_pose_control_added=False)
        if not np.array_equal(model.actuator_forcerange, np.asarray(record["original_actuator_force_ranges"])):
            raise RuntimeError("Actuator torque limits unexpectedly changed")
        return env

    fixture.make_env = make_env
    try:
        result = runner.run_trial(job)
    finally:
        fixture.make_env = original
    folder = Path(job["output"])
    metrics = json.loads((folder / "metrics.json").read_text())
    record.update(adapter_source=str(Path(__file__).resolve()), adapter_sha256=runner.sha(__file__),
                  meaning="Independent controller sensitivity; does not replace baseline or imply successful grasp")
    metrics["hand_controller_intervention"] = record
    runner.write_json(folder / "metrics.json", metrics)
    runner.write_json(folder / "controller_intervention.json", record)
    result["profile"] = job["profile"]
    runner.write_json(folder / "result.json", result)
    return result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--manifest", type=Path, default=ROOT / "grasp_search/candidates.json")
    parser.add_argument("--candidates", nargs="+", default=["vertical_center"])
    parser.add_argument("--profiles", nargs="+", choices=["root_5ms", "root_5ms_kp10"], default=["root_5ms"])
    parser.add_argument("--conditions", nargs="+", choices=["plain", "shallow"], default=["plain", "shallow"])
    parser.add_argument("--outdir", type=Path, default=ROOT / "controller_ablation")
    parser.add_argument("--workers", type=int, default=2)
    parser.add_argument("--worker-job", type=Path)
    args = parser.parse_args()
    if args.worker_job:
        run_profile(json.loads(args.worker_job.read_text()))
        return
    variants = {v["id"]: v for v in json.loads(args.manifest.read_text())["variants"]}
    jobs = []
    for profile in args.profiles:
        for name in args.candidates:
            for condition in args.conditions:
                job = {"variant": variants[name], "fixture": condition, "profile": profile,
                       "output": str((args.outdir / profile / condition / name).resolve()), "resume": False}
                path = args.outdir / "jobs" / f"{profile}__{condition}__{name}.json"
                path.parent.mkdir(parents=True, exist_ok=True)
                runner.write_json(path, job)
                jobs.append(path)

    def execute(path):
        result = subprocess.run([sys.executable, str(Path(__file__).resolve()), "--worker-job", str(path)], capture_output=True, text=True)
        if result.stdout:
            print(result.stdout, end="", flush=True)
        if result.stderr:
            print(result.stderr, end="", file=sys.stderr, flush=True)
        job = json.loads(path.read_text())
        folder = Path(job["output"])
        data = json.loads((folder / "result.json").read_text()) if result.returncode == 0 else {"job": job, "error": result.stderr}
        return {"exit_code": result.returncode, **data}

    with ThreadPoolExecutor(max_workers=args.workers) as pool:
        results = list(pool.map(execute, jobs))
    runner.write_json(args.outdir / "summary.json", {"adapter_sha256": runner.sha(__file__), "trials": results,
                      "tested": len(results), "exceptions": sum(r["exit_code"] != 0 for r in results)})
    if any(r["exit_code"] for r in results):
        raise SystemExit(1)


if __name__ == "__main__":
    main()
