#!/usr/bin/env python3
"""Independent final media/source/report check. Never edits trial or media files."""
from pathlib import Path
import csv
import hashlib
import json
import subprocess

import numpy as np
from PIL import Image

ROOT = Path('/workspace/shadow-lift-sweep-200g/upright-1mm-20261022')
QA = ROOT / 'qa'


def read(p):
    return json.loads(Path(p).read_text())


def sha(p):
    h = hashlib.sha256()
    with Path(p).open('rb') as f:
        for c in iter(lambda: f.read(1024 * 1024), b''): h.update(c)
    return h.hexdigest()


def main():
    index_path = ROOT / 'animations/index.json'
    index = read(index_path)
    audit = read(QA / 'independent-trial-audit.json')
    trial_paths = {row['metrics'] for row in audit['trials']}
    assert audit['trial_count'] == 18 and audit['scientific_full_sequence_passes'] == 0
    assert len(index['sources']) == 18 and len(index['videos']) == 19
    assert {s['metrics'] for s in index['sources']} == trial_paths
    assert sha(index['renderer']) == index['renderer_sha256']
    for path, digest in index['dependencies'].items(): assert sha(path) == digest
    for item in index.get('postprocessors', []): assert sha(item['path']) == item['sha256']
    source_checks = []
    all_hold_support = []
    for s in index['sources']:
        r = read(s['metrics'])
        for key, digest in s['source_sha256'].items(): assert sha(s[key]) == digest
        assert not s['full_sequence_passed'] and s['renderer_sha256'] == index['renderer_sha256']
        assert sha(s['numerical_output']['path']) == s['numerical_output']['sha256']
        for preview in s['previews']: assert sha(preview['path']) == preview['sha256']
        if s.get('controller_caption'):
            caption = s['controller_caption']
            assert sha(caption['processor']) == caption['processor_sha256']
            assert sha(caption['original_video']) == caption['original_video_sha256']
            assert caption['physical_states_and_timestamps_changed'] is False
        with Path(s['numerical_output']['path']).open(newline='') as f: frames = list(csv.DictReader(f))
        with np.load(s['trace'], allow_pickle=False) as trace, np.load(s['diagnostics'], allow_pickle=False) as d:
            t = trace['time_s']
            grid = np.arange(0, float(t[-1]) + .05, .1)
            indices = np.clip(np.searchsorted(t, grid + 1e-5, side='right') - 1, 0, len(t) - 1)
            indices[-1] = len(t) - 1
            assert len(frames) == len(indices) == s['video_frames']
            displayed = set()
            for f, frame in enumerate(frames):
                i = int(frame['trace_index'])
                assert i == int(indices[f])
                assert abs(float(frame['recorded_time_s']) - float(t[i])) < 1e-10
                assert frame['phase'] == str(trace['phase_names'][trace['phase_id'][i]])
                displayed.add(frame['phase'])
                assert abs(float(frame['object_rise_mm']) - (trace['object_pose'][i, 2] - r['initial_object_pose'][2]) * 1000) < 1e-9
                for field, key in [('hand_object_contacts', 'hand_object_contacts'), ('object_fixture_contacts', 'object_fixture_contacts'), ('object_table_contacts', 'object_plane_contacts'), ('hand_fixture_contacts', 'hand_fixture_contacts'), ('normal_hand_force_N', 'normal_hand_contact_force_sum_N'), ('normal_fixture_force_N', 'normal_fixture_contact_force_sum_N'), ('rod_tilt_deg', 'rod_tilt_deg')]:
                    assert abs(float(frame[field]) - float(trace[key][i])) < 1e-10
            assert displayed == set(trace['phase_names']) and len(displayed) == 9
            assert int(frames[0]['trace_index']) == 0 and int(frames[-1]['trace_index']) == len(t) - 1 == s['final_trace_index']
            assert all(float(f['hand_object_contacts']) == 0 for f in frames if float(f['recorded_time_s']) <= 2.5 + 1e-5)
            hold = d['phase_id'] == list(d['phase_names']).index('postlift_hold')
            supported_every_step = bool(np.all((d['object_fixture_contacts'][hold] + d['object_plane_contacts'][hold]) > 0))
            all_hold_support.append(supported_every_step)
            assert not np.any(d['hand_object_contacts'][hold])
            source_checks.append({'trial_id': s['trial_id'], 'metrics_sha256': sha(s['metrics']), 'all_csv_frame_rows_match_original_trace': True,
                                  'all9_phases_displayed': True, 'initial_and_terminal_real_states_included': True,
                                  'postlift_supported_every_physics_step': supported_every_step, 'video_frames': len(frames)})
    assert all(all_hold_support)
    media = []
    for v in index['videos']:
        assert sha(v['path']) == v['sha256']
        probe = json.loads(subprocess.check_output(['ffprobe','-v','error','-count_frames','-select_streams','v:0',
            '-show_entries','stream=codec_name,pix_fmt,width,height,r_frame_rate,avg_frame_rate,nb_frames,nb_read_frames:format=duration','-of','json',v['path']]))
        p = probe['streams'][0]
        assert p['codec_name'] == 'h264' and p['pix_fmt'] == 'yuv420p'
        assert (p['width'], p['height']) == (v['width'], v['height'])
        assert p['r_frame_rate'] == p['avg_frame_rate'] == '10/1'
        assert int(p['nb_frames']) == int(p['nb_read_frames']) == v['frames']
        assert abs(float(probe['format']['duration']) - v['frames'] / 10) < 1e-6
        subprocess.run(['ffmpeg','-nostdin','-v','error','-xerror','-threads','1','-i',v['path'],'-f','null','-'],check=True,capture_output=True)
        media.append({'path':v['path'],'sha256':v['sha256'],'probe':probe,'full_decode':'passed'})
        print('PASS full decode:', Path(v['path']).parent.name, Path(v['path']).name, flush=True)
    selected = [v for v in index['videos'] if len(v.get('source_trial_ids', [])) == 2 or 'root_5ms_kp10__shallow' in v.get('source_trial_id', '')]
    if len(selected) == 1:
        selected.append(next(s['video'] for s in index['sources'] if s.get('controller_profile') == 'root_5ms_kp10' and s['fixture'] == 'shallow'))
    extracted = []
    for j, v in enumerate(selected):
        positions = [v['frames'] // 2, v['frames'] - 1]
        expression = '+'.join(f'eq(n\\,{i})' for i in positions)
        raw = subprocess.check_output(['ffmpeg','-nostdin','-v','error','-threads','1','-i',v['path'],'-vf','select='+expression,'-fps_mode','vfr','-pix_fmt','rgb24','-f','rawvideo','-'])
        images = np.frombuffer(raw,dtype=np.uint8).reshape(2,v['height'],v['width'],3)
        for label, im in zip(['mid','last'],images):
            target = QA / f'decoded_review{j}_{label}.png'; Image.fromarray(im).save(target); extracted.append(str(target))
    summary = read(ROOT / 'experiment-summary.json')
    assert summary['baseline_trials'] == 14 and summary['controller_trials'] == 4 and summary['full_sequence_passed'] == 0
    assert len(summary['rows']) == 18
    for row in summary['rows']:
        p = ROOT / row['metrics']; r = read(p)
        assert sha(p) == row['metrics_sha256']
        assert sha(r['trace']) == row['trace_sha256'] and sha(r['upright_protocol']['diagnostics']) == row['diagnostics_sha256']
    static = read(ROOT / 'grasp_search/refined/final-summary.json')
    assert static['static_solutions'] == 14 and static['total_fk_evaluations'] == 5892 and static['new_full_physics_trials'] == 0
    original = read(ROOT.parent / 'height-diagnosis-20261022/tilt-overview/qa/independent-original-files-baseline.json')
    mismatch = [p for p, saved in original['files'].items() if not Path(p).is_file() or Path(p).stat().st_size != saved['bytes'] or sha(p) != saved['sha256']]
    assert not mismatch, mismatch
    old_tilt = ROOT.parent / 'height-diagnosis-20261022/tilt-overview'
    assert sha(old_tilt/'qa/independent-final-media-audit.json') == '38b4a5140632b5f69551d8e1fda76696cee0ffd4bc74072c71748d9f23d1b04e'
    old_index = read(old_tilt/'index.json')
    for v in old_index['videos']: assert sha(v['path']) == v['sha256']
    assert sha(old_index['renderer']) == old_index['renderer_sha256']
    repo_status = subprocess.check_output(['git','-C','/workspace/Dexonomy','status','--porcelain=v1','--untracked-files=no'],text=True)
    assert not repo_status
    report = {'all_automated_checks_passed':True,'physics_trials':18,'final_media_files':19,'sources':source_checks,'media':media,
              'all_original4994_files_unchanged':True,'published_previous_tilt_audit_and_media_unchanged':True,'repository_tracked_files_clean':True,
              'report_artifacts':{name:sha(ROOT/name) for name in ['UPRIGHT_1MM_REPORT.md','PIPELINE.md','experiment-summary.json','experiment-results.csv','summarize_upright.py']},
              'static_search_included_only_as_static_evidence':True,'report_support_every_hold_step_claim_verified':True,
              'extracted_decoded_review_frames':extracted,'source_index_sha256':sha(index_path),'assistant_visual_review':'pending_final_encoded_frame_review'}
    (QA/'independent-media-report-audit.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
    print(json.dumps({'automated_checks':'passed','physics_trials':18,'final_decoded_videos':19,'original_files_preserved':len(original['files']),'review_frames':extracted},indent=2))


if __name__ == '__main__': main()
