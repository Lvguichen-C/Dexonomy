#!/usr/bin/env python3
"""Independent read-only audit of the 14 baseline + 4 controller trials."""
from pathlib import Path
import hashlib
import json

import mujoco
import numpy as np

ROOT = Path('/workspace/shadow-lift-sweep-200g/upright-1mm-20261022')
QA = ROOT / 'qa'
PHASES = ['start_pause', 'approach', 'approach_close_squeeze', 'loaded_hold', 'lift', 'postlift_hold', 'release_open', 'release_retreat', 'release_settle']


def read(path):
    return json.loads(Path(path).read_text())


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def groups(model):
    result = {name: [] for name in ['hand', 'object', 'fixture', 'plane']}
    for i in range(model.ngeom):
        if not (model.geom_contype[i] or model.geom_conaffinity[i]):
            continue
        b, name = model.body(int(model.geom_bodyid[i])).name, model.geom(i).name
        key = 'hand' if b.startswith('hand-') else 'object' if b.startswith('obj-') else 'fixture' if name.startswith('fixture-') else 'plane' if b == 'world' else None
        if key:
            result[key].append(i)
    return result


def gap(model, data, a, b):
    distances = [float(mujoco.mj_geomDistance(model, data, i, j, 1.0, np.zeros(6))) for i in a for j in b
                 if (model.geom_contype[i] & model.geom_conaffinity[j]) or (model.geom_contype[j] & model.geom_conaffinity[i])]
    return min(distances) if distances else None


def pair_contacts(model, data, left, right):
    return sum(bool(({int(c.geom1), int(c.geom2)} & set(left)) and ({int(c.geom1), int(c.geom2)} & set(right))) for c in data.contact)


def main():
    paths = sorted((ROOT / 'trials').rglob('metrics.json')) + sorted((ROOT / 'controller_ablation').rglob('metrics.json'))
    assert len(paths) == 18, len(paths)
    assert read(ROOT / 'trials/summary.json')['tested'] == 14
    assert read(ROOT / 'trials/summary.json')['exceptions'] == 0
    baseline = {}
    for fixture in ['plain', 'shallow']:
        record = read(ROOT / f'trials/{fixture}/vertical_center/metrics.json')
        baseline[fixture] = mujoco.MjModel.from_binary_path(record['upright_protocol']['model_mjb'])
    rows = []
    for path in paths:
        r = read(path)
        p = r['upright_protocol']
        assert (path.parent / 'result.json').is_file()
        assert sha(r['input']) == r['input_sha256'] == r['upright_provenance']['input_sha256']
        assert sha(ROOT / 'run_upright_trials.py') == r['upright_provenance']['runner_sha256']
        assert sha(ROOT / 'fixtures/fixture_scene.py') == r['upright_provenance']['fixture_source_sha256']
        assert sha(ROOT.parent / 'evaluate_lifts.py') == r['upright_provenance']['frozen_evaluator_sha256']
        assert sha(p['model_mjb']) == p['model_mjb_sha256'] and sha(p['model_xml']) == p['model_xml_sha256']
        model = mujoco.MjModel.from_binary_path(p['model_mjb'])
        assert model.opt.timestep == .001 == r['dt_s']
        assert np.array_equal(model.opt.gravity, [0, 0, -9.81])
        assert not (model.opt.disableflags & int(mujoco.mjtDisableBit.mjDSBL_GRAVITY))
        assert r['config']['mass_kg'] == .2 and r['gravity_enabled']
        objj = [j for j in range(model.njnt) if model.body(int(model.jnt_bodyid[j])).name.startswith('obj-')]
        assert len(objj) == 1 and model.jnt_type[objj[0]] == mujoco.mjtJoint.mjJNT_FREE
        objbody, objadr = int(model.jnt_bodyid[objj[0]]), int(model.jnt_qposadr[objj[0]])
        assert model.body_mocapid[objbody] < 0 and np.isclose(model.body_mass[objbody], .2, rtol=1e-6)
        assert np.all(model.body_inertia[objbody] > 0)
        assert model.neq == 1 and objbody not in list(model.eq_obj1id) + list(model.eq_obj2id)
        geo = groups(model)
        assert len(geo['object']) == 1
        object_geom = geo['object'][0]
        mid = int(model.geom_dataid[object_geom])
        start, count = int(model.mesh_vertadr[mid]), int(model.mesh_vertnum[mid])
        vertices = model.mesh_vert[start:start + count]
        dimensions = vertices.max(axis=0) - vertices.min(axis=0)
        assert np.allclose(dimensions, [.001, .001, .004], rtol=0, atol=1e-9)
        assert all(int(model.geom_bodyid[g]) == 0 for g in geo['fixture'])
        if r['fixture'] == 'shallow':
            assert len(geo['fixture']) == 33
            assert all(model.geom_priority[g] == 1 and model.geom_condim[g] == 3 and model.geom_margin[g] == 0 for g in geo['fixture'])
        else:
            assert not geo['fixture']
        with np.load(r['trace'], allow_pickle=False) as z, np.load(p['diagnostics'], allow_pickle=False) as d:
            assert z['qpos'].dtype == np.float64
            assert list(z['phase_names']) == PHASES == list(d['phase_names'])
            times = d['time_s']
            assert len(times) == r['physics_steps']
            assert abs(times[0] - .001) < 1e-12 and abs(times[-1] - r['simulation_duration_s']) < 1e-9
            assert np.allclose(np.diff(times), .001, rtol=0, atol=1e-10)
            assert np.all(np.diff(z['time_s']) >= 0) and abs(z['time_s'][0]) < 1e-12
            assert abs(z['time_s'][-1] - r['simulation_duration_s']) < 1e-9
            assert np.isfinite(z['qpos']).all() and np.isfinite(z['ctrl']).all()
            assert np.array_equal(z['qpos'][0], model.key_qpos[0])
            assert np.allclose(z['qpos'][0, objadr:objadr + 7], [0, 0, .002, 1, 0, 0, 0], rtol=0, atol=1e-9)
            data = mujoco.MjData(model)
            data.qpos[:] = z['qpos'][0]
            data.ctrl[:] = z['ctrl'][0]
            data.mocap_pos[:] = z['mocap_pos'][0]
            data.mocap_quat[:] = z['mocap_quat'][0]
            mujoco.mj_forward(model, data)
            gaps = {name: gap(model, data, geo['hand'], geo[name]) for name in ['object', 'fixture', 'plane']}
            assert gaps['object'] > .01 and gaps['plane'] > 0
            assert gaps['fixture'] is None or gaps['fixture'] > 0
            assert abs(gaps['object'] - p['initial_minimum_hand_object_geom_distance']['distance_m']) < 1e-9
            initial_contacts = {name: pair_contacts(model, data, geo['hand'], geo[name]) for name in ['object', 'fixture', 'plane']}
            assert not any(initial_contacts.values())
            assert r['finite_states'] and not r['unexpected_time_resets'] and not any(r['maximum_warning_counts'])
            assert len(p['interventions']['reset']) == 1 and p['interventions']['object_pose_writes_within_trial'] == 0
            assert p['interventions']['gravity_changes_within_trial'] == 0
            assert not np.any(d['object_external_force_norm_N']) and not np.any(d['object_external_torque_norm_Nm'])
            command = p['native_trajectory_execution'][0]
            expected_closure_steps = int(command['segments'] * 5 * 20 * p['closure_duration_scale'])
            assert command['substep'] == 20 * p['closure_duration_scale'] and command['step'] == 5
            phase_steps = [500, 2000, expected_closure_steps, 1000, 5000, 5000, 1500, 1000, 3000]
            phases = []
            for i, (name, expected_count) in enumerate(zip(PHASES, phase_steps)):
                selected = d['phase_id'] == i
                assert int(np.sum(selected)) == expected_count
                assert p['phase_statistics'][name]['samples'] == expected_count
                pen = float(np.max(d['hand_object_max_penetration_m'][selected]))
                assert abs(pen - p['phase_statistics'][name]['maximum_hand_object_penetration_m']) < 1e-12
                phases.append({'phase': name, 'physics_steps': expected_count,
                               'max_hand_object_overlap_mm': pen * 1000, 'overlap_to_rod_radius': pen / .0005,
                               'max_object_fixture_contacts': int(np.max(d['object_fixture_contacts'][selected])),
                               'max_object_plane_contacts': int(np.max(d['object_plane_contacts'][selected])),
                               'max_hand_fixture_contacts': int(np.max(d['hand_fixture_contacts'][selected]))})
            assert sum(phase_steps) == r['physics_steps']
            pause = d['phase_id'] == 0
            assert not np.any(d['hand_object_contacts'][pause])
            hold = d['phase_id'] == 5
            support_free = not (np.any(d['object_fixture_contacts'][hold]) or np.any(d['object_plane_contacts'][hold]))
            assert support_free == p['checks']['no_fixture_or_plane_support_throughout_five_second_hold']
            contact_indices = np.flatnonzero(d['hand_object_contacts'] > 0)
            if len(contact_indices):
                first = int(contact_indices[0])
                assert abs(times[first] - p['first_hand_object_contact']['time_s']) < 1e-12
                precontact_tilt = float(np.max(d['rod_tilt_deg'][:first])) if first else 0.
            else:
                precontact_tilt = float(np.max(d['rod_tilt_deg']))
            max_pen = float(np.max(d['hand_object_max_penetration_m']))
        profile = r.get('hand_controller_intervention', {})
        base = baseline[r['fixture']]
        unchanged_fields = ['body_mass', 'body_inertia', 'geom_size', 'geom_pos', 'geom_quat', 'geom_friction', 'geom_condim', 'geom_priority', 'geom_margin', 'geom_solref', 'geom_solimp', 'actuator_forcerange', 'actuator_forcelimited', 'actuator_ctrlrange', 'actuator_ctrllimited', 'eq_data', 'eq_solimp', 'jnt_range']
        for field in unchanged_fields:
            assert np.array_equal(getattr(model, field), getattr(base, field)), (path, field)
        eq = base.eq_solref.copy()
        gain, bias = base.actuator_gainprm.copy(), base.actuator_biasprm.copy()
        if profile:
            assert sha(profile['adapter_source']) == profile['adapter_sha256']
            eq[profile['equality_id']] = [.005, 1]
            factor = 10 if profile['profile'] == 'root_5ms_kp10' else 1
            gain[:, 0] *= factor
            bias[:, 1] *= factor
        assert np.array_equal(model.eq_solref, eq)
        assert np.array_equal(model.actuator_gainprm, gain) and np.array_equal(model.actuator_biasprm, bias)
        flags = []
        if not support_free: flags.append('fixture_or_plane_support_remains_during_postlift_hold')
        if not r['hold_criteria']['actual_object_lift_within_tolerance_throughout_hold']: flags.append('actual_lift_height_outside_95_to105mm')
        if not r['hold_criteria']['at_least_two_final_hand_object_contacts']: flags.append('insufficient_final_hand_object_contacts')
        if not r['release_passed']: flags.append('release_criteria_failed')
        if max_pen >= .0005: flags.append('hand_object_overlap_reaches_or_exceeds_rod_radius')
        if not r['full_sequence_passed'] and not flags: flags.append('other_recorded_hold_criterion_failed')
        rows.append({'metrics': str(path), 'metrics_sha256': sha(path), 'trace': r['trace'], 'trace_sha256': sha(r['trace']),
                     'diagnostics': p['diagnostics'], 'diagnostics_sha256': sha(p['diagnostics']),
                     'model_mjb': p['model_mjb'], 'model_mjb_sha256': sha(p['model_mjb']),
                     'fixture': r['fixture'], 'variant': r['variant'], 'profile': profile.get('profile', 'baseline'),
                     'execution_and_archive_integrity_checks': 'passed', 'initial_minimum_hand_clearance_mm': {k: None if v is None else v * 1000 for k, v in gaps.items()},
                     'initial_hand_contacts': initial_contacts, 'phase_statistics_independently_verified': phases,
                     'physics_steps': r['physics_steps'], 'duration_s': r['simulation_duration_s'],
                     'pre_first_hand_contact_maximum_tilt_deg': precontact_tilt,
                     'first_hand_contact': p['first_hand_object_contact'], 'postlift_support_free_all5000_steps': support_free,
                     'maximum_hand_object_overlap_mm': max_pen * 1000, 'maximum_overlap_fraction_of_radius': max_pen / .0005,
                     'actual_object_lift_mm': r['measured_object_lift_mm'], 'scientific_full_sequence_passed': r['full_sequence_passed'],
                     'applicable_failure_flags': flags, 'controller_compiled_values_and_unchanged_force_limits_verified': True})
        print(f"PASS archive/protocol audit: {r['fixture']} {r['variant']} {profile.get('profile', 'baseline')}", flush=True)
    report = {'schema_version': 1, 'scope': 'Independent18trial actual-MJB, initial-geometry and every1msdiagnostic audit; no physics reintegration',
              'trial_count': len(rows), 'scientific_full_sequence_passes': sum(r['scientific_full_sequence_passed'] for r in rows),
              'all_execution_and_archive_checks_passed': True, 'experiments_failing_scientific_criteria_are_retained': True,
              'microscale_contact_limitation': 'Hand-object torsional contact coefficient remains0.02m=40times0.5mmradius; no claim of real-material micrograsp validity. Overlap ratios are reported per phase and all actual failures retained.',
              'trials': rows}
    (QA / 'independent-trial-audit.json').write_text(json.dumps(report, ensure_ascii=False, indent=2) + '\n')
    print(json.dumps({'trial_count': len(rows), 'execution_and_archive_checks': 'passed', 'scientific_successes': report['scientific_full_sequence_passes']}, indent=2))


if __name__ == '__main__':
    main()
