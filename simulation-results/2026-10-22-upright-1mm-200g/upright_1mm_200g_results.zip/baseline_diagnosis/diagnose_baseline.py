#!/usr/bin/env python3
"""Read-only timing/geometry diagnosis of the original unsupported 1 mm case.

Uses saved states and kinematics only. Does not execute any mj_step or modify
the original metrics, trace, model, controls, or geometry.
"""
from __future__ import annotations

from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import sys

import mujoco
import numpy as np
import trimesh

sys.path.insert(0, "/workspace/Dexonomy")
from dexonomy.util.file_util import load_scene_cfg


ROOT = Path("/workspace/shadow-lift-sweep-200g")
OUT = ROOT / "upright-1mm-20261022/baseline_diagnosis"


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def quaternion_matrix(quaternion):
    q = np.asarray(quaternion, dtype=np.float64)
    q /= np.linalg.norm(q)
    matrix = np.empty(9)
    mujoco.mju_quat2Mat(matrix, q)
    return matrix.reshape(3, 3)


def axis_tilt(quaternion):
    # A cylinder's +axis and -axis are physically the same unoriented line.
    axis = quaternion_matrix(quaternion) @ np.array([0., 0., 1.])
    return float(np.degrees(np.arccos(np.clip(abs(axis[2]), 0., 1.)))), axis


def first_event(mask, times, tilts):
    indices = np.flatnonzero(mask)
    if not len(indices):
        return None
    i = int(indices[0])
    previous = i - 1
    while previous >= 0 and times[previous] >= times[i] - 1e-5:
        previous -= 1
    return {"first_sample_index": i, "first_observed_time_s": float(times[i]),
            "previous_sample_time_s": float(times[previous]) if previous >= 0 else None,
            "previous_sample_tilt_deg": float(tilts[previous]) if previous >= 0 else None,
            "first_sample_tilt_deg": float(tilts[i]),
            "timing_semantics": "Threshold/contact first observed in saved samples; exact onset may be anywhere since previous distinct sample"}


def main():
    index_path = ROOT / "animations/index.json"
    selection = json.loads(index_path.read_text())
    selected = next(row for row in selection["representatives"] if row["diameter_mm"] == 1)
    metrics_path = Path(selected["metrics"])
    metrics = json.loads(metrics_path.read_text())
    trace_path, input_path = Path(metrics["trace"]), Path(metrics["input"])
    model_path = metrics_path.parents[2] / "model.xml"
    grasp = np.load(input_path, allow_pickle=True).item()
    scene_path = Path(grasp["scene_path"])
    scene = load_scene_cfg(scene_path)
    obj = scene["scene"][scene["task"]["obj_name"]]
    mesh_path = Path(obj["file_path"])
    sources = {str(path): sha(path) for path in (index_path, metrics_path, trace_path, input_path, model_path, scene_path, mesh_path)}
    mesh = trimesh.load(mesh_path, force="mesh")
    vertices = np.asarray(mesh.vertices, dtype=np.float64) * np.asarray(obj["scale"])
    extents = np.ptp(vertices, axis=0)
    values, vectors = np.linalg.eigh(np.cov(vertices.T))
    local_axis = vectors[:, int(np.argmax(values))]
    assert abs(local_axis @ [0, 0, 1]) > 1 - 1e-8
    assert np.allclose(extents, [.001, .001, .004], rtol=0, atol=1e-9)
    model = mujoco.MjModel.from_xml_path(str(model_path))
    data = mujoco.MjData(model)
    with np.load(trace_path, allow_pickle=False) as a:
        trace = {key: np.asarray(a[key]).copy() for key in a.files}
    times = np.asarray(trace["time_s"], dtype=float)
    tilts = np.asarray([axis_tilt(q)[0] for q in trace["object_pose"][:, 3:7]])
    hand_contacts = trace["hand_object_contacts"].astype(int)
    normal_forces = np.asarray(trace["normal_hand_contact_force_sum_N"], dtype=float)
    phase_names = [str(name) for name in trace["phase_names"]]
    phase_times = {r["phase"]: r["time_s"] for r in metrics["phase_boundaries"]}
    object_geoms = [g for g in range(model.ngeom) if model.body(int(model.geom_bodyid[g])).name.startswith("obj-") and model.geom_contype[g] != 0]
    hand_geoms = [g for g in range(model.ngeom) if model.body(int(model.geom_bodyid[g])).name.startswith("hand-") and model.geom_contype[g] != 0]
    assert len(object_geoms) == 1 and len(hand_geoms)
    object_geom = object_geoms[0]
    mesh_id = int(model.geom_dataid[object_geom])
    ma, mn = int(model.mesh_vertadr[mesh_id]), int(model.mesh_vertnum[mesh_id])
    eigenvalues, eigenvectors = np.linalg.eigh(np.cov(np.asarray(model.mesh_vert[ma:ma + mn], dtype=float).T))
    compiled_mesh_local_axis = eigenvectors[:, int(np.argmax(eigenvalues))]

    def reconstructed_gap(i):
        data.qpos[:] = trace["qpos"][i]
        data.mocap_pos[:] = trace["mocap_pos"][i]
        data.mocap_quat[:] = trace["mocap_quat"][i]
        mujoco.mj_forward(model, data)
        candidates = []
        for hand in hand_geoms:
            if not ((model.geom_contype[hand] & model.geom_conaffinity[object_geom]) or (model.geom_contype[object_geom] & model.geom_conaffinity[hand])):
                continue
            points = np.zeros(6)
            distance = float(mujoco.mj_geomDistance(model, data, hand, object_geom, 1.0, points))
            candidates.append((distance, hand))
        distance, closest = min(candidates)
        compiled_axis_world = data.geom_xmat[object_geom].reshape(3, 3) @ compiled_mesh_local_axis
        return {"minimum_hand_object_surface_distance_mm": distance * 1000,
                "nearest_hand_geom": model.geom(closest).name,
                "nearest_hand_body": model.body(int(model.geom_bodyid[closest])).name,
                "compiled_object_geometry_axis_world": compiled_axis_world.tolist(),
                "distance_source": "Kinematic reconstruction of saved qpos, no mj_step; qpos is post-integration state and can lead saved object_pose by one 4ms step"}

    initial_geom = reconstructed_gap(0)
    assert abs(np.asarray(initial_geom["compiled_object_geometry_axis_world"]) @ [0, 0, 1]) > 1 - 1e-6
    first_hand = first_event(hand_contacts > 0, times, tilts)
    events = {f"tilt_above_{threshold}_deg": first_event(tilts > threshold, times, tilts) for threshold in (1, 5, 15, 45, 75)}
    events["first_hand_object_contact_sample"] = first_hand
    events["first_positive_normal_force_sample"] = first_event(normal_forces > 1e-6, times, tilts)
    wanted = [0., .1, .2, .3, .4, .5, .6, 2., 2.7, 3.7, 8.7, 13.7]
    rows = []
    for time in wanted:
        candidates = np.flatnonzero(np.abs(times - time) < 1e-4)
        if not len(candidates):
            continue
        i = int(candidates[-1])
        tilt, axis = axis_tilt(trace["object_pose"][i, 3:7])
        rows.append({"trace_index": i, "time_s": float(times[i]), "phase": phase_names[int(trace["phase_id"][i])],
                     "object_z_mm": float(trace["object_pose"][i, 2]) * 1000,
                     "object_axis_tilt_to_vertical_deg": tilt, "object_axis_world": axis.tolist(),
                     "hand_object_contact_points": int(hand_contacts[i]),
                     "object_table_contact_points": int(trace["object_table_contacts"][i]),
                     "normal_hand_contact_force_sum_N": float(normal_forces[i]),
                     "source_sha256": {"metrics": sources[str(metrics_path)], "trace": sources[str(trace_path)], "model": sources[str(model_path)]},
                     **reconstructed_gap(i)})
    stages = []
    definitions = [("initial", "initial_object_pose", "approach"),
                   ("approach_end_closure_start", None, "approach_close_squeeze"),
                   ("closure_end", "closure_object_pose", "loaded_hold"),
                   ("loaded_end_lift_start", "loaded_object_pose", "lift"),
                   ("lift_end", "lift_end_object_pose", "postlift_hold"),
                   ("hold_end", "held_object_pose", "release_open")]
    for label, key, phase in definitions:
        time = phase_times[phase]
        i = int(np.flatnonzero((np.abs(times - time) < 1e-4) & (trace["phase_id"] == phase_names.index(phase)))[-1])
        pose = metrics[key] if key else trace["object_pose"][i]
        tilt, axis = axis_tilt(pose[3:7])
        stages.append({"stage": label, "time_s": time, "object_z_mm": float(pose[2]) * 1000,
                       "axis_tilt_deg": tilt, "axis_world": axis.tolist(),
                       "hand_object_contacts": int(hand_contacts[i]), "object_table_contacts": int(trace["object_table_contacts"][i]),
                       "normal_hand_contact_force_N": float(normal_forces[i]),
                       "source_sha256": {"metrics": sources[str(metrics_path)], "trace": sources[str(trace_path)]}})
    early_gaps = [r["minimum_hand_object_surface_distance_mm"] for r in rows if r["time_s"] <= .6 + 1e-4]
    assert all(sha(path) == digest for path, digest in sources.items())
    report = {
        "generated_at_utc": datetime.now(timezone.utc).isoformat(), "input": str(input_path),
        "metrics": str(metrics_path), "trace": str(trace_path), "model": str(model_path),
        "source_sha256": sources, "source_files_unchanged": True, "physics_steps_executed": 0,
        "diameter_mm": 1, "height_mm": 4, "mass_kg": metrics["object_mass_kg"],
        "compiled_mass_kg": float(model.body_subtreemass[int(model.geom_bodyid[object_geom])]),
        "canonical_axis_verified": "Source OBJ longest principal axis is local Z; compiled geometry is upright in initial world pose",
        "axis_convention": "tilt = acos(abs((R_object*[0,0,1]).z)); unoriented cylinder axis, range0..90deg",
        "trace_rate_hz": metrics["trace_fps"], "physics_timestep_s": metrics["dt_s"], "saved_trace_rows": len(times),
        "first_events": events, "stages": stages, "early_and_phase_samples": rows,
        "all_saved_hand_object_contact_points_zero": bool(np.max(hand_contacts) == 0),
        "all_saved_normal_hand_forces_zero": bool(np.max(normal_forces) == 0),
        "minimum_reconstructed_hand_object_gap_in_0_to_0p6s_samples_mm": min(early_gaps),
        "interpretation": [
            "The cylinder is already almost horizontal by0.5-0.6s, during the2s approach and before the nominal closure phase begins.",
            "No hand/object contact or normal hand/object force is observed in any saved sample, including all closure and holding phases.",
            "The saved states therefore do not support a claim that a successful pinch was formed and later lost. They support early loss of the upright pose followed by failure to capture the small cylinder.",
            "Saved10Hz contacts cannot mathematically exclude a short unrecorded collision between samples. Kinematic gaps provide additional separation evidence at those same sampled times, not a continuous contact history.",
            "A no-hand control with the identical free object, gravity, table contact parameters and initial pose is required to attribute early toppling to unsupported object/table dynamics rather than any unseen hand disturbance.",
        ],
        "proposed_controls_not_executed": [
            "No hand/no mocap/no hand actuator/equality: same compiled free cylinder geometry/mass/inertia/table/friction/solver/timestep/initial upright pose; observe at every4ms for2.7s.",
            "Repeat no-hand with a declared0.1deg initial tilt to test robustness; keep separate from exactly upright baseline.",
            "Only if necessary, run timestep/contact sensitivity checks with clearly recorded deviations; do not silently change the main baseline.",
        ],
    }
    (OUT / "baseline-diagnosis.json").write_text(json.dumps(report, indent=2, ensure_ascii=False) + "\n")
    lines = ["# 原 200 g、直径1 mm圆柱的倾倒时序诊断", "",
             "仅只读已发布轨迹和模型，没有重新执行物理仿真。圆柱直径1 mm、高4 mm、质量200 g，物体自由运动、初始竖直。轴倾角使用原始物体四元数旋转局部z轴，并按轴的正反等价取0–90°；源码网格与编译模型均验证局部z是圆柱长轴。", "",
             "## 已保存的时间顺序", "",
             "| t(s) | 阶段 | 中心z(mm) | 轴倾角° | 手物接触 | 物桌接触 | 手物法向力N | 重建手物最小间隙mm |",
             "|---:|---|---:|---:|---:|---:|---:|---:|"]
    for row in rows:
        lines.append(f"| {row['time_s']:.3f} | {row['phase']} | {row['object_z_mm']:.6f} | {row['object_axis_tilt_to_vertical_deg']:.6f} | {row['hand_object_contact_points']} | {row['object_table_contact_points']} | {row['normal_hand_contact_force_sum_N']:.6f} | {row['minimum_hand_object_surface_distance_mm']:.6f} |")
    lines += ["", "0.2秒仍竖直；0.3秒约4.85°，0.4秒约14.84°，0.5秒约77.92°，0.6秒约88.67°。正式闭合在2秒开始，此时圆柱已经接近横卧。", "",
              f"全{len(times)}个保存样本（10 Hz及阶段边界）中手物接触和手物法向力都为0，没有可列出的“首次手物接触”事件。0–0.6秒所核对样本的最小几何间隙为{min(early_gaps):.6f} mm。不能把本例描述为先成功夹住、抬升后才掉落；记录显示先失去竖直姿态，之后始终没有形成可观测夹持。", "",
              "## 可确认与不能确认的部分", "",
              "可确认的是，圆柱在2秒接近阶段的早期已经倾倒，远早于正式闭合；在所有保存时刻均未发现手碰物体。几何间隙是对原qpos做mj_forward/mj_geomDistance的静态核对，不是新一次物理试验。", "",
              "接触与倾角只以10 Hz保存，首次倾斜超过1°只能定位在0.2–0.3秒，超过15°/45°/75°只能定位在0.4–0.5秒之间。不能据0.1秒采样数学上排除瞬间碰撞，或独断究竟哪一个接触/数值因素触发了倾倒。", "",
              "中心z在0.5秒有一个低于桌面的瞬态，随后横卧中心约0.33 mm；这是当前微小几何、200 g负载和软接触模型中的记录，不是对实物站立能力的直接证明。倾倒原因需由无手对照检验。", "",
              "## 建议的无手对照（本诊断未执行）", "",
              "先保留同一自由圆柱的几何、200 g质量与惯性、桌面、摩擦、求解器、4 ms步长及初始竖直姿态，移除手、mocap和对应执行器/等式约束，记录每个物理步至少2.7秒。若无手也倾倒，说明原始无支撑站立条件本身在该模型中不能维持；若无手稳定，则需以250 Hz接触记录重查手接近造成的实际扰动。之后可另做明确标注的0.1°初始倾斜敏感性对照。不要为了得到站立结果而静默修改原基准。", "",
              "更换物理浅杯/笔筒/底部配重盘属于新的支撑场景，应保留物体自由运动并单独检查接触与释放，不能修改原失败轨迹或用焊接物体代替站立。", "",
              "完整阶段表、首次事件区间和每行来源SHA256见baseline-diagnosis.json。全部原文件读取后再次校验SHA256未变。", ""]
    (OUT / "BASELINE_DIAGNOSIS.md").write_text("\n".join(lines))
    print(json.dumps({"physics_steps_executed": 0, "saved_samples": len(times), "all_saved_HO_zero": report["all_saved_hand_object_contact_points_zero"],
                      "early_gap_min_mm": min(early_gaps), "first_events": events, "source_files_unchanged": True}, indent=2))


if __name__ == "__main__":
    main()
