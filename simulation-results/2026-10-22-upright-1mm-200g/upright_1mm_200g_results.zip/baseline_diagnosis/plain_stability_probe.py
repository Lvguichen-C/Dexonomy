#!/usr/bin/env python3
"""Isolate free-standing micro-cylinder behavior with the hand far away."""
from pathlib import Path
import hashlib
import json
import sys

sys.path.insert(0, '/workspace/shadow-lift-sweep-200g')
import evaluate_lifts as evaluation
import mujoco
import numpy as np

ROOT = Path('/workspace/shadow-lift-sweep-200g')
OUT = Path(__file__).resolve().parent


def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def run(source, timestep):
    grasp, scene = evaluation.prepare_scene(source['input'], .2)
    env = evaluation.make_env(scene, Path('/workspace/Dexonomy/assets/hand/shadow/right.xml'))
    env._model.opt.timestep = timestep
    hand = np.asarray(grasp['pregrasp_qpos'][0], dtype=float).copy()
    hand[:3] += [0, 0, .5]
    env.reset_qpos(hand)
    env._data.qfrc_applied[:] = 0
    env._data.xfrc_applied[:] = 0
    body = env._obj_active_bodyid
    joints = [j for j in range(env._model.njnt)
              if int(env._model.jnt_bodyid[j]) == body and env._model.jnt_type[j] == mujoco.mjtJoint.mjJNT_FREE]
    assert len(joints) == 1
    address = int(env._model.jnt_qposadr[joints[0]])
    times, positions, tilts, contacts = [], [], [], []
    for step in range(round(3 / timestep) + 1):
        if step:
            env.step_sim(1)
        q = env._data.qpos[address:address+7].copy()
        q[3:] /= np.linalg.norm(q[3:])
        axis = np.empty(3)
        mujoco.mju_rotVecQuat(axis, np.array([0., 0., 1.]), q[3:])
        tilt = np.degrees(np.arccos(np.clip(abs(axis[2]), 0, 1)))
        hp, tp, _, _ = evaluation.contact_stats(env)
        times.append(float(env._data.time)); positions.append(q); tilts.append(float(tilt)); contacts.append([hp, tp])
    a = np.asarray(tilts)
    c = np.asarray(contacts)
    label = f'dt{round(timestep*1e6)}us'
    target = OUT / f'plain_stability_{label}.npz'
    np.savez_compressed(target, time_s=times, object_qpos=positions, axis_tilt_deg=tilts, hand_world_contacts=contacts)
    first = {}
    for threshold in [5, 45, 80]:
        indices = np.flatnonzero(a >= threshold)
        first[str(threshold)] = float(times[int(indices[0])]) if len(indices) else None
    return {'timestep_s': timestep, 'duration_s': float(times[-1]), 'actual_object_mass_kg': float(env._model.body_subtreemass[body]),
            'hand_offset_m': [0, 0, .5], 'all_physics_steps_without_hand_object_contact': bool(np.max(c[:, 0]) == 0),
            'initial_tilt_deg': tilts[0], 'final_tilt_deg': tilts[-1], 'maximum_tilt_deg': float(a.max()),
            'first_axis_tilt_crossings_s': first, 'final_object_center_z_mm': float(positions[-1][2]*1000),
            'finite_states': bool(np.isfinite(env._data.qpos).all() and np.isfinite(env._data.qvel).all()),
            'warning_counts': [int(w.number) for w in env._data.warning], 'trace': str(target), 'trace_sha256': digest(target)}


def main():
    OUT.mkdir(parents=True, exist_ok=True)
    selection = json.loads((ROOT/'animations/selection.json').read_text())
    source = next(r for r in selection['representatives'] if r['diameter_mm'] == 1)
    watched = [Path(source[k]) for k in ['input', 'metrics', 'trace']]+[Path(evaluation.__file__)]
    before = {str(p): digest(p) for p in watched}
    results = [run(source, dt) for dt in [.004, .001]]
    assert all(digest(p) == value for p, value in before.items())
    report = {'scope': 'Diagnostic free-standing object; hand shifted 0.5m upward and held away throughout. Original plane/contact/gravity settings, object mass and geometry retained. Timestep1ms is a separate sensitivity condition, not a replacement official result.',
              'diameter_mm': 1, 'height_mm': 4, 'mass_kg': .2, 'source_files_unchanged': before, 'results': results}
    (OUT/'plain_stability_probe.json').write_text(json.dumps(report, indent=2)+'\n')
    print(json.dumps(report, indent=2))


if __name__ == '__main__':
    main()
