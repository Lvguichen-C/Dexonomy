#!/usr/bin/env python3
"""Read-only reduction of the 14 baseline and four controller trials."""
from pathlib import Path
import csv
import hashlib
import json

ROOT = Path(__file__).resolve().parent


def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def main():
    files = [*sorted((ROOT / "trials").glob("*/*/metrics.json")),
             *sorted((ROOT / "controller_ablation").rglob("metrics.json"))]
    if len(files) != 18:
        raise ValueError(f"Expected 18 completed physical trials; found {len(files)}")
    rows = []
    for path in files:
        m = json.loads(path.read_text())
        p = m["upright_protocol"]
        phases = p["phase_statistics"]
        hold = phases["postlift_hold"]
        profile = m.get("hand_controller_intervention", {}).get("profile", "baseline")
        gap = p["initial_minimum_hand_object_geom_distance"]["distance_m"] * 1000
        if gap < 50 or m["dt_s"] != .001 or m["unexpected_time_resets"] or any(m["maximum_warning_counts"]) or not m["finite_states"] or not m["gravity_enabled"]:
            raise ValueError(f"Protocol or numerical integrity check failed: {path}")
        if hold["samples"] != 5000:
            raise ValueError(f"Full five-second hold was not executed: {path}")
        max_hp = max(v["maximum_hand_object_contacts"] for v in phases.values())
        max_pen = max(v["maximum_hand_object_penetration_m"] for v in phases.values()) * 1000
        before_release = max(phases[k]["maximum_hand_object_penetration_m"] for k in
                             ["approach", "approach_close_squeeze", "loaded_hold", "lift", "postlift_hold"]) * 1000
        rows.append({"profile": profile, "fixture": m["fixture"], "variant": m["variant"],
                     "initial_true_gap_mm": gap, "closure_duration_s": p["native_trajectory_execution"][0]["duration_s"],
                     "measured_object_lift_mm": m["measured_object_lift_mm"],
                     "maximum_hand_object_contacts": max_hp,
                     "maximum_hand_object_penetration_mm": max_pen,
                     "pre_release_maximum_hand_object_penetration_mm": before_release,
                     "maximum_penetration_over_rod_radius": max_pen / .5,
                     "postlift_hold_hand_object_contacts_max": hold["maximum_hand_object_contacts"],
                     "postlift_hold_fixture_contacts_max": hold["maximum_object_fixture_contacts"],
                     "postlift_hold_plane_contacts_max": hold["maximum_object_plane_contacts"],
                     "support_free_throughout_hold": p["checks"]["no_fixture_or_plane_support_throughout_five_second_hold"],
                     "lift_hold_passed": m["lift_hold_passed"], "release_passed": m["release_passed"],
                     "full_sequence_passed": m["full_sequence_passed"],
                     "metrics": str(path.relative_to(ROOT)), "metrics_sha256": digest(path),
                     "trace_sha256": digest(path.parent / "trace.npz"),
                     "diagnostics_sha256": digest(path.parent / "diagnostics.npz"),
                     "model_mjb_sha256": digest(path.parent / "model.mjb")})
    report = {"scope": "18 actual continuous physics trials; static IK and support-only probes are excluded",
              "diameter_mm": 1, "height_mm": 4, "mass_kg": .2, "physics_timestep_s": .001,
              "baseline_trials": sum(r["profile"] == "baseline" for r in rows),
              "controller_trials": sum(r["profile"] != "baseline" for r in rows),
              "full_sequence_passed": sum(r["full_sequence_passed"] for r in rows),
              "all_initial_true_gaps_at_least_50mm": True,
              "all_numerically_finite_warning_reset_free": True,
              "all_postlift_hold_phases_completed_5000_steps": True,
              "rows": rows, "summarizer_sha256": digest(__file__)}
    (ROOT / "experiment-summary.json").write_text(json.dumps(report, ensure_ascii=False, indent=2) + "\n")
    with (ROOT / "experiment-results.csv").open("w", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)
    print(json.dumps({k: v for k, v in report.items() if k != "rows"}, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
