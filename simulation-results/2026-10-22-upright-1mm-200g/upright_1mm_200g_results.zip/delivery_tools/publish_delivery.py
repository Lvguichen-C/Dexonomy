#!/usr/bin/env python3
"""Local delivery validation by default; GitHub writes only with --publish."""
from __future__ import annotations
import argparse
import base64
import hashlib
import json
from pathlib import Path
import re
import subprocess
import tempfile
from urllib.parse import quote
from common import validated_rows, write_json


def gh(arguments,payload=None):
    if payload is None:
        result=subprocess.run(["gh",*arguments],text=True,capture_output=True,check=True)
    else:
        with tempfile.NamedTemporaryFile("w",suffix=".json",encoding="utf-8") as stream:
            json.dump(payload,stream,ensure_ascii=False)
            stream.flush()
            result=subprocess.run(["gh",*arguments,"--input",stream.name],text=True,capture_output=True)
            if result.returncode:
                raise RuntimeError(f"GitHub API request failed: {result.stderr.strip()}")
    return json.loads(result.stdout) if result.stdout.strip() else None


def report_links(text,rows):
    by_name={row["name"]:row["raw_url"] for row in rows}
    def replace(match):
        label,target=match.groups()
        if target.startswith(("https://","http://","#")):
            return match.group(0)
        if target in by_name:
            return f"[{label}]({by_name[target]})"
        return f"{label}（`{target}`，见完整ZIP）"
    return re.sub(r"\[([^\]]+)\]\(([^)]+)\)",replace,text)


def main():
    root=Path(__file__).resolve().parent.parent
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--deliverables",type=Path,default=root/"newdeliverables")
    parser.add_argument("--repo",default="Lvguichen-C/Dexonomy")
    parser.add_argument("--branch",default="mujoco-animation-results-20261016-assets")
    parser.add_argument("--prefix",default="simulation-results/2026-10-22-upright-1mm-200g")
    parser.add_argument("--release-tag",default="shadow-upright-1mm-200g-20261022")
    parser.add_argument("--release-title",default="Shadow Φ1×4 mm / 200 g：远离接近、竖直抓取与浅托对照")
    parser.add_argument("--report-name",default="UPRIGHT_1MM_REPORT.md")
    parser.add_argument("--expected-parent",default="86450c3e8927cf536d96a7243af0c8b33bbf3cea")
    parser.add_argument("--publish",action="store_true")
    args=parser.parse_args()
    folder=args.deliverables.resolve()
    manifest,rows=validated_rows(folder)
    if args.branch in ("main","master") or args.prefix.startswith("/") or ".." in Path(args.prefix).parts:
        raise SystemExit("Refusing invalid/source-branch delivery destination")
    if args.report_name not in {row["name"] for row in rows}:
        raise SystemExit("The release body report must be part of the validated manifest")
    state=folder.parent/"publication-state"
    plan={"repo":args.repo,"branch":args.branch,"prefix":args.prefix,"release_tag":args.release_tag,"release_title":args.release_title,"expected_parent":args.expected_parent,"files":rows,"renderer_video_verification":manifest.get("actual_video_streams")}
    write_json(state/"plan.json",plan)
    if not args.publish:
        print(json.dumps({"published":False,"local_validation":"passed","files":len(rows),"bytes":sum(row["bytes"] for row in rows),"plan":str(state/"plan.json")},ensure_ascii=False,indent=2))
        return
    api=f"repos/{args.repo}"
    # A preexisting tag is never silently reused or overwritten.
    try:
        existing=gh(["api",f"{api}/releases/tags/{quote(args.release_tag,safe='')}"])
    except subprocess.CalledProcessError as error:
        if "HTTP 404" not in (error.stderr or ""):
            raise
        existing=None
    if existing is not None:
        raise SystemExit("Release already exists; refusing to overwrite it")
    parent=gh(["api",f"{api}/git/ref/heads/{quote(args.branch,safe='/')}"])["object"]["sha"]
    if args.expected_parent and parent!=args.expected_parent:
        raise SystemExit(f"Result branch changed: expected {args.expected_parent}, found {parent}; inspect before changing --expected-parent")
    main_before=gh(["api",f"{api}/git/ref/heads/main"])["object"]["sha"]
    parent_commit=gh(["api",f"{api}/git/commits/{parent}"])
    tree_rows=[]
    for row in rows:
        content=(folder/row["name"]).read_bytes()
        expected=hashlib.sha1(f"blob {len(content)}\0".encode()+content).hexdigest()
        blob=gh(["api","--method","POST",f"{api}/git/blobs"],{"content":base64.b64encode(content).decode("ascii"),"encoding":"base64"})
        if blob["sha"]!=expected:
            raise SystemExit(f"Remote Git blob mismatch: {row['name']}")
        row["git_blob_sha"]=expected
        tree_rows.append({"path":f"{args.prefix}/{row['name']}","mode":"100644","type":"blob","sha":expected})
        write_json(state/"upload-progress.json",{"parent":parent,"uploaded_files":[r for r in rows if "git_blob_sha" in r]})
    tree=gh(["api","--method","POST",f"{api}/git/trees"],{"base_tree":parent_commit["tree"]["sha"],"tree":tree_rows})
    commit=gh(["api","--method","POST",f"{api}/git/commits"],{"message":"Add continuous upright 1mm 200g grasp and shallow support experiments","tree":tree["sha"],"parents":[parent]})
    gh(["api","--method","PATCH",f"{api}/git/refs/heads/{quote(args.branch,safe='/')}"],{"sha":commit["sha"],"force":False})
    main_after=gh(["api",f"{api}/git/ref/heads/main"])["object"]["sha"]
    for row in rows:
        path=quote(f"{args.prefix}/{row['name']}")
        row["raw_url"]=f"https://raw.githubusercontent.com/{args.repo}/{commit['sha']}/{path}"
        row["view_url"]=f"https://github.com/{args.repo}/blob/{commit['sha']}/{path}"
    publication={**plan,"files":rows,"published":True,"parent_commit":parent,"commit":commit["sha"],"main_before":main_before,"main_after":main_after,"main_unchanged":main_before==main_after,"release_created":False}
    publication_path=folder.parent/"publication.json"
    write_json(publication_path,publication)
    downloads=[]
    for row in rows:
        if row["name"].endswith(".mp4") or row["name"].endswith(".zip"):
            downloads.append(f"- [{row['name']}]({row['raw_url']})")
    body="## 动画与完整包下载\n\n"+"\n".join(downloads)+"\n\n"+report_links((folder/args.report_name).read_text(),rows).rstrip()
    body+="\n\n## 固定提交中的全部下载文件\n\n"
    for row in rows:
        body+=f"- [{row['name']}]({row['raw_url']})（{row['bytes']:,} bytes）\n"
    body+="\n下载文件保存于结果分支的固定提交，Release 正文提供直接链接。\n"
    notes=state/"release-notes.md"
    notes.write_text(body)
    release=gh(["api","--method","POST",f"{api}/releases"],{"tag_name":args.release_tag,"target_commitish":commit["sha"],"name":args.release_title,"body":body,"draft":False,"prerelease":False})
    publication.update(release_created=True,release_id=release["id"],release_url=release["html_url"])
    write_json(publication_path,publication)
    print(json.dumps({"published":True,"files":len(rows),"commit":commit["sha"],"main_unchanged":publication["main_unchanged"],"release_url":release["html_url"],"publication":str(publication_path)},ensure_ascii=False,indent=2))


if __name__=="__main__":
    main()
