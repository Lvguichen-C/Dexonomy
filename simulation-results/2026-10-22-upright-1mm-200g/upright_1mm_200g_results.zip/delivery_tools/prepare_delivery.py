#!/usr/bin/env python3
"""Package this experiment's reviewed outputs, with no network operations."""
from __future__ import annotations
import json
from pathlib import Path
import shutil
import subprocess
import zipfile
from fractions import Fraction
from common import CAP_BYTES, digest, safe_source, write_json

ROOT = Path(__file__).resolve().parent.parent


def probe(path):
    raw = subprocess.check_output([
        "ffprobe", "-v", "error", "-select_streams", "v:0", "-show_entries",
        "stream=width,height,avg_frame_rate,nb_frames,duration", "-of", "json", str(path)
    ], text=True)
    s = json.loads(raw)["streams"][0]
    return {"width": int(s["width"]), "height": int(s["height"]),
            "fps": float(Fraction(s["avg_frame_rate"])),
            "frames": int(s["nb_frames"]), "duration_s": float(s["duration"])}


def main():
    index_path = safe_source(ROOT / "animations/index.json")
    index = json.loads(index_path.read_text())
    report = safe_source(ROOT / "UPRIGHT_1MM_REPORT.md")
    # This gate is written only after independent numerical and media review.
    qa = json.loads(safe_source(ROOT / "qa/final-review.json").read_text())
    if qa.get("ready_for_delivery") is not True:
        raise SystemExit("Independent final QA has not passed")
    out = ROOT / "newdeliverables"
    out.mkdir(exist_ok=True)
    top = {report.name: report, "animation-index.json": index_path,
           "final-review.json": ROOT / "qa/final-review.json"}
    for name in ("PIPELINE.md", "experiment-summary.json", "experiment-results.csv"):
        top[name] = safe_source(ROOT / name)
    streams = []
    indexed_video_paths = set()
    for row in index["videos"]:
        path = Path(row["path"])
        path = safe_source(path if path.is_absolute() else index_path.parent / path)
        if not path.is_relative_to(ROOT / "animations"):
            raise ValueError("Only this experiment's animations can be delivered")
        actual = probe(path)
        indexed_video_paths.add(path.resolve())
        for key in ("width", "height", "frames"):
            if actual[key] != row[key]:
                raise ValueError(f"Video stream mismatch: {path.name} {key}")
        if abs(actual["fps"] - row["fps"]) > 1e-6 or abs(actual["duration_s"] - row["duration_s"]) > .015:
            raise ValueError(f"Video time mismatch: {path.name}")
        if row.get("sha256") and digest(path) != row["sha256"]:
            raise ValueError(f"Video hash mismatch: {path.name}")
        delivery_name = f"{path.parent.name}.mp4" if path.name == "full_sequence.mp4" else path.name
        if delivery_name in top:
            raise ValueError(f"Duplicate delivery filename: {delivery_name}")
        top[delivery_name] = path
        streams.append({"name": delivery_name, **actual, "sha256": digest(path)})
    if not streams:
        raise ValueError("No completed animations")
    for name, source in top.items():
        shutil.copy2(source, out / name)
    archive = {}
    allowed_suffixes = {".md", ".py", ".json", ".xml", ".mjb", ".npy", ".npz", ".csv", ".png", ".jpg", ".mp4", ".obj", ".stl", ".urdf", ".txt", ".yaml", ".yml"}
    for directory in ("baseline_diagnosis", "fixtures", "grasp_search", "trials", "animations", "qa", "delivery_tools", "controller_ablation"):
        base = ROOT / directory
        if not base.exists():
            continue
        for path in sorted(base.rglob("*")):
            if path.is_file() and path.suffix.lower() in allowed_suffixes and "__pycache__" not in path.parts:
                if directory == "animations" and path.suffix.lower() == ".mp4" and path.resolve() not in indexed_video_paths:
                    continue
                archive[str(path.relative_to(ROOT))] = safe_source(path)
    for path in ROOT.glob("*.py"):
        archive[path.name] = safe_source(path)
    archive[report.name] = report
    for name in ("PIPELINE.md", "experiment-summary.json", "experiment-results.csv"):
        archive[name] = safe_source(ROOT / name)
    # Include original evaluator, video encoder and public model assets so that
    # numerical outputs can be independently inspected without private files.
    archive["frozen_dependencies/evaluate_lifts.py"] = safe_source(ROOT.parent / "evaluate_lifts.py")
    archive["frozen_dependencies/video_writer.py"] = safe_source("/workspace/shadow-reproduction/video_writer.py")
    for asset_root in (Path("/workspace/Dexonomy/assets/hand/shadow"),
                       Path("/workspace/Dexonomy/assets/object/cylinder_sweep_20261022/processed_data/cylinder_thin")):
        for path in sorted(asset_root.rglob("*")):
            if path.is_file() and path.suffix.lower() in allowed_suffixes:
                archive[str(Path("frozen_dependencies/Dexonomy") / path.relative_to("/workspace/Dexonomy"))] = safe_source(path)
    scene_path = Path("/workspace/Dexonomy/assets/object/cylinder_sweep_20261022/scene_cfg/cylinder_thin/table_top/d1.npy")
    archive[str(Path("frozen_dependencies/Dexonomy") / scene_path.relative_to("/workspace/Dexonomy"))] = safe_source(scene_path)
    model_archives = {"plain": {}, "shallow": {}}
    for target, source in list(archive.items()):
        if source.suffix == ".mjb":
            fixture = json.loads((source.parent / "metrics.json").read_text())["fixture"]
            model_archives[fixture][target] = source
            del archive[target]
    model_names = []
    for fixture, models in model_archives.items():
        if len(models) != 9:
            raise ValueError(f"Expected 9 {fixture} runtime MJB models, found {len(models)}")
        model_name = f"upright_1mm_200g_models_{fixture}.zip"
        with zipfile.ZipFile(out / model_name, "w", zipfile.ZIP_DEFLATED, compresslevel=6) as z:
            for target, source in sorted(models.items()):
                z.write(source, target)
        with zipfile.ZipFile(out / model_name) as z:
            if z.testzip() is not None:
                raise ValueError(f"ZIP CRC failure: {model_name}")
        model_names.append(model_name)
    name = "upright_1mm_200g_results.zip"
    with zipfile.ZipFile(out / name, "w", zipfile.ZIP_DEFLATED, compresslevel=6) as z:
        for target, source in sorted(archive.items()):
            z.write(source, target)
        z.writestr("PACKAGE_README.txt", "Read UPRIGHT_1MM_REPORT.md first. This main package contains actual continuous MuJoCo traces, all 19 final animation outputs, failed-trial metrics and source code. Exact original compiled models are in upright_1mm_200g_models_plain.zip and upright_1mm_200g_models_shallow.zip, nine models each. Extract those archives into the same folder as this archive; their relative trial paths match exactly. Static IK proposals and support-only pullout probes are not successful grasps. Original working paths in scripts and XML identify provenance; relocate these paths or use the bundled public assets when replaying on another machine. No user attachment, token, credential or Python environment is included.\n")
    with zipfile.ZipFile(out / name) as z:
        if z.testzip() is not None:
            raise ValueError("ZIP CRC failure")
    names = [*top, name, *model_names]
    rows = [{"name": n, "bytes": (out / n).stat().st_size, "sha256": digest(out / n)} for n in names]
    if any(row["bytes"] >= CAP_BYTES for row in rows):
        raise ValueError("Split files exceeding the 95 MB cap before publication")
    write_json(out / "delivery_manifest.json", {
        "scope": "Own upright D1 H4 mm, 200g continuous trials and reviewed replay outputs",
        "actual_video_streams": streams, "zip_entries": len(archive) + 1,
        "compiled_model_archives": {f: {"name": f"upright_1mm_200g_models_{f}.zip", "models": len(a)} for f, a in model_archives.items()}, "files": rows,
        "report_sha256": digest(report), "independent_review_sha256": digest(ROOT / "qa/final-review.json")})
    print(json.dumps({"files": len(rows), "zip_bytes": (out / name).stat().st_size,
                      "videos": len(streams), "outdir": str(out)}, indent=2))


if __name__ == "__main__":
    main()
