#!/usr/bin/env python3
"""One finite high-precision IK follow-up; includes raised-support diagnosis.

Raised-support rows are static reachability only: the mathematically equivalent
table clearance is tested before translating hand and rod together by +5mm.
No such diagnostic is a baseline physical grasp or a successful lift.
"""
from search_refined import *

def solve(s,qbase,plane_level,seed):
    rbase=quat_to_rotation(qbase[3:7]);inds=s.hinge_idx
    x0=np.r_[np.zeros(6),np.clip(qbase[inds],s.lo,s.hi)]
    x0[3:6]=[0,seed*.18,seed*.12]
    bounds=(np.r_[[-.02]*3,[-1.]*3,s.lo],np.r_[[.02]*3,[1.]*3,s.hi])
    direction=np.array([np.cos(.92),np.sin(.92),0.])
    targets=np.asarray([-direction,direction])*.00052;targets[:,2]=.0037
    s.m.opt.ccd_tolerance=1e-10;s.m.opt.ccd_iterations=100
    calls=0
    def unpack(x):
        q=qbase.copy();q[:3]+=x[:3];q[3:7]=rotation_to_quat(Rotation.from_rotvec(x[3:6])*rbase);q[inds]=x[6:];return q
    def fun(x):
        nonlocal calls;calls+=1
        s.set(unpack(x));ds,sg=s.distances()
        hhseg=np.zeros(6);hh=mujoco.mj_geomDistance(s.m,s.d,*s.tips,.2,hhseg)
        plane=s.min_plane();hho,ho=s.collisions()
        return np.r_[(ds-.000020)/.0005,
                     ((sg[:,0]-targets)/.002).ravel(),
                     min(0,hh-.000020)/.000020,
                     min(0,hho)/.000020,min(0,ho)/.000020,
                     min(0,plane-plane_level-.000020)/.000020,
                     x[:3]/.02*.0001,x[3:6]*.0001,(x[6:]-x0[6:])*.0001]
    def jac(x):
        out=[]
        for k in range(len(x)):
            h=1e-6 if k<3 else 3e-5
            a=x.copy();b=x.copy();a[k]+=h;b[k]-=h
            out.append((fun(a)-fun(b))/(2*h))
        return np.asarray(out).T
    start=time.time()
    opt=least_squares(fun,x0,jac=jac,bounds=bounds,max_nfev=220,x_scale=np.r_[[.005]*3,[.4]*3,[.5]*9],ftol=1e-9,xtol=1e-9,gtol=1e-7)
    q=unpack(opt.x);s.set(q);ds,sg=s.distances();plane=s.min_plane();hh,ho=s.collisions()
    ds_tight=ds.copy()
    # Exact source-native numerical setting is restored before native screening.
    s.m.opt.ccd_tolerance=1e-6;s.m.opt.ccd_iterations=50;s.set(q)
    native=GraspFilter(OmegaConf.load(CFG).grasp.filter,s.env,'refined_precision')
    info=copy.deepcopy(s.source);passed,hoc=native.forward(info)
    cw=qp=None
    if len(hoc['dist']):cw,qp=ContactQP([.6,.02]).solve(hoc['pos'],hoc['normal'],info['ext_wrench'],info['ext_center'])
    s.set(q);ds_native,seg_native=s.distances();hh_native,ho_native=s.collisions()
    row=dict(template='24_Tip_Pinch',seed=seed,raised_support_diagnostic_m=-plane_level,nfev=opt.nfev,fk_evaluations=calls,seconds=time.time()-start,cost=float(opt.cost),termination=int(opt.status),true_tip_object_distance_m=ds_native,high_precision_tip_distance_m=ds_tight,closest_segments_m=seg_native,minimum_hand_z_m=plane,raised_minimum_hand_z_m=plane-plane_level,hand_hand_min_negative_distance_m=hh_native,hand_object_min_negative_distance_m=ho_native,native_filter_passed=bool(passed),native_qp_residual=qp,native_contact_body_names=hoc['bn1'],native_query_contact_distances_m=hoc['dist'],native_thresholds_unchanged=True,optimization_ccd_tolerance_m=1e-10,native_screening_ccd_tolerance_m=1e-6,epsilon_target_m=.000020,physical_success_inferred=False)
    row['microgeometry_50um_gate']=bool(passed and np.all((ds_native>=0)&(ds_native<=.00005)) and hh_native>=0 and ho_native>=0 and plane-plane_level>=0)
    return q,row,hoc

def main():
    s=Search();rows=[];variants=[]
    q=np.load(HERE/'24_Tip_Pinch_z4000_s1_static_qpos.npy')
    for level in [0.,-.005]:
        for seed in [0,1,-1]:
            qout,row,hoc=solve(s,q,level,seed)
            name=f'precision_tip_raise{round(-level*1000)}_seed{seed}'
            np.save(HERE/f'{name}_static_qpos.npy',qout)
            if row['microgeometry_50um_gate'] and level==0:
                row=s.write_candidate(qout,row,hoc,name);variants.append(row)
            rows.append(row);save_json(HERE/'precision-log.json',rows)
            save_json(HERE/'precision-candidates.json',dict(schema_version=1,candidate_count=len(variants),variants=variants,source_candidate=str(SOURCE),source_sha256=sha(SOURCE),static_kinematic_only=True))
            print(json.dumps(row,default=encode),flush=True)

if __name__=='__main__':main()
