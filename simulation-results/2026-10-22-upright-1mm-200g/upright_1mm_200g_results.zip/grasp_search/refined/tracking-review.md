# Read-only review of the 1 ms upright plain center trial

Input is `../source_grasp.npy`; physical data are `../../trials/plain/vertical_center/trace.npz`, `diagnostics.npz`, `metrics.json`, and `model.mjb`. No physics was rerun and no source or recorded data was modified. Timing/contact diagnostics have 1 ms resolution; full qpos/mocap traces have 25 Hz samples plus phase boundaries. MuJoCo FK reconstruction below does not imply a new physical experiment.

## The rod is struck during unilateral closure

The rod remains exactly upright throughout the 0.5 s visible pause and 2 s vertical approach. First hand/object contact occurs at 3.127 s with one contact and 0.8925 N summed normal force. Tilt first exceeds 0.1° at 3.128 s, 1° at 3.132 s, 5° at 3.138 s, 15° at 3.147 s, 45° at 3.162 s, and 80° at 3.173 s. There is never more than one hand/object contact during closure. Closure ends at 3.2 s with rod tilt 71.799°; the loaded hold ends at 4.2 s with tilt 88.985° and no hand contact.

This trial therefore differs from the old 4 ms case that toppled before closure. Here a unilateral contact is followed immediately by toppling. Closure's transient maximum summed normal force is 9.444 N, but it is a one-sided impact, not opposing grip force. Total normal force alone is not a grasp certificate.

## Root and finger tracking are distinct

Actual root is the freejoint qpos `[0:7]`; target is recorded mocap position/quaternion. Root translation/rotation errors are:

| Time / event | Translation error | Rotation error |
| --- | ---: | ---: |
| 0.5 s / end pause | 0.707 mm | 3.178° |
| 2.5 s / end approach | 0.489 mm | 3.063° |
| 3.12 s / before first contact, nearest qpos sample | 0.335 mm | 0.940° |
| 3.2 s / closure end | 0.149 mm | 0.462° |
| 4.2 s / loaded end | 0.210 mm | 0.401° |

The sampled maximum root translation error during approach is 2.218 mm; closure maximum is 0.541 mm and 3.063°. Pause's rotation maximum is 3.558°. The global 5.882 mm translation maximum occurs during release retreat and is not a cause of initial failure. Even 0.4–1° root rotation can move a tip by approximately 1–2 mm over this long hand lever arm.

A separate and larger issue is the coupled index-finger flexion shape. The XML's fixed tendon controls the sum of FFJ2 and FFJ1, not both joints separately. At loaded end:

| Quantity | FFJ2 | FFJ1 | Sum |
| --- | ---: | ---: | ---: |
| Saved grasp target | 0.406537 | 0.295871 | 0.702409 |
| Saved squeeze target | 0.429052 | 0.307349 | 0.736401 |
| Actual qpos at 4.2 s | 0.092258 | 0.638101 | 0.730358 |

The actuated sum tracks to within 0.00604 rad, while the individual flexion angles have redistributed by about 0.33 rad. Higher position-actuator gain strengthens the sum target but does not directly add independent control of this internal degree of freedom. This is not evidence that a gain ablation cannot help: it specifies what that ablation does and does not constrain.

## Static distance reconstructions

Loaded `model.mjb` was used without stepping. Collision geoms are 18 (index distal), 53 (thumb distal), and 54 (rod). At 3.12 s, the actual recorded qpos gives index/thumb distance approximately 9.328/0.499 mm. Replacing only actual root pose with recorded mocap pose, retaining all hinge angles and rod pose, gives approximately 7.366/0.501 mm. These are static counterfactual geometry queries; the remaining large index gap cannot be attributed to root alone. At 3.2 s the actual fallen-rod gaps are approximately 2.458/2.936 mm; at 4.2 s, 1.740/2.190 mm. Root correction alone at 4.2 s gives 1.827/2.023 mm and cannot re-establish a grip on the already displaced rod.

Values close to zero require reviewing MuJoCo collision-query tolerance; nearest-point output should not be treated as a measured pressure or a 20 µm certification. Native 2 mm proximity queries remain distinct from actual contact force.

## Settling changes the microscopic target geometry

Before hand contact, the upright rod center settles from initial z=2.000000 mm to z=1.792765 mm, with zero tilt. Its actual top is therefore z=3.792765 mm, a 0.207235 mm shift relative to the stored scene pose. This is roughly 21% of diameter and exceeds a static 20–50 µm gap goal. Proposal diagnostics should state which rod pose is fitted. A geometry fit at initial pose does not by itself demonstrate contact after gravity-on settling. In the actual free-object trial, no object pose writes occur within the sequence.

The practical diagnosis is sequential: settling changes the target by 0.207 mm; root and tendon-shape tracking change actual tip locations; one thumb-side contact arrives first and tips the rod. These observations motivate independent controller and geometry checks without weakening the continuous lift/hold/release success criteria.
