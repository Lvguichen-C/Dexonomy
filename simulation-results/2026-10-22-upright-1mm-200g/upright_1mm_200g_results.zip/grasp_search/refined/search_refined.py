#!/usr/bin/env python3
"""Finite MuJoCo collision-geometry IK proposals, never a physical lift test.

Only new files are written. The free rod is left at its scene pose; mj_forward
evaluates static kinematics, without stepping, fixing or welding the object.
The unchanged native filter is reported separately from 20um geometric goals.
"""
from __future__ import annotations
import copy, hashlib, json, sys, time
from pathlib import Path
import mujoco
import numpy as np
from scipy.optimize import least_squares
from scipy.spatial.transform import Rotation
from omegaconf import OmegaConf

HERE=Path(__file__).resolve().parent
BASE=HERE.parent
sys.path.insert(0,str(BASE.parent/'fixtures'))
sys.path.insert(0,'/workspace/Dexonomy')
from fixture_scene import make_env
from dexonomy.util.file_util import load_scene_cfg
from dexonomy.op.gen_grasp import GraspFilter
from dexonomy.qp.qp_single import ContactQP
from dexonomy.sim import MuJoCo_OptEnv

SOURCE=BASE/'source_grasp.npy'
XML=Path('/workspace/Dexonomy/assets/hand/shadow/right.xml')
CFG=Path('/workspace/Dexonomy/dexonomy/config/op/grasp.yaml')

def sha(path): return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def encode(value):
    if isinstance(value,np.ndarray): return value.tolist()
    if isinstance(value,np.generic): return value.item()
    raise TypeError(type(value).__name__)
def save_json(path,value): path.write_text(json.dumps(value,indent=2,default=encode)+'\n')
def quat_to_rotation(q): return Rotation.from_quat(np.r_[q[1:],q[0]])
def rotation_to_quat(r):
    q=r.as_quat();return np.r_[q[3],q[:3]]

class Search:
    def __init__(self):
        self.source=np.load(SOURCE,allow_pickle=True).item()
        self.scene=load_scene_cfg(self.source['scene_path'])
        self.env=make_env(self.scene,XML,'plain',.2,.001)
        self.m,self.d=self.env._model,self.env._data
        self.obj=[i for i in range(self.m.ngeom) if self.m.geom(i).name.startswith('obj-')][0]
        self.bodies=['rh_ffdistal','rh_thdistal']
        self.tips=[next(i for i in range(self.m.ngeom) if self.m.body(self.m.geom_bodyid[i]).name=='hand-'+b and self.m.geom_contype[i]) for b in self.bodies]
        self.hand_geoms=[i for i in range(self.m.ngeom) if self.m.body(self.m.geom_bodyid[i]).name.startswith('hand-') and self.m.geom_contype[i]]
        self.hinge_idx=np.r_[np.arange(7,11),np.arange(24,29)]
        self.lo=np.asarray([self.m.jnt_range[np.where(self.m.jnt_qposadr==i)[0][0],0] for i in self.hinge_idx])+1e-6
        self.hi=np.asarray([self.m.jnt_range[np.where(self.m.jnt_qposadr==i)[0][0],1] for i in self.hinge_idx])-1e-6
        self.evaluations=0
    def set(self,q):
        self.d.qpos[:29]=q;self.d.qvel[:]=0;mujoco.mj_forward(self.m,self.d)
    def distances(self):
        ds=[];segments=[]
        for gi in self.tips:
            s=np.zeros(6);ds.append(mujoco.mj_geomDistance(self.m,self.d,gi,self.obj,.2,s));segments.append(s.reshape(2,3))
        return np.asarray(ds),np.asarray(segments)
    def min_plane(self):
        lowest=.5
        for gi in self.hand_geoms:
            p=self.d.geom_xpos[gi];r=self.d.geom_xmat[gi].reshape(3,3);s=self.m.geom_size[gi];typ=self.m.geom_type[gi]
            if typ==mujoco.mjtGeom.mjGEOM_MESH:
                mid=self.m.geom_dataid[gi];v=self.m.mesh_vert[self.m.mesh_vertadr[mid]:self.m.mesh_vertadr[mid]+self.m.mesh_vertnum[mid]]
                z=p[2]+np.min(v@r[2])
            elif typ==mujoco.mjtGeom.mjGEOM_CAPSULE:z=p[2]-s[0]-s[1]*abs(r[2,2])
            elif typ==mujoco.mjtGeom.mjGEOM_SPHERE:z=p[2]-s[0]
            elif typ==mujoco.mjtGeom.mjGEOM_BOX:z=p[2]-np.abs(r[2])@s
            elif typ==mujoco.mjtGeom.mjGEOM_CYLINDER:z=p[2]-s[1]*abs(r[2,2])-s[0]*np.linalg.norm(r[2,:2])
            else:continue
            lowest=min(lowest,z)
        return float(lowest)
    def collisions(self):
        hh=ho=0.
        for c in self.d.contact:
            bs=[self.m.body(self.m.geom_bodyid[i]).name for i in (c.geom1,c.geom2)]
            if all(b.startswith('hand-') for b in bs):hh=min(hh,float(c.dist))
            elif any(b.startswith('hand-') for b in bs) and any(b.startswith('obj-') for b in bs):ho=min(ho,float(c.dist))
        return hh,ho
    def solve(self,template,target_z,azimuth,seed_mode):
        src=self.source['grasp_qpos'][0].astype(float)
        qbase=src.copy()
        if template!='9_Palmar_Pinch':
            t=np.load('/workspace/Dexonomy/assets/hand/shadow/init_tmpl/'+template+'.npy',allow_pickle=True).item()
            qbase[7:]=t['grasp_qpos'][0,7:]
            # Align its two annotated contact centers with the original candidate.
            self.set(qbase)
            # Use exact current tip-object closest points to remove coarse offset.
            _,sg=self.distances();qbase[:3]-=sg[:,0].mean(0)-np.array([0,0,target_z+.001])
        rbase=quat_to_rotation(qbase[3:7])
        x0=np.r_[np.zeros(6),np.clip(qbase[self.hinge_idx],self.lo,self.hi)]
        if seed_mode:x0[3:6]=[.12,-.08,.0]
        bounds=(np.r_[[-.012]*3,[-.45]*3,self.lo],np.r_[[.012]*3,[.45]*3,self.hi])
        # Source tips lie on opposite sides along this direction; rotate targets.
        direction=np.array([np.cos(azimuth),np.sin(azimuth),0.])
        targets=np.asarray([-direction,direction])*.0005;targets[:,2]=target_z
        def unpack(x):
            q=qbase.copy();q[:3]+=x[:3];q[3:7]=rotation_to_quat(Rotation.from_rotvec(x[3:6])*rbase);q[self.hinge_idx]=x[6:];return q
        calls=0
        def fun(x):
            nonlocal calls;calls+=1;self.evaluations+=1
            q=unpack(x);self.set(q);ds,sg=self.distances();delta=sg[:,1]-sg[:,0]
            unit=delta/np.maximum(np.linalg.norm(delta,axis=1,keepdims=True),1e-9)
            hh,ho=self.collisions();plane=self.min_plane()
            return np.r_[
                (ds-.000020)/.001,
                ((sg[:,1]-targets)/.002).ravel(),
                # Opposing nearly horizontal contact normals, not both pressing down.
                (unit-np.asarray([direction,-direction])).ravel()*.10,
                min(0,hh)/.0001,min(0,ho)/.0001,min(0,plane-.000025)/.0001,
                x[:3]/.02*.003,x[3:6]*.002,(x[6:]-x0[6:])*.002]
        started=time.time()
        opt=least_squares(fun,x0,bounds=bounds,max_nfev=180,diff_step=2e-5,ftol=2e-7,xtol=2e-7,gtol=1e-7,x_scale=np.r_[[.003]*3,[.2]*3,[.3]*9])
        q=unpack(opt.x);self.set(q);ds,sg=self.distances();hh,ho=self.collisions();plane=self.min_plane()
        # Original exact native filter, including contact query=2mm and QP=.001.
        info=copy.deepcopy(self.source);info['tmpl_name']=template
        native=GraspFilter(OmegaConf.load(CFG).grasp.filter,self.env,'refined_static_proposal')
        passed,hoc=native.forward(info)
        qp=None
        if len(hoc['dist']):
            _,qp=ContactQP([.6,.02]).solve(hoc['pos'],hoc['normal'],info['ext_wrench'],info['ext_center'])
        self.set(q)
        row=dict(template=template,target_z_m=target_z,azimuth_rad=azimuth,seed_mode=seed_mode,optimizer='scipy_least_squares_MuJoCo_exact_geomDistance',nfev=opt.nfev,fk_evaluations=calls,seconds=time.time()-started,cost=float(opt.cost),termination=int(opt.status),true_tip_object_distance_m=ds,closest_segments_m=sg,hand_hand_min_negative_distance_m=hh,hand_object_min_negative_distance_m=ho,minimum_hand_z_m=plane,native_filter_passed=bool(passed),native_thresholds_unchanged=True,native_qp_residual=qp,native_query_contact_distances_m=hoc['dist'],native_contact_body_names=hoc['bn1'],epsilon_target_m=.000020,physical_success_inferred=False)
        strict=bool(passed and np.all((ds>=0)&(ds<=.000050)) and hh>=0 and ho>=0 and plane>=0)
        row['microgeometry_50um_gate']=strict
        return q,row,hoc
    def write_candidate(self,q,row,hoc,name):
        out=copy.deepcopy(self.source)
        out['tmpl_name']=row['template'];out['grasp_qpos']=q[None].astype(np.float32)
        out['ho_c']=hoc
        # Native QP-based squeeze, same 10x contact-wrench scaling as gen_grasp.
        if 'wrench' not in hoc:
            cw,_=ContactQP([.6,.02]).solve(hoc['pos'],hoc['normal'],out['ext_wrench'],out['ext_center']);hoc['wrench']=10*cw
        sq=MuJoCo_OptEnv.get_squeeze_qpos(self.env,q,hoc['bn1'],hoc['pos'],hoc['wrench'])
        # Do not change hinge limits; record any saturations in the proposal.
        before=sq.copy()
        for ji in range(self.m.njnt):
            a=self.m.jnt_qposadr[ji]
            if self.m.jnt_limited[ji] and a<29:sq[a]=np.clip(sq[a],*self.m.jnt_range[ji])
        out['squeeze_qpos']=sq[None].astype(np.float32)
        # Preserve the original six-frame opening displacement, now based on
        # the retargeted grasp. No time/pose reset occurs in later physics.
        src=self.source['grasp_qpos'][0];pre=self.source['pregrasp_qpos'].astype(float).copy()
        pre[:,:3]+=q[:3]-src[:3]
        delta=quat_to_rotation(q[3:7])*quat_to_rotation(src[3:7]).inv()
        for p in pre:p[3:7]=rotation_to_quat(delta*quat_to_rotation(p[3:7]))
        pre[:,7:]+=q[7:]-src[7:]
        for ji in range(self.m.njnt):
            a=self.m.jnt_qposadr[ji]
            if self.m.jnt_limited[ji] and a<29:pre[:,a]=np.clip(pre[:,a],*self.m.jnt_range[ji])
        out['pregrasp_qpos']=pre.astype(np.float32)
        self.set(q)
        out['hand_cpn_w']=np.c_[hoc['pos'],hoc['normal']]
        out['hand_cbody']=hoc['bn1']
        path=HERE/'candidates'/f'{name}.npy';path.parent.mkdir(exist_ok=True);np.save(path,out)
        row.update(input=str(path),input_sha256=sha(path),squeeze_clipped_l2_rad=float(np.linalg.norm(before[7:]-sq[7:])),source_grasp=str(SOURCE),source_sha256=sha(SOURCE),stage='native_filter_passed_static_kinematic_proposal',approach={'direction_world':[0,0,1],'offset_m':.1,'duration_s':2.0},far_start_hold_s=.5,closure_duration_scale=1.,loaded_hold_s=1.,lift_m=.1,lift_s=5.,postlift_hold_s=5.,release_required=True,mass_kg=.2,object_freejoint_required=True,gravity_enabled_required=True)
        return row

def main():
    search=Search();rows=[];variants=[];start=time.time()
    # Eight finite solves: 2 templates x 2 heights x 2 small orientation seeds.
    for template in ['9_Palmar_Pinch','24_Tip_Pinch']:
        for z in [.0038,.0040]:
            for seed in [0,1]:
                q,row,hoc=search.solve(template,z,.92,seed)
                name=f"{template}_z{round(z*1e6)}_s{seed}"
                if row['microgeometry_50um_gate']:
                    row=search.write_candidate(q,row,hoc,name);variants.append(row)
                np.save(HERE/f'{name}_static_qpos.npy',q)
                rows.append(row);save_json(HERE/'search-log.json',rows)
                save_json(HERE/'candidates.json',dict(schema_version=1,source_candidate=str(SOURCE),source_sha256=sha(SOURCE),candidate_count=len(variants),variants=variants,static_kinematic_only=True,native_thresholds_unchanged=True,physical_success_inferred=False))
                print(json.dumps({k:row[k] for k in ['template','target_z_m','seed_mode','seconds','true_tip_object_distance_m','minimum_hand_z_m','native_filter_passed','native_qp_residual','microgeometry_50um_gate']},default=encode),flush=True)
    save_json(HERE/'summary.json',dict(source_sha256=sha(SOURCE),search_seconds=time.time()-start,proposal_solutions=len(rows),retained_native_and_microgeometry=len(variants),total_fk_evaluations=search.evaluations,object_freejoint=True,gravity_enabled=True,physics_steps=0,native_config=str(CFG),native_config_sha256=sha(CFG),notes='Static FK IK retargets real collision surfaces. No dynamic lift/force success is inferred; independent continuous free-object trial is required. Native 2mm queries are not physical contacts.'))

if __name__=='__main__':main()
