# Frozen finite microscopic grasp search

This isolated search kept the 1 mm diameter, 4 mm height, 0.2 kg rod and all source files unchanged. It produced **0 new proposals satisfying the stricter two-tip 50 µm, no-penetration geometry gate**. Of 14 static IK solutions, two passed the unchanged native filter: one at the original table level and one requiring a raised-support interpretation. None is a demonstrated physical grasp. This finite search does not establish impossibility.

## What ran

Eight initial IK solves used actual MuJoCo collision-mesh `mj_geomDistance`, root six degrees of freedom and nine index/thumb hinges, for Palmar Pinch and Tip Pinch at target contact heights 3.8/4.0 mm. Six follow-up solves used explicit central finite differences and optimization-only CCD tolerance 1e-10, with the original 1e-6 setting restored for final native filtering. Three follow-ups imposed the original table clearance; three allowed a mathematically equivalent 5 mm upward translation of hand and object together, as a static raised-support diagnosis. Total: 5,892 FK evaluations and 14 solver endpoints. No new dynamics or native force-guided optimizer steps were run.

The final native configuration was loaded directly from the unchanged `dexonomy/config/op/grasp.yaml`: zero allowed negative hand/hand or hand/object distances, zero joint-limit violation, required contact-body coverage, 2 mm proximity query and QP residual ≤0.001 at friction [0.6, 0.02]. The extra 50 µm requirement was an explicitly stricter geometric proposal gate; none of the physical success criteria was weakened.

## Results

| Set / endpoint | Native filter | Actual tip gaps | Hand minimum z | Interpretation |
| --- | --- | --- | --- | --- |
| Original source candidate | accepted previously | 1.134 / 1.854 mm | +0.321 mm | Native proximity, not pressing contact |
| Best first-pass Tip Pinch | fail | 0.248 / 0.268 mm | +0.023 mm | Hand/hand penetration 2.19 µm; rejected |
| Precision baseline, seed +1 | pass | 0.308 / 0.371 mm | +0.032 mm | No negative hand/hand distance, but misses 50 µm target |
| Precision raised-support, seed 0 | pass | 52.016 / 50.855 µm | −0.646 mm before raising | +5 mm rigid translation gives +4.354 mm table clearance; still misses 50 µm target |

The raised result is only a static reachability clue. It has not been compiled/evaluated with an actual raised cup, and cup/finger interference, settling, coupled actuator motion, and loaded forces were not verified. The raw table-level state intersects the original table, so it must never be entered as a normal baseline grasp. Static root/object rigid translation is a diagnostic equivalence, not a physical object relocation within a trial.

The best geometries still put the closest rod points on its top edge, rather than demonstrating symmetric side pressure. The native QP at these positive distances is a force-balance proposal calculation; no measured normal pressure or lift follows from it. At μ=0.6, supporting 0.2 kg against gravity alone would require approximately 3.27 N total appropriately directed normal pressure, plus moments and geometry constraints.

## Why target geometry alone is insufficient

The independent recorded-trial audit in [tracking-review.md](tracking-review.md) found that the new 1 ms plain trial stays upright until first one-sided contact at 3.127 s, then tips beyond 80° by 3.173 s. This is distinct from the older 4 ms pre-contact numerical toppling. Root translation error at closure end is 0.149 mm with 0.462° rotation; it is relevant but does not explain the whole miss.

The fixed tendon controls the sum of index FFJ2+FFJ1, leaving their internal distribution uncontrolled. At loaded-hold end, actual values are 0.0923/0.6381 rad, while the squeeze targets are 0.4291/0.3073 rad; the actuator sums are close (0.7304 vs 0.7364). IK treating these hinges independently therefore does not establish executable tip shape, even when its static geometry is good. Increased position gain controls that sum more strongly but does not directly constrain this nullspace.

Before first hand contact the freely standing rod settles from center z=2.000000 mm to 1.792765 mm without tilt: 207.235 µm below the stored scene. Every static IK here fits the initial scene pose, not this settled pose. That settling exceeds the 20–50 µm fitting goal. A future settled-pose retarget must be declared separately and tested with the free rod; it was not silently applied to these results.

## Artifacts and boundaries

`search_refined.py` and `refine_precision.py` reproduce the finite search. `search-log.json` and `precision-log.json` preserve every endpoint and numerical setting; `*_static_qpos.npy` store static hand targets only. The manifests intentionally contain zero approved new full candidate payloads. These qpos files are diagnostics, not completed grasp/lift results. `final-summary.json` records source/config/evaluator hashes. Original source payload bytes match the existing source copy.

No object weld, gravity deletion, physical teleport, geometry scaling, joint-limit relaxation, collision-threshold relaxation, or physical success claim was introduced. No further search or physical trial is running in this directory.
