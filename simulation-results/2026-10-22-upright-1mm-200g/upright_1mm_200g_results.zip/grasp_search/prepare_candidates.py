#!/usr/bin/env python3
"""Prepare finite upright-cylinder control proposals without running physics.

The source grasp remains untouched. New proposal files keep every joint target;
only explicitly declared root XY offsets and optional scene metadata may differ.
Runtime approach/timing settings live in the manifest for a fixture evaluator.
"""
from __future__ import annotations

import argparse
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import shutil

import numpy as np


ROOT = Path('/workspace/shadow-lift-sweep-200g/upright-1mm-20261022/grasp_search')
SOURCE = Path('/workspace/shadow-lift-sweep-200g/output/diameter_sweep_200g_shadow/grasp_data/9_Palmar_Pinch/cylinder_thin_table_1/scaledall200_0_7_grasp.npy')


def sha256(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--source', type=Path, default=SOURCE)
    parser.add_argument('--outdir', type=Path, default=ROOT)
    parser.add_argument('--scene-path', type=Path, help='Optional new fixture scene; never edits the source scene')
    args = parser.parse_args()
    args.outdir.mkdir(parents=True, exist_ok=True)
    original = np.load(args.source, allow_pickle=True).item()
    scene_path = args.scene_path or Path(original['scene_path'])
    scene = np.load(scene_path, allow_pickle=True).item()
    object_config = scene['scene'][scene['task']['obj_name']]
    assert np.allclose(object_config['scale'], [0.001, 0.001, 0.001])
    assert np.allclose(object_config['pose'][:3], [0, 0, 0.002])
    assert np.allclose(object_config['pose'][3:], [1, 0, 0, 0])
    source_copy = args.outdir / 'source_grasp.npy'
    shutil.copy2(args.source, source_copy)
    assert source_copy.read_bytes() == args.source.read_bytes()

    # One baseline anchor, four small XY perturbations, two slower closures,
    # and two approach-offset controls: nine explicit proposals, no random sweep.
    settings = [
        ('vertical_center', 0, 0, 1.0, .05),
        ('vertical_x_plus', .00015, 0, 1.0, .05),
        ('vertical_x_minus', -.00015, 0, 1.0, .05),
        ('vertical_y_plus', 0, .00015, 1.0, .05),
        ('vertical_y_minus', 0, -.00015, 1.0, .05),
        ('vertical_close_slow', 0, 0, 2.0, .05),
        ('vertical_close_slower', 0, 0, 3.0, .05),
        ('vertical_start_high', 0, 0, 1.0, .10),
        ('vertical_start_low', 0, 0, 1.0, .02),
    ]
    variants = []
    for name, dx, dy, close_scale, approach_offset in settings:
        data = np.load(args.source, allow_pickle=True).item()
        data['scene_path'] = str(scene_path.resolve())
        for key in ('pregrasp_qpos', 'grasp_qpos', 'squeeze_qpos'):
            values = np.asarray(data[key]).copy()
            assert values.ndim == 2 and values.shape[1] == 29
            values[:, 0] += dx
            values[:, 1] += dy
            assert np.array_equal(values[:, 3:], np.asarray(original[key])[:, 3:])
            assert np.array_equal(values[:, 2], np.asarray(original[key])[:, 2])
            data[key] = values
        output = args.outdir / 'candidates' / f'{name}.npy'
        output.parent.mkdir(parents=True, exist_ok=True)
        np.save(output, data)
        variants.append({
            'id': name, 'input': str(output.resolve()), 'input_sha256': sha256(output),
            'source_grasp': str(args.source.resolve()), 'source_sha256': sha256(args.source),
            'scene_path': str(scene_path.resolve()),
            'root_xy_offset_m': [dx, dy],
            'joint_targets_unchanged': True, 'root_orientation_unchanged': True,
            'approach': {'direction_world': [0, 0, 1], 'offset_m': approach_offset, 'duration_s': 2.0,
                         'interpretation': 'Start above the stored first pregrasp target, descend continuously; never reset inside the trial'},
            'closure_duration_scale': close_scale,
            'loaded_hold_s': 1.0, 'lift_m': .1, 'lift_s': 5.0, 'postlift_hold_s': 5.0,
            'release_required': True, 'mass_kg': .2,
            'object_freejoint_required': True, 'gravity_enabled_required': True,
            'stage': 'unverified_control_proposal',
        })
    manifest = {
        'schema_version': 1, 'created_at_utc': datetime.now(timezone.utc).isoformat(),
        'source_candidate': str(args.source.resolve()), 'source_sha256': sha256(args.source),
        'source_copy': str(source_copy.resolve()), 'source_payload_byte_copy_verified': True,
        'object': {'diameter_mm': 1, 'height_mm': 4, 'mass_kg': .2, 'initial_pose': [0, 0, .002, 1, 0, 0, 0]},
        'fixture_policy': 'Fixed environment geometry is allowed; the cylinder stays free. Fixture geometry and local contact margins must be supplied by a separate explicit adapter and retained in provenance.',
        'candidate_count': len(variants), 'variants': variants,
        'native_filter_policy': {'joint_limit_threshold_rad': 0, 'hand_hand_min_distance_m': 0,
                                 'hand_object_min_distance_m': 0, 'required_contact_bodies': True,
                                 'contact_query_margin_m': .002, 'qp_max_residual': .001,
                                 'friction_coefficients': [.6, .02],
                                 'additional_fixture_check': 'Reject negative hand/fixture distance; native GraspFilter ignores world-body fixture contacts'},
        'success_policy': 'No proposal is a success until continuous gravity-on fixture evaluation completes real lift, 5s hold and release. Native geometric filtering alone is insufficient.',
        'mutation_scope': 'New proposal files only. Original grasp, scene, evaluator and published results are untouched.',
    }
    (args.outdir / 'candidates.json').write_text(json.dumps(manifest, indent=2) + '\n')
    print(json.dumps({'manifest': str(args.outdir / 'candidates.json'), 'candidate_count': len(variants), 'source_unchanged': sha256(args.source) == manifest['source_sha256']}, indent=2))


if __name__ == '__main__':
    main()
