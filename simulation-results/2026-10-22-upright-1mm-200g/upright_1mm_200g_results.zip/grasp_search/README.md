# 竖立 1 mm 圆柱：有限候选准备

`prepare_candidates.py` 已生成 `candidates.json` 与九个新的控制提案；没有运行新的物理搜索，也没有修改原 200 g 数据、场景、评价器或已发布结果。

这些提案来源于原 1 mm 唯一通过合成过滤的 `9_Palmar_Pinch/scaledall200_0_7_grasp.npy`。它在原完整物理评价中失败，不能把“曾通过合成过滤”理解为可稳定提起，更不能把九个复用提案说成九个优化认证结果。

九个变体包括：居中垂直接近、根 x/y 各 ±0.15 mm、居中闭合时间 ×2/×3、接近起点高 100/20 mm。其余变体起点高 50 mm，接近用时 2 秒。预抓取/抓取/夹紧三段中的根 xy 目标一致偏移，22 个关节目标、根朝向和根 z 保持不变。完全未改动的源候选另存为逐字节一致的 `source_grasp.npy`。

## 执行器接口

`candidates.json.variants` 中每项有：

```text
id, input, input_sha256, source_grasp, source_sha256
root_xy_offset_m
approach.direction_world = [0,0,1]
approach.offset_m = 0.05（或 0.10 / 0.02）
approach.duration_s = 2
closure_duration_scale = 1（或 2 / 3）
loaded_hold_s = 1
lift_m = 0.1, lift_s = 5, postlift_hold_s = 5
mass_kg = 0.2, object_freejoint_required = true
stage = unverified_control_proposal
```

新执行器只需在首次重置前令接近起点为 `controls[0]` 根 z 加上 `offset_m`，然后连续插值下降到原预抓取目标。初次重置后不能再写物体位姿或逐帧重置关节。托座使用 `fixtures/fixture_scene.py` 的 `with_fixture_env_class` / `make_env` 接口；固定几何属于环境，圆柱始终自由，重力始终开启。

新主试验若用 1 ms 步长，必须注意原生 `run_trajectory` 默认每段 `5×5` 个子步：直接沿用会把原 4 ms 时每段 0.1 秒的物理闭合时间缩成 0.025 秒。可令 `step=5`、`substep=round(0.020/dt*closure_duration_scale)`，即 1 ms 下分别为 20/40/60，以保持旧物理时标再乘闭合变体比例。候选本身不修改冻结评价器；这个行为必须在新托座执行器中显式记录。

## 过滤与验证的含义

`native_filter_check.py` 提供 `check_native_on_clone(env, grasp_data)`，在临时复制的 MuJoCo data 上使用原始 `GraspFilter` 和原始配置，检查关节、手手/手物接触、必需接触组与 QP；检查后恢复所有临时 margin，活跃 trial 的 qpos/time 不变。它还单独记录 hand/fixture 最小距离，因为原生过滤器不会处理 hand/world 托座接触。

这只是提案诊断，不能在物理测试中静默增加或改变通过门槛。特别是原生过滤设计用于带正 margin 的优化状态；实际物理软接触可能具有微小负距离，应与当前明确的碰撞/接触容差一起报告，不能把所有负距离自动解释为非物理穿透，也不能凭静态过滤通过宣称提升成功。

必须重新执行真实、重力开启的完整闭合、100 mm 提升、5 秒持握及释放，测量实际高度、接触/受力、fixture 是否已经脱离、稳定性和数值状态。托座接触的局部 margin 由 fixture 适配器明确控制；不能沿用宏观 1–20 mm margin 把 1.2 mm 孔的实际间隙全部吃掉。候选准备没有运行固定物体优化、没有新增物体焊接、没有关闭重力。

重新准备候选：

```bash
/workspace/shadow-reproduction/run_cpu.sh python \
  /workspace/shadow-lift-sweep-200g/upright-1mm-20261022/grasp_search/prepare_candidates.py
```

如使用新的独立 scene 文件，可传 `--scene-path` 和新 `--outdir`，不得覆盖源场景。
