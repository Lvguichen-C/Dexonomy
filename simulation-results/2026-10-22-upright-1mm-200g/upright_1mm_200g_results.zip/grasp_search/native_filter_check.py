"""Original native grasp-filter diagnostics on a cloned MuJoCo data state.

The filter was designed for margin-based grasp optimization. Its output is
reported separately from the continuous free-object lift/hold/release result.
Never interpret a source proposal's filter result as current fixture validity.
"""
from __future__ import annotations

import copy
from pathlib import Path

import mujoco
import numpy as np
from omegaconf import OmegaConf

from dexonomy.op.gen_grasp import GraspFilter


NATIVE_CONFIG = Path('/workspace/Dexonomy/dexonomy/config/op/grasp.yaml')


def check_native_on_clone(env, grasp_data, fixture_prefix='fixture-'):
    """Inspect an existing pose without advancing time or changing live data.

The exact native filter thresholds are loaded from the unchanged source config.
Margins used temporarily by get_contacts are restored even on an exception.
This is an isolated proposal diagnostic, not an extra success gate silently
inserted into an already frozen physical evaluator.
"""
    live_data = env._data
    before_time = float(live_data.time)
    before_qpos = live_data.qpos.copy()
    margins = env._model.geom_margin.copy()
    result = None
    try:
        env._data = copy.copy(live_data)
        mujoco.mj_forward(env._model, env._data)
        fixture_hand_distances = []
        for contact in env._data.contact:
            geom_names = [env._model.geom(g).name for g in (contact.geom1, contact.geom2)]
            body_names = [env._model.body(int(env._model.geom_bodyid[g])).name for g in (contact.geom1, contact.geom2)]
            if any(name.startswith(fixture_prefix) for name in geom_names) and any(name.startswith('hand-') for name in body_names):
                fixture_hand_distances.append(float(contact.dist))
        config = OmegaConf.load(NATIVE_CONFIG).grasp.filter
        native = GraspFilter(config, env, 'isolated_upright_proposal_check')
        passed, hand_object = native.forward(grasp_data)
        result = {
            'native_filter_passed': bool(passed),
            'native_config': str(NATIVE_CONFIG),
            'native_thresholds_unchanged': True,
            'hand_object_contact_records': len(hand_object['dist']),
            'hand_object_min_distance_m': float(np.min(hand_object['dist'])) if len(hand_object['dist']) else None,
            'contact_body_names': sorted(set(hand_object['bn1'])),
            'fixture_hand_min_distance_m': min(fixture_hand_distances) if fixture_hand_distances else None,
            'fixture_hand_negative_distance_present': any(d < 0 for d in fixture_hand_distances),
            'fixture_check_role': 'Separate geometry diagnostic; native filter itself does not inspect hand/world fixture contacts',
            'physical_lift_success_inferred': False,
        }
    finally:
        env._model.geom_margin[:] = margins
        env._data = live_data
    assert np.array_equal(live_data.qpos, before_qpos)
    assert float(live_data.time) == before_time
    return result
