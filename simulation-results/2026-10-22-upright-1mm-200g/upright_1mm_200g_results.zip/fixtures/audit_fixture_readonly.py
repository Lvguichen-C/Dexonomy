#!/usr/bin/env python3
"""Read-only fixture/DOF/contact-parameter audit; compiles but never steps.

The two-sphere contact below is only a static parameter-mixing query using
mj_forward. It is not a new mechanics trial or evidence of grasp success.
"""
from __future__ import annotations
import hashlib
import json
from pathlib import Path
import mujoco
import numpy as np
import fixture_scene as fixture


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def geom_record(model,i):
    return {"id":i,"name":model.geom(i).name,"body_id":int(model.geom_bodyid[i]),
        "body_name":model.body(int(model.geom_bodyid[i])).name,
        "type":int(model.geom_type[i]),"size":model.geom_size[i].tolist(),
        "condim":int(model.geom_condim[i]),"priority":int(model.geom_priority[i]),
        "solmix":float(model.geom_solmix[i]),"solref":model.geom_solref[i].tolist(),
        "solimp":model.geom_solimp[i].tolist(),"margin_m":float(model.geom_margin[i]),
        "gap_m":float(model.geom_gap[i]),"friction":model.geom_friction[i].tolist()}


def static_pair(a,b):
    spec=mujoco.MjSpec.from_string('''<mujoco><option timestep=".001" gravity="0 0 0"/><worldbody>
        <geom name="a" type="sphere" size=".0005"/>
        <body pos="0 0 .00095"><freejoint/><geom name="b" type="sphere" size=".0005" mass=".2"/></body>
        </worldbody></mujoco>''')
    for name,row in (("a",a),("b",b)):
        geom=next(g for g in spec.geoms if g.name==name)
        for key in ("condim","priority","solmix","solref","solimp","friction"):
            setattr(geom,key,row[key])
        geom.margin=row["margin_m"]
        geom.gap=row["gap_m"]
    model=spec.compile()
    data=mujoco.MjData(model)
    mujoco.mj_forward(model,data)
    assert data.ncon==1
    c=data.contact[0]
    return {"method":"Static mj_forward parameter query; no time integration",
        "contact_dim":int(c.dim),"solref":c.solref.tolist(),"solimp":c.solimp.tolist(),
        "friction_5d":c.friction.tolist(),"signed_distance_m":float(c.dist)}


def main():
    root=Path(__file__).parent
    fixture_hash=sha(fixture.__file__)
    candidate=next(Path("/workspace/shadow-lift-sweep-200g/output/diameter_sweep_200g_shadow/grasp_data").glob("*/cylinder_thin_table_1/*.npy"))
    module=fixture.frozen_module()
    _,scene=module.prepare_scene(candidate,.2)
    results={}
    for name in ("plain","shallow"):
        env=fixture.make_env(scene,"/workspace/Dexonomy/assets/hand/shadow/right.xml",fixture=name,mass_kg=.2,timestep=.001)
        model,data=env._model,env._data
        obj=env._obj_active_bodyid
        root_body=model.body("hand-world").id
        mocap=model.body("mocap_body").id
        object_joints=[i for i in range(model.njnt) if int(model.jnt_bodyid[i])==obj]
        equalities=[]
        for i in range(model.neq):
            equalities.append({"id":i,"type":int(model.eq_type[i]),
                "body1":model.body(int(model.eq_obj1id[i])).name,"body2":model.body(int(model.eq_obj2id[i])).name,
                "body_ids":[int(model.eq_obj1id[i]),int(model.eq_obj2id[i])],
                "solref":model.eq_solref[i].tolist(),"solimp":model.eq_solimp[i].tolist(),
                "data":model.eq_data[i].tolist()})
        assert model.neq==1 and all(obj not in item["body_ids"] for item in equalities)
        assert object_joints and int(model.jnt_type[object_joints[0]])==int(mujoco.mjtJoint.mjJNT_FREE)
        hand_geoms=[i for i in range(model.ngeom) if model.body(int(model.geom_bodyid[i])).name.startswith("hand-") and model.geom_contype[i]!=0]
        obj_geoms=[i for i in range(model.ngeom) if int(model.geom_bodyid[i])==obj]
        fixtures=[i for i in range(model.ngeom) if model.geom(i).name.startswith("fixture-")]
        assert all(int(model.geom_bodyid[i])==0 for i in fixtures)
        hand=geom_record(model,hand_geoms[0])
        rod=geom_record(model,obj_geoms[0])
        bottom=geom_record(model,model.geom("fixture-bottom").id) if fixtures else None
        address=int(model.jnt_dofadr[object_joints[0]])
        moments=np.zeros((model.nu,model.nv))
        mujoco.mju_sparse2dense(moments,data.actuator_moment,data.moment_rownnz,data.moment_rowadr,data.moment_colind)
        assert np.max(np.abs(moments[:,address:address+6]))==0
        assert np.max(np.abs(data.qfrc_applied))==0 and np.max(np.abs(data.xfrc_applied))==0
        results[name]={"compiled_only_no_steps":True,"simulated_time_s":float(data.time),
            "dt_s":float(model.opt.timestep),"mass_kg":float(model.body_subtreemass[obj]),
            "object_initial_qpos":data.qpos[int(model.jnt_qposadr[object_joints[0]]):int(model.jnt_qposadr[object_joints[0]])+7].tolist(),
            "object_mesh_half_extents_m":model.geom_size[obj_geoms[0]].tolist(),
            "nbody":model.nbody,"nq":model.nq,"nv":model.nv,"nu":model.nu,"neq":model.neq,
            "hand_root_body_id":root_body,"mocap_body_id":mocap,"object_body_id":obj,
            "object_freejoint_ids":object_joints,"object_direct_actuation_max":0.0,
            "object_external_force_or_torque_applied":False,"equalities":equalities,
            "fixture_geom_count":len(fixtures),"all_fixture_geoms_static_world":True,
            "representative_hand_collision_geom":hand,"object_collision_geom":rod,"fixture_bottom_geom":bottom,
            "hand_object_effective_contact":static_pair(hand,rod),
            "fixture_object_effective_contact":static_pair(bottom,rod) if bottom else None,
            "opt":{"iterations":int(model.opt.iterations),"tolerance":float(model.opt.tolerance),
                "impratio":float(model.opt.impratio),"noslip_iterations":int(model.opt.noslip_iterations),
                "integrator":int(model.opt.integrator),"solver":int(model.opt.solver)}}
    assert all(results["plain"][key]==results["shallow"][key] for key in ("nbody","nq","nv","nu","neq","hand_root_body_id","mocap_body_id","object_body_id"))
    assert sha(fixture.__file__)==fixture_hash
    report={"source_fixture_sha256":fixture_hash,"source_evaluator_sha256":sha(fixture.FROZEN),
        "source_simulator_sha256":sha("/workspace/Dexonomy/dexonomy/sim/mujoco_env.py"),
        "candidate_path":str(candidate),"candidate_sha256":sha(candidate),
        "geometry":fixture.geometry_definition("shallow"),"compiled_scene_audits":results,
        "independent_dynamic_evidence":"validation-priority1/summary.json (already completed; not rerun by this audit)",
        "superseded_dynamic_evidence":"validation/ is priority0 diagnostic only",
        "source_changed_by_audit":False,"new_grasp_or_fixture_physics_steps":0,
        "required_live_monitors":["hand-object real contact count/normal forces","hand-fixture contact count/signed distances/normal forces","object-fixture and object-table contacts separately","Require zero object-fixture/table contacts throughout post-lift hold","Penetration divided by object radius 0.5mm"]}
    (root/"FIXTURE_READONLY_AUDIT.json").write_text(json.dumps(report,indent=2)+"\n")
    print(json.dumps({"audit":str(root/"FIXTURE_READONLY_AUDIT.json"),"new_physics_steps":0,"fixture_source_sha256":fixture_hash,
        "hand_object_contact":results["shallow"]["hand_object_effective_contact"],"fixture_object_contact":results["shallow"]["fixture_object_effective_contact"]},indent=2))


if __name__=="__main__":
    main()
