#!/usr/bin/env python3
"""Small no-hand fixture tests; not a grasp-success evaluation.

Rest and brief torque trials run for 3 s. A separate force-controlled upward
pull checks that the free rod clears the cup without a weld/spring constraint.
"""
from __future__ import annotations
import argparse
import json
import math
from pathlib import Path
import mujoco
import numpy as np
from fixture_scene import add_fixture_to_spec,contact_log,cup_spec,geometry_definition


MESH=Path("/workspace/Dexonomy/assets/object/cylinder_sweep_20261022/processed_data/cylinder_thin/mesh/simplified.obj")


def build(fixture,dt):
    config=cup_spec(fixture)
    floor_z=-config.bottom_thickness_m if config else 0
    # Match the original object's exact 64-sided canonical mesh and soft default
    # contact model. The additional fixture is the only new geometry.
    text=f'''<mujoco model="upright_fixture_no_hand">
      <compiler angle="radian"/>
      <option timestep="{dt}" gravity="0 0 -9.81" integrator="implicitfast" cone="elliptic" noslip_iterations="2" impratio="10"/>
      <default><geom friction="0.6 0.02 0.0001" condim="4" margin="0"/></default>
      <asset><mesh name="rod_mesh" file="{MESH}" scale="0.001 0.001 0.001"/></asset>
      <worldbody>
        <geom name="plane-table" type="plane" size=".4 .4 .01" pos="0 0 {floor_z}"/>
        <body name="obj-cylinder_thinworld" pos="0 0 .002">
          <freejoint name="cylinder_thin_freejoint"/>
          <geom name="obj-rod" type="mesh" mesh="rod_mesh" mass="0.2"/>
        </body>
      </worldbody>
    </mujoco>'''
    spec=mujoco.MjSpec.from_string(text)
    add_fixture_to_spec(spec,fixture)
    model=spec.compile()
    return model,mujoco.MjData(model),spec.to_xml()


def tilt(q):
    rotation=np.empty(9)
    mujoco.mju_quat2Mat(rotation,q)
    return math.degrees(math.acos(np.clip(rotation.reshape(3,3)[2,2],-1,1)))


def run(fixture,dt,kind,out):
    model,data,xml=build(fixture,dt)
    body=model.body("obj-cylinder_thinworld").id
    actual_mass=float(model.body_subtreemass[body])
    assert abs(actual_mass-.2)<1e-6
    assert model.neq==0 and model.nq==7 and model.nv==6
    duration=3 if kind!="pullout" else 1.3
    count=round(duration/dt)
    rows=[]
    force_rows=[]
    time_resets=[]
    max_warn=np.zeros(len(data.warning),dtype=int)
    last=0.0
    for step in range(count):
        data.xfrc_applied[:]=0
        if kind=="perturb" and 1<=data.time<1.04:
            data.xfrc_applied[body,3]=0.0002
        elif kind=="pullout" and data.time>=1:
            data.xfrc_applied[body,2]=1.1*actual_mass*9.81
        mujoco.mj_step(model,data)
        if data.time<=last:
            time_resets.append(step)
        last=float(data.time)
        max_warn=np.maximum(max_warn,[w.number for w in data.warning])
        contacts=contact_log(model,data,body)
        fixture_force=sum(max(0,row["normal_force_N"]) for row in contacts if row["kind"]=="fixture")
        table_force=sum(max(0,row["normal_force_N"]) for row in contacts if row["kind"]=="table")
        side_force=sum(max(0,row["normal_force_N"]) for row in contacts if any(name.startswith("fixture-wall-") for name in row["geom_names"]))
        rows.append([data.time,*data.qpos,*data.qvel,tilt(data.qpos[3:7]),fixture_force,table_force,side_force,len(contacts)])
        if step%max(1,round(.05/dt))==0 or step==count-1:
            force_rows.append({"time_s":float(data.time),"contacts":contacts})
    arr=np.array(rows)
    tilt_values=arr[:,14]
    # Columns: t(0),qpos(1..7),qvel(8..13),tilt14,fixture15,table16,side17,ncontact18.
    finite=bool(np.isfinite(arr).all())
    passed=finite and not time_resets and not max_warn.any()
    if kind=="pullout":
        config=cup_spec(fixture)
        rim=config.wall_height_m if config else 0
        clear=bool(data.qpos[2]-.002>rim+.0001)
        final_contacts=contact_log(model,data,body)
        passed &= clear and len(final_contacts)==0
    else:
        clear=None
        passed &= float(tilt_values[-1])<15 and float(data.qpos[2])>.001
    stem=f"{fixture}_{round(dt*1e6)}us_{kind}"
    np.savez_compressed(out/f"{stem}.npz",rows=arr,column_names=np.array(["time_s",*[f"qpos{i}" for i in range(7)],*[f"qvel{i}" for i in range(6)],"tilt_deg","fixture_normal_sum_N","table_normal_sum_N","wall_normal_sum_N","object_contacts"]))
    (out/f"{stem}.xml").write_text(xml)
    result={"fixture":fixture,"test":kind,"dt_s":dt,"duration_s":duration,"steps":count,
        "passed_fixture_mechanics_check":bool(passed),"not_a_grasp_test":True,"actual_mass_kg":actual_mass,
        "object_nq":model.nq,"object_freejoint":True,"equality_count":model.neq,
        "initial_pose":[0,0,.002,1,0,0,0],"final_qpos":data.qpos.copy().tolist(),
        "maximum_tilt_deg":float(tilt_values.max()),"final_tilt_deg":float(tilt_values[-1]),
        "maximum_wall_normal_force_N":float(arr[:,17].max()),"final_fixture_normal_force_N":float(arr[-1,15]),
        "final_table_normal_force_N":float(arr[-1,16]),"free_upward_exit_verified":clear,
        "finite":finite,"unexpected_time_resets":time_resets,"warning_counts":max_warn.tolist(),
        "perturbation":"0.0002 Nm x-axis torque for 40ms at t=1s" if kind=="perturb" else None,
        "pull_verification":"1.1 × weight upward force at COM during t=1..1.3s; test rig only, not candidate control" if kind=="pullout" else None,
        "force_samples":force_rows,"trace":str(out/f"{stem}.npz"),"model_xml":str(out/f"{stem}.xml")}
    (out/f"{stem}.json").write_text(json.dumps(result,indent=2)+"\n")
    return {k:v for k,v in result.items() if k!="force_samples"}


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--outdir",type=Path,default=Path(__file__).parent/"validation")
    parser.add_argument("--fixture",choices=("shallow","deep"),default="shallow")
    parser.add_argument("--timesteps",type=float,nargs="+",default=[.004,.001])
    args=parser.parse_args()
    args.outdir.mkdir(parents=True,exist_ok=True)
    results=[]
    for dt in args.timesteps:
        for kind in ("rest","perturb","pullout"):
            row=run(args.fixture,dt,kind,args.outdir)
            results.append(row)
            print(json.dumps({k:row[k] for k in ("fixture","test","dt_s","passed_fixture_mechanics_check","maximum_tilt_deg","final_tilt_deg","final_qpos","free_upward_exit_verified")}),flush=True)
    summary={"geometry":geometry_definition(args.fixture),"results":results,"scope":"No-hand local fixture mechanics only; does not establish Shadow grasp success. No old benchmark result is modified."}
    (args.outdir/"summary.json").write_text(json.dumps(summary,indent=2)+"\n")


if __name__=="__main__":
    main()
