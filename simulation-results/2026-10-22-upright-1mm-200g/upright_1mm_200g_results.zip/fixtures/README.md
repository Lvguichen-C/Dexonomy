# 1 mm upright cylinder: isolated static fixtures

`fixture_scene.py` adds only static world geometry before model compilation. No body, joint, actuator, object weld or spring is added. The existing hand-to-mocap weld remains the only equality in the hand scene. The cylinder remains a free object of diameter 1 mm, height 4 mm and compiled mass approximately 0.2 kg, with initial center `[0,0,0.002]` and identity orientation.

The active shallow cup has a minimum 1.2 mm circular opening, 0.75 mm wall height, 5 mm nominal outside diameter and 32 overlapping tangential box segments. Their inner faces form a closed regular polygon with apothem 0.6 mm; the opening grows to at most 1.20581 mm between face normals. The upright rod has at least 0.1 mm radial clearance and 3.25 mm exposed height. Tangential boxes overlap, rather than leaving gaps between radial spokes.

The physical bottom is 0.2 mm thick with its upper surface at `z=0`. Only this new fixture scene lowers the table plane to `z=-0.2 mm`; the original object center and all old scene files remain unchanged. Fixture collision margin is zero. `priority=1` makes the actual rod/fixture contact use the declared `condim=3`, friction `[0.6,0.00002,0.000001]` and `solref=[0.01,1]`, avoiding inheritance of the old rod's large torsional-friction setting. The hand and rod parameters themselves are not changed by the wrapper.

```python
from fixture_scene import make_env
env = make_env(scene, hand_xml, fixture="shallow", mass_kg=0.2, timestep=0.001)
```

`with_fixture_env_class(base_cls, fixture)` works with the original environment class interface, and `add_fixture_to_spec(spec, fixture)` is available when a caller builds its own model. A caller using the latter must also apply the documented table height. `contact_log(model,data,object_body_id)` returns actual solved normal forces, contact dimensions, geometry names and signed distances for fixture/table/other contacts.

`validation-priority1/summary.json` is the final no-hand mechanical validation. At 1 ms, three-second rest remained upright (maximum tilt 6.19°, final 4.92°); a separate 40 ms torque perturbation of 0.0002 N·m remained upright (maximum 1.05°, final 0.90°). The 4 ms counterparts also did not fall (rest maximum 5.16°, perturbation maximum 11.26°). All states were finite with zero warnings or time resets. Actual fixture contact dimension is 3, the bottom carries approximately 1.95–2.00 N at rest, and the lower table contributes zero normal force.

A separate no-hand pull test applies 1.1 times the rod weight vertically at its center of mass. Both time steps let the free object clear the cup with zero final cup/table contacts. The unsupported object rotates after extraction; this check proves no mechanical lock and does not prove a successful grasp or orientation hold. Per-step traces, actual contact-force samples, model XML and each trial's metrics are preserved.

`validation/` is a superseded diagnostic with equal contact priority: it inherited the rod's torsional contact and sometimes contacted both bottom and lower table. Do not use those first results as the final fixture validation.

The optional deep cup is specified by `cup_spec("deep")` with 2.5 mm wall height and 1.5 mm exposed rod. It has not been run because the shallow cup already remains upright; deep geometry should be used only if the user-authorized stability fallback is needed, not as a response to a failed grip caused by obstruction.

These are fixture mechanics tests only. Candidate grasp tests remain separate: require real hand/object contacts and zero fixture/table contacts throughout the post-lift hold; no support force may be counted as a successful hand grasp. Candidate physics is launched by the root agent after this setup review.
