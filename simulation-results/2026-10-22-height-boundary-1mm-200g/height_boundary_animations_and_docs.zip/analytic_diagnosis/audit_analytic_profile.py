#!/usr/bin/env python3
"""Zero-step paired model audit, including analytic+micro composition."""
import json
from pathlib import Path
import sys
from types import SimpleNamespace

import mujoco
import numpy as np

ROOT=Path(__file__).resolve().parent.parent
sys.path.insert(0,str(ROOT))
import scene_factory as factory
import analytic_cylinder_profile as analytic
import micro_contact_profile as micro

HAND="/workspace/Dexonomy/assets/hand/shadow/right.xml"


def native_micro(scene,support):
    # Micro's temporary class hook is preserved; it delegates model creation to
    # the analytic constructor without mutating the real factory.make_env.
    facade=SimpleNamespace(fixture_module=factory.fixture_module,
        make_env=lambda *a,**k:analytic.make_env_analytic(factory,*a,**k))
    return micro.make_env_micro(facade,scene,HAND,fixture=support,mass=.2,timestep=.001)


def main():
    source_sha=analytic.sha256(analytic.__file__)
    rows=[]
    jobs=[(h,s,False) for h in (12,40,240) for s in ("plain","shallow")]+[(40,s,True) for s in ("plain","shallow")]
    for height,support,use_micro in jobs:
        scene=factory.load_height_scene(height)
        if use_micro:
            base=micro.make_env_micro(factory,scene,HAND,fixture=support,mass=.2,timestep=.001)
            native=native_micro(scene,support)
        else:
            base=factory.make_env(scene,HAND,fixture=support,mass=.2,timestep=.001)
            native=analytic.make_env_analytic(factory,scene,HAND,fixture=support,mass=.2,timestep=.001)
        x,y=base._model,native._model;b=base._obj_active_bodyid
        assert b==native._obj_active_bodyid
        for count in ("nbody","ngeom","njnt","nq","nv","nu","neq","nmocap","npair"):
            assert getattr(x,count)==getattr(y,count),(height,support,use_micro,count)
        mask=np.arange(x.nbody)!=b
        for key in ("mass","inertia","ipos","iquat","pos","quat","parentid","mocapid"):
            np.testing.assert_array_equal(getattr(x,"body_"+key)[mask],getattr(y,"body_"+key)[mask])
        for key in ("friction","condim","priority","margin","gap","solref","solimp","solmix","contype","conaffinity"):
            np.testing.assert_array_equal(getattr(x,"geom_"+key),getattr(y,"geom_"+key))
        geom_mask=x.geom_bodyid!=b
        for key in ("size","pos","quat","type","rgba","matid"):
            np.testing.assert_array_equal(getattr(x,"geom_"+key)[geom_mask],getattr(y,"geom_"+key)[geom_mask])
        for key in ("timestep","integrator","solver","iterations","ls_iterations","tolerance","noslip_iterations","noslip_tolerance","impratio","cone","gravity","disableflags","enableflags"):
            np.testing.assert_array_equal(getattr(x.opt,key),getattr(y.opt,key))
        for key in ("type","obj1id","obj2id","solref","solimp","data","active0"):
            np.testing.assert_array_equal(getattr(x,"eq_"+key),getattr(y,"eq_"+key))
        np.testing.assert_array_equal(x.qpos0,y.qpos0)
        assert abs(x.body_subtreemass[b]-y.body_subtreemass[b])<1e-12
        assert np.max(np.abs(native._data.xfrc_applied[b]))==0
        if use_micro:
            assert y.npair>=2
            for key in ("dim","geom1","geom2","friction","margin","gap","solref","solimp"):
                np.testing.assert_array_equal(getattr(x,"pair_"+key),getattr(y,"pair_"+key))
            assert native.micro_contact_definition["explicit_pair_count"]==y.npair
        row={"height_mm":height,"fixture":support,"micro_contact":use_micro,"physics_steps_executed":0,
             "same_nonobject_bodies_and_geoms":True,"same_all_geom_material_parameters":True,"same_solver_gravity_timestep":True,"same_equality_arrays":True,"same_qpos0_and_index_layout":True,
             "same_explicit_micro_pairs":True if use_micro else None,
             "mesh_mass_kg":float(x.body_subtreemass[b]),"native_mass_kg":float(y.body_subtreemass[b]),
             "mesh_object_inertia_kg_m2":x.body_inertia[b].tolist(),"native_object_inertia_kg_m2":y.body_inertia[b].tolist(),
             "native_minus_mesh_inertia_relative":(y.body_inertia[b]/x.body_inertia[b]-1).tolist(),
             "native_definition":native.analytic_cylinder_definition,
             "micro_definition":getattr(native,"micro_contact_definition",None)}
        rows.append(row)
        report={"scope":"Paired compile-only geometry-sensitivity audit; no stability or grasp claim; no mj_step",
                "profile_id":analytic.PROFILE_ID,"adapter_sha256":source_sha,"factory_sha256":analytic.sha256(factory.__file__),"micro_source_sha256":analytic.sha256(micro.__file__),"audit_script_sha256":analytic.sha256(__file__),"completed_cases":len(rows),"expected_cases":len(jobs),"rows":rows}
        path=ROOT/"analytic_diagnosis/compiled-profile-audit.json";temp=path.with_suffix('.json.tmp');temp.write_text(json.dumps(report,indent=2)+'\n');temp.replace(path)
        print(json.dumps({"height_mm":height,"fixture":support,"micro":use_micro,"mass_kg":row["native_mass_kg"],"paired_nonobject_params_identical":True,"physics_steps":0}),flush=True)
        del base,native
    assert analytic.sha256(analytic.__file__)==source_sha


if __name__=="__main__":main()
