# 原生圆柱几何独立诊断

`analytic_cylinder_profile.py` 是独立模型敏感性profile；原`scene_factory.py`、64边mesh及所有已跑trial均未修改。

```python
import analytic_cylinder_profile as analytic
env = analytic.make_env_analytic(
    factory, scene, hand_xml, fixture="plain", mass=.2, timestep=.001)
# 结果应保存 env.analytic_cylinder_definition
```

profile为`native_cylinder_same_contact_v1`，源码SHA256：
`9c1b4cb9d628ef6b06b2c7c72f67647aa41aff9558d70b7abf1fd904bd05e17e`。

该构造器创建局部环境子类，在第一次编译之前将原对象唯一geom从mesh改为MuJoCo原生cylinder，保留其名称、材料和所在body/joint；半径0.5mm、半高H/2、局部轴z、identity旋转。该同一geom既用于碰撞，也以真实尺寸显示，没有视觉放大。显式geom质量为0.2kg，MuJoCo按原生实心圆柱自动计算解析惯量。自由关节、初始中心H/2、重力、手模型、浅托、摩擦、solver及控制器均保留原设置。构造器不使用全局monkeypatch、不替换已缓存环境的compiled model，也不执行积分。

原64边圆柱与连续圆的名义直径均为1mm。64边形侧面到外接圆最大弓高约0.6023µm；解析圆柱固定质量后的轴向惯量相对原网格增加约0.16077%，横向惯量差更小。此处改变的是几何表示与相应解析惯量，不能把其成绩并入旧mesh序列后宣称仅高度产生因果效果。

## 与micro HO profile组合

`make_env_micro` 临时包裹fixture class hook，该hook由原生构造器正常读取。可用只暴露两个入口的facade避免改真实factory.make_env：

```python
from types import SimpleNamespace
from micro_contact_profile import make_env_micro

facade = SimpleNamespace(
    fixture_module=factory.fixture_module,
    make_env=lambda *a, **k: analytic.make_env_analytic(factory, *a, **k))
env = make_env_micro(facade, scene, hand_xml,
                     fixture="plain", mass=.2, timestep=.001)
# 必须同时保存 analytic_cylinder_definition 和 micro_contact_definition
```

组合后显式HO contact pair来自原micro profile，未额外改变对象–地面/浅托材料。正式结果必须独立命名并记录几何和接触两个profile。原micro wrapper自身的临时hook仍应在单个隔离worker中使用。

## 零积分实际编译审计

`audit_analytic_profile.py` 生成`compiled-profile-audit.json`。已实际比较：H12/H40/H240的plain/shallow共6组，以及H40的micro plain/shallow两组，共8组mesh/native配对。每组核验：

- 相同body/geom/joint/actuator/equality索引布局；非对象body质量/惯量/位姿完全相同。
- 所有geom材料参数逐值相同；非对象geom类型/尺寸/位姿/颜色逐值相同。
- solver、gravity、timestep、equality、qpos0逐值相同。
- 质量0.2kg、native解析惯量与真实半径/高度；对象无附加equality或外力。
- H40两个micro组合的全部pair geom索引、friction、condim、margin、gap、solref、solimp逐值相同。

所有检查通过，累计执行0个物理步。这证明模型构造和组合可用，不证明任何稳定、接触可靠性或抓取成功。
