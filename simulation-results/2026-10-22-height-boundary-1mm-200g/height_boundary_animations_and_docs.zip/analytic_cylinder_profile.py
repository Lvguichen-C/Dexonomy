#!/usr/bin/env python3
"""Isolated native-cylinder shape sensitivity; no controller/contact changes.

The frozen mesh factory is read-only. A local subclass replaces its one object
geom before initial compilation, retaining all names, hand/support and material
parameters. No global monkeypatch, recompiled-environment cache or mj_step.
"""
from __future__ import annotations
import copy
import hashlib
import math
from pathlib import Path

import mujoco
import numpy as np

PROFILE_ID="native_cylinder_same_contact_v1"
RADIUS_M=.0005


def sha256(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def make_env_analytic(factory,scene,hand_xml,fixture="plain",mass=.2,timestep=.001,mass_kg=None):
    """Factory-compatible isolated native D1mm cylinder, integer H>=10mm."""
    from dexonomy.sim import HandCfg,MuJoCo_EvalCfg
    if mass_kg is not None:
        mass=mass_kg
    if abs(float(mass)-.2)>1e-12:
        raise ValueError("This diagnostic profile holds object mass fixed at .2kg")
    if fixture not in ("plain","shallow"):
        raise ValueError("Only the frozen plain/shallow conditions are supported")
    scene=copy.deepcopy(scene)
    obj=scene["scene"][scene["task"]["obj_name"]]
    if obj["type"]!="rigid_object" or sum(c["type"]=="rigid_object" for c in scene["scene"].values())!=1:
        raise ValueError("Exactly one free rigid cylinder is required")
    height_mm=float(obj["scale"][2])*4000
    height=factory.validated_height(round(height_mm))
    if abs(height_mm-height)>1e-7 or not np.allclose(obj["scale"][:2],[.001,.001],rtol=0,atol=1e-12):
        raise ValueError("Expected D1mm and integer height>=10mm")
    if not np.allclose(obj["pose"],[0,0,height/2000,1,0,0,0],rtol=0,atol=1e-8):
        raise ValueError("Object must begin upright at H/2 with bottom z0")
    if abs(float(scene["scene"]["table"]["pose"][2]))>1e-12:
        raise ValueError("Base scene plane must be0; support offset is applied once")
    halfheight=height/2000
    density=float(mass)/(math.pi*RADIUS_M**2*(height/1000))
    obj["density"]=density
    api=factory.fixture_module()
    parent=api.with_fixture_env_class(factory.frozen_module().SweepEnv,fixture)

    class NativeCylinderEnv(parent):
        def _add_rigid_object(self,name,*args,**kwargs):
            result=super()._add_rigid_object(name,*args,**kwargs)
            geoms=[g for g in self._spec.geoms if g.parent.name==self._cfg.obj_prefix+name+"world"]
            if len(geoms)!=1 or geoms[0].type!=mujoco.mjtGeom.mjGEOM_MESH:
                raise RuntimeError("Expected one original mesh object collision/visual geom")
            geom=geoms[0]
            geom.type=mujoco.mjtGeom.mjGEOM_CYLINDER
            geom.meshname=""
            geom.size=[RADIUS_M,halfheight,0]
            geom.pos=[0,0,0]
            geom.quat=[1,0,0,0]
            # MuJoCo computes the exact primitive inertia from this one mass.
            # Explicit geom mass overrides density; neither body inertia nor
            # object pose is overwritten after compilation.
            geom.mass=float(mass)
            geom.density=density
            return result

    cfg=MuJoCo_EvalCfg(miu_coef=[.6,.02])
    cfg.timestep=float(timestep)
    env=NativeCylinderEnv(hand_cfg=HandCfg(str(hand_xml),freejoint=True),scene_cfg=scene,sim_cfg=cfg,debug_render=False,debug_view=False)
    m=env._model;b=env._obj_active_bodyid
    m.opt.disableflags&=~int(mujoco.mjtDisableBit.mjDSBL_GRAVITY)
    m.opt.gravity[:]=[0,0,-9.81]
    # Reflect the runtime setting in this new profile's construction export.
    env._spec.option.disableflags&=~int(mujoco.mjtDisableBit.mjDSBL_GRAVITY)
    env._spec.option.gravity=[0,0,-9.81]
    for i in range(m.ngeom):
        if m.body(int(m.geom_bodyid[i])).name.startswith("hand-"):
            m.geom_matid[i]=-1
            m.geom_rgba[i]=[.863157,.0865002,.0802199,1]
    geoms=[i for i in range(m.ngeom) if m.geom_bodyid[i]==b]
    if len(geoms)!=1 or m.geom_type[geoms[0]]!=mujoco.mjtGeom.mjGEOM_CYLINDER:
        raise RuntimeError("Native cylinder collision/visual replacement failed")
    g=geoms[0]
    analytic_I=np.array([float(mass)*(3*RADIUS_M**2+(height/1000)**2)/12]*2+[float(mass)*RADIUS_M**2/2])
    if abs(float(m.body_subtreemass[b])-float(mass))>1e-12:
        raise RuntimeError("Compiled native-cylinder mass mismatch")
    np.testing.assert_allclose(np.sort(m.body_inertia[b]),np.sort(analytic_I),rtol=1e-12,atol=1e-20)
    np.testing.assert_allclose(m.geom_size[g],[RADIUS_M,halfheight,0],rtol=0,atol=1e-15)
    np.testing.assert_allclose(m.geom_quat[g],[1,0,0,0],rtol=0,atol=1e-15)
    joint=int(m.body_jntadr[b])
    assert m.body_jntnum[b]==1 and m.jnt_type[joint]==mujoco.mjtJoint.mjJNT_FREE
    assert all(b not in (m.eq_obj1id[i],m.eq_obj2id[i]) for i in range(m.neq))
    env.fixture_definition=api.geometry_definition(fixture)
    env.fixture_definition.update(height_mm=height,diameter_mm=1,object_initial_center_m=[0,0,height/2000],
        object_initial_quaternion_wxyz=[1,0,0,0],support_policy="Rod bottom z0, center H/2; unchanged fixed shallow support or plain plane",exposed_upright_object_length_m=height/1000-(.00075 if fixture=="shallow" else 0))
    env.fixture_geom_ids=[i for i in range(m.ngeom) if m.geom(i).name.startswith("fixture-")]
    env.height_mm=height
    env.density_calibration={"analytic_density_kg_m3":density,"effective_density_kg_m3":density,"compile_passes":1,"actual_mass_kg":float(m.body_subtreemass[b]),"mass_assignment":"One primitive geom explicit mass; MuJoCo-derived analytic inertia"}
    polygon_Izz=float(mass)*RADIUS_M**2*(2+math.cos(2*math.pi/64))/6
    env.analytic_cylinder_definition={
        "profile_id":PROFILE_ID,"adapter_sha256":sha256(__file__),"factory_sha256":sha256(factory.__file__),
        "fixture_source_sha256":factory.FIXTURE_SHA256,"hand_xml":str(hand_xml),"hand_xml_sha256":sha256(hand_xml),
        "geometry":"MuJoCo native cylinder; the same one geom handles collision and true-scale rendering",
        "radius_m":RADIUS_M,"halfheight_m":halfheight,"height_mm":height,"diameter_mm":1,
        "actual_mass_kg":float(m.body_subtreemass[b]),"analytic_inertia_kg_m2":analytic_I.tolist(),"actual_inertia_kg_m2":m.body_inertia[b].tolist(),
        "body_axis":"Cylinder local z; geom identity rotation","object_freejoint":True,"no_object_equality":True,
        "actual_initial_qpos":m.qpos0[int(m.jnt_qposadr[joint]):int(m.jnt_qposadr[joint])+7].tolist(),
        "gravity_enabled":True,"gravity_m_s2":m.opt.gravity.tolist(),"timestep_s":float(m.opt.timestep),
        "material":{key:getattr(m,"geom_"+key)[g].tolist() for key in ["friction","condim","priority","margin","gap","solref","solimp","solmix","contype","conaffinity"]},
        "hand_support_friction_solver_controllers_unchanged":True,"object_external_actuation_added":False,
        "separate_geometry_sensitivity_not_height_only_causal_comparison":True,
        "ideal_regular64_reference_polar_inertia_kg_m2":polygon_Izz,
        "native_vs_regular64_polar_inertia_relative_change":analytic_I[2]/polygon_Izz-1,
        "maximum_nominal_polygon_side_sagitta_m":RADIUS_M*(1-math.cos(math.pi/64)),
        "no_physics_steps_in_constructor":True,
    }
    return env
