#!/usr/bin/env python3
"""Yaw damping through an ordinary hand-root trajectory about the rod center.

The successful two-task finger controller remains unchanged. A distinct root
trajectory counters measured free-rod axial spin; all reaction forces come
through the unchanged root weld and genuine dim3 finger/object contacts.
"""
from __future__ import annotations
import argparse
import json
from pathlib import Path
import sys
from types import MethodType
import mujoco
import numpy as np
from scipy.spatial.transform import Rotation

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT))
import normal_contact_axis_profile as axial
normal = axial.normal
BaseRootFeedback = normal.AnchoredRootFeedback
SETTINGS = dict(yaw_position_gain_per_s=10., axial_velocity_feedback_gain=.5,
               yaw_deadband_deg=.1, maximum_root_yaw_velocity_rad_s=1.,
               maximum_root_yaw_acceleration_rad_s2=5., maximum_root_yaw_angle_deg=180.,
               active_phases=['loaded_hold', 'lift', 'postlift_hold'],
               yaw_rotation_axis_world=[0., 0., 1.],
               pivot_policy='Capture actual rod center at loaded start; rotate nominal root pose about this fixed world-vertical pivot, preserving its nominal z trajectory.',
               release_policy='Stop yaw feedback and retain the reached wrist yaw through opening, retreat and settling to avoid a sudden root jump.',
               original_root_weld_and_finger_controller_changed=False,
               object_pose_or_force_directly_written=False,
               strict_success_conditions_changed=False)
PROFILE = 'normal_integrator_contact_axis_root_twist_preload5'


class RootTwistFeedback(BaseRootFeedback):
    def __init__(self, env):
        super().__init__(env)
        self.raw_nominal = self.nominal.copy()
        self.object_reference = None
        self.pivot = None
        self.yaw_angle = 0.
        self.yaw_velocity = 0.
        self.yaw_logs = []

    def install(self):
        super().install()
        base_set = self.env.set_ctrl
        base_step = self.env.step_sim
        c = self

        def set_control(env, qpos, ctrl_type='ee_pose', *args, **kwargs):
            c.raw_nominal = np.asarray(qpos[:7], float).copy()
            return base_set(qpos, ctrl_type, *args, **kwargs)

        def step(env, substep):
            dt = float(env._model.opt.timestep)
            bid = env._obj_active_bodyid
            for _ in range(substep):
                phase = getattr(env.observer, 'phase', 'inactive')
                active = phase in SETTINGS['active_phases']
                actual_rotation = env._data.xmat[bid].reshape(3, 3).copy()
                yaw_error = 0.
                omega = 0.
                if active:
                    if c.object_reference is None:
                        c.object_reference = actual_rotation.copy()
                        c.pivot = env._data.xpos[bid].copy()
                    relative = Rotation.from_matrix(actual_rotation @ c.object_reference.T).as_quat()
                    yaw_error = float(2. * np.arctan2(relative[2], relative[3]))
                    yaw_error = float((yaw_error + np.pi) % (2. * np.pi) - np.pi)
                    velocity = np.zeros(6)
                    mujoco.mj_objectVelocity(env._model, env._data, mujoco.mjtObj.mjOBJ_BODY, bid, velocity, 0)
                    omega = float(velocity[:3] @ actual_rotation[:, 2])
                    db = np.radians(SETTINGS['yaw_deadband_deg'])
                    error_with_deadband = np.sign(yaw_error) * max(0., abs(yaw_error) - db)
                    desired_velocity = np.clip(-SETTINGS['yaw_position_gain_per_s'] * error_with_deadband - SETTINGS['axial_velocity_feedback_gain'] * omega,
                        -SETTINGS['maximum_root_yaw_velocity_rad_s'], SETTINGS['maximum_root_yaw_velocity_rad_s'])
                    c.yaw_velocity += float(np.clip(desired_velocity - c.yaw_velocity,
                        -SETTINGS['maximum_root_yaw_acceleration_rad_s2'] * dt, SETTINGS['maximum_root_yaw_acceleration_rad_s2'] * dt))
                    limit = np.radians(SETTINGS['maximum_root_yaw_angle_deg'])
                    c.yaw_angle = float(np.clip(c.yaw_angle + c.yaw_velocity * dt, -limit, limit))
                    if abs(c.yaw_angle) >= limit and c.yaw_angle * c.yaw_velocity > 0:
                        c.yaw_velocity = 0.
                else:
                    c.yaw_velocity = 0.
                corrected = c.raw_nominal.copy()
                if c.pivot is not None:
                    rot = Rotation.from_rotvec(np.array([0., 0., c.yaw_angle]))
                    corrected[:3] = c.pivot + rot.apply(c.raw_nominal[:3] - c.pivot)
                    raw_rotation = Rotation.from_quat(np.r_[c.raw_nominal[4:7], c.raw_nominal[3]])
                    quat_xyzw = (rot * raw_rotation).as_quat()
                    corrected[3:7] = np.r_[quat_xyzw[3], quat_xyzw[:3]]
                c.nominal = corrected
                base_step(1)
                object_quat = np.zeros(4)
                mujoco.mju_mat2Quat(object_quat, env._data.xmat[bid])
                c.yaw_logs.append((float(env._data.time), str(phase), active,
                    c.raw_nominal.copy(), corrected.copy(), env._data.mocap_pos[0].copy(), env._data.mocap_quat[0].copy(),
                    np.r_[env._data.xpos[bid], object_quat], yaw_error, omega,
                    c.yaw_angle, c.yaw_velocity, np.zeros(3) if c.pivot is None else c.pivot.copy()))

        self.env.set_ctrl = MethodType(set_control, self.env)
        self.env.step_sim = MethodType(step, self.env)

    def finish(self, folder):
        record = super().finish(folder)
        names = ['time_s', 'phase', 'feedback_active', 'raw_planner_root_pose', 'yaw_adjusted_nominal_root_pose',
                 'actual_mocap_position', 'actual_mocap_quaternion_wxyz', 'actual_object_pose',
                 'measured_object_yaw_error_rad', 'measured_object_axial_angular_velocity_rad_s',
                 'commanded_root_yaw_angle_rad', 'commanded_root_yaw_velocity_rad_s', 'captured_pivot_world']
        np.savez_compressed(folder / 'root_twist_feedback.npz', **{name: np.asarray([row[i] for row in self.yaw_logs]) for i, name in enumerate(names)})
        record['root_twist_intervention'] = dict(adapter_source=str(Path(__file__).resolve()), adapter_sha256=normal.runner.sha(__file__),
            settings=SETTINGS, feedback_trace=str((folder / 'root_twist_feedback.npz').resolve()),
            feedback_sha256=normal.runner.sha(folder / 'root_twist_feedback.npz'))
        return record


def run_trial(job):
    original = normal.AnchoredRootFeedback
    normal.AnchoredRootFeedback = RootTwistFeedback
    try:
        result = axial.run_trial(job)
    finally:
        normal.AnchoredRootFeedback = original
    folder = Path(job['output'])
    metrics = json.loads((folder / 'metrics.json').read_text())
    metrics.update(comparison_profile=PROFILE,
        root_twist_intervention=metrics['root_pose_feedback_intervention']['root_twist_intervention'])
    normal.runner.write_json(folder / 'metrics.json', metrics)
    result.update(comparison_profile=PROFILE)
    normal.runner.write_json(folder / 'result.json', result)
    print(json.dumps(result, ensure_ascii=False), flush=True)
    return result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--job', type=Path)
    parser.add_argument('--manifest', type=Path, default=ROOT / 'grasp_search/d5-h060-normalmapped-frozen.json')
    parser.add_argument('--candidate', default='h060_d5_normalmapped_release_squeeze0')
    parser.add_argument('--condition', choices=['plain', 'shallow'], default='plain')
    args = parser.parse_args()
    if args.job:
        return run_trial(json.loads(args.job.read_text()))
    variant = dict(next(v for v in json.loads(args.manifest.read_text())['variants'] if v['id'] == args.candidate))
    variant['id'] += '_normal_contact_axis_root_twist_preload5'
    job = dict(variant=variant, fixture=args.condition, resume=False,
        output=str((ROOT / 'trials' / f"h{variant['height_mm']:03d}" / args.condition / variant['id']).resolve()),
        declared_root_yaw_trajectory_settings=SETTINGS, declared_preload_duration_s=5.,
        provenance_sources=[str(Path(__file__).resolve()), str(Path(axial.__file__).resolve()), str(Path(normal.__file__).resolve()),
                            str(ROOT / 'anchored_root_control.py'), str(ROOT / 'micro_contact_profile.py')])
    out = ROOT / 'control_analysis/jobs'
    out.mkdir(exist_ok=True)
    normal.runner.write_json(out / f'{args.condition}__{variant["id"]}.json', job)
    return run_trial(job)


if __name__ == '__main__':
    main()
