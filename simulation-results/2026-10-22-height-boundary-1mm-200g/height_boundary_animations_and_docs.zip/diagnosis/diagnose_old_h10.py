#!/usr/bin/env python3
"""Read-only reduction of old H10 actual traces; no mj_step or source edits."""
from pathlib import Path
import hashlib,json,math
import mujoco
import numpy as np
ROOT=Path(__file__).resolve().parent
OLD=Path('/workspace/shadow-height-gradient-1mm-200g-20261022')
ID='h010_palmar_oracle_v1_squeeze005_force_clamp_root_micro'
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def angle(q1,q2):return math.degrees(2*math.acos(float(np.clip(abs(np.dot(q1,q2))/(np.linalg.norm(q1)*np.linalg.norm(q2)),0,1))))
def gap(model,data,left,right):
 best=(math.inf,None,None)
 for a in left:
  for b in right:
   v=np.zeros(6); dist=float(mujoco.mj_geomDistance(model,data,a,b,1,v))
   if dist<best[0]:best=(dist,[model.geom(a).name,model.geom(b).name],v.tolist())
 return {'distance_um':best[0]*1e6,'geom_names':best[1],'closest_points_world_m':best[2]}
rows=[]
for fixture in ['plain','shallow']:
 folder=OLD/'trials/h010'/fixture/ID
 files=[folder/n for n in ['metrics.json','diagnostics.npz','force_feedback.npz','root_pose_feedback.npz','trace.npz','model.mjb']]
 hashes={str(p):sha(p) for p in files}
 metrics=json.loads(files[0].read_text());d=np.load(files[1]);f=np.load(files[2]);r=np.load(files[3]);tr=np.load(files[4]);model=mujoco.MjModel.from_binary_path(str(files[5]));data=mujoco.MjData(model)
 assert np.allclose(d['time_s'],f['time_s'],rtol=0,atol=1e-12) and np.allclose(d['time_s'],r['time_s'],rtol=0,atol=1e-12)
 phases=d['phase_names'].tolist();loaded=np.flatnonzero(d['phase_id']==phases.index('loaded_hold'));lift=np.flatnonzero(d['phase_id']==phases.index('lift'));both=np.all(f['finger_contact_count']>0,axis=1)
 dual=loaded[both[loaded]];peak=loaded[np.argmax(np.min(f['actual_normal_force_N'][loaded],axis=1))]
 events=[('loaded_start',loaded[0]),('peak_balanced_normal',peak),('last_dual_in_loaded',dual[-1]),('loaded_end',loaded[-1]),('lift_start',lift[0])]
 if dual[-1]+1<len(d['time_s']):events.insert(3,('first_step_after_final_dual',dual[-1]+1))
 joint_names=[]
 for j in range(model.njnt):
  if model.body(int(model.jnt_bodyid[j])).name.startswith('hand-') and model.jnt_type[j]==mujoco.mjtJoint.mjJNT_HINGE:joint_names.append((model.joint(j).name,int(model.jnt_qposadr[j])))
 thumb=[i for i in range(model.ngeom) if model.body(int(model.geom_bodyid[i])).name.startswith('hand-rh_th') and (model.geom_contype[i] or model.geom_conaffinity[i])]
 index=[i for i in range(model.ngeom) if model.body(int(model.geom_bodyid[i])).name.startswith('hand-rh_ff') and (model.geom_contype[i] or model.geom_conaffinity[i])]
 obj=[i for i in range(model.ngeom) if model.body(int(model.geom_bodyid[i])).name.startswith('obj-') and (model.geom_contype[i] or model.geom_conaffinity[i])]
 base=loaded[0];event_rows=[]
 for name,i in events:
  ti=int(np.argmin(abs(tr['time_s']-d['time_s'][i])));data.qpos[:]=tr['qpos'][ti];data.ctrl[:]=tr['ctrl'][ti];data.mocap_pos[:]=tr['mocap_pos'][ti];data.mocap_quat[:]=tr['mocap_quat'][ti];mujoco.mj_forward(model,data)
  delta=d['actual_hand_qpos'][i]-d['actual_hand_qpos'][base];jd=sorted([(jn,float(delta[adr])) for jn,adr in joint_names],key=lambda x:abs(x[1]),reverse=True)[:5]
  ad=f['actual_actuator_ctrl'][i]-f['actual_actuator_ctrl'][base];ai=np.argsort(-abs(ad))[:5]
  event_rows.append({'event':name,'time_s':float(d['time_s'][i]),'tilt_deg':float(d['rod_tilt_deg'][i]),'object_z_mm':float(d['object_z_m'][i])*1000,'thumb_index_contacts':f['finger_contact_count'][i].tolist(),'actual_normal_force_N':f['actual_normal_force_N'][i].tolist(),'desired_normal_force_N':f['desired_normal_force_N'][i].tolist(),'commanded_inward_force_N':f['commanded_inward_force_N'][i].tolist(),'root_rotation_since_loaded_start_deg':angle(r['actual_root_pose'][i,3:],r['actual_root_pose'][base,3:]),'root_displacement_since_loaded_start_mm':float(np.linalg.norm(r['actual_root_pose'][i,:3]-r['actual_root_pose'][base,:3]))*1000,'anchored_root_error_mm':float(np.linalg.norm(r['anchored_position_error_m'][i]))*1000,'anchored_root_error_deg':math.degrees(float(np.linalg.norm(r['anchored_rotation_error_rotvec_rad'][i]))),'maximum_actual_actuator_offset_rad':float(np.max(abs(f['actuator_target_offset_rad'][i]))),'largest_actual_hinge_changes_since_loaded_start_rad':jd,'largest_applied_actuator_ctrl_changes_since_loaded_start_rad':[(str(f['actuator_names'][k]),float(ad[k])) for k in ai],'maximum_nominal_actuator_ctrl_change_since_loaded_start_rad':float(np.max(abs(f['nominal_actuator_ctrl'][i]-f['nominal_actuator_ctrl'][base]))),'actual_root_pose':r['actual_root_pose'][i].tolist(),'geometry_snapshot_time_s':float(tr['time_s'][ti]),'geometry_snapshot_offset_from_event_s':float(tr['time_s'][ti]-d['time_s'][i]),'geometry_snapshot_thumb_gap':gap(model,data,thumb,obj),'geometry_snapshot_index_gap':gap(model,data,index,obj)})
 entry={'fixture':fixture,'id':ID,'input_sha256':metrics['input_sha256'],'source_sha256':hashes,'events':event_rows,'loaded_dual_contact_fraction':float(np.mean(both[loaded])),'loaded_maximum_rod_tilt_deg':float(np.max(d['rod_tilt_deg'][loaded])),'loaded_root_maximum_anchored_error_mm':float(np.max(np.linalg.norm(r['anchored_position_error_m'][loaded],axis=1)))*1000,'loaded_root_maximum_anchored_error_deg':float(np.max(np.linalg.norm(r['anchored_rotation_error_rotvec_rad'][loaded],axis=1)))*180/math.pi,'nominal_actuator_targets_constant_during_loaded':bool(np.max(np.ptp(f['nominal_actuator_ctrl'][loaded],axis=0))==0),'all_lift_dual_contact_fraction':float(np.mean(both[lift])),'loaded_mean_normal_forces_N':np.mean(f['actual_normal_force_N'][loaded],axis=0).tolist(),'loaded_peak_normal_forces_N':np.max(f['actual_normal_force_N'][loaded],axis=0).tolist(),'measured_object_lift_mm':metrics['measured_object_lift_mm'],'original_files_unchanged_after_read':all(sha(p)==hashes[str(p)] for p in files)}
 rows.append(entry)
 print(fixture,'lastdual',d['time_s'][dual[-1]],'peak',d['time_s'][peak],'tilt max',entry['loaded_maximum_rod_tilt_deg'],'root anchored deg',entry['loaded_root_maximum_anchored_error_deg'])
 for e in event_rows: print(e['event'],round(e['time_s'],3),'tilt',round(e['tilt_deg'],3),'forces',e['actual_normal_force_N'],'rootdeg',round(e['root_rotation_since_loaded_start_deg'],6),'maxoffset',round(e['maximum_actual_actuator_offset_rad'],6))
(ROOT/'old-h10-loaded-diagnosis.json').write_text(json.dumps({'scope':'Read-only analysis of saved actual states/logs, no physics steps; geometry snapshots use actual nearest25Hz qpos and mj_forward only','rows':rows},ensure_ascii=False,indent=2)+'\n')
lines=['# 旧 H10 加载失败的只读时序诊断','','仅分析已发布 H10 `force_clamp_root_micro` 的实际状态与反馈日志；没有重新仿真，没有修改旧文件。力/接触/角度按1ms记录，几何间隙只对真实25Hz状态使用 `mj_forward` 查询，JSON明确每个事件与最近几何帧的时间差。','','| 条件 | loaded双指覆盖 | 最后双指时刻 s | loaded最大杆倾角° | root锚定最大角误差° | nominal开合目标是否恒定 | 实际升高 mm |','|---|---:|---:|---:|---:|---|---:|']
for row in rows:
 last=next(e for e in row['events'] if e['event']=='last_dual_in_loaded');lines.append(f"|{row['fixture']}|{row['loaded_dual_contact_fraction']:.1%}|{last['time_s']:.3f}|{row['loaded_maximum_rod_tilt_deg']:.3f}|{row['loaded_root_maximum_anchored_error_deg']:.6f}|{row['nominal_actuator_targets_constant_during_loaded']}|{row['measured_object_lift_mm']:+.6f}|")
lines+=['','可直接证实：loaded期间保存的nominal执行器目标保持不变，因而不是原计划在加载阶段主动开指。反馈对实际执行器目标施加了非零、有变化的偏置，关节与物体继续运动；plain杆在loaded内倒下，浅托限制了运动但仍丢失食指接触。双指接触在抬升命令开始前已消失，因此首要失败发生于加载夹紧阶段。','','根姿态反馈把实际根维持在进入loaded时捕获的参考附近；其锚定误差需与杆倾角变化分开看。微小根误差不代表指尖/联动关节或杆在接触中也稳定，不能用根位置跟踪精度代替夹持稳定性。','','反馈源码对单侧接触施加0.1N command上限，并将该侧积分限制为非正；在一侧接触丢失后，它会主动降低仍有接触一侧的推力，而另一侧是否能够重建接触取决于Jacobian到既有执行器空间的投影与位形。此机制与日志一致，但仅凭这两条轨迹不能把具体因果比例唯一分配给上限、投影或物体滑动；需要新的明确控制对照验证。','','每个事件的目标/实际normal力、实际关节变化、执行器偏置、root位姿、最近真实几何帧的双指间隙及全部源SHA见JSON。新的长杆优化应明确比较实际作用到执行器空间的闭合量与对向接触的再获得能力，而不是继续增大一个未真正落实的笛卡尔“期望力”。']
(ROOT/'old-h10-loaded-diagnosis.md').write_text('\n'.join(lines)+'\n')
