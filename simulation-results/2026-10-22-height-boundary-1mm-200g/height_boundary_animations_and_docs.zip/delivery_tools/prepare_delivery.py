#!/usr/bin/env python3
"""Readiness check by default; --build creates reviewed <=35MB local packages.

Never performs network operations. Main archive contains videos/docs/code and
small diagnostics; actual trial files are retained byte-for-byte in separate
condition archives. Requires final independent QA binding all final documents.
"""
from __future__ import annotations
import argparse
from collections import defaultdict
from fractions import Fraction
import hashlib
import json
import math
from pathlib import Path
import shutil
import subprocess
import tempfile
import xml.etree.ElementTree as ET
import zipfile

from common import CAP_BYTES, digest, plain_name, safe_source, validated_rows, write_json

ROOT = Path(__file__).resolve().parent.parent
REQUIRED_DOCS = ("BOUNDARY_REPORT.md", "PIPELINE.md", "search-results.json", "search-results.csv")
PUBLIC_REPORT_FIGURES=("h017_latch_comparison.png","h017_latch_comparison.svg")
ALLOWED = {".md", ".py", ".json", ".jsonl", ".log", ".csv", ".xml", ".mjb", ".npy", ".npz", ".png", ".jpg", ".svg", ".mp4", ".obj", ".stl", ".urdf", ".txt", ".yaml", ".yml"}
FORBIDDEN_PARTS = {"__pycache__", "newdeliverables", "publication", "publication-state", "download-verified", ".git", ".venv", "venv", "venvs", "attachments"}
FORBIDDEN_NAMES={"publication.json","public-download-verification.json"}


def resolve(path, parent=None):
    path = Path(path)
    parent = ROOT if parent is None else parent
    return safe_source(path if path.is_absolute() else parent / path)


def dependency_items(index):
    dependencies=index.get("dependencies",{})
    if isinstance(dependencies,dict):
        return list(dependencies.items())
    if isinstance(dependencies,list):
        return [(row["path"],row["sha256"]) for row in dependencies]
    raise ValueError("Unsupported dependency path/SHA collection")


def probe(path):
    value = json.loads(subprocess.check_output([
        "ffprobe", "-v", "error", "-select_streams", "v:0", "-show_entries",
        "stream=width,height,avg_frame_rate,nb_frames,duration", "-of", "json", str(path)
    ], text=True))["streams"][0]
    return {"width": int(value["width"]), "height": int(value["height"]),
            "fps": float(Fraction(value["avg_frame_rate"])), "frames": int(value["nb_frames"]),
            "duration_s": float(value["duration"])}


def insert(target, archive, source):
    source = safe_source(source)
    archive = str(Path(archive))
    if archive.startswith("/") or ".." in Path(archive).parts or "\\" in archive:
        raise ValueError(f"Unsafe archive path: {archive}")
    if archive in target and target[archive] != source:
        raise ValueError(f"Conflicting archive source: {archive}")
    target[archive] = source


def discover_trials(trial_roots):
    paths = set()
    for folder in trial_roots:
        for p in folder.rglob("metrics.json"):
            paths.add(p.resolve())
    if not paths:
        raise ValueError("No completed actual trials found")
    return paths


def validate_path_hashes(value, parent, checked=None):
    """Validate all explicit {path,sha256} bindings, including processors."""
    checked = {} if checked is None else checked
    if isinstance(value, dict):
        if isinstance(value.get("path"), str) and isinstance(value.get("sha256"), str):
            path = resolve(value["path"], parent)
            expected = value["sha256"]
            if path not in checked:
                checked[path] = digest(path)
            actual = checked[path]
            if actual != expected:
                raise ValueError(f"Index path/SHA binding changed: {path}")
        for child in value.values():
            validate_path_hashes(child, parent, checked)
    elif isinstance(value, list):
        for child in value:
            validate_path_hashes(child, parent, checked)
    return checked


def preview_selection(index,sources,videos,composites,qa,docs,extra=(),all_previews=False):
    """Keep primary/strict/QA evidence; other PNG previews are derivatives."""
    images={p.resolve() for p in (ROOT/"animations").rglob("*") if p.is_file() and p.suffix.lower() in (".png",".jpg")}
    if all_previews:
        return images,[]
    keep={p for p in images if not p.name.startswith("preview")}
    primary_ids={key for video in videos if video["path"] in composites for key in video["ids"]}
    public_dirs={p.parent for p in composites}
    for source in sources:
        previews=[row for row in source.get("previews",[]) if row.get("path")]
        if not previews:
            continue
        important=source["trial_id"] in primary_ids or any(source.get(k) is True for k in ("frozen_full_sequence_passed","qualified_full_sequence_passed","full_sequence_passed"))
        if important:
            chosen=previews
        else:
            hold=next((float(row["time_s"]) for row in source.get("phase_boundaries",[]) if row.get("phase")=="postlift_hold"),None)
            chosen=[min(previews,key=lambda row:abs(float(row.get("recorded_time_s",0))-(hold if hold is not None else float(previews[-2 if len(previews)>1 else 0].get("recorded_time_s",0)))))]
        keep.update(resolve(row["path"]) for row in chosen)
    keep.update(p for p in images if p.parent in public_dirs)
    protected=set()
    for path in [*extra,*qa.get("delivery_evidence_paths",[])]:
        image=resolve(path);keep.add(image);protected.add(image)
    # Explicitly referenced report images remain usable after extraction.
    import re
    for path in docs.values():
        if path.suffix.lower()==".md":
            for target in re.findall(r"!\[[^\]]*\]\(([^)]+)\)",path.read_text()):
                image=path.parent/target
                if image.is_file():keep.add(image.resolve());protected.add(image.resolve())
    # Deterministic repeats can have identical preview bytes. Keep one complete
    # copy and record explicit aliases for each original path, never touching
    # formal movies, model files, trajectory arrays or feedback logs.
    canonical={};aliases={}
    for path in sorted(keep,key=lambda p:(p not in protected,str(p))):
        expected=digest(path)
        if expected in canonical and path not in protected:
            aliases[path]=canonical[expected];keep.remove(path)
        else:
            canonical.setdefault(expected,path)
    omitted=[]
    for path in sorted(images-keep):
        row={"path":str(path),"sha256":digest(path),"bytes":path.stat().st_size}
        if path in aliases:
            row.update(reason="Exact duplicate derivative image; identical bytes retained once",retained_identical_image=str(aliases[path]))
        else:
            row["reason"]="Optional derivative debug preview; formal movie, model, trajectory and feedback are preserved"
        omitted.append(row)
    return keep,omitted


def validate_inputs(args):
    index_path = resolve(args.index)
    index = json.loads(index_path.read_text())
    qa_path = resolve(args.qa)
    qa = json.loads(qa_path.read_text())
    if qa.get(args.qa_ready_field) is not True:
        raise ValueError(f"Independent final QA {args.qa_ready_field} is not true")
    docs = {name: resolve(name) for name in args.documents}
    required_binding_paths=list(docs.values())
    ledgers = [resolve(path) for path in args.execution_ledger]
    if not ledgers:
        ledgers = sorted({p.resolve() for base in (ROOT,ROOT/"trials",ROOT/"control_analysis") for p in base.glob("*ledger*") if p.is_file() and p.suffix.lower() in ALLOWED and "execution" in p.name.lower()})
    if not ledgers and (ROOT/"execution-ledger/final-counts.json").is_file():
        ledgers=[resolve(ROOT/"execution-ledger/final-counts.json")]
    if not ledgers:
        raise ValueError("The execution ledger, including repeated execution events, is required")
    for num,path in enumerate(ledgers):
        name=f"execution-ledger-{path.name}" if path.parent.name=="execution-ledger" else path.name
        if name in docs:name=f"execution-ledger-{num}-{name}"
        docs[name] = path
    bound = qa.get(args.qa_hash_field)
    if not isinstance(bound, dict):
        raise ValueError(f"Final QA must contain {args.qa_hash_field} absolute-path bindings")
    for path in [*required_binding_paths, index_path]:
        if bound.get(str(path)) != digest(path):
            raise ValueError(f"Final QA binding missing/stale: {path}")
    for path, expected in bound.items():
        if digest(resolve(path)) != expected:
            raise ValueError(f"QA reviewed file changed: {path}")
    for path, expected in dependency_items(index):
        if digest(resolve(path)) != expected:
            raise ValueError(f"Animation dependency changed: {path}")
    validate_path_hashes(index, index_path.parent)
    sources = index.get("sources", [])
    by_id = {s["trial_id"]: s for s in sources}
    if not sources or len(by_id) != len(sources):
        raise ValueError("No animation sources or duplicate trial IDs")
    expected_trials = discover_trials(args.trials_root or [ROOT / "trials"])
    got_trials = {resolve(s["metrics"], index_path.parent) for s in sources}
    if got_trials != expected_trials:
        raise ValueError(f"Animation source coverage differs from actual trials: missing={sorted(map(str,expected_trials-got_trials))}, unexpected={sorted(map(str,got_trials-expected_trials))}")
    source_files = {}
    condition_sources = defaultdict(list)
    for source in sources:
        required = ("input", "metrics", "trace", "diagnostics", "model_mjb", "model_xml")
        files = {key: resolve(source[key], index_path.parent) for key in required}
        hashes = source["source_sha256"]
        for key, path in files.items():
            if hashes.get(key) != digest(path):
                raise ValueError(f"Source SHA missing/stale: {source['trial_id']}:{key}")
        # New transparent control ablations may add root-pose/force-feedback
        # arrays. Every extra index hash must resolve to a real preserved file.
        for key, expected in hashes.items():
            if key in files:
                continue
            if not isinstance(source.get(key), str):
                raise ValueError(f"Extra source hash has no explicit file path: {source['trial_id']}:{key}")
            path = resolve(source[key], index_path.parent)
            if digest(path) != expected:
                raise ValueError(f"Extra source hash changed: {source['trial_id']}:{key}")
            files[key] = path
        for num, processor in enumerate(source.get("processor_chain", [])):
            # Final indexed videos remain the only movies in the main ZIP. Preserve
            # original caption-processor inputs separately with their raw trial.
            if processor.get("input_video"):
                files[f"processor_{num}_input_video"] = resolve(processor["input_video"]["path"], index_path.parent)
        for num, intervention in enumerate(source.get("intervention_sources", [])):
            files[f"intervention_source_{num}"] = resolve(intervention["path"], index_path.parent)
        metrics = json.loads(files["metrics"].read_text())
        if metrics["input_sha256"] != digest(files["input"]):
            raise ValueError("Metrics/input binding changed")
        height=float(metrics["height_mm"])
        if metrics["fixture"] not in ("plain", "shallow") or not math.isfinite(height) or height<10 or height!=round(height):
            raise ValueError("Unexpected physical condition")
        condition = f"h{int(metrics['height_mm']):03d}_{metrics['fixture']}"
        source_files[source["trial_id"]] = files
        condition_sources[condition].append(source)
    videos = []
    single_ids = set()
    composites = []
    video_paths = set()
    for row in index["videos"]:
        path = resolve(row["path"], index_path.parent)
        if not path.is_relative_to(ROOT / "animations") or path in video_paths:
            raise ValueError("Video must be a unique animation in this experiment")
        video_paths.add(path)
        actual = probe(path)
        if digest(path) != row["sha256"]:
            raise ValueError(f"Video SHA mismatch: {path}")
        for key in ("width", "height", "frames"):
            if actual[key] != row[key]:
                raise ValueError(f"Video {key} mismatch: {path}")
        if abs(actual["fps"] - row["fps"]) > 1e-6 or abs(actual["duration_s"] - row["duration_s"]) > .015:
            raise ValueError(f"Video time mismatch: {path}")
        if row.get("full_decode_passed") is not True:
            raise ValueError(f"Renderer full decode gate missing: {path}")
        ids = [row["source_trial_id"]] if row.get("source_trial_id") else row.get("source_trial_ids", [])
        if not ids or not set(ids).issubset(by_id):
            raise ValueError(f"Video source bindings incomplete: {path}")
        if row.get("kind")=="trial" or (len(ids)==1 and row.get("kind") not in ("overview","success_overview")):
            single_ids.update(ids)
        if row.get("public_download") is True or row.get("kind") in ("overview","success_overview") or len(ids)>1:
            composites.append(path)
        public_name=row.get("download_name")
        if public_name is None:
            public_name=f"{ids[0]}.mp4" if len(ids)==1 and path.name in ("full_sequence.mp4","full_sequence_presented.mp4") else path.name
        videos.append({"path": path, "ids": ids, "actual": actual, "sha256": row["sha256"],"public_name":plain_name(public_name)})
    if single_ids != set(by_id):
        raise ValueError("Every actual trial requires a full single-trial video")
    selected = index.get("selected_conditions", [])
    if {row["trial_id"] for row in selected} - set(by_id):
        raise ValueError("Selected-condition source bindings are incomplete")
    return index_path, index, qa_path, qa, docs, sources, source_files, condition_sources, videos, composites


def archive_inventory(files):
    return {target: {"sha256": digest(path), "bytes": path.stat().st_size, "source": str(path)}
            for target, path in sorted(files.items())}


def make_zip(path, files):
    inventory = archive_inventory(files)
    with zipfile.ZipFile(path, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=6) as z:
        for target, source in sorted(files.items()):
            # MP4 and NPZ are already compressed; retain them without wasted CPU.
            compression = zipfile.ZIP_STORED if source.suffix.lower() in (".mp4", ".npz") else zipfile.ZIP_DEFLATED
            z.write(source, target, compress_type=compression)
        z.writestr("ARCHIVE_FILES_SHA256.json", json.dumps(inventory, ensure_ascii=False, indent=2) + "\n")
    with zipfile.ZipFile(path) as z:
        bad = z.testzip()
        if bad:
            raise ValueError(f"ZIP CRC failed: {path.name}:{bad}")
        if set(z.namelist()) != set(files) | {"ARCHIVE_FILES_SHA256.json"}:
            raise ValueError("ZIP content list differs from intended inventory")
    return {"name": path.name, "bytes": path.stat().st_size, "sha256": digest(path),
            "zip_crc_verified": True, "contents": inventory}


def partition_archives(staging, basename, bundles):
    """Keep every bundle/trial intact; split groups after measuring actual ZIP."""
    def pack(group, suffix=""):
        files = {}
        for bundle in group:
            for target, source in bundle.items():
                insert(files, target, source)
        path = staging / f"{basename}{suffix}.zip"
        result = make_zip(path, files)
        if result["bytes"] <= CAP_BYTES:
            return [result]
        path.unlink()
        if len(group) <= 1:
            files=list(group[0].items())
            if len(files)>1:
                # Very long trials may span multiple ZIPs, but every original
                # model/array/log file remains intact and keeps its own SHA.
                mid=len(files)//2
                return pack([dict(files[:mid])],suffix+"_files1")+pack([dict(files[mid:])],suffix+"_files2")
            raise ValueError(f"One intact source file exceeds 35MB: {basename}; no source bytes were modified")
        mid = len(group) // 2
        return pack(group[:mid], suffix + "_part1") + pack(group[mid:], suffix + "_part2")
    return pack(bundles)


def build(args, validated):
    index_path, index, qa_path, qa, docs, sources, source_files, conditions, videos, composites = validated
    out = ROOT / "newdeliverables"
    state = ROOT / "publication-state"
    if out.exists() and any(out.iterdir()):
        raise ValueError("newdeliverables is not empty; preserve or remove the previous build explicitly")
    state.mkdir(exist_ok=True)
    main = {}
    qa_evidence={}
    report_figures={name:resolve(ROOT/"control_analysis/figures"/name) for name in PUBLIC_REPORT_FIGURES}
    for name, path in docs.items():
        insert(main, name, path)
    for name,path in report_figures.items():
        insert(main,name,path)
    for folder in ("grasp_search", "control_analysis", "scenes", "qa", "baseline_candidates", "diagnosis", "analytic_diagnosis", "execution-ledger", "delivery_tools"):
        for path in sorted((ROOT / folder).rglob("*")):
            if path.is_file() and path.suffix.lower() in ALLOWED and not FORBIDDEN_PARTS.intersection(path.parts):
                if path.is_relative_to(ROOT/"qa/decoded-media"):
                    insert(qa_evidence,path.relative_to(ROOT),path)
                else:
                    insert(main, path.relative_to(ROOT), path)
    for path in ROOT.glob("*"):
        if path.is_file() and path.suffix.lower() in ALLOWED and path.name not in FORBIDDEN_NAMES:
            insert(main, path.name, path)
    # Only summary files at trial-root top level go in the main ZIP. Actual
    # trial-directory MJB/trace/diagnostics are exclusively in the raw archives.
    for folder in args.trials_root or [ROOT / "trials"]:
        for path in folder.glob("*"):
            if path.is_file() and path.suffix.lower() in (".json", ".md", ".csv"):
                insert(main, path.relative_to(ROOT), path)
    video_set = {v["path"] for v in videos}
    public_names={v["path"]:v["public_name"] for v in videos if v["path"] in composites}
    keep_previews,omitted_previews=preview_selection(index,sources,videos,composites,qa,docs,args.preview_evidence,args.all_previews)
    def video_archive_path(path):
        # Keep report-relative public comparison links valid after extraction,
        # with no duplicate MP4 bytes. Single trials retain their subfolders.
        return public_names[path] if path in composites else str(path.relative_to(ROOT))
    for path in sorted((ROOT / "animations").rglob("*")):
        if path.is_file() and path.suffix.lower() in ALLOWED and not FORBIDDEN_PARTS.intersection(path.parts):
            if path.suffix.lower() == ".mp4" and path not in video_set:
                continue
            if path.suffix.lower() in (".png",".jpg") and path.resolve() not in keep_previews:
                continue
            insert(main, video_archive_path(path) if path.suffix.lower() == ".mp4" else path.relative_to(ROOT), path)
    # Frozen dependencies are explicit source/model allowlists, not workspace
    # recursion. User attachments, credentials and environments are excluded.
    for path,_ in dependency_items(index):
        path = resolve(path)
        if not path.is_relative_to(ROOT):
            insert(main, Path("frozen_dependencies") / path.relative_to("/workspace"), path)
    for asset_root in (Path("/workspace/Dexonomy/assets/hand/shadow"), Path("/workspace/Dexonomy/assets/object/cylinder_sweep_20261022/processed_data/cylinder_thin")):
        for path in sorted(asset_root.rglob("*")):
            if path.is_file() and path.suffix.lower() in ALLOWED:
                insert(main, Path("frozen_dependencies/Dexonomy") / path.relative_to("/workspace/Dexonomy"), path)
    # The Shadow XML's meshdir points into the public menagerie checkout;
    # include precisely its referenced OBJ files, preserving relative paths.
    hand_xml = Path("/workspace/Dexonomy/assets/hand/shadow/right.xml")
    hand_tree = ET.fromstring(hand_xml.read_text())
    mesh_dir = (hand_xml.parent / hand_tree.find("compiler").get("meshdir", "")).resolve()
    for mesh in hand_tree.findall("asset/mesh"):
        if mesh.get("file"):
            path = resolve(mesh_dir / mesh.get("file"))
            insert(main, Path("frozen_dependencies/Dexonomy") / path.relative_to("/workspace/Dexonomy"), path)
    menagerie = Path("/workspace/Dexonomy/third_party/mujoco_menagerie")
    for path in [menagerie / "LICENSE", menagerie / "shadow_hand/README.md", menagerie / "shadow_hand/LICENSE"]:
        if path.is_file():
            insert(main, Path("frozen_dependencies/Dexonomy") / path.relative_to("/workspace/Dexonomy"), path)
    for path in (Path("/workspace/shadow-reproduction/video_writer.py"), Path("/workspace/shadow-reproduction/run_cpu.sh")):
        insert(main, Path("frozen_dependencies/shadow-reproduction") / path.name, path)
    if args.include_spec:
        for row in json.loads(resolve(args.include_spec).read_text()):
            insert(main, row["archive_path"], resolve(row["source"]))
    snapshot = archive_inventory(main)
    qa_evidence_snapshot=archive_inventory(qa_evidence)
    raw_specs = {}
    all_raw_sources = {}
    trial_profiles = {}
    for condition, members in sorted(conditions.items()):
        bundles = []
        for member in sorted(members, key=lambda row: row["trial_id"]):
            files = {}
            source = source_files[member["trial_id"]]
            metrics=json.loads(source["metrics"].read_text())
            trial_profiles[member["trial_id"]]={
                "condition":condition,"source_metadata":member,
                "declared_configuration":metrics.get("config"),
                "unchanged_result_and_profile_fields":{key:value for key,value in metrics.items() if any(token in key.lower() for token in ("passed","criteria","axis","symmetr","yaw","profile","preload","intervention","phase","controller","analytic","cylinder"))},
                "interpretation":"Original reported fields only; full-quaternion strict, task and post-result axis diagnostics are not merged or reclassified by packaging"}
            for path in source["metrics"].parent.rglob("*"):
                if path.is_file():
                    insert(files, path.relative_to(ROOT), path)
            insert(files, Path("inputs") / member["trial_id"] / source["input"].name, source["input"])
            for key, path in source.items():
                if key == "input" or path.is_relative_to(source["metrics"].parent):
                    continue
                insert(files, Path("additional_sources") / member["trial_id"] / key / path.name, path)
            bundles.append(files)
            all_raw_sources.update(archive_inventory(files))
        raw_specs[condition] = bundles
    with tempfile.TemporaryDirectory(prefix="height-boundary-delivery-", dir=ROOT / "delivery_tools") as tmp:
        staging = Path(tmp)
        profiles_path=staging/"trial-profiles.json"
        write_json(profiles_path,{"schema_version":1,"delivery_revision":"height_boundary_delivery_v1","trials":trial_profiles})
        insert(main,"trial-profiles.json",profiles_path)
        archives = []
        qa_archive_rows=partition_archives(staging,"height_boundary_qa_evidence",[qa_evidence]) if qa_evidence else []
        archives.extend(qa_archive_rows)
        raw_mapping = {}
        for condition, bundles in raw_specs.items():
            rows = partition_archives(staging, "raw_" + condition, bundles)
            archives.extend(rows)
            raw_mapping[condition] = [{"archive": row["name"], "members": list(row["contents"])} for row in rows]
        layout = {"schema_version": 1, "purpose": "Relative archive mapping; original animation index/source paths remain byte-identical for provenance",
                  "actual_trials": len(sources), "videos": [{"original_path": str(v["path"]), "archive_path": video_archive_path(v["path"]), "source_trial_ids": v["ids"], "sha256": v["sha256"]} for v in videos],
                  "raw_condition_archives": raw_mapping,
                  "qa_evidence_archives":[{"archive":row["name"],"members":list(row["contents"])} for row in qa_archive_rows],
                  "qa_evidence_policy":"Complete independent decoded PNG evidence is preserved byte-for-byte in a separate QA ZIP; extract it alongside the main ZIP to restore original qa/decoded-media paths. All QA reports/code remain in the main ZIP.",
                  "omitted_derivative_debug_previews":omitted_previews,
                  "original_input_and_model_bindings": {s["trial_id"]: {"condition": f"h{int(s['height_mm']):03d}_{s['fixture']}", "source_sha256": s["source_sha256"]} for s in sources}}
        layout_path = staging / "delivery-index.json"
        write_json(layout_path, layout)
        insert(main, "delivery-index.json", layout_path)
        combined = make_zip(staging / "height_boundary_animations_and_docs.zip", main)
        if combined["bytes"] <= CAP_BYTES:
            archives.append(combined)
            layout["main_archives"] = [combined["name"]]
        else:
            (staging / combined["name"]).unlink()
            movies = [{key: source} for key, source in main.items() if source.suffix.lower() == ".mp4"]
            support = {key: source for key, source in main.items() if source.suffix.lower() != ".mp4"}
            movie_rows = partition_archives(staging, "height_boundary_movies", movies)
            support_rows = partition_archives(staging,"height_boundary_support_docs",[{key:path} for key,path in support.items()])
            archives.extend([*movie_rows, *support_rows])
            layout["main_archives"] = [r["name"] for r in [*movie_rows, *support_rows]]
        # The layout stored in ZIP intentionally precedes this top-level archive
        # list, avoiding self-hashes/cycles. External layout adds that mapping.
        write_json(layout_path, layout)
        top = {**docs,**report_figures, "animation-index.json": index_path, "final-review.json": qa_path, "delivery-index.json": layout_path,"trial-profiles.json":profiles_path}
        for path in composites:
            name=public_names[path]
            if name in top:
                raise ValueError("Public filename collision")
            top[name] = path
        for row in archives:
            top[row["name"]] = staging / row["name"]
        # Ensure no inputs changed while packages were written, including model
        # binaries, large traces, renderer index, QA and final report.
        for record in [*snapshot.values(), *all_raw_sources.values(),*qa_evidence_snapshot.values()]:
            if digest(record["source"]) != record["sha256"]:
                raise ValueError(f"Source changed during packaging: {record['source']}")
        validate_inputs(args)
        out.mkdir(exist_ok=True)
        for name, path in top.items():
            if path.stat().st_size > CAP_BYTES:
                raise ValueError(f"Public file exceeds35MB: {name}")
            shutil.copy2(path, out / name)
        rows = [{"name": name, "bytes": (out / name).stat().st_size, "sha256": digest(out / name)} for name in sorted(top)]
        manifest = {"schema_version": 1,"delivery_revision":"height_boundary_delivery_v1", "benchmark": "D1mm 200g height-boundary search with declared geometry/control/preload profiles", "file_size_cap_bytes": CAP_BYTES,
                    "actual_trial_count": len(sources), "actual_video_count": len(videos),
                    "actual_video_streams": [{"archive_path": video_archive_path(v["path"]), "sha256": v["sha256"], **v["actual"]} for v in videos],
                    "files": rows}
        write_json(out / "delivery_manifest.json", manifest)
        validated_rows(out)
        write_json(state / "package-validation.json", {
            "ready_for_publication": True, "network_operations": False,
            "all_files_at_most_35MB": True, "all_zip_crc_verified": True,
            "actual_trial_count": len(sources), "actual_video_count": len(videos),
            "omitted_derivative_debug_preview_count":len(omitted_previews),
            "final_qa_sha256": digest(qa_path), "animation_index_sha256": digest(index_path),
            "document_sha256": {name: digest(path) for name, path in docs.items()},
            "trial_profiles_sha256":digest(profiles_path),
            "delivery_manifest_sha256": digest(out / "delivery_manifest.json"),
            "archives": archives, "main_source_snapshot": snapshot, "raw_source_snapshot": all_raw_sources,"qa_evidence_source_snapshot":qa_evidence_snapshot,
        })
        print(json.dumps({"built": True, "network_operations": False, "public_files": len(rows) + 1,
                          "actual_trials": len(sources), "videos": len(videos),
                          "archives": [{key: row[key] for key in ("name", "bytes", "sha256")} for row in archives]}, indent=2))


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--index", type=Path, default=ROOT / "animations/index.json")
    parser.add_argument("--qa", type=Path, default=ROOT / "qa/final-review.json")
    parser.add_argument("--qa-ready-field",default="ready_for_delivery")
    parser.add_argument("--qa-hash-field",default="content_sha256")
    parser.add_argument("--documents",nargs="+",default=list(REQUIRED_DOCS))
    parser.add_argument("--execution-ledger",type=Path,action="append",default=[])
    parser.add_argument("--preview-evidence",type=Path,action="append",default=[])
    parser.add_argument("--all-previews",action="store_true")
    parser.add_argument("--trials-root", type=Path, action="append")
    parser.add_argument("--include-spec", type=Path, help="Explicit JSON [{source,archive_path}] extra own/public dependencies")
    parser.add_argument("--build", action="store_true")
    args = parser.parse_args()
    try:
        validated = validate_inputs(args)
    except (OSError, KeyError, ValueError) as error:
        if args.build:
            raise SystemExit(str(error))
        print(json.dumps({"ready": False, "built": False, "reason": str(error)}))
        return
    if args.build:
        build(args, validated)
    else:
        print(json.dumps({"ready": True, "built": False, "actual_trials": len(validated[5]), "videos": len(validated[8])}))


if __name__ == "__main__":
    main()
