# 高度边界实验交付工具

工具版本：`height_boundary_delivery_v1`。由旧height-gradient交付工具只读移植，父工具SHA记录于`tool-provenance.json`。当前仅准备工具；主代理冻结最终报告、动画和独立QA后才执行打包与发布。

```bash
# 默认仅检查，不创建结果包、不访问网络
python delivery_tools/prepare_delivery.py

# 最终freeze后，由主代理启动
python delivery_tools/prepare_delivery.py --build --execution-ledger /absolute/path/to/execution-ledger.json
python delivery_tools/publish_delivery.py
python delivery_tools/publish_delivery.py --publish
python delivery_tools/verify_publication.py
```

默认最终文件为`BOUNDARY_REPORT.md`、`PIPELINE.md`、`search-results.json`、`search-results.csv`、`animations/index.json`，由`qa/final-review.json`中的`ready_for_delivery:true`和`content_sha256`绝对路径SHA映射绑定。若最终QA采用其他字段，可用`--qa-ready-field`和`--qa-hash-field`指定；文档列表可用`--documents`明确指定。工具不自行定义科学通过条件。

所有`trials`子目录的实际`metrics.json`必须逐一出现在最终index.sources中，并有各自独立视频。可重复`--trials-root`添加其他正式trial根目录。工具支持任意已正式测试的整数高度≥10mm、任意trial数和实际视频时长；不预设比较片数、固定高度或固定帧数。

每个source的input/metrics/trace/diagnostics/MJB/XML及额外source_sha256逐一验证；所有递归`{path,sha256}`（含intervention_sources、预览、数值输出和processor链）也核验。video的width/height/frames/fps/duration再轻读ffprobe，与冻结index比对，独立全解码由最终QA负责。

主包`height_boundary_animations_and_docs.zip`包含全部最终index.videos、报告、结果表、源码、场景、QA、拟合/诊断材料及明确引用的公开手模型资产。不同几何、controller、预载时序及原strict/任务/轴对称诊断字段原样写入`trial-profiles.json`，不合并重分类。正式trial的原MJB/trace/feedback/log等在按height/fixture分组的raw ZIP中保留原字节及对应输入NPY；新增intervention来源也保留。execution ledger必需，并原样入包，重复执行事件不会因唯一trial index而丢弃。

所有公开单文件≤35,000,000 bytes。raw格超过上限时按完整trial子组拆分；单trial仍超限可按原文件子组拆分，模型/轨迹文件本身保持完整且SHA不变。若单个原文件压缩后仍超限则明确拒绝，等待制定可复核的交付方法。主包超限时自动分movies/support_docs并继续拆组。公开单片按index中`kind=overview/success_overview`、`public_download:true`或多源比较选择；普通trial片只在主动画包，减少GitHub请求。公开主片在包内与报告同级，其他视频保留子目录，`delivery-index.json`记录映射。

视频可用`download_name`显式指定公开文件名；被选公开的`full_sequence.mp4`默认使用`<trial_id>.mp4`，避免不同trial之间同名冲突。

每ZIP内有`ARCHIVE_FILES_SHA256.json`并执行完整CRC。源文件在打包前后核SHA，所有公开文件bytes/SHA写`newdeliverables/delivery_manifest.json`。最终文档/QA/index、ZIP及源模型SHA记录于外部`publication-state/package-validation.json`，避免自引用。排除用户附件、凭据、环境、publication状态和newdeliverables递归；已存在非空结果包拒绝覆盖。

发布默认仓库`Lvguichen-C/Dexonomy`，结果分支`mujoco-animation-results-20261016-assets`，期望父提交`54130e1e19fed7a5b98b660a34d38ae7651c66f1`，prefix `simulation-results/2026-10-22-height-boundary-1mm-200g`，Release tag `shadow-height-boundary-1mm-200g-20261022`。只有`--publish`访问GitHub写接口，拒绝main/master与已有Release/tag覆盖，固定提交的raw下载链接写入Release。发布后的匿名curl检查逐一下载核bytes/SHA并核验公开Release JSON和tag提交。
