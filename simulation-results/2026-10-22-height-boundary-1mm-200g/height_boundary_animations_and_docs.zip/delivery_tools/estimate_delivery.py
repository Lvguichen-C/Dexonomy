#!/usr/bin/env python3
"""Read source bytes and estimate the main ZIP; never builds any ZIP."""
import argparse
from collections import defaultdict
import json
from pathlib import Path
import re
import xml.etree.ElementTree as ET
import zlib

import prepare_delivery as prep
from common import CAP_BYTES,write_json

ROOT=prep.ROOT


def compressed_bytes(path):
    if path.suffix.lower() in (".mp4",".npz"):
        return path.stat().st_size
    c=zlib.compressobj(6,zlib.DEFLATED,-15)
    total=0
    with path.open('rb') as stream:
        for block in iter(lambda:stream.read(1024*1024),b''):
            total+=len(c.compress(block))
    return total+len(c.flush())


def load_pool():
    index_path=ROOT/'animations/index.json'
    if index_path.is_file():
        index=json.loads(index_path.read_text())
        return index,'final_global_index'
    sources={};comparisons=[]
    for path in sorted((ROOT/'animations').rglob('render-index.json')):
        record=json.loads(path.read_text())
        if record.get('metrics') and record.get('video'):
            metrics=str(Path(record['metrics']).resolve())
            versions=[int(v) for v in re.findall(r'presentation_v(\d+)',str(path))]
            rank=(max(versions,default=0),Path(record['video']['path']).stat().st_size)
            if metrics not in sources or rank>sources[metrics][0]:sources[metrics]=(rank,record)
        elif record.get('video'):
            row=dict(record['video']);row.setdefault('source_trial_ids',record.get('source_trial_ids',[]));comparisons.append(row)
    selected=[record for _,record in sources.values()]
    return {'sources':selected,'videos':[s['video'] for s in selected]+comparisons},'provisional_per_trial_indices'


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--expected-trials',type=int)
    parser.add_argument('--expected-videos',type=int)
    parser.add_argument('--reserve-bytes',type=int,default=2_000_000)
    parser.add_argument('--output',type=Path,default=ROOT/'publication-state/main-package-estimate.json')
    args=parser.parse_args()
    index,mode=load_pool();sources=index['sources'];video_paths=set();videos=[];public=[]
    for row in index['videos']:
        path=Path(row['path']).resolve()
        if path in video_paths:continue
        video_paths.add(path)
        ids=[row['source_trial_id']] if row.get('source_trial_id') else row.get('source_trial_ids',[])
        videos.append({'path':path,'ids':ids})
        if row.get('public_download') or row.get('kind') in ('overview','success_overview') or len(ids)>1:public.append(path)
    docs={p.name:p for p in ROOT.glob('*.md')}
    qa_path=ROOT/'qa/final-review.json';qa=json.loads(qa_path.read_text()) if qa_path.is_file() else {}
    keep,omitted=prep.preview_selection(index,sources,videos,public,qa,docs)
    files=set(video_paths)
    for path in (ROOT/'animations').rglob('*'):
        if not path.is_file() or path.suffix.lower() not in prep.ALLOWED or prep.FORBIDDEN_PARTS.intersection(path.parts):continue
        if path.suffix.lower()=='.mp4' and path.resolve() not in video_paths:continue
        if path.suffix.lower() in ('.png','.jpg') and path.resolve() not in keep:continue
        files.add(path.resolve())
    for folder in ('grasp_search','control_analysis','scenes','qa','baseline_candidates','diagnosis','analytic_diagnosis','execution-ledger','delivery_tools'):
        for path in (ROOT/folder).rglob('*'):
            if path.is_file() and path.suffix.lower() in prep.ALLOWED and not prep.FORBIDDEN_PARTS.intersection(path.parts) and not path.is_relative_to(ROOT/'qa/decoded-media'):files.add(path.resolve())
    for path in ROOT.glob('*'):
        if path.is_file() and path.suffix.lower() in prep.ALLOWED and path.name not in prep.FORBIDDEN_NAMES:files.add(path.resolve())
    for path in (ROOT/'trials').glob('*'):
        if path.is_file() and path.suffix.lower() in ('.json','.jsonl','.md','.csv'):files.add(path.resolve())
    for path,_ in prep.dependency_items(index):files.add(Path(path).resolve())
    for asset_root in (Path('/workspace/Dexonomy/assets/hand/shadow'),Path('/workspace/Dexonomy/assets/object/cylinder_sweep_20261022/processed_data/cylinder_thin')):
        files.update(p.resolve() for p in asset_root.rglob('*') if p.is_file() and p.suffix.lower() in prep.ALLOWED)
    hand=Path('/workspace/Dexonomy/assets/hand/shadow/right.xml');tree=ET.fromstring(hand.read_text());meshdir=(hand.parent/tree.find('compiler').get('meshdir')).resolve()
    files.update((meshdir/g.get('file')).resolve() for g in tree.findall('asset/mesh') if g.get('file'))
    menagerie=Path('/workspace/Dexonomy/third_party/mujoco_menagerie')
    files.update(p for p in (menagerie/'LICENSE',menagerie/'shadow_hand/README.md',menagerie/'shadow_hand/LICENSE',Path('/workspace/shadow-reproduction/video_writer.py'),Path('/workspace/shadow-reproduction/run_cpu.sh')) if p.is_file())
    category=defaultdict(lambda:{'files':0,'source_bytes':0,'estimated_zip_payload_bytes':0})
    for path in sorted(files):
        kind='formal_movies' if path in video_paths else ('retained_animation_previews' if path in keep else ('required_report_figures' if path.is_relative_to(ROOT/'control_analysis/figures') else 'documents_sources_metadata_public_assets'))
        c=category[kind];c['files']+=1;c['source_bytes']+=path.stat().st_size;c['estimated_zip_payload_bytes']+=compressed_bytes(path)
    payload=sum(c['estimated_zip_payload_bytes'] for c in category.values())
    overhead=sum(76+2*len(str(p).encode()) for p in files)
    missing=max(0,(args.expected_videos or len(video_paths))-len(video_paths))
    pending_movie_allowance=missing*max((p.stat().st_size for p in video_paths),default=1_000_000)
    pending_preview_allowance=max(0,(args.expected_trials or len(sources))-len(sources))*6*100_000
    duplicate_figures=sum(compressed_bytes(ROOT/'control_analysis/figures'/name)+76+2*len(name) for name in prep.PUBLIC_REPORT_FIGURES if (ROOT/'control_analysis/figures'/name).is_file())
    total=payload+overhead+args.reserve_bytes+pending_movie_allowance+pending_preview_allowance+duplicate_figures
    result={'mode':mode,'zip_built':False,'network_operations':False,'indexed_trial_count':len(sources),'indexed_video_count':len(video_paths),'expected_trials':args.expected_trials,'expected_videos':args.expected_videos,'categories':dict(category),'omitted_debug_previews':len(omitted),'omitted_debug_preview_bytes':sum(x['bytes'] for x in omitted),'zip_header_estimate_bytes':overhead,'published_report_figure_root_copy_bytes':duplicate_figures,'pending_movie_allowance_bytes':pending_movie_allowance,'pending_preview_allowance_bytes':pending_preview_allowance,'metadata_and_unfinished_docs_reserve_bytes':args.reserve_bytes,'conservative_main_zip_estimate_bytes':total,'cap_bytes':CAP_BYTES,'estimated_headroom_bytes':CAP_BYTES-total,'all_control_analysis_figures_included':True,'note':'Read-only compression estimate; actual final ZIP bytes/CRC/SHA are checked only after explicit build GO'}
    write_json(args.output,result);print(json.dumps(result,indent=2))


if __name__=='__main__':main()
