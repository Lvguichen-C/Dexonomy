#!/usr/bin/env python3
"""Immutable center-height translations of the H60 reference controls.

This adapter does no per-height contact optimization and introduces no controller
change. Its auxiliary far-hand check only diagnoses geometric floor clearance;
the independent formal owner supplies the exact matched feedback profile.
"""
from __future__ import annotations
import argparse,copy,hashlib,json,sys
from pathlib import Path
import mujoco
import numpy as np
HERE=Path(__file__).resolve().parent;ROOT=HERE.parent
sys.path.insert(0,str(ROOT))
import scene_factory as factory
from micro_contact_profile import make_env_micro
from geometry_utils import CollisionQueries,encode

MANIFEST=HERE/'d5-h060-normalmapped-frozen.json'
XML=Path('/workspace/Dexonomy/assets/hand/shadow/right.xml')
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def write(p,x):p.write_text(json.dumps(x,indent=2,default=encode)+'\n')

class Geometry(CollisionQueries):
    def __init__(self,env):
        self.env=env;self.m,self.d=env._model,env._data
        self.obj=next(i for i in range(self.m.ngeom) if self.m.geom(i).name.startswith('obj-'))
        self.tips=[next(i for i in range(self.m.ngeom) if self.m.body(self.m.geom_bodyid[i]).name==f'hand-rh_{finger}distal' and self.m.geom_contype[i]) for finger in ['ff','th']]
        self.hand_geoms=[i for i in range(self.m.ngeom) if self.m.body(self.m.geom_bodyid[i]).name.startswith('hand-') and self.m.geom_contype[i]]
    def inspect(self,q):
        self.d.qpos[:29]=q;self.d.qvel[:]=0;mujoco.mj_forward(self.m,self.d)
        ds,_=self.distances();hh,ho=self.collisions()
        return dict(minimum_hand_z_m=self.min_plane(),tip_gap_query_m=ds,hand_hand_negative_distance_m=hh,hand_object_negative_distance_m=ho)

def check(data,height,offset):
    env=make_env_micro(factory,factory.load_height_scene(height),XML,'plain',mass=.2,timestep=.001)
    geo=Geometry(env);static={}
    for key in ['pregrasp_qpos','grasp_qpos','squeeze_qpos']:
        q=np.asarray(data[key]);static[key]=[geo.inspect(row) for row in q]
    # Release root is only a stored convention; the formal evaluator preserves
    # the lifted root. Inspect with its physical +100mm release reference.
    release=np.asarray(data['release_qpos'])[-1].copy();release[2]+=.1
    static['release_at_lifted_root']=geo.inspect(release)
    first=np.asarray(data['pregrasp_qpos'])[0].copy();first[2]+=offset
    env.reset_qpos(first);geo.d=env._data
    initial_gap=min(mujoco.mj_geomDistance(geo.m,geo.d,gi,geo.obj,2.,np.zeros(6)) for gi in geo.hand_geoms)
    mujoco.mj_step(geo.m,geo.d,nstep=500)
    controls=np.vstack([data['pregrasp_qpos'],data['grasp_qpos'],data['squeeze_qpos']])
    for a,b in zip(controls[:-1],controls[1:]):
        for k in range(5):
            t=(1-(k+1)/5)*a+(k+1)/5*b
            t[3:7]/=np.linalg.norm(t[3:7]);t[2]+=offset
            env.set_ctrl(t);mujoco.mj_step(geo.m,geo.d,nstep=20)
    final=controls[-1].copy();final[2]+=offset;env.set_ctrl(final)
    mujoco.mj_step(geo.m,geo.d,nstep=1000)
    far_actual=geo.d.qpos[:29].copy();projected=far_actual.copy();projected[2]-=offset
    live_ho=sum(any(geo.m.body(geo.m.geom_bodyid[g]).name.startswith('obj-') for g in [c.geom1,c.geom2]) and any(geo.m.body(geo.m.geom_bodyid[g]).name.startswith('hand-') for g in [c.geom1,c.geom2]) for c in geo.d.contact)
    clone=copy.copy(geo.d);env._data=clone;geo.d=clone
    measured=geo.inspect(projected)
    return dict(initial_exact_control_minimum_hand_object_gap_m=float(initial_gap),initial_gap_at_least_50mm=bool(initial_gap>=.05),nominal_target_geometry=static,isolated_hand_projected_geometry=measured,isolated_actual_hand_qpos=projected,far_hand_final_object_contact_count=int(live_ho),auxiliary_timestep_s=.001,auxiliary_scope='Original hand plus declared micro HO pairs, gravity/free object; far initial/open/close/1s settle. Only a copied post-run state is translated for floor geometry. Feedback controller is not run in this clearance diagnostic.',micro_contact_definition=env.micro_contact_definition,physical_full_trial_passed=None)

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--heights',type=int,nargs='+',default=[30,40,50,80,20,120]);ap.add_argument('--strategy',choices=['center','top_minus_2mm'],default='center');args=ap.parse_args()
    source_row=json.loads(MANIFEST.read_text())['variants'][0];source_path=Path(source_row['input']);assert sha(source_path)==source_row['input_sha256']
    source=np.load(source_path,allow_pickle=True).item();rows=[];diagnostic=[]
    for height in args.heights:
        delta=(height-60)/2000 if args.strategy=='center' else (height-32)/1000
        data=copy.deepcopy(source)
        translated=[]
        for key in ['pregrasp_qpos','grasp_qpos','squeeze_qpos','release_qpos']:
            values=np.asarray(data[key],dtype=np.float64).copy()
            if values.shape[-1]==29:
                values[...,2]+=delta;translated.append(key)
                assert np.array_equal(values[...,3:],np.asarray(source[key])[...,3:])
                assert np.array_equal(values[...,:2],np.asarray(source[key])[...,:2])
            elif values.shape[-1]!=22:raise ValueError((key,values.shape))
            data[key]=values
        data['scene_path']=str(factory.scene_path(height))
        data['obj_pose']=np.array([0,0,height/2000,1,0,0,0],dtype=float)
        data['obj_scale']=np.array([.001,.001,.001*height/4],dtype=float)
        data['ext_center']=np.array([0,0,height/2000],dtype=float)
        for key in ['hand_cpn_w','obj_cpn_w']:
            a=np.array(data[key],dtype=float).copy();a[...,2]+=delta;data[key]=a
        if 'ho_c' in data and len(data['ho_c']['pos']):data['ho_c']['pos']=np.array(data['ho_c']['pos'],dtype=float)+[0,0,delta]
        tag='center' if args.strategy=='center' else 'topminus2'
        ident=f'h{height:03d}_matched_h060_{tag}_v1';path=HERE/'candidates'/f'{ident}.npy'
        if path.exists():raise RuntimeError(f'Frozen input already exists: {path}')
        np.save(path,data)
        offset=max(.1,height/2000+.07) if args.strategy=='center' else .1
        qa=check(data,height,offset)
        row=dict(id=ident,input=str(path),input_sha256=sha(path),height_mm=height,diameter_mm=1,mass_kg=.2,closure_duration_scale=source_row['closure_duration_scale'],far_start_offset_m=offset,extra_squeeze_gain=0.,stage='same_controller_center_translated_probe',reference_height_mm=60,reference_input=str(source_path),reference_input_sha256=sha(source_path),reference_manifest=str(MANIFEST),reference_manifest_sha256=sha(MANIFEST),center_translation_z_m=delta,root_translated_fields=translated,joint_and_quaternion_arrays_exactly_unchanged=True,release_target_joint_limits_preserved=True,per_height_grasp_reoptimized=False,controller_policy='Use the same frozen controller and configuration as the matched H60 reference selected by the sole formal-trial owner. This input adapter changes no feedback/controller.',matched_reference_profile_at_request='normal_integrator_contact_axis_preload5',scene_path=str(factory.scene_path(height)),scene_sha256=sha(factory.scene_path(height)),object_freejoint_required=True,gravity_enabled_required=True,version_frozen=True,geometry_clearance_check=qa,full_physics_success_inferred=False)
        floor=qa['isolated_hand_projected_geometry']['minimum_hand_z_m'];row['projected_isolated_hand_floor_clearance_m']=floor
        row['grasp_site_strategy']=args.strategy
        if args.strategy=='top_minus_2mm':
            row['root_translation_z_m']=row.pop('center_translation_z_m')
            row['stage']='same_controller_top_minus_2mm_translated_probe'
            row['commanded_grasp_reference_z_m']=(height-2)/1000
        measured=qa['isolated_hand_projected_geometry']
        row['eligible_for_matched_formal_probe']=bool(floor>=0 and qa['initial_gap_at_least_50mm'] and measured['hand_hand_negative_distance_m']>=0 and measured['hand_object_negative_distance_m']>=0)
        write(HERE/f'{ident}.json',row)
        if row['eligible_for_matched_formal_probe']:rows.append(row)
        else:diagnostic.append(row)
        print(json.dumps(dict(id=ident,floor_clearance_mm=floor*1000,initial_gap_mm=qa['initial_exact_control_minimum_hand_object_gap_m']*1000,eligible=row['eligible_for_matched_formal_probe']),default=encode),flush=True)
        # Publish the requested first four heights as soon as each is immutable.
        scheduled=[30,40,50,80] if args.strategy=='center' else [17,20]
        current=[r for r in rows if r['height_mm'] in scheduled]
        first_name='matched-h030-h040-h050-h080-frozen.json' if args.strategy=='center' else 'matched-topminus2-h017-h020-frozen.json'
        write(HERE/first_name,dict(schema_version=1,variants=current,candidate_count=len(current),version_frozen=len(current)==len(scheduled)))
    prefix='matched-' if args.strategy=='center' else 'matched-topminus2-'
    write(HERE/(prefix+'height-probes-frozen.json'),dict(schema_version=1,variants=rows,candidate_count=len(rows),version_frozen=True))
    write(HERE/(prefix+'clearance-diagnostics.json'),dict(variants=diagnostic,count=len(diagnostic),interpretation='Excluded only from automatic matched physical probes because this unchanged pose intersects floor, lacks far clearance or has negative native contact distance. This is not a formal physical failure or proof the height cannot be grasped.'))
if __name__=='__main__':main()
