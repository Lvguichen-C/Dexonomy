#!/usr/bin/env python3
"""H120 proposal using fixed material surface anchors and actual hand motion.

The anchors smooth the optimization objective; native collision checks remain
authoritative. Auxiliary dynamics do not perform or certify a grasp/lift.
"""
import hashlib
import importlib.util
import json
from pathlib import Path
import sys
import numpy as np
from scipy.spatial.transform import Rotation

HERE = Path(__file__).resolve().parent
sys.path[:0] = [str(HERE), str(HERE.parent)]
BASE = HERE / 'fit_d5_direction_frozen.py'
spec = importlib.util.spec_from_file_location('anchor_d5_base', BASE)
base = importlib.util.module_from_spec(spec)
spec.loader.exec_module(base)
base.SOURCE = HERE / 'd5_sources/h060_d5_seed_center_aligned.npy'


def encode(x):
    return x.tolist() if isinstance(x, np.ndarray) else x.item() if isinstance(x, np.generic) else str(x)


class Anchored(base.Controlled):
    def __init__(self):
        seed = HERE / 'candidates/h060_d5_normalmapped_release_squeeze0.npy'
        super().__init__(120, '9_Palmar_Pinch', .1, seed_path=seed)
        self.qbase[2] += .03
        q = self.qbase.copy()
        _, _, _, segments, _, _, _ = self.simulate(q)
        self.anchor_ids = [int(self.m.geom_bodyid[g]) for g in self.tips]
        self.local_points = []
        self.local_normals = []
        for bid, seg in zip(self.anchor_ids, segments):
            r = self.d.xmat[bid].reshape(3, 3)
            inward = seg[1] - seg[0]
            inward /= np.linalg.norm(inward)
            self.local_points.append(r.T @ (seg[0] - self.d.xpos[bid]))
            self.local_normals.append(r.T @ inward)
        points = segments[:, 0]
        delta = points[0] - points[1]
        horizontal = delta.copy()
        horizontal[2] = 0
        horizontal /= np.linalg.norm(horizontal)
        delta /= np.linalg.norm(delta)
        axis = np.cross(delta, horizontal)
        angle = np.arctan2(np.linalg.norm(axis), np.dot(delta, horizontal))
        align = Rotation.from_rotvec(axis / np.linalg.norm(axis) * angle)
        pivot = np.mean(points, axis=0)
        self.qbase[:3] = pivot + align.apply(q[:3] - pivot)
        self.rbase = align * base.quat_to_rotation(q[3:7])
        self.qbase[3:7] = base.rotation_to_quat(self.rbase)
        self.measured_pinch_direction = -horizontal
        provenance = dict(seed=str(seed), seed_sha256=base.sha(seed), height_mm=120,
                          body_ids=self.anchor_ids, body_local_points=self.local_points,
                          body_local_inward_normals=self.local_normals,
                          aligned_root_qpos=self.qbase, direction=self.measured_pinch_direction,
                          script_sha256=base.sha(Path(__file__)), base_fitter_sha256=base.sha(BASE),
                          auxiliary_only=True)
        (HERE / 'd5_sources/h120-fixed-anchor-provenance.json').write_text(json.dumps(provenance, indent=2, default=encode) + '\n')

    def objective(self, x, detail=False):
        self.calls += 1
        q = self.unpack(x)
        actual, obj, ds, sg, hh, ho, plane = self.simulate(q)
        points, normals = [], []
        for bid, lp, ln in zip(self.anchor_ids, self.local_points, self.local_normals):
            r = self.d.xmat[bid].reshape(3, 3)
            points.append(self.d.xpos[bid] + r @ lp)
            normals.append(r @ ln)
        points, normals = np.asarray(points), np.asarray(normals)
        desired_normals = np.asarray([self.measured_pinch_direction, -self.measured_pinch_direction])
        targets = -desired_normals * .00052
        targets[:, 2] = obj[2]
        residual = np.r_[((points - targets) / .0003).ravel(),
                         (normals - desired_normals).ravel(),
                         (points[0, 2] - points[1, 2]) / .00005,
                         min(0, hh) / .00005, min(0, ho) / .00005,
                         min(0, plane - .00005) / .00005,
                         x[:3] * .00001, x[3:6] * .0001]
        if detail:
            return q, actual, obj, ds, sg, hh, ho, plane, float(residual @ residual)
        return residual

    def fit(self):
        # The inherited writer gets a distinct height120 id. Preserve every
        # previous height120 candidate; caller must select this explicit input.
        path = HERE / 'candidates/h120_d5_normalmapped_9_Palmar_Pinch_preshape0.1.npy'
        if path.exists():
            raise RuntimeError('Refusing to overwrite candidate')
        super().fit()


if __name__ == '__main__':
    Anchored().fit()
