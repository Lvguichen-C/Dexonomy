#!/usr/bin/env python3
"""Finite gravity-on, path-aware actuator-space candidate fitting.

Each objective executes an isolated hand at +100mm using the unmodified model,
then queries a clone translated down for geometric comparison. The rod remains
free during auxiliary dynamics. Geometry queries are not physical contacts.
Formal trials must restart far away and run their own continuous sequence.
"""
from __future__ import annotations
import argparse, copy, hashlib, json, sys, time
from pathlib import Path
import mujoco
import numpy as np
from scipy.optimize import least_squares
from scipy.spatial.transform import Rotation
from omegaconf import OmegaConf

HERE=Path(__file__).resolve().parent;ROOT=HERE.parent
sys.path.insert(0,str(ROOT))
sys.path.insert(0,'/workspace/Dexonomy')
from scene_factory import make_env,load_height_scene,scene_path
from geometry_utils import CollisionQueries,quat_to_rotation,rotation_to_quat,encode
from dexonomy.op.gen_grasp import GraspFilter
from dexonomy.qp.qp_single import ContactQP

SOURCE=HERE/'sources/original_d1h4_palmar.npy'
CFG=Path('/workspace/Dexonomy/dexonomy/config/op/grasp.yaml')
XML=Path('/workspace/Dexonomy/assets/hand/shadow/right.xml')
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def write(p,x):p.write_text(json.dumps(x,indent=2,default=encode)+'\n')

class Controlled(CollisionQueries):
    def __init__(self,height,template,alpha,seed_path=None):
        self.height=height;self.template=template;self.alpha=alpha
        self.seed_path=Path(seed_path) if seed_path is not None else None
        self.source=np.load(SOURCE,allow_pickle=True).item()
        if template=='14_Tripod' and seed_path is not None:
            self.source=np.load(seed_path,allow_pickle=True).item()
        self.env=make_env(load_height_scene(height),XML,'plain',mass=.2,timestep=.001)
        self.m,self.d=self.env._model,self.env._data
        self.live=self.d
        self.obj=next(i for i in range(self.m.ngeom) if self.m.geom(i).name.startswith('obj-'))
        self.bodies=['rh_ffdistal','rh_thdistal']
        self.tips=[next(i for i in range(self.m.ngeom) if self.m.body(self.m.geom_bodyid[i]).name=='hand-'+b and self.m.geom_contype[i]) for b in self.bodies]
        self.hand_geoms=[i for i in range(self.m.ngeom) if self.m.body(self.m.geom_bodyid[i]).name.startswith('hand-') and self.m.geom_contype[i]]
        self.ranges={int(self.m.jnt_qposadr[j]):self.m.jnt_range[j].copy() for j in range(self.m.njnt) if self.m.jnt_limited[j] and self.m.jnt_qposadr[j]<29}
        self.qbase=self.source['grasp_qpos'][0].astype(float).copy()
        if template=='24_Tip_Pinch' and seed_path is None:
            self.qbase=np.load('/workspace/shadow-lift-sweep-200g/upright-1mm-20261022/grasp_search/refined/precision_tip_raise0_seed1_static_qpos.npy')
        self.qbase[2]+=(height-4)/1000
        if seed_path is not None:self.qbase=np.load(seed_path,allow_pickle=True).item()['grasp_qpos'][0].astype(float).copy()
        self.rbase=quat_to_rotation(self.qbase[3:7]);self.calls=0;self.dynamic_steps=0;self.log=[]
        self.config=OmegaConf.load(CFG).grasp.filter
        self.numerical=dict(timestep_s=float(self.m.opt.timestep),root_weld_solref=self.m.eq_solref.copy(),position_gains=self.m.actuator_gainprm[:,0].copy(),gravity=self.m.opt.gravity.copy(),original_ccd_tolerance=float(self.m.opt.ccd_tolerance))
    def open_path(self,q):
        old=self.source['grasp_qpos'][0];pre=self.source['pregrasp_qpos'].astype(float).copy()
        pre[:,:3]=q[:3]+self.alpha*(pre[:,:3]-old[:3])
        pre[:,3:7]=q[3:7]
        pre[:,7:]=q[7:]+self.alpha*(pre[:,7:]-old[7:])
        for k,(lo,hi) in self.ranges.items():pre[:,k]=np.clip(pre[:,k],lo+1e-6,hi-1e-6)
        return pre
    def unpack(self,x):
        q=self.qbase.copy();q[:3]+=x[:3]/1000
        q[3:7]=rotation_to_quat(Rotation.from_rotvec(x[3:6])*self.rbase)
        q[7:9]=x[6:8]
        # Only the tendon sum is a fitted control; retain the seed's target split.
        delta=(x[8]-self.qbase[9:11].sum())/2
        q[9:11]=self.qbase[9:11]+delta
        q[24:29]=x[9:14]
        if len(x)>14:
            q[11:13]=x[14:16]
            delta=(x[16]-self.qbase[13:15].sum())/2
            q[13:15]=self.qbase[13:15]+delta
        return q
    def simulate(self,q,squeeze=None):
        self.env._data=self.live;self.d=self.live
        pre=self.open_path(q);high=pre[0].copy();high[2]+=.1
        self.env.reset_qpos(high)
        mujoco.mj_step(self.m,self.d,nstep=500)
        # The same near-grasp preshape is physically present from the far start.
        points=np.vstack([pre,q[None]])
        if squeeze is not None:points=np.vstack([points,squeeze[None]])
        last=points[0].copy()
        for nxt in points[1:]:
            for k in range(5):
                w=(k+1)/5;t=(1-w)*last+w*nxt;t[3:7]=rotation_to_quat(quat_to_rotation(nxt[3:7]));t[2]+=.1
                self.env.set_ctrl(t);mujoco.mj_step(self.m,self.d,nstep=20)
            last=nxt
        target=(q if squeeze is None else squeeze).copy();target[2]+=.1;self.env.set_ctrl(target)
        mujoco.mj_step(self.m,self.d,nstep=1000)
        self.dynamic_steps+=1500+100*(len(points)-1)
        actual=self.d.qpos[:29].copy();actual[2]-=.1
        object_pose=self.d.qpos[29:36].copy()
        # Separate static clone: no object writes or hand contact in the oracle.
        probe=copy.copy(self.d);probe.qpos[:29]=actual;probe.qvel[:]=0
        self.env._data=probe;self.d=probe;mujoco.mj_forward(self.m,probe)
        ds,sg=self.distances();hh,ho=self.collisions();plane=self.min_plane()
        return actual,object_pose,ds,sg,hh,ho,plane
    def objective(self,x,detail=False):
        self.calls+=1;q=self.unpack(x)
        actual,obj,ds,sg,hh,ho,plane=self.simulate(q)
        hh_pair=mujoco.mj_geomDistance(self.m,self.d,*self.tips,.2,np.zeros(6))
        direction=np.array([np.cos(.92),np.sin(.92),0.])
        # Long-rod target is near its center, with opposing horizontal normals.
        # This prevents merely following the original top-rim contact geometry.
        z=obj[2]
        targets=np.asarray([-direction,direction])*.0005;targets[:,2]=z
        delta=sg[:,1]-sg[:,0];unit=delta/np.maximum(np.linalg.norm(delta,axis=1,keepdims=True),1e-8)
        residual=np.r_[(ds-.000020)/.0005,((sg[:,1]-targets)/.003).ravel(),
                       (unit-np.asarray([direction,-direction])).ravel()*.35,
                       min(0,hh_pair-.000020)/.000010,
                       min(0,hh)/.000010,min(0,ho)/.000010,min(0,plane-.000025)/.00005,
                       (x[:3]/20)*.0002,x[3:6]*.0002]
        if detail:return q,actual,obj,ds,sg,hh,ho,plane,float(residual@residual)
        return residual
    def native(self,q,obj):
        self.d.qpos[:29]=q;self.d.qpos[29:36]=obj;self.d.qvel[:]=0;mujoco.mj_forward(self.m,self.d)
        passed,hoc=GraspFilter(self.config,self.env,'controlled_static_probe').forward(self.source)
        qp=None
        if len(hoc['dist']):_,qp=ContactQP([.6,.02]).solve(hoc['pos'],hoc['normal'],self.source['ext_wrench'],self.source['ext_center'])
        return bool(passed),qp,hoc
    def fit(self):
        x0=np.r_[np.zeros(6),self.qbase[7:9],self.qbase[9:11].sum(),self.qbase[24:29]]
        lower=np.r_[[-35.]*3,[-1.]*3,self.ranges[7][0],self.ranges[8][0],0.,[self.ranges[k][0] for k in range(24,29)]]
        upper=np.r_[[35.]*3,[1.]*3,self.ranges[7][1],self.ranges[8][1],3.1,[self.ranges[k][1] for k in range(24,29)]]
        if self.template=='14_Tripod':
            x0=np.r_[x0,self.qbase[11:13],self.qbase[13:15].sum()]
            oldmf=self.qbase[13:15]
            mflo=max(2*(self.ranges[k][0]-oldmf[k-13])+oldmf.sum() for k in [13,14])+1e-6
            mfhi=min(2*(self.ranges[k][1]-oldmf[k-13])+oldmf.sum() for k in [13,14])-1e-6
            lower=np.r_[lower,self.ranges[11][0],self.ranges[12][0],mflo]
            upper=np.r_[upper,self.ranges[11][1],self.ranges[12][1],mfhi]
        # Keep both target hinge numbers legal even though only their sum drives.
        old=self.qbase[9:11];lower[8]=max(2*(self.ranges[k][0]-old[k-9])+old.sum() for k in [9,10])+1e-6
        upper[8]=min(2*(self.ranges[k][1]-old[k-9])+old.sum() for k in [9,10])-1e-6
        x0=np.clip(x0,lower+1e-6,upper-1e-6)
        start=time.time();initial=self.objective(x0,True)
        def jac(x):
            # Absolute steps resolve the microscopic geometry; no zero-root FD.
            result=[]
            for k in range(len(x)):
                h=.015 if k<3 else .0005
                a=x.copy();b=x.copy();a[k]+=h;b[k]-=h
                result.append((self.objective(a)-self.objective(b))/(2*h))
            return np.asarray(result).T
        opt=least_squares(self.objective,x0,jac=jac,bounds=(lower+1e-7,upper-1e-7),max_nfev=24,ftol=2e-5,xtol=1e-5,gtol=1e-5,x_scale=np.r_[[6.]*3,[.35]*3,[.4]*(len(x0)-6)])
        q,actual,obj,ds,sg,hh,ho,plane,cost=self.objective(opt.x,True)
        actual_pass,actual_qp,hoc=self.native(actual,obj)
        ctrl_pass,ctrl_qp,ctrl_hoc=self.native(q,obj)
        strict=bool(actual_pass and np.all((ds>=0)&(ds<.00005)) and hh>=0 and ho>=0 and plane>=0)
        out=copy.deepcopy(self.source);out['scene_path']=str(scene_path(self.height));out['tmpl_name']=self.template
        out['grasp_qpos']=q[None].astype(np.float64);out['pregrasp_qpos']=self.open_path(q).astype(np.float64)
        # Pressure targets are actuator-space commands, not independent FF drives.
        sq=q.copy()
        # A macro 10x-QP squeeze was observed to cause hand/hand collision and
        # tendon nullspace redistribution. This declared micro command is 5%
        # of the old added squeeze, without altering gains or collision rules.
        sq[7:]+=.05*(self.source['squeeze_qpos'][0,7:]-self.source['grasp_qpos'][0,7:])
        for k,(lo,hi) in self.ranges.items():sq[k]=np.clip(sq[k],lo,hi)
        out['squeeze_qpos']=sq[None].astype(np.float64)
        out['ext_center']=np.array([0,0,self.height/2000],dtype=np.float32)
        out['obj_pose']=np.array([0,0,self.height/2000,1,0,0,0],dtype=np.float32)
        out['obj_scale']=np.array([.001,.001,.001*self.height/4],dtype=np.float32)
        # Source annotations are provenance only; replace world contacts by the
        # actual endpoint geometric query if both required bodies are present.
        out['ho_c']=hoc
        if len(hoc['dist']):out['hand_cpn_w']=np.c_[hoc['pos'],hoc['normal']];out['hand_cbody']=hoc['bn1']
        ident=f'h{self.height:03d}_sidefit_{self.template}_preshape{self.alpha:g}'
        path=HERE/'candidates'/f'{ident}.npy';path.parent.mkdir(exist_ok=True);np.save(path,out)
        row=dict(id=ident,input=str(path),input_sha256=sha(path),height_mm=self.height,template=self.template,preshape_alpha=self.alpha,squeeze_source_delta_gain=.05,closure_duration_scale=1.,native_filter_passed=ctrl_pass,actual_settled_native_filter_passed=actual_pass,strict_geometry_passed=strict,stage='isolated_hand_tracked_geometry_certified_unverified_full_trial' if strict else 'uncertified_dynamic_proposal',object_freejoint_required=True,gravity_enabled_required=True,source_grasp=str(SOURCE),source_sha256=sha(SOURCE),scene_path=str(scene_path(self.height)),scene_sha256=sha(scene_path(self.height)),initial_tip_gaps_m=initial[3],tracked_tip_gaps_m=ds,tracked_closest_segments_m=sg,actual_hand_qpos=actual,control_grasp_qpos=q,isolated_object_pose=obj,tracked_hand_hand_negative_distance_m=hh,tracked_hand_object_negative_distance_m=ho,tracked_hand_minimum_z_m=plane,control_native_qp_residual=ctrl_qp,actual_native_qp_residual=actual_qp,oracle_evaluations=self.calls,oracle_dynamic_steps=self.dynamic_steps,seconds=time.time()-start,optimizer_nfev=opt.nfev,initial_residual_squared=initial[-1],final_residual_squared=cost,numerical_settings=self.numerical,collision_thresholds_unchanged=True,strict_microgeometry_threshold_m=.00005,far_start_offset_m=.1,far_start_hold_s=.5,approach_s=2.,loaded_hold_s=1.,lift_s=5.,postlift_hold_s=5.,release_required=True,mass_kg=.2,full_physics_trial_passed=None,actual_physics_success_inferred=False,auxiliary_scope='Gravity-on free hand 100mm above rod, actual compressed-opening close then 1s settle; post-run translated clone for geometric queries only. No HO contact during oracle; no physical lift is tested.')
        if self.seed_path is not None:
            row.update(runtime_seed_path=str(self.seed_path),runtime_seed_sha256=sha(self.seed_path))
            if self.template=='14_Tripod':row.update(source_grasp=str(self.seed_path),source_sha256=sha(self.seed_path))
        write(HERE/f'{ident}.json',row)
        print(json.dumps({k:row[k] for k in ['id','seconds','initial_tip_gaps_m','tracked_tip_gaps_m','native_filter_passed','actual_settled_native_filter_passed','strict_geometry_passed','stage']},default=encode),flush=True)

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--height',type=int,required=True);ap.add_argument('--template',choices=['9_Palmar_Pinch','24_Tip_Pinch','14_Tripod'],required=True);ap.add_argument('--alpha',type=float,default=.25);ap.add_argument('--seed-path',type=Path);args=ap.parse_args()
    HERE.mkdir(exist_ok=True);Controlled(args.height,args.template,args.alpha,args.seed_path).fit()
if __name__=='__main__':main()
