# Ongoing independent Tripod contact research

The control seed is an actual native `14_Tripod` result for the earlier D40 mm / H160 mm cylinder, copied byte-for-byte to `sources/tripod_d40h160_native_source.npy`. It is not asserted to grasp a D1 mm rod. Its five recorded contact bodies include palm/proximal surfaces plus index, middle and thumb tips, while its original required groups remain unchanged. New centered seeds record their scene, source hashes and target dimensions.

The real controlled fit uses 17 variables: commanded root6; index abduction/proximal/summed FFJ2+FFJ1; thumb5; and middle abduction/proximal/summed MFJ2+MFJ1. Every objective runs a gravity-on far hand opening/settle path in the original hand model. No independent drive was added to a coupled pair. The hand is translated only in a post-dynamics cloned data state for diagnostic geometry; the formal trial always starts far away and remains continuous.

| Record | Tip query gaps (mm) | Axial separation (mm) | Native HO minimum negative distance (mm) | Actual native pass |
| --- | ---: | ---: | ---: | --- |
| h040_sidefit_14_Tripod_preshape0.1 | 0.246 / 0.331 | 0.172 | 0.000 | False |
| h080_sidefit_14_Tripod_preshape0.1 | -0.001 / 0.331 | 1.556 | -0.001 | False |
| h080_sidefit_14_Tripod_preshape0.1_normalmapped | 0.268 / 0.058 | 12.891 | 0.000 | False |
| h120_sidefit_14_Tripod_preshape0.1_anchored | 2.466 / -0.001 | 1.780 | -0.001 | False |
| h120_sidefit_14_Tripod_preshape0.1_forcebalanced | 0.030 / 0.011 | 16.185 | 0.000 | False |
| h120_sidefit_14_Tripod_preshape0.1_heightmatch | 1.371 / 0.352 | 0.339 | 0.000 | False |
| h120_sidefit_14_Tripod_preshape0.1_horizontalized | 1.371 / 0.352 | 8.163 | 0.000 | False |


Two points can be near the cylindrical side yet differ greatly in height. Their opposed radial forces then create an unbalanced moment. With a 1 mm diameter and friction 0.6, millimetres of axial stagger cannot be treated as a stable two-point force closure. A nearly zero gap therefore does not replace the original QP or the real loaded lift test. The H120 force-balanced scout reached about 30/11 micrometres without native hand/hand or hand/object penetration, but its 16 mm axial stagger and nonzero QP error still rejected it.

The first side solver assumed a fixed pinching azimuth from the earlier Palmar seed. Independent Tripod seeds have the opposite handed side assignment; new `normalmapped` records derive this direction from the seed itself. Those new IDs preserve the earlier results without relabeling them.

A `forcebalanced` objective adds the difference in FFJ2/FFJ1 generalized torques produced by a unit radial fingertip load. This probes whether real pressure would drive the tendon internal difference mode, even when its sum tracks the target. It is a pose-selection diagnostic, not hardware or joint-limit modification.

A rigid `horizontalized` seed aligns the previous contact line with the horizontal plane. Real gravity-on motion changes finger shape again, so its actual endpoint must be remeasured. Raising the closest-point axial weight alone stalled; the subsequent `anchored` branch instead fits fixed body-local surface points and normals obtained from the actual seed. Actual body transforms give stable point correspondence during control fitting, while all original native collisions and final distance checks remain active.

Only the H40 Tripod version has been sent to a completed original-profile formal trial so far; it failed and toppled with large hand/object overlap. Other static/auxiliary records are not extra successful or failed physical lift trials. The root agent independently explores the load-bearing D5 Palmar family; its results must remain separate from this Tripod branch.

This checkpoint is not a conclusion that any tested height is impossible. The search continues toward actual full-cycle success, and any boundary will be stated only within the tested profile/support/family after success.

The anchored endpoint remained rejected (index query about 2.47 mm, native hand/hand overlap about 67 µm). No further Tripod optimization is running. At parent request, work moved to matched height probes from the separate D5/controller breakthrough; see `MATCHED_HEIGHT_PROBES.md` and `MATCHED_TOP_MINUS_2MM_PROBES.md`. These are separate families and do not relabel the failed Tripod experiments.
