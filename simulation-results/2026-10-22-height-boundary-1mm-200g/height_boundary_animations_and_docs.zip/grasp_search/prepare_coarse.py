#!/usr/bin/env python3
"""Quick frozen top/mid dynamic proposals for a non-monotonic height scout.

These copied and translated control seeds are explicitly not optimized/native
certified. A separate actuator-aware fit follows. No old file is modified.
"""
import argparse,copy,hashlib,json,sys
from pathlib import Path
import numpy as np
HERE=Path(__file__).resolve().parent;ROOT=HERE.parent
sys.path.insert(0,str(ROOT))
from scene_factory import scene_path
SOURCE=HERE/'sources/h010_palmar_oracle_v1_squeeze005.npy'
def sha(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def main():
    ap=argparse.ArgumentParser();ap.add_argument('--heights',type=int,nargs='+',default=[20,40,80]);args=ap.parse_args()
    source=np.load(SOURCE,allow_pickle=True).item();rows=[]
    for h in args.heights:
        for site in ['top','mid']:
            # Original tracked closest contacts are near z9.6mm for the H10 seed.
            dz=(h-10)/1000 if site=='top' else h/2000-.0003-.0096
            data=copy.deepcopy(source)
            for key in ['grasp_qpos','squeeze_qpos','pregrasp_qpos']:
                data[key]=np.asarray(data[key],dtype=np.float64).copy();data[key][:,2]+=dz
            data['scene_path']=str(scene_path(h))
            data['obj_pose']=np.array([0,0,h/2000,1,0,0,0],dtype=float)
            data['obj_scale']=np.array([.001,.001,.001*h/4],dtype=float)
            data['ext_center']=np.array([0,0,h/2000],dtype=float)
            ident=f'h{h:03d}_coarse_{site}_v1';path=HERE/'candidates'/f'{ident}.npy';path.parent.mkdir(exist_ok=True)
            if path.exists():raise RuntimeError(f'Refuse to overwrite frozen seed: {path}')
            np.save(path,data)
            row=dict(id=ident,input=str(path),input_sha256=sha(path),height_mm=h,grasp_site=site,commanded_root_z_offset_m=dz,seed_contact_reference_z_m=.0096,seed_target_segment_z_m=.0096+dz,source_grasp=str(SOURCE),source_sha256=sha(SOURCE),scene_path=str(scene_path(h)),scene_sha256=sha(scene_path(h)),closure_duration_scale=1.,squeeze_source_delta_gain=.05,preshape_alpha=.25,control_dtype='float64',stage='uncertified_translated_coarse_dynamic_seed',native_filter_passed=None,strict_geometry_passed=False,object_freejoint_required=True,gravity_enabled_required=True,mass_kg=.2,diameter_mm=1,version_frozen=True,actual_physics_success_inferred=False,interpretation='Quick top/mid segment exploration; not a solved grasp. Formal continuous trials decide success. Further actual-controlled side-contact fitting uses new independent candidate IDs.')
            row['far_start_offset_m']=max(.1,h/2000+.06) if site=='mid' else .1
            rows.append(row)
            (HERE/f'{ident}.json').write_text(json.dumps(row,indent=2)+'\n')
    manifest=HERE/('coarse-'+ '-'.join(str(h) for h in args.heights)+'-frozen.json')
    manifest.write_text(json.dumps(dict(schema_version=1,candidate_count=len(rows),variants=rows,version_frozen=True),indent=2)+'\n')
    print(manifest,flush=True)
if __name__=='__main__':main()
