#!/usr/bin/env python3
"""Refine the D5-derived seed using its measured pinch-side convention."""
import hashlib
import importlib.util
import json
from pathlib import Path
import sys
import numpy as np

HERE = Path(__file__).resolve().parent
sys.path[:0] = [str(HERE), str(HERE.parent)]


def sha(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()


def main():
    base = HERE / 'fit_d5_frozen.py'
    snapshot = HERE / 'fit_d5_direction_frozen.py'
    if snapshot.exists():
        raise RuntimeError('Refusing to overwrite fitter snapshot')
    text = base.read_text()
    old = 'direction=np.array([np.cos(.92),np.sin(.92),0.])'
    assert text.count(old) == 1
    text = text.replace(old, 'direction=self.measured_pinch_direction')
    text = text.replace("ident=f'h{self.height:03d}_sidefit_", "ident=f'h{self.height:03d}_d5_normalmapped_")
    snapshot.write_text(text)
    spec = importlib.util.spec_from_file_location('d5_direction_fitter', snapshot)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    module.SOURCE = HERE / 'd5_sources/h060_d5_seed_center_aligned.npy'
    seed = HERE / 'candidates/h060_d5_palmar_side_release_squeeze0.npy'
    oracle = module.Controlled(60, '9_Palmar_Pinch', .1, seed_path=seed)
    q = np.load(seed, allow_pickle=True).item()['grasp_qpos'][0]
    _, _, _, segments, _, _, _ = oracle.simulate(q)
    direction = segments[0, 1] - segments[0, 0]
    direction[2] = 0
    if np.linalg.norm(direction) < 1e-9:
        raise RuntimeError('Cannot identify a nonzero horizontal index-to-rod direction')
    direction /= np.linalg.norm(direction)
    oracle.measured_pinch_direction = direction
    record = dict(seed=str(seed), seed_sha256=sha(seed), fitter=str(snapshot),
                  fitter_sha256=sha(snapshot), measured_pinch_direction=direction.tolist(),
                  original_direction=[float(np.cos(.92)), float(np.sin(.92)), 0.],
                  scope='Auxiliary real-hand fitting only; no successful grasp inferred.')
    (HERE / 'd5_sources/direction-refinement-provenance.json').write_text(json.dumps(record, indent=2) + '\n')
    oracle.fit()


if __name__ == '__main__':
    main()
