#!/usr/bin/env python3
"""Auxiliary same-height pinch fit; an unloaded proposal, never lift success."""
import hashlib
import importlib.util
import json
from pathlib import Path
import sys
import numpy as np
from scipy.spatial.transform import Rotation

HERE = Path(__file__).resolve().parent
sys.path[:0] = [str(HERE), str(HERE.parent)]


def sha(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()


def main():
    base = HERE / 'fit_d5_direction_frozen.py'
    snapshot = HERE / 'fit_d5_equal_height_frozen.py'
    if snapshot.exists():
        raise RuntimeError('Refusing to overwrite fitter snapshot')
    code = base.read_text()
    code = code.replace("ident=f'h{self.height:03d}_d5_normalmapped_", "ident=f'h{self.height:03d}_d5_equalheight_")
    before = '((sg[:,1]-targets)/.003).ravel(),'
    assert code.count(before) == 1
    after = ('((sg[:,1]-targets)/.001).ravel(),'
             '(sg[0,1,2]-sg[1,1,2])/.000025,')
    code = code.replace(before, after)
    snapshot.write_text(code)
    spec = importlib.util.spec_from_file_location('d5_equal_height_fitter', snapshot)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    module.SOURCE = HERE / 'd5_sources/h060_d5_seed_center_aligned.npy'
    seed = HERE / 'candidates/h060_d5_normalmapped_release_squeeze0.npy'
    oracle = module.Controlled(60, '9_Palmar_Pinch', .1, seed_path=seed)
    q = np.load(seed, allow_pickle=True).item()['grasp_qpos'][0]
    _, _, _, segments, _, _, _ = oracle.simulate(q)
    delta = segments[0, 0] - segments[1, 0]
    horizontal = delta.copy()
    horizontal[2] = 0
    delta /= np.linalg.norm(delta)
    horizontal /= np.linalg.norm(horizontal)
    axis = np.cross(delta, horizontal)
    angle = np.arctan2(np.linalg.norm(axis), np.dot(delta, horizontal))
    align = Rotation.from_rotvec(axis / np.linalg.norm(axis) * angle)
    pivot = .5 * (segments[0, 0] + segments[1, 0])
    old_q = oracle.qbase.copy()
    oracle.qbase[:3] = pivot + align.apply(old_q[:3] - pivot)
    original_rotation = module.quat_to_rotation(old_q[3:7])
    oracle.rbase = align * original_rotation
    oracle.qbase[3:7] = module.rotation_to_quat(oracle.rbase)
    direction = -horizontal
    oracle.measured_pinch_direction = direction
    record = dict(seed=str(seed), seed_sha256=sha(seed), fitter=str(snapshot),
                  fitter_sha256=sha(snapshot), measured_pinch_direction=direction.tolist(),
                  initial_alignment_rotation_vector=align.as_rotvec().tolist(),
                  initial_pivot_m=pivot.tolist(), aligned_root_qpos=oracle.qbase.tolist(),
                  equal_height_residual_scale_m=.000025,
                  scope='High isolated-hand dynamics and geometry only, not a physical lift.')
    (HERE / 'd5_sources/equal-height-refinement-provenance.json').write_text(json.dumps(record, indent=2) + '\n')
    oracle.fit()


if __name__ == '__main__':
    main()
