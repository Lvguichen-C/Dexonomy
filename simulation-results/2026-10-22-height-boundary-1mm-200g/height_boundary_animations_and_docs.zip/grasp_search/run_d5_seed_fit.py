#!/usr/bin/env python3
"""Independent long-rod proposal from a previously load-bearing D5 seed.

This is an auxiliary fit, never a full grasp/lift test. All source files and
the fitter snapshot are preserved; no old input is changed.
"""
import copy
import hashlib
import importlib.util
import json
from pathlib import Path
import shutil
import sys

import numpy as np

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent
sys.path.insert(0, str(ROOT))
sys.path.insert(0, str(HERE))
from scene_factory import scene_path

ORIGINAL = Path('/workspace/shadow-lift-sweep-200g/output/diameter_sweep_200g_shadow/grasp_data/9_Palmar_Pinch/cylinder_thin_table_5/scaledfull20_0_4_grasp.npy')


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    height = 60
    sources = HERE / 'd5_sources'
    sources.mkdir(exist_ok=True)
    original_copy = sources / 'original_d5h20_loadbearing_seed.npy'
    snapshot = HERE / 'fit_d5_frozen.py'
    if original_copy.exists() or snapshot.exists():
        raise RuntimeError('Refusing to overwrite frozen D5 seed or fitter snapshot')
    shutil.copyfile(ORIGINAL, original_copy)
    shutil.copyfile(HERE / 'fit_side_controlled.py', snapshot)
    d = copy.deepcopy(np.load(original_copy, allow_pickle=True).item())
    offset = height / 2000 - float(d['obj_pose'][2])
    for key in ['pregrasp_qpos', 'grasp_qpos', 'squeeze_qpos']:
        d[key] = np.asarray(d[key], dtype=np.float64).copy()
        d[key][:, 2] += offset
    d.update(scene_path=str(scene_path(height)),
             obj_pose=np.array([0, 0, height / 2000, 1, 0, 0, 0], dtype=np.float64),
             obj_scale=np.array([.001, .001, .001 * height / 4], dtype=np.float64),
             ext_center=np.array([0, 0, height / 2000], dtype=np.float64))
    seed = sources / 'h060_d5_seed_center_aligned.npy'
    np.save(seed, d)
    record = dict(source=str(ORIGINAL), source_sha256=sha(ORIGINAL),
                  source_copy=str(original_copy), source_copy_sha256=sha(original_copy),
                  fitter_snapshot=str(snapshot), fitter_sha256=sha(snapshot),
                  initial_proposal=str(seed), initial_proposal_sha256=sha(seed),
                  initial_root_z_translation_m=offset,
                  scope='Auxiliary gravity-on actual-hand fit, not a successful physical grasp.')
    (sources / 'provenance.json').write_text(json.dumps(record, indent=2) + '\n')
    spec = importlib.util.spec_from_file_location('boundary_d5_fitter_frozen', snapshot)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    module.SOURCE = seed
    fit = module.Controlled(height, '9_Palmar_Pinch', .1, seed_path=seed)
    fit.fit()


if __name__ == '__main__':
    main()
