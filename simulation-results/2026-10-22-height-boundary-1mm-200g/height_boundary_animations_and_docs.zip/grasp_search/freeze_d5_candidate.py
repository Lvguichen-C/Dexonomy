#!/usr/bin/env python3
"""Freeze exact H60 controls with a separate full release-opening target."""
import hashlib
import importlib.util
import json
from pathlib import Path
import sys
import numpy as np

HERE = Path(__file__).resolve().parent
sys.path[:0] = [str(HERE), str(HERE.parent)]


def sha(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()


def encode(x):
    if isinstance(x, np.ndarray):
        return x.tolist()
    if isinstance(x, np.generic):
        return x.item()
    return str(x)


def main():
    source = HERE / 'candidates/h060_sidefit_9_Palmar_Pinch_preshape0.1.npy'
    out = HERE / 'candidates/h060_d5_palmar_side_release.npy'
    if out.exists():
        raise RuntimeError('Refusing to overwrite frozen candidate')
    seed = HERE / 'd5_sources/h060_d5_seed_center_aligned.npy'
    snapshot = HERE / 'fit_d5_frozen.py'
    spec = importlib.util.spec_from_file_location('d5_frozen_recheck', snapshot)
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    mod.SOURCE = seed
    oracle = mod.Controlled(60, '9_Palmar_Pinch', .1, source)
    d = np.load(source, allow_pickle=True).item()
    old = np.load(seed, allow_pickle=True).item()
    release = d['grasp_qpos'][0].copy()
    release[7:] += old['pregrasp_qpos'][0, 7:] - old['grasp_qpos'][0, 7:]
    for k, (lo, hi) in oracle.ranges.items():
        release[k] = np.clip(release[k], lo, hi)
    d['release_qpos'] = release[None]
    d['boundary_proposal_provenance'] = dict(source=str(source), source_sha256=sha(source),
        fitter_snapshot=str(snapshot), fitter_snapshot_sha256=sha(snapshot),
        release='Optimized grasp plus full D5 source joint opening delta; clipped to original joint limits.',
        physical_success_inferred=False)
    np.save(out, d)
    saved = np.load(out, allow_pickle=True).item()
    checks = {}
    for phase, squeeze in [('grasp', None), ('squeeze', saved['squeeze_qpos'][0])]:
        actual, obj, gaps, segments, hh, ho, plane = oracle.simulate(saved['grasp_qpos'][0], squeeze)
        native, qp, contacts = oracle.native(actual, obj)
        checks[phase] = dict(tip_gaps_m=gaps, segments_m=segments,
                            hand_hand_negative_distance_m=hh, hand_object_negative_distance_m=ho,
                            minimum_hand_z_m=plane, native_filter_passed=native, qp_residual=qp,
                            actual_hand_qpos=actual, isolated_object_pose=obj)
    v = dict(id='h060_d5_palmar_side_release', input=str(out), input_sha256=sha(out),
             height_mm=60, template='9_Palmar_Pinch', closure_duration_scale=1.,
             far_start_offset_m=.1, stage='uncertified_dynamic_proposal',
             source_grasp=str(source), source_sha256=sha(source),
             recheck=checks, release_target_joint_limits_preserved=True,
             source_seed_provenance=str(HERE / 'd5_sources/provenance.json'),
             formal_lift_success_inferred=False)
    manifest = HERE / 'd5-h060-frozen.json'
    manifest.write_text(json.dumps(dict(variants=[v]), indent=2, default=encode) + '\n')
    print(json.dumps(dict(manifest=str(manifest), input=str(out), input_sha256=v['input_sha256'],
                         recheck=checks), default=encode))


if __name__ == '__main__':
    main()
