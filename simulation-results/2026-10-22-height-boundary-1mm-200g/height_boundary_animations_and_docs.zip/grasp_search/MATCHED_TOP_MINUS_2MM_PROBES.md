# Low-height top-minus-2mm strategy probes

This is a separate grasp-site strategy from center-height translation. It uses the identical frozen H60 control payload and requested matched feedback, but places its nominal 30 mm grab reference at `H−2` mm rather than at the new rod center. All pregrasp/grasp/squeeze/release root Z values receive `H−32` mm; root X/Y, hinge values, quaternions and source controller instructions are unchanged.

This is not per-height optimization, a claim of physical success, or evidence of a universal minimum height. In particular, a center-aligned H20 floor collision does not exclude this different top grip. The rod center/scene and diameter1 mm/mass0.2 kg are preserved correctly.

The sole formal owner was sent the immutable H17/H20 priority manifest `matched-topminus2-h017-h020-frozen.json` for matched support conditions. The remaining inputs and diagnostics are kept separately.

| Height | Root Z translation | Actual projected hand-floor clearance | Actual projected HH minimum negative distance | Actual projected HO minimum negative distance | Initial all-hand/object gap | Auto formal eligible |
| --- | ---: | ---: | ---: | ---: | ---: | --- |
| 16 mm | -16.0 mm | -0.0170 mm | 0.0000 µm | 0.0000 µm | 97.636 mm | False |
| 17 mm | -15.0 mm | 0.9830 mm | 0.0000 µm | 0.0000 µm | 97.636 mm | True |
| 18 mm | -14.0 mm | 1.9830 mm | 0.0000 µm | -9.3819 µm | 97.636 mm | False |
| 20 mm | -12.0 mm | 3.9830 mm | 0.0000 µm | 0.0000 µm | 97.636 mm | True |
| 24 mm | -8.0 mm | 7.9830 mm | 0.0000 µm | 0.0000 µm | 97.636 mm | True |


The auxiliary diagnostics physically simulate the original free hand far from a free gravity-on rod, with declared micro hand/object pairs. They then inspect a cloned state translated to closure height; no physical object is teleported or welded in a trial. This check does not run the complete matched normal/axis/root controller, so it cannot replace formal lift/hold/release verification.

H16 has only a small negative projected floor clearance (~17 µm), while H18 has a microscopic negative native HO distance despite positive floor clearance. They are conservatively excluded from the automatic queue and retained as **diagnostic inputs**, not counted as formal failures or claims that those heights are impossible. H24 is available in `matched-topminus2-height-probes-frozen.json` with positive clearance. Any decision to test diagnostic inputs must retain the unchanged registered physical gates.

Keep these strategy results separate from the center-aligned series. Once matched full physical outcomes exist, refine locally and test nonmonotonic cases; a successful H17 plus an untested/diagnostic H16 would establish a lowest tested height for this strategy, not a proven global boundary.
