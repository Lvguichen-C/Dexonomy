#!/usr/bin/env python3
"""Cheap actual far-hand probes of original legal index joint stops.

No drive, range, geometry or contact parameter is changed. These are isolated
hand diagnostics, not physical rod grips or successful lift candidates.
"""
from fit_side_controlled import *

def main():
    record=HERE/'h120_sidefit_14_Tripod_preshape0.1_forcebalanced.json'
    row=json.loads(record.read_text());base=np.array(row['control_grasp_qpos'])
    source=HERE/'sources/h120_tripod_centered_seed.npy'
    c=Controlled(120,'14_Tripod',0.,source)
    total=float(base[9:11].sum());eps=1e-5
    cases={'original_split':base.copy()}
    for name,pair in {
        'FFJ2_lower':(eps,min(total-eps,c.ranges[10][1]-eps)),
        'FFJ1_upper':(max(eps,total-c.ranges[10][1]+eps),c.ranges[10][1]-eps),
        'FFJ1_lower':(min(total-eps,c.ranges[9][1]-eps),eps),
        'FFJ2_upper':(c.ranges[9][1]-eps,max(eps,total-c.ranges[9][1]+eps)),
    }.items():
        q=base.copy();q[9:11]=pair;cases[name]=q
    results=[]
    for name,q in cases.items():
        actual,obj,ds,sg,hh,ho,plane=c.simulate(q)
        live_ho=0;live_hh_negative=0.
        for contact in c.live.contact:
            names=[c.m.body(c.m.geom_bodyid[g]).name for g in (contact.geom1,contact.geom2)]
            if any(n.startswith('hand-') for n in names) and any(n.startswith('obj-') for n in names):live_ho+=1
            if all(n.startswith('hand-') for n in names):live_hh_negative=min(live_hh_negative,float(contact.dist))
        result=dict(case=name,commanded_FFJ2_FFJ1=q[9:11],actual_FFJ2_FFJ1=actual[9:11],commanded_sum=float(q[9:11].sum()),actual_sum=float(actual[9:11].sum()),actual_pair_qvel=c.live.qvel[c.ff_pair_dofs],far_approach_offset_m=c.far_offset_m,live_far_hand_object_contacts=live_ho,live_far_hand_hand_negative_distance_m=live_hh_negative,projected_tip_gap_query_m=ds,projected_hand_object_negative_distance_m=ho,projected_hand_hand_negative_distance_m=hh,physical_grasp_success_inferred=False,parameters_changed='Only legal control/initial finger targets; original joint ranges and drives are untouched')
        results.append(result);print(json.dumps(result,default=encode),flush=True)
    write(HERE/'joint_stop_probe.json',dict(height_mm=120,gravity_enabled=True,timestep_s=.001,seed_record=str(record),seed_record_sha256=sha(record),profile='isolated_far_hand_original_joint_stops',results=results))
if __name__=='__main__':main()
