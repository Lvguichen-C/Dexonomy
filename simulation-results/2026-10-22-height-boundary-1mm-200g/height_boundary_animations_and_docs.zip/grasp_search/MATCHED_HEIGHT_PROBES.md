# Matched-controller height probes from the H60 reference

The same H60 D5-derived normalmapped control payload is used at every height. This is a **matched translated-control probe**, not a new per-height optimization or a native/physical certification. The sole formal-trial owner binds the exact same frozen feedback controller and configuration to H60 and all probe jobs. The requested reference at generation time was `normal_integrator_contact_axis_preload5`; later controller comparisons must be applied symmetrically and identified in their own jobs.

The parent experiment has demonstrated the real H60 lift/hold/release task under that feedback family, while the full-quaternion yaw checks remained unresolved at the time of preparation. This document does not relabel those checks or assert success at any other height.

## Exact input adaptation

For H mm the new root translation is `(H−60)/2` mm. Every row of `pregrasp_qpos`, `grasp_qpos`, `squeeze_qpos` and `release_qpos` receives only that world-Z offset. Their hinge targets, quaternions and root X/Y values are verified bit-for-bit unchanged. Reference input SHA256 is `ded2bb08b96e0f15d394c776650c1604366efd5e72e899d100f42e9689fe9d0c`. Scene center/height/scale and world contact annotation positions are updated to the new rod; mass remains 0.2 kg and diameter remains 1 mm. The reference H60 file is not modified.

Larger rods need a larger far-start offset to preserve the same ≥50 mm initial all-hand/object clearance requirement: H80 uses 110 mm and H120 uses 130 mm. This initial clearance adaptation is explicit; feedback gains/tasks, contact settings and lifting/holding instructions are unchanged. H30/H40/H50 retain 100 mm.

## Actual far-hand clearance diagnostics

The auxiliary check uses the original hand plus the declared micro HO-pair model, with gravity and free object. It starts high, physically holds 0.5 s, executes saved opening/grasp/squeeze targets and holds 1 s. A copied post-run data state then translates the hand down to inspect the closure-height floor clearance. It does not execute normal/axis/root feedback or a real grasp, so its output is a diagnostic rather than a claim that the formal controller will reproduce it. Formal input/reset rules are unchanged.

| Height | Center translation | Far-start offset | Actual projected hand-floor clearance | Initial all-hand/object gap | Eligible matched probe |
| --- | ---: | ---: | ---: | ---: | --- |
| 20 mm | -20.0 mm | 100 mm | -4.017 mm | 89.714 mm | False |
| 30 mm | -15.0 mm | 100 mm | 0.983 mm | 84.770 mm | True |
| 40 mm | -10.0 mm | 100 mm | 5.983 mm | 79.833 mm | True |
| 50 mm | -5.0 mm | 100 mm | 10.983 mm | 74.904 mm | True |
| 80 mm | +10.0 mm | 110 mm | 25.983 mm | 69.950 mm | True |
| 120 mm | +30.0 mm | 130 mm | 45.983 mm | 69.950 mm | True |


The unchanged H20 pose extends approximately 4.017 mm below the table in this diagnostic. It is excluded from automatic formal scheduling and preserved in `matched-height-clearance-diagnostics.json`; this is **not a formal failure and not evidence that H20 cannot be grasped with a different pose**. H30 has only about 0.983 mm clearance, so the actual controller and table interaction must be observed in its full trial.

The four immediately scheduled immutable inputs are in `matched-h030-h040-h050-h080-frozen.json`. `matched-height-probes-frozen.json` additionally includes H120. Source checks, per-input hashes, full array checks, scene hashes, auxiliary data and floor geometry are stored in each row/record. No tests below H30 or above H60 are claimed successful here.

A success boundary must compare the same controller/support/profile across heights. Different failed Palmar/Tripod seeds from the initial scout do not establish the boundary for this newly successful feedback strategy. After real matched successes and failures, sample adjacent integer heights and keep nonmonotonic results rather than inferring a universal threshold.
