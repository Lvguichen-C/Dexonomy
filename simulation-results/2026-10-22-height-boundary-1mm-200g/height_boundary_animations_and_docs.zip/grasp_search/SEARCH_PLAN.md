# Diameter 1 mm, 200 g height-boundary search

The goal is a real free-object 100 mm lift followed by a five-second hold and
release, using the existing Shadow actuators and hand geometry. A native static
filter result, contact force target, translated seed or isolated-hand geometry
fit does not satisfy this goal. All old experiment directories are read-only.

## Coarse exploration

The requested initial height set is 12, 16, 20, 30, 40, 60, 80 and 120 mm. The
first rapid physical scout uses 20/40/80 mm, each with top and middle seed
positions. These quick translated H10 controls are explicitly uncertified. The
remaining five heights have immutable prepared inputs, but repeating a failed
shape is lower priority than testing a genuinely different contact topology.

The six first plain scouts failed: top contact did not carry weight, while the
middle seeds pushed the long rod over. This is evidence about these control
seeds, not a proof that any height is infeasible.

## Independent contact families and actual control

Three families are being explored:

- A previous D1 H10 Palmar target that formed loaded double contact but had
  insufficient force; its new middle fit explicitly targets horizontal opposing
  normals, with actual gravity-on opening and settle at every objective call.
- An independent native 14 Tripod source from the earlier D40/H160 experiment;
  both index and middle use only their existing abduction/proximal/summed tendon
  controls. This adds a new contact topology rather than another rigid shift.
- A genuinely load-bearing D5/H20 Palmar source from the 200 g sweep, explored
  independently by the root agent. It held weight previously but still requires
  new diameter/segment retargeting and a full D1 trial.

The high-altitude auxiliary dynamics use gravity, a free rod and the original
hand gains/weld. Only after those dynamics does a cloned data state translate
the hand for geometry queries. This diagnostic translation is never used inside
a formal trial. Saved float64 controls are remeasured at both grasp and squeeze;
the formal trial starts from a far, contact-free state and remains continuous.

The pinching azimuth is measured from each seed's actual index-to-object side.
Hard-coding the Palmar side assignment was unsuitable for the independent
Tripod orientation; the corrected searches have new `normalmapped` IDs.

A new force-aware objective also minimizes the difference between generalized
FFJ2 and FFJ1 torques produced by a unit radial fingertip load. The existing
tendon supplies equal torque to these hinges; a large differential contact
torque can redistribute their unactuated internal angle despite a well-tracked
sum. This is a pose-selection constraint, not a new actuator or altered limit.
The first such finite candidate is H120 Tripod, with a distinct `forcebalanced`
ID. Any predicted improvement must still survive actual loaded trials.

## Physical checks and numerical profiles

Native joint/collision/contact/QP thresholds and the extra two-tip 50 micrometre
geometry gate remain unchanged. In this tiny mesh case, `mj_geomDistance` can
give positive values while native contacts show negative distance. Certification
therefore requires the native contact checks too; proximity output is never
interpreted as pressure.

At friction 0.6, supporting 0.2 kg needs at least about 3.27 N total appropriately
directed normal pressure, before moment constraints. That lower bound is a
diagnostic, not a success threshold replacing the registered lift/hold checks.
Force-control experiments are separate profiles with recorded actuator targets.

Original mesh/contact results remain separate from optional analytic-cylinder
and contact-stiffness diagnostic profiles. They preserve nominal rod dimensions
and hand mechanics but change numerical modeling; successes in those profiles
must not be relabeled as original-profile successes or a pure height effect.

Long rods need more than 100 mm approach offset to ensure every part of the
hand starts at least 50 mm from the rod. New middle inputs record their larger
offset explicitly. Actual minimum distance is checked by the formal runner.

## Refining a successful region

Height is not assumed to have a monotonic effect. Once a profile/support/contact
family has a real successful trial, test nearby integer heights and refine the
interval between that success and its nearest tested failure using new full
trials. Midpoint selection is only a way to sample that interval, not a proof of
monotonicity. Keep counterexamples and test both immediate neighbours of a
candidate boundary. Report the lowest **tested** successful height and any
observed successful intervals; do not claim a global minimum from bisection.

If the initial coarse set has no success, add genuinely new stable contact
poses/feedback before merely extending translated failed controls to 160/240 mm.
The search budget is one heavy candidate-fitting worker, independent of the
formal trial and controller workers. Checkpoints preserve all failed formal
results and immutable candidate hashes so the result remains reviewable.
