#!/usr/bin/env python3
"""Pure observer sidecar for a declared control profile; no physics edits.

The original metrics remain owned by the unchanged profile/evaluator. This
wrapper only reads actual object pose, freejoint state and velocities after
each original observer call, and writes a separate 1 kHz NPZ and provenance.
"""
from __future__ import annotations
import argparse
import importlib
import json
from pathlib import Path
import sys

import mujoco
import numpy as np

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT))
import run_height_trials as runner


def run_logged(job, profile_script):
    profile_script = Path(profile_script).resolve()
    if profile_script.parent != ROOT:
        raise ValueError("Profile must be an explicit script in this isolated experiment root")
    output = Path(job["output"])
    if output.exists():
        raise RuntimeError("Refusing an existing output directory; use a new run UUID")
    job = dict(job)
    job["provenance_sources"] = list(dict.fromkeys(job.get("provenance_sources", []) + [str(Path(__file__).resolve()), str(profile_script)]))
    job["diagnostic_logger_only"] = {"script": str(Path(__file__).resolve()), "sha256": runner.sha(__file__),
        "changes_controller_model_or_metrics": False, "sample_period_s": .001}
    profile = importlib.import_module(profile_script.stem)
    original_builder = runner.make_observer_class

    def builder(frozen):
        base = original_builder(frozen)

        class ObjectStateLogger(base):
            def __init__(self, *args, **kwargs):
                super().__init__(*args, **kwargs)
                model = self.env._model
                joints = [j for j in range(model.njnt) if model.jnt_type[j] == mujoco.mjtJoint.mjJNT_FREE
                          and model.body(int(model.jnt_bodyid[j])).name.startswith("obj-")]
                if len(joints) != 1:
                    raise RuntimeError("Expected one actual object freejoint")
                self.object_joint_id = joints[0]
                self.object_qpos_address = int(model.jnt_qposadr[joints[0]])
                self.object_dof_address = int(model.jnt_dofadr[joints[0]])
                self.object_state_rows = []
                self.object_state_phase_names = list(frozen.PHASES)

            def observe(self):
                super().observe()
                data = self.env._data
                qa, va = self.object_qpos_address, self.object_dof_address
                self.object_state_rows.append((float(data.time), self.object_state_phase_names.index(self.phase),
                    self.env.get_active_obj_pose().copy(), data.qpos[qa:qa + 7].copy(),
                    data.qvel[va:va + 6].copy(), data.qvel.copy()))

            def finish(self):
                super().finish()
                fields = ["time_s", "phase_id", "object_pose_evaluator_body_xpos_xquat", "object_freejoint_qpos",
                          "object_freejoint_qvel_generalized", "all_generalized_qvel"]
                arrays = {name: np.asarray([row[i] for row in self.object_state_rows], dtype=np.int16 if name == "phase_id" else np.float64)
                          for i, name in enumerate(fields)}
                arrays["phase_names"] = np.asarray(self.object_state_phase_names)
                path = self.output / "object_state_1khz.npz"
                np.savez_compressed(path, **arrays)
                runner.write_json(self.output / "object_state_1khz.json", {
                    "logger_source": str(Path(__file__).resolve()), "logger_sha256": runner.sha(__file__),
                    "profile_source": str(profile_script), "profile_sha256": runner.sha(profile_script),
                    "npz": str(path.resolve()), "npz_sha256": runner.sha(path),
                    "object_joint_id": self.object_joint_id, "object_joint_name": self.env._model.joint(self.object_joint_id).name,
                    "object_qpos_address": self.object_qpos_address, "object_dof_address": self.object_dof_address,
                    "samples": len(self.object_state_rows), "sample_period_s": float(self.env._model.opt.timestep),
                    "no_control_model_metrics_or_original_trace_edits": True,
                    "sampling_note": "Both evaluator body xpos/xquat and current freejoint qpos are retained. mj_step data may retain pre-integration kinematics while qpos/qvel already contain the integrated state; these fields are explicitly distinguished."
                })

        return ObjectStateLogger

    runner.make_observer_class = builder
    try:
        return profile.run_trial(job)
    finally:
        runner.make_observer_class = original_builder


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--job", type=Path, required=True)
    parser.add_argument("--profile-script", type=Path, default=ROOT / "normal_contact_axis_profile.py")
    args = parser.parse_args()
    return run_logged(json.loads(args.job.read_text()), args.profile_script)


if __name__ == "__main__":
    main()
