#!/usr/bin/env python3
"""Independent archived-model/1ms-data audit; does not integrate physics."""
from pathlib import Path
import argparse
import hashlib
import importlib.util
import json
import mujoco
import numpy as np

ROOT = Path(__file__).resolve().parents[1]
OLD_HELPERS = Path('/workspace/shadow-lift-sweep-200g/upright-1mm-20261022/qa/audit_trials.py')
spec = importlib.util.spec_from_file_location('previous_independent_helpers', OLD_HELPERS)
helpers = importlib.util.module_from_spec(spec)
spec.loader.exec_module(helpers)
PHASES = helpers.PHASES
sha = helpers.sha


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--metrics-root', type=Path, nargs='+', default=[ROOT / 'trials'])
    parser.add_argument('--output', type=Path, default=ROOT / 'qa/independent-trial-audit.json')
    args = parser.parse_args()
    paths = sorted({p for folder in args.metrics_root for p in folder.rglob('metrics.json')})
    assert paths
    rows, fixture_signature = [], None
    for path in paths:
        r = json.loads(path.read_text()); p = r['upright_protocol']; height = r['height_mm']
        assert isinstance(height, int) and height >= 10 and r['diameter_mm'] == 1
        for key, source in [('runner_sha256', ROOT / 'run_height_trials.py'), ('fixture_source_sha256', ROOT / 'scene_factory.py'), ('frozen_evaluator_sha256', Path('/workspace/shadow-lift-sweep-200g/evaluate_lifts.py'))]:
            assert r['upright_provenance'][key] == sha(source), (path, key)
        assert sha(r['input']) == r['input_sha256'] == r['upright_provenance']['input_sha256']
        assert sha(r['upright_provenance']['scene_path']) == r['upright_provenance']['scene_npy_sha256']
        assert sha(p['model_mjb']) == p['model_mjb_sha256'] and sha(p['model_xml']) == p['model_xml_sha256']
        model = mujoco.MjModel.from_binary_path(p['model_mjb'])
        assert model.opt.timestep == .001 and np.array_equal(model.opt.gravity, [0, 0, -9.81])
        assert not (model.opt.disableflags & int(mujoco.mjtDisableBit.mjDSBL_GRAVITY))
        geo = helpers.groups(model)
        objj = [j for j in range(model.njnt) if model.body(int(model.jnt_bodyid[j])).name.startswith('obj-')]
        assert len(objj) == 1 and model.jnt_type[objj[0]] == mujoco.mjtJoint.mjJNT_FREE
        body, adr = int(model.jnt_bodyid[objj[0]]), int(model.jnt_qposadr[objj[0]])
        assert abs(model.body_mass[body] - .2) < 1e-9 and model.body_mocapid[body] < 0
        assert body not in list(model.eq_obj1id) + list(model.eq_obj2id) and model.neq == 1
        assert len(geo['object']) == 1
        gid = geo['object'][0]
        if model.geom_type[gid] == mujoco.mjtGeom.mjGEOM_MESH:
            mid = int(model.geom_dataid[gid])
            vertices = model.mesh_vert[model.mesh_vertadr[mid]:model.mesh_vertadr[mid] + model.mesh_vertnum[mid]]
            dimensions = vertices.max(axis=0) - vertices.min(axis=0)
        else:
            assert model.geom_type[gid] == mujoco.mjtGeom.mjGEOM_CYLINDER
            dimensions = np.array([model.geom_size[gid, 0] * 2] * 2 + [model.geom_size[gid, 1] * 2])
        assert np.allclose(dimensions, [.001, .001, height / 1000], rtol=0, atol=1e-8)
        analytic = np.array([.2 * (3 * .0005 ** 2 + (height / 1000) ** 2) / 12] * 2 + [.2 * .0005 ** 2 / 2])
        assert np.allclose(np.sort(model.body_inertia[body]), np.sort(analytic), rtol=.01, atol=0)
        assert all(int(model.geom_bodyid[g]) == 0 for g in geo['fixture'])
        if r['fixture'] == 'shallow':
            assert len(geo['fixture']) == 33
            signature = {key: getattr(model, key)[geo['fixture']].tolist() for key in ['geom_type', 'geom_size', 'geom_pos', 'geom_quat', 'geom_friction', 'geom_condim', 'geom_priority', 'geom_margin', 'geom_solref', 'geom_solimp']}
            if fixture_signature is None: fixture_signature = signature
            assert signature == fixture_signature, 'Shallow support changed across conditions'
        else:
            assert r['fixture'] == 'plain' and not geo['fixture']
        with np.load(r['trace'], allow_pickle=False) as z, np.load(p['diagnostics'], allow_pickle=False) as d:
            assert list(z['phase_names']) == PHASES == list(d['phase_names'])
            assert z['qpos'].dtype == np.float64 and np.array_equal(z['qpos'][0], model.key_qpos[0])
            assert np.allclose(z['qpos'][0, adr:adr + 7], [0, 0, height / 2000, 1, 0, 0, 0], rtol=0, atol=1e-9)
            assert np.isfinite(z['qpos']).all() and np.isfinite(z['ctrl']).all()
            times = d['time_s']; assert len(times) == r['physics_steps']
            assert abs(times[0] - .001) < 1e-12 and np.allclose(np.diff(times), .001, rtol=0, atol=1e-10)
            assert abs(times[-1] - r['simulation_duration_s']) < 1e-9 and abs(z['time_s'][-1] - times[-1]) < 1e-9
            data = mujoco.MjData(model); data.qpos[:] = z['qpos'][0]; data.ctrl[:] = z['ctrl'][0]
            data.mocap_pos[:] = z['mocap_pos'][0]; data.mocap_quat[:] = z['mocap_quat'][0]; mujoco.mj_forward(model, data)
            gaps = {key: helpers.gap(model, data, geo['hand'], geo[key]) for key in ['object', 'fixture', 'plane']}
            assert gaps['object'] >= .05 and gaps['plane'] > 0 and (gaps['fixture'] is None or gaps['fixture'] > 0)
            assert abs(gaps['object'] - p['initial_minimum_hand_object_geom_distance']['distance_m']) < 1e-9
            assert not any(helpers.pair_contacts(model, data, geo['hand'], geo[key]) for key in gaps)
            assert r['finite_states'] and not r['unexpected_time_resets'] and not any(r['maximum_warning_counts'])
            assert len(p['interventions']['reset']) == 1 and p['interventions']['object_pose_writes_within_trial'] == 0
            assert p['interventions']['gravity_changes_within_trial'] == 0
            assert not np.any(d['object_external_force_norm_N']) and not np.any(d['object_external_torque_norm_Nm'])
            command = p['native_trajectory_execution'][0]
            assert command['step'] == 5 and command['substep'] == 20 * p['closure_duration_scale']
            counts = [500, 2000, int(command['segments'] * 5 * command['substep']), round(r['config']['loaded_hold_s'] / .001), 5000, 5000, 1500, 1000, 3000]
            phases = []
            for i, (name, count) in enumerate(zip(PHASES, counts)):
                selected = d['phase_id'] == i; assert np.count_nonzero(selected) == count
                overlap = float(np.max(d['hand_object_max_penetration_m'][selected]))
                assert p['phase_statistics'][name]['samples'] == count
                assert abs(overlap - p['phase_statistics'][name]['maximum_hand_object_penetration_m']) < 1e-12
                phases.append({'phase': name, 'physics_steps': count, 'max_HO_overlap_mm': overlap * 1000, 'max_HO_overlap_over_radius': overlap / .0005})
            assert sum(counts) == r['physics_steps'] and not np.any(d['hand_object_contacts'][d['phase_id'] == 0])
            hold = d['phase_id'] == 5; loaded_lift = np.isin(d['phase_id'], [3, 4]); prerelease = d['phase_id'] <= 5
            body_names = d['body_names'].tolist(); mask = d['hand_object_contact_body_mask'].astype(np.uint64)
            thumb_bits = sum(1 << i for i, name in enumerate(body_names) if name.startswith('hand-') and 'th' in name.rsplit('-', 1)[-1])
            index_bits = sum(1 << i for i, name in enumerate(body_names) if name.startswith('hand-') and 'ff' in name.rsplit('-', 1)[-1])
            both = ((mask & thumb_bits) != 0) & ((mask & index_bits) != 0)
            assert np.array_equal(both, d['thumb_and_index_in_contact'] > 0)
            gain = d['object_z_m'][hold] - z['object_pose'][0, 2]
            checks = {
                'thumb_and_index_distinct_contacts_every_hold_step': bool(np.all(both[hold])),
                'thumb_and_index_positive_normal_load_every_hold_step': bool(np.all(d['normal_thumb_contact_force_sum_N'][hold] > 0) and np.all(d['normal_index_contact_force_sum_N'][hold] > 0)),
                'hold_HO_maximum_penetration_at_most_50um': bool(np.max(d['hand_object_max_penetration_m'][hold]) <= .00005),
                'loaded_and_lift_HO_maximum_penetration_at_most_100um': bool(np.max(d['hand_object_max_penetration_m'][loaded_lift]) <= .0001),
                'prerelease_HO_penetration_strictly_less_than_rod_radius_500um': bool(np.max(d['hand_object_max_penetration_m'][prerelease]) < .0005),
                'actual_object_height_95_to_105mm_every_hold_step': bool(np.all((gain >= .095) & (gain <= .105))),
                'support_absent_every_hold_step': bool(not np.any(d['object_fixture_contacts'][hold]) and not np.any(d['object_plane_contacts'][hold]))}
            assert checks == p['scientific_criteria'], (path, checks, p['scientific_criteria'])
            qualified = bool(r['frozen_lift_hold_passed'] and all(p['checks'].values()) and all(checks.values()))
            assert qualified == r['qualified_lift_hold_passed'] == r['lift_hold_passed']
            assert r['full_sequence_passed'] == bool(qualified and r['release_passed'])
            rows.append({'metrics': str(path), 'metrics_sha256': sha(path), 'trace': r['trace'], 'trace_sha256': sha(r['trace']), 'diagnostics': p['diagnostics'], 'diagnostics_sha256': sha(p['diagnostics']), 'model_mjb': p['model_mjb'], 'model_mjb_sha256': sha(p['model_mjb']), 'height_mm': height, 'fixture': r['fixture'], 'variant': r['variant'], 'loaded_hold_s': r['config']['loaded_hold_s'], 'matches_original_one_second_loading': r['config']['loaded_hold_s'] == 1., 'compiled_mass_kg': float(model.body_mass[body]), 'compiled_dimensions_m': dimensions.tolist(), 'compiled_inertia_kg_m2': model.body_inertia[body].tolist(), 'initial_true_hand_clearance_mm': {k: None if v is None else v * 1000 for k, v in gaps.items()}, 'phase_statistics': phases, 'independently_recomputed_scientific_criteria': checks, 'hold_thumb_index_positive_load_fraction': float(np.mean(both[hold] & (d['normal_thumb_contact_force_sum_N'][hold] > 0) & (d['normal_index_contact_force_sum_N'][hold] > 0))), 'hold_object_rise_range_mm': [float(np.min(gain) * 1000), float(np.max(gain) * 1000)], 'maximum_HO_overlap_mm': float(np.max(d['hand_object_max_penetration_m']) * 1000), 'raw_frozen_pass': r['frozen_full_sequence_passed'], 'qualified_full_sequence_pass': r['full_sequence_passed'], 'all_archive_model_and_protocol_checks_passed': True})
        print(f'QA passed: H{height} {r["fixture"]} {r["variant"]}', flush=True)
    result = {'schema_version': 1, 'scope': 'Independent compiled-model and every-1ms diagnostic/qualified-criteria audit; no physics integration', 'trial_count': len(rows), 'qualified_full_sequence_passes': sum(row['qualified_full_sequence_pass'] for row in rows), 'all_archive_model_and_protocol_checks_passed': True, 'same_shallow_fixture_geometry_across_all_heights': True if fixture_signature is not None else None, 'scientific_failure_is_not_qa_failure': True, 'inertia_check_tolerance': 'Within1% of analytic solid-cylinder inertia; original collision mesh is polygonal.', 'trials': rows}
    args.output.write_text(json.dumps(result, indent=2, ensure_ascii=False) + '\n')


if __name__ == '__main__':
    main()
