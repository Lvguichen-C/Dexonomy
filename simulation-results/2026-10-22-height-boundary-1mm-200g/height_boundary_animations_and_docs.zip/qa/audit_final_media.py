#!/usr/bin/env python3
"""One independent final full decode per delivered video; no MuJoCo stepping."""
from pathlib import Path
import csv
import json
import re
import subprocess
import numpy as np
from review_latch_six_and_repeats import ROOT, QA, sha, load, write

INDEX=ROOT/'animations/index.json'
def main():
    idx=load(INDEX); pool=load(ROOT/'trials/final-pool-freeze.json')
    assert len(idx['sources'])==39 and len(idx['videos'])==45
    assert {s['metrics'] for s in idx['sources']}=={s['metrics'] for s in pool['rows']}
    for key in ['dependencies','previews','numerical_outputs','source_manifests','composite_manifests']:
        for f in idx[key]: assert sha(f['path'])==f['sha256'],(key,f['path'])
    for key in ['formal_pool_freeze','independent_outcome_review']:
        f=idx[key];assert sha(f['path'])==f['sha256']
    original_sidecar=load(idx['independent_outcome_review']['path']); outcomes={r['metrics_path']:r for r in original_sidecar['rows']}
    rows=[]
    for s in idx['sources']:
        r=load(s['metrics']);out=outcomes[s['metrics']]
        for key,h in s['source_sha256'].items(): assert sha(s[key])==h,(s['trial_id'],key)
        assert s['full_sequence_passed']==r['full_sequence_passed']==out['original_full_sequence_passed']
        assert s['task_lift_hold_release_passed']==out['user_task_lift_hold_release_passed']
        assert abs(s['mass_kg']-.2)<1e-12 and s['initial_hover_no_hand_contact']
        with np.load(s['trace']) as z:
            times=z['time_s']; phase_names=z['phase_names'].tolist()
            with open(s['numerical_output']['path']) as f: frames=list(csv.DictReader(f))
            assert len(frames)==s['video_frames']
            seen=set()
            for n,c in enumerate(frames):
                i=int(c['trace_index']); assert int(c['frame'])==n and abs(float(c['video_time_s'])-n/10)<1e-8
                assert 0<=i<len(times) and abs(float(c['recorded_time_s'])-times[i])<1e-9
                assert c['phase']==phase_names[int(z['phase_id'][i])];seen.add(c['phase'])
                assert abs(float(c['object_rise_mm'])-(z['object_pose'][i,2]-z['object_pose'][0,2])*1000)<1e-8
                # Legacy trace object_table_contacts aggregates table-like fixture contacts;
                # video footer explicitly splits fixture vs actual world plane.
                for csvkey,npkey in [('hand_object_contacts','hand_object_contacts'),('object_fixture_contacts','object_fixture_contacts'),('object_table_contacts','object_plane_contacts'),('normal_hand_force_N','normal_hand_contact_force_sum_N'),('rod_tilt_deg','rod_tilt_deg')]:
                    assert abs(float(c[csvkey])-float(z[npkey][i]))<1e-8,(s['trial_id'],n,csvkey)
            assert seen==set(phase_names) and len(seen)==9
            assert int(frames[0]['trace_index'])==0 and float(frames[0]['hand_object_contacts'])==0
            assert int(frames[-1]['trace_index'])==s['final_trace_index']==len(times)-1
            assert abs(float(frames[-1]['recorded_time_s'])-s['final_recorded_time_s'])<1e-9
            assert abs(times[-1]-r['simulation_duration_s'])<1e-9
            rows.append({'trial_id':s['trial_id'],'metrics_sha256':sha(s['metrics']),'all9phases_present':True,'per_frame_values_match_actual_archived_state':True,'frame_count':len(frames),'final_trace_index':len(times)-1,'final_recorded_time_s':float(times[-1]),'original_strict_pass':r['full_sequence_passed'],'posthoc_task_pass':out['user_task_lift_hold_release_passed']})
    singles=[v for v in idx['videos'] if v['kind']=='trial']
    assert len(singles)==39 and {v['source_trial_id'] for v in singles}=={s['trial_id'] for s in idx['sources']}
    assert {s['trial_id'] for s in idx['sources'] if s['full_sequence_passed']}=={s['trial_id'] for s in idx['sources'] if s['height_mm']==17 and s['fixture']=='plain' and 'latch' in s['controller_profile']}
    video_rows=[];evidence=[]
    for v in idx['videos']:
        path=Path(v['path']); assert sha(path)==v['sha256']
        probe=json.loads(subprocess.check_output(['ffprobe','-v','error','-select_streams','v:0','-show_entries','stream=codec_name,pix_fmt,width,height,r_frame_rate,avg_frame_rate,nb_frames:format=duration','-of','json',str(path)],text=True))
        st=probe['streams'][0]
        assert st['codec_name']=='h264' and st['pix_fmt']=='yuv420p'
        assert st['r_frame_rate']==st['avg_frame_rate']=='10/1'
        assert int(st['nb_frames'])==v['frames'] and (st['width'],st['height'])==(v['width'],v['height'])
        assert abs(float(probe['format']['duration'])-v['duration_s'])<1e-6 and abs(v['frames']/10-v['duration_s'])<1e-8
        label=None;sample=[]
        if v['kind']=='overview':label='overview';sample=[0,181,237]
        elif path.name=='h017_axis_vs_latch_plain.mp4':label='axis_vs_latch';sample=[181,237]
        elif path.name=='h017_latch_plain_vs_shallow.mp4':label='h017_pair';sample=[181]
        elif path.name=='h060_latch_plain_vs_shallow.mp4':label='h060_pair';sample=[181]
        elif v['kind']=='trial' and 'h17__plain__' in v['source_trial_id'] and 'latch' in v['source_trial_id']:
            label='h017_strict_repeat' if 'strict_reference_' in v['source_trial_id'] else 'h017_strict_discovery';sample=[0,132,237] if label.endswith('discovery') else [132]
            if label.endswith('repeat'):label+='_'+v['source_trial_id'].split('strict_reference_')[-1]
        elif v['kind']=='trial' and 'h80__plain__h080_coarse_mid' in v['source_trial_id']:label='h080_failed';sample=[0,137,197]
        command=['ffmpeg','-v','error','-xerror','-threads','1','-filter_threads','1','-i',str(path),'-map','0:v:0','-an','-f','null','/dev/null']
        if label:
            target=QA/'decoded-media'/label;target.mkdir(parents=True,exist_ok=True)
            expression='+'.join('eq(n,%d)'%f for f in sample)
            command+=['-map','0:v:0','-vf',"select='"+expression+"'",'-vsync','0','-threads','1','-compression_level','2',str(target/'frame_%03d.png')]
        command+=['-progress','pipe:1','-nostats','-y']
        result=subprocess.run(command,capture_output=True,text=True,check=True)
        counts=re.findall(r'^frame=(\d+)\s*$',result.stdout,re.M)
        assert counts and int(counts[-1])==v['frames'],(path,result.stdout,result.stderr)
        assert 'progress=end' in result.stdout
        if label:
            actual=sorted(target.glob('frame_*.png'));assert len(actual)==len(sample)
            for n,p in zip(sample,actual):evidence.append({'path':str(p),'sha256':sha(p),'source_video':str(path),'source_video_sha256':v['sha256'],'decoded_frame_index':n,'purpose':label})
        video_rows.append({'path':str(path),'sha256':v['sha256'],'width':st['width'],'height':st['height'],'fps':10,'decoded_frames':int(counts[-1]),'duration_s':v['duration_s'],'full_decode_passed':True,'kind':v['kind']})
        print('Decoded',len(video_rows),'/45',path.name,flush=True)
    write(QA/'independent-final-media-review.json',{'schema_version':1,'all_automatic_checks_passed':True,'visual_review_status':'pending','animation_index_sha256':sha(INDEX),'independent_outcome_snapshot_sha256':idx['independent_outcome_review']['sha256'],'formal_trial_count':39,'video_count':45,'full_decode_passed':True,'physics_steps_reintegrated':0,'actual_state_binding_rows':rows,'videos':video_rows,'decoded_visual_evidence':evidence})

if __name__=='__main__':main()
