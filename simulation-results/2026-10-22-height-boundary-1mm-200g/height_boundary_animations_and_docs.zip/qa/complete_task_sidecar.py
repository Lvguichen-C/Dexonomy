#!/usr/bin/env python3
"""Complete posthoc sidecar from frozen records, preserving original labels."""
from pathlib import Path
import json
import numpy as np
from review_latch_six_and_repeats import ROOT, QA, sha, axis, axis_angle, angle, load, write

def main():
    side=load(QA/'task-and-axis-outcomes.json'); old={x['metrics_path']:x for x in side['rows']}; rows=[]
    audit=load(QA/'independent-all39-trial-audit.json'); archived={x['metrics']:x for x in audit['trials']}
    for path in sorted((ROOT/'trials').rglob('metrics.json')):
        r=load(path); u=r['upright_protocol']; p=path.parent
        assert archived[str(path)]['metrics_sha256']==sha(path)
        with np.load(u['diagnostics']) as d,np.load(r['trace']) as z:
            h=d['phase_id']==5; rise=d['object_z_m'][h]-r['initial_object_pose'][2]
            tilt=float(d['rod_tilt_deg'][h].max())
            nonquat=all(v for k,v in r['hold_criteria'].items() if k not in ['closure_rotation_throughout_hold','orientation_drift_throughout_hold'])
            checks={'all_original_non_fullquat_hold_criteria':nonquat,'all_original_protocol_checks':all(u['checks'].values()),
                'all_strict_contact_height_support_conditions':all(u['scientific_criteria'].values()),'release_passed':r['release_passed'],
                'all5000_hold_steps_positive_thumb_and_index_load':bool(np.all(d['normal_thumb_contact_force_sum_N'][h]>0) and np.all(d['normal_index_contact_force_sum_N'][h]>0)),
                'all5000_hold_steps_no_fixture_or_plane_contacts':bool(not np.any(d['object_fixture_contacts'][h]) and not np.any(d['object_plane_contacts'][h])),
                'hold_actual_height95to105mm':bool(np.all((rise>=.095)&(rise<=.105))),
                'hold_axis_within15deg_of_initial_vertical_every1ms':tilt<15}
            task=bool(all(checks.values())); cq=np.array(r['closure_object_pose'][3:]); sq=np.array(r['lift_end_object_pose'][3:]); ca=axis(cq); sa=axis(sq)
            closure_bound=min(tilt+float(axis_angle(ca,np.array([0,0,1.]))),r['maximum_closure_rotation_during_hold_deg'])
            drift_bound=min(tilt+float(axis_angle(sa,np.array([0,0,1.]))),r['postlift_hold_maximum_rotation_deg'])
            sampled_axes=axis(z['object_pose'][z['phase_id']==5,3:]); resolution=.04
            if (p/'contact_axis_feedback.npz').exists():
                with np.load(p/'contact_axis_feedback.npz') as f:
                    sel=f['phase']=='postlift_hold'
                    if np.any(sel): sampled_axes=f['rod_axis_world'][sel];resolution=.005
            exact=False
            if (p/'object_state_1khz.npz').exists():
                with np.load(p/'object_state_1khz.npz') as o:
                    assert np.array_equal(o['time_s'],d['time_s'])
                    sampled_axes=axis(o['object_pose_evaluator_body_xpos_xquat'][h,3:]);resolution=.001;exact=True
            cm=float(axis_angle(sampled_axes,ca).max());dm=float(axis_angle(sampled_axes,sa).max())
            symmetry=False if not task else bool(cm<15 and dm<15) if exact else True if closure_bound<15 and drift_bound<15 else None
            row={'metrics_path':str(path),'metrics_sha256':sha(path),'height_mm':r['height_mm'],'fixture':r['fixture'],'variant':r['variant'],
                'model_mjb_sha256':sha(u['model_mjb']),'diagnostics_sha256':sha(u['diagnostics']),
                'original_full_sequence_passed':r['full_sequence_passed'],
                'original_fullquat_failed_criteria':[k for k,v in r['hold_criteria'].items() if not v and k in ['closure_rotation_throughout_hold','orientation_drift_throughout_hold']],
                'user_task_lift_hold_release_passed':task,'user_task_diagnostic_defined_after_observing_axis_spin_result':True,
                'declared_loaded_hold_s':r['config']['loaded_hold_s'],'matches_original_one_second_loaded_hold':r['config']['loaded_hold_s']==1,
                'task_checks':checks,'hold_object_rise_range_mm':[float(rise.min()*1000),float(rise.max()*1000)],
                'closure_axis_angle_max_deg':cm,'hold_axis_drift_max_deg':dm,'axis_vector_sampling_s':resolution,
                'closure_axis_angle_conservative_upper_bound_deg_every1ms':closure_bound,
                'hold_axis_drift_conservative_upper_bound_deg_every1ms':drift_bound,
                'hold_world_axis_tilt_max_deg_every1ms':tilt,'symmetry_aware_axis_sampled_passed':bool(task and cm<15 and dm<15),
                'symmetry_aware_axis_passed':symmetry,
                'symmetry_aware_axis_pass_resolution':'Direct1ms vectors' if exact else 'Conservative1ms world-axis/fullquat bounds' if symmetry else 'Other task conditions fail' if not task else 'Sampled axes pass, but available1ms bounds cannot certify the15degree drift gate; not asserted.',
                'geometry_symmetry_scope':'Regular64mesh exact axial yaw symmetries are discrete5.625deg. Continuous-yaw axis quotient is posthoc diagnostic, not original fullquat gate.',
                'interpretation':'Original strict result preserved. Separate task/axis diagnostic defined after H60 axial-spin observation. Loading duration is explicitly recorded; no minimum-height or robustness conclusion.'}
            # Preserve deeper already-audited1ms or repeat evidence from prior independent reviews.
            if str(path) in old:
                previous=old[str(path)]; assert previous['metrics_sha256']==sha(path)
                row.update(previous)
            rows.append(row)
    assert len(rows)==len(archived)
    side.update(status='Frozen39-record pool posthoc sidecar; original metrics untouched.',rows=rows,
        retained_trial_record_count=len(rows),original_strict_success_count=sum(r['original_full_sequence_passed'] for r in rows),
        posthoc_task_success_count=sum(r['user_task_lift_hold_release_passed'] for r in rows),
        symmetry_axis_certified_count=sum(r['symmetry_aware_axis_passed'] is True for r in rows),
        symmetry_axis_undetermined_count=sum(r['symmetry_aware_axis_passed'] is None for r in rows),
        archived_trial_audit_sha256=sha(QA/'independent-all39-trial-audit.json'))
    write(QA/'task-and-axis-outcomes.json',side)
    print(json.dumps({k:side[k] for k in ['retained_trial_record_count','original_strict_success_count','posthoc_task_success_count','symmetry_axis_certified_count','symmetry_axis_undetermined_count']}))

if __name__=='__main__':main()
