#!/usr/bin/env python3
"""Read archived states, never integrate physics or edit frozen trial outputs."""
from pathlib import Path
import hashlib
import json
import numpy as np
import mujoco

ROOT = Path(__file__).resolve().parents[1]
QA = ROOT / 'qa'
def sha(p): return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def load(p): return json.loads(Path(p).read_text())
def axis(q):
    q = np.asarray(q, dtype=float); q = q / np.linalg.norm(q, axis=-1, keepdims=True)
    w, x, y, z = np.moveaxis(q, -1, 0)
    return np.stack([2*(x*z+w*y), 2*(y*z-w*x), 1-2*(x*x+y*y)], axis=-1)
def angle(q, ref):
    q = q / np.linalg.norm(q, axis=-1, keepdims=True)
    ref = ref / np.linalg.norm(ref, axis=-1, keepdims=True)
    return np.degrees(2*np.arccos(np.clip(np.abs(q @ ref), 0, 1)))
def axis_angle(a, b): return np.degrees(np.arccos(np.clip(a @ b, -1, 1)))
def write(p, x): Path(p).write_text(json.dumps(x, indent=2, ensure_ascii=False)+'\n')

def review(directory):
    p = Path(directory); r = load(p/'metrics.json'); u = r['upright_protocol']
    for src, h in r['upright_provenance']['declared_external_sources'].items(): assert sha(src) == h
    model = mujoco.MjModel.from_binary_path(u['model_mjb'])
    object_geoms = [i for i in range(model.ngeom) if model.body(int(model.geom_bodyid[i])).name.startswith('obj-')]
    assert len(object_geoms) == 1 and model.npair == 31
    for i in range(model.npair):
        gs = [int(model.pair_geom1[i]), int(model.pair_geom2[i])]
        assert len(set(gs) & set(object_geoms)) == 1
        assert any(model.body(int(model.geom_bodyid[g])).name.startswith('hand-') for g in gs)
        assert model.pair_dim[i] == 3
    assert np.allclose(model.pair_solref, [.004, 1.], rtol=0, atol=0)
    assert np.allclose(model.pair_solimp, [.95,.99,.00005,.5,2], rtol=0, atol=0)
    assert np.allclose(model.pair_friction[:, :2], .6, rtol=0, atol=0)
    with np.load(p/'diagnostics.npz') as d, np.load(p/'normal_integrator_feedback.npz') as n, np.load(p/'trace.npz') as z:
        assert np.array_equal(d['time_s'], n['time_s'])
        assert np.array_equal(d['actuator_ctrl'], n['actual_actuator_ctrl'])
        assert np.array_equal(d['normal_thumb_contact_force_sum_N'],n['actual_normal_force_N'][:,0])
        assert np.array_equal(d['normal_index_contact_force_sum_N'],n['actual_normal_force_N'][:,1])
        h = d['phase_id'] == 5; ll = np.isin(d['phase_id'], [4,5])
        assert np.count_nonzero(h) == 5000
        ctrl_ptp = float(np.max(np.ptp(d['actuator_ctrl'][ll],axis=0))); assert ctrl_ptp == 0
        closure_q = np.array(r['closure_object_pose'][3:]); start_q = np.array(r['lift_end_object_pose'][3:])
        closure_a = axis(closure_q); start_a = axis(start_q)
        tilt = float(np.max(d['rod_tilt_deg'][h])); closure_bound = tilt + float(axis_angle(closure_a,np.array([0,0,1.])))
        drift_bound = min(tilt + float(axis_angle(start_a,np.array([0,0,1.]))),r['postlift_hold_maximum_rotation_deg'])
        axis_data = {'axis_resolution_s': None, 'closure_axis_conservative_upper_bound_deg_every1ms':closure_bound,
                     'hold_axis_drift_conservative_upper_bound_deg_every1ms':drift_bound,
                     'world_axis_tilt_max_deg_every1ms':tilt}
        pose_checks = None
        if (p/'object_state_1khz.npz').exists():
            with np.load(p/'object_state_1khz.npz') as o:
                assert np.array_equal(d['time_s'],o['time_s']) and np.array_equal(d['phase_id'],o['phase_id'])
                po = o['object_pose_evaluator_body_xpos_xquat']; free = o['object_freejoint_qpos']
                assert np.array_equal(po[:,2],d['object_z_m'])
                assert np.isfinite(po).all() and np.isfinite(free).all() and np.isfinite(o['all_generalized_qvel']).all()
                expected=np.array(r['expected_lifted_object_pose']); start=np.array(r['lift_end_object_pose'])
                rise = po[h,2]-r['initial_object_pose'][2]
                expected_error=np.linalg.norm(po[h,:3]-expected[:3],axis=1)
                position_drift=np.linalg.norm(po[h,:3]-start[:3],axis=1)
                closure_rot=angle(po[h,3:],expected[3:]); hold_rot=angle(po[h,3:],start[3:])
                for got,key in [(float(closure_rot.max()),'maximum_closure_rotation_during_hold_deg'),(float(hold_rot.max()),'postlift_hold_maximum_rotation_deg')]:
                    assert abs(got-r[key]) < 1e-6,(p,key,got,r[key])
                pose_checks={
                    'minimum_height_gain_throughout_hold': bool(rise.min()>=.08),
                    'actual_object_lift_within_tolerance_throughout_hold':bool(np.max(np.abs(rise-.1))<=.005),
                    'expected_position_error_throughout_hold':bool(expected_error.max()<.02),
                    'closure_rotation_throughout_hold':bool(closure_rot.max()<15),
                    'position_drift_throughout_hold':bool(position_drift.max()<.02),
                    'orientation_drift_throughout_hold':bool(hold_rot.max()<15)}
                for k,v in pose_checks.items(): assert v == r['hold_criteria'][k],(p,k)
                a=axis(po[h,3:]); fa=axis(free[h,3:]); aq=axis_angle(a,closure_a); ad=axis_angle(a,start_a)
                axis_data.update(axis_resolution_s=.001, closure_axis_angle_max_deg=float(aq.max()),hold_axis_drift_max_deg=float(ad.max()),
                    current_freejoint_hold_rise_range_mm=((free[h,2]-r['initial_object_pose'][2])*1000).min().item())
                axis_data['current_freejoint_hold_rise_range_mm']=[float(np.min(free[h,2]-r['initial_object_pose'][2])*1000),float(np.max(free[h,2]-r['initial_object_pose'][2])*1000)]
                axis_data['current_freejoint_closure_axis_max_deg']=float(axis_angle(fa,closure_a).max())
                axis_data['current_freejoint_hold_axis_drift_max_deg']=float(axis_angle(fa,start_a).max())
                axis_data['object_state_1khz_sha256']=sha(p/'object_state_1khz.npz')
        else:
            a=axis(z['object_pose'][z['phase_id']==5,3:])
            axis_data.update(axis_resolution_s=.04,closure_axis_angle_max_deg=float(axis_angle(a,closure_a).max()),hold_axis_drift_max_deg=float(axis_angle(a,start_a).max()),
                resolution_note='No 1kHz quaternion sidecar was recorded for this earlier H60plain latch trial. 25Hz axes are descriptive; 1ms tilt and recorded fullquat drift supply conservative bounds, not exact 1ms vector extrema.')
        nonquat=all(v for k,v in r['hold_criteria'].items() if k not in ['closure_rotation_throughout_hold','orientation_drift_throughout_hold'])
        scientific=all(u['scientific_criteria'].values()); protocol=all(u['checks'].values())
        task_checks={'all_original_non_fullquat_hold_criteria':nonquat,'all_original_protocol_checks':protocol,
            'all_strict_contact_height_support_conditions':scientific,'release_passed':r['release_passed'],
            'all5000_hold_steps_positive_thumb_and_index_load':bool(np.all(d['normal_thumb_contact_force_sum_N'][h]>0) and np.all(d['normal_index_contact_force_sum_N'][h]>0)),
            'all5000_hold_steps_no_fixture_or_plane_contacts':bool(not np.any(d['object_fixture_contacts'][h]) and not np.any(d['object_plane_contacts'][h])),
            'hold_actual_height95to105mm':bool(np.all((d['object_z_m'][h]-r['initial_object_pose'][2]>=.095)&(d['object_z_m'][h]-r['initial_object_pose'][2]<=.105))),
            'hold_axis_within15deg_of_initial_vertical_every1ms':tilt<15}
        symmetry=bool(all(task_checks.values()) and (axis_data['closure_axis_angle_max_deg']<15 and axis_data['hold_axis_drift_max_deg']<15 if pose_checks is not None else closure_bound<15 and drift_bound<15))
        return {'metrics_path':str(p/'metrics.json'),'metrics_sha256':sha(p/'metrics.json'),'model_mjb_sha256':sha(u['model_mjb']),
            'diagnostics_sha256':sha(p/'diagnostics.npz'),'contact_axis_feedback_sha256':sha(p/'contact_axis_feedback.npz'),
            'height_mm':r['height_mm'],'fixture':r['fixture'],'variant':r['variant'],
            'original_full_sequence_passed':r['full_sequence_passed'],
            'original_fullquat_failed_criteria':[k for k,v in r['hold_criteria'].items() if not v and k in ['closure_rotation_throughout_hold','orientation_drift_throughout_hold']],
            'original_pose_checks_independently_recomputed_1khz':pose_checks,
            'original_fullquat_closure_max_deg':r['maximum_closure_rotation_during_hold_deg'],
            'original_fullquat_holdstart_drift_max_deg':r['postlift_hold_maximum_rotation_deg'],
            'user_task_lift_hold_release_passed':bool(all(task_checks.values())),
            'user_task_diagnostic_defined_after_observing_axis_spin_result':True,
            'declared_loaded_hold_s':r['config']['loaded_hold_s'],'matches_original_one_second_loaded_hold':r['config']['loaded_hold_s']==1,
            'task_checks':task_checks,'hold_max_HO_penetration_um':float(d['hand_object_max_penetration_m'][h].max()*1e6),
            'hold_object_rise_range_mm':[float((d['object_z_m'][h]-r['initial_object_pose'][2]).min()*1000),float((d['object_z_m'][h]-r['initial_object_pose'][2]).max()*1000)],
            'actual_all_actuator_ctrl_lift_hold_peak_to_peak':ctrl_ptp,
            'symmetry_aware_axis_passed':symmetry,**axis_data,
            'interpretation':'Original strict result is preserved. Separate task/axis diagnostics are posthoc; all cases use declared5s preload, not original1s loading.'}

def main():
    manifest=load(ROOT/'control_analysis/final-latch-six-cases.json')
    for x in manifest['source_files'].values(): assert sha(x['path'])==x['sha256']
    rows=[]
    for c in manifest['cases']:
        for key,x in c['files'].items():
            if isinstance(x,dict): assert sha(x.get('path',Path(c['directory'])/key))==x['sha256']
            else: assert sha(Path(c['directory'])/key)==x
        rows.append(review(c['directory']))
    refs=load(ROOT/'execution-ledger/h017-strict-reference-manifest.json'); base=Path(refs['reference_metrics']).parent
    repeat_rows=[]
    for j in refs['jobs']:
        assert j['status']=='completed'; p=Path(j['output']); rr=review(p); assert rr['original_full_sequence_passed']
        br=load(base/'metrics.json'); r=load(p/'metrics.json')
        assert r['input_sha256']==br['input_sha256'] and r['upright_provenance']['scene_npy_sha256']==br['upright_provenance']['scene_npy_sha256']
        assert sha(p/'model.mjb')==sha(base/'model.mjb')
        arrays={}
        for name in ['trace.npz','diagnostics.npz','normal_integrator_feedback.npz','root_pose_feedback.npz','contact_axis_feedback.npz','latch_feedback.npz','object_state_1khz.npz']:
            with np.load(base/name) as a,np.load(p/name) as b:
                assert a.files==b.files and all(np.array_equal(a[k],b[k]) for k in a.files),(p,name)
            arrays[name]=True
        rr['all_recorded_arrays_bitwise_equal_to_discovery']=arrays;rr['run_uuid']=j['run_uuid'];repeat_rows.append(rr)
    out={'schema_version':1,'all_independent_checks_passed':True,'physics_steps_reintegrated':0,
         'fixed_six_comparison_manifest_sha256':sha(ROOT/'control_analysis/final-latch-six-cases.json'),
         'fixed_six_original_strict_passes':sum(r['original_full_sequence_passed'] for r in rows),
         'fixed_six_posthoc_task_passes':sum(r['user_task_lift_hold_release_passed'] for r in rows),
         'fixed_six':rows,'h017_additional_independent_output_repeats':repeat_rows,
         'h017_discovery_plus_repeats_original_strict_passes':4,
         'repeat_scope':'Three additional full deterministic executions with separate UUID outputs, identical input/model/recorded arrays. Demonstrates deterministic reproducibility; no initial-state perturbation robustness tested.',
         'loading_scope':'Declared5s preload. No conclusion about original1s loading success.',
         'height_scope':'H17/H20 inputs share top-relative placement; H60 retains original middle placement. These declared inputs and finite trials cannot establish a monotonic/minimum height or hardware limit.'}
    write(QA/'independent-final-latch-six-and-strict-repeats-review.json',out)
    side=load(QA/'task-and-axis-outcomes.json'); by={r['metrics_path']:r for r in side['rows']}
    for r in rows+repeat_rows: by[r['metrics_path']]=r
    side['rows']=list(by.values());side['status']='Append-only independent sidecar; full pool finalization pending. Frozen metrics untouched.'
    write(QA/'task-and-axis-outcomes.json',side)
    print(json.dumps({'strict':out['fixed_six_original_strict_passes'],'task':out['fixed_six_posthoc_task_passes'],'repeat_strict':4,'sidecar_rows':len(side['rows'])}))

if __name__=='__main__':main()
