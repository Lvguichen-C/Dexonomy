#!/usr/bin/env python3
"""Read completed formal trials without changing any trial or criterion."""
import argparse
import csv
import hashlib
import io
import json
from pathlib import Path

import numpy as np

ROOT = Path(__file__).resolve().parent
ROTATION_GATES = {'closure_rotation_throughout_hold', 'orientation_drift_throughout_hold'}


def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def collect(root=ROOT):
    rows = []
    for path in sorted((root / 'trials').glob('h*/*/*/metrics.json')):
        folder = path.parent
        if not (folder / 'result.json').exists() or not (folder / 'diagnostics.npz').exists():
            continue
        m = json.loads(path.read_text())
        row = dict(height_mm=m['height_mm'], fixture=m['fixture'],
                   variant=m['variant'], profile=m.get('comparison_profile', 'original'),
                   full_pass=bool(m['full_sequence_passed']),
                   lift_hold_pass=bool(m['qualified_lift_hold_passed']),
                   release_pass=bool(m['release_passed']),
                   hold_min_rise_mm=1000 * m['minimum_hold_height_gain_m'],
                   hold_max_rise_mm=1000 * m['maximum_hold_height_gain_m'],
                   final_rise_mm=m['measured_object_lift_mm'], metrics=str(path),
                   metrics_sha256=digest(path), input=m['input'],
                   input_sha256=digest(m['input']),
                   model_mjb_sha256=digest(folder / 'model.mjb'),
                   trace_sha256=digest(folder / 'trace.npz'),
                   diagnostics_sha256=digest(folder / 'diagnostics.npz'),
                   loaded_hold_s=float(m['config']['loaded_hold_s']),
                   failed_original_hold_criteria=[k for k, v in m['hold_criteria'].items() if not v])
        with np.load(folder / 'diagnostics.npz', allow_pickle=False) as d:
            names = list(d['phase_names'])
            z0 = float(m['initial_object_pose'][2])
            for phase, prefix in [('loaded_hold', 'load'), ('lift', 'lift'), ('postlift_hold', 'hold')]:
                mask = d['phase_id'] == names.index(phase)
                dual = ((d['normal_thumb_contact_force_sum_N'] > 1e-10)
                        & (d['normal_index_contact_force_sum_N'] > 1e-10))
                row[prefix + '_dual_pct'] = 100 * float(np.mean(dual[mask]))
                row[prefix + '_mean_total_normal_N'] = float(np.mean(d['normal_hand_contact_force_sum_N'][mask]))
                row[prefix + '_peak_total_normal_N'] = float(np.max(d['normal_hand_contact_force_sum_N'][mask]))
                row[prefix + '_max_penetration_um'] = 1e6 * float(np.max(d['hand_object_max_penetration_m'][mask]))
                support = ((d['object_plane_contacts'][mask] > 0) | (d['object_fixture_contacts'][mask] > 0))
                row[prefix + '_unsupported_pct'] = 100 * float(np.mean(~support))
                if phase == 'postlift_hold':
                    row['hold_world_axis_tilt_max_deg'] = float(np.max(d['rod_tilt_deg'][mask]))
            pre_release = d['phase_id'] < names.index('release_open')
            row['maximum_prerelease_rise_mm'] = 1000 * float(np.max(d['object_z_m'][pre_release]) - z0)
            row['maximum_prerelease_penetration_um'] = 1e6 * float(np.max(d['hand_object_max_penetration_m'][pre_release]))
        # This derived diagnostic was explicitly added after observing the
        # first axial-spin outcome. It never replaces the original full gate.
        row['user_task_lift_hold_release_passed'] = bool(
            all(v for k, v in m['hold_criteria'].items() if k not in ROTATION_GATES)
            and all(m['upright_protocol']['checks'].values())
            and all(m['upright_protocol']['scientific_criteria'].values())
            and m['release_passed'] and row['hold_world_axis_tilt_max_deg'] < 15.)
        row['user_task_diagnostic_posthoc'] = True
        axis_path = root / 'qa/task-and-axis-outcomes.json'
        axis_rows = json.loads(axis_path.read_text())['rows'] if axis_path.exists() else []
        axis_record = next((v for v in axis_rows if v['metrics_path'] == str(path)), None)
        row['independent_user_task_checked'] = False
        row['symmetry_aware_axis_passed'] = None
        if axis_record is not None:
            if axis_record['metrics_sha256'] != row['metrics_sha256']:
                raise RuntimeError(f'Independent task record is stale: {path}')
            if axis_record['user_task_lift_hold_release_passed'] != row['user_task_lift_hold_release_passed']:
                raise RuntimeError(f'Independent task outcome disagrees: {path}')
            row['independent_user_task_checked'] = True
            row['symmetry_aware_axis_passed'] = axis_record['symmetry_aware_axis_passed']
        rows.append(row)
    return rows


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--write', action='store_true', help='Write summary JSON and CSV; never changes trial files.')
    args = ap.parse_args()
    rows = collect()
    data = dict(scope='Completed retained formal trial records only; overlapping duplicate startup is separately logged; auxiliary probes excluded.',
                trials=len(rows), full_passes=sum(r['full_pass'] for r in rows),
                task_passes=sum(r['user_task_lift_hold_release_passed'] for r in rows),
                additional_task_diagnostic_defined_posthoc=True,
                original_full_quaternion_criteria_preserved=True,
                rows=rows)
    if args.write:
        (ROOT / 'search-results.json').write_text(json.dumps(data, ensure_ascii=False, indent=2) + '\n')
        if rows:
            stream = io.StringIO()
            writer = csv.DictWriter(stream, fieldnames=list(rows[0]))
            writer.writeheader()
            writer.writerows(rows)
            (ROOT / 'search-results.csv').write_text(stream.getvalue())
    print(json.dumps({k: v for k, v in data.items() if k != 'rows'}, ensure_ascii=False))
    for row in rows:
        print(json.dumps({k: row[k] for k in ('height_mm', 'fixture', 'variant', 'full_pass', 'user_task_lift_hold_release_passed',
              'final_rise_mm', 'load_dual_pct', 'hold_dual_pct', 'hold_unsupported_pct',
              'maximum_prerelease_rise_mm', 'maximum_prerelease_penetration_um')}, ensure_ascii=False))


if __name__ == '__main__':
    main()
