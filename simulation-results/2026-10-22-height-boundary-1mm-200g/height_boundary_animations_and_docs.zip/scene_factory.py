#!/usr/bin/env python3
"""Isolated D1 mm, 200 g arbitrary integer-height scenes and fixed support.

The lazily generated base NPY scenes use plane z=0. The explicit shallow factory lowers that
new model's plane to -0.2mm and adds the unchanged frozen support. Old files are
read-only. Mass is normalized by density, including a compile calibration pass.
"""
from __future__ import annotations
import copy
import hashlib
import importlib.util
import json
import os
import tempfile
from pathlib import Path
import sys

import mujoco
import numpy as np

ROOT=Path(__file__).resolve().parent
REPO=Path("/workspace/Dexonomy")
ASSET_ROOT=REPO/"assets/object/cylinder_sweep_20261022/processed_data/cylinder_thin"
FIXTURE_SOURCE=Path("/workspace/shadow-lift-sweep-200g/upright-1mm-20261022/fixtures/fixture_scene.py")
FIXTURE_SHA256="8e5468ee643dfac5997e856691db0c2456a30c8b3ffa05c2bbf833a15ff35dc4"
HEIGHTS_MM=(12,16,20,30,40,60,80,120,160,240)
SOURCE_FACTORY=Path("/workspace/shadow-height-gradient-1mm-200g-20261022/scene_factory.py")
SOURCE_FACTORY_SHA256="520f96817ad6a3484b79421ab3e63280d97c6d3ed36e3a0833aa8982c475e35d"
sys.path.insert(0,str(REPO))


def sha256(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def fixture_module():
    if sha256(FIXTURE_SOURCE)!=FIXTURE_SHA256:
        raise RuntimeError("Frozen priority1 fixture source changed")
    name="_height_gradient_frozen_fixture"
    if name not in sys.modules:
        spec=importlib.util.spec_from_file_location(name,FIXTURE_SOURCE)
        module=importlib.util.module_from_spec(spec)
        sys.modules[name]=module
        spec.loader.exec_module(module)
    return sys.modules[name]


def frozen_module():
    return fixture_module().frozen_module()


def validated_height(height_mm):
    if isinstance(height_mm,(bool,np.bool_)):
        raise ValueError("Height must be an integer >=10mm")
    try:
        height=int(height_mm)
        exact=float(height_mm)==height
    except (TypeError,ValueError,OverflowError):
        raise ValueError("Height must be an integer >=10mm") from None
    if not exact or height<10:
        raise ValueError("Height must be an integer >=10mm")
    return height


def scene_path(height_mm):
    """Return a scene path, atomically creating this integer height if absent."""
    height=validated_height(height_mm)
    path=ROOT/"scenes"/f"h{height:03d}.npy"
    if not path.exists():
        generate_scenes((height,))
    return path


def generate_scenes(heights=None):
    paths=[]
    for height in HEIGHTS_MM if heights is None else heights:
        height=validated_height(height)
        path=ROOT/"scenes"/f"h{height:03d}.npy"
        height_m=height/1000
        scene={"scene":{
            "cylinder_thin":{"type":"rigid_object",
                "file_path":str(ASSET_ROOT/"mesh/simplified.obj"),
                "xml_path":str(ASSET_ROOT/"urdf/coacd.xml"),
                "urdf_path":str(ASSET_ROOT/"urdf/coacd.urdf"),
                "info_path":str(ASSET_ROOT/"info/simplified.json"),
                "scale":np.array([.001,.001,.001*height/4],dtype=np.float64),
                "pose":np.array([0,0,height_m/2,1,0,0,0],dtype=np.float64)},
            "table":{"type":"plane","pose":np.array([0,0,0,1,0,0,0],dtype=np.float64),
                "size":np.array([.4,.4,.01],dtype=np.float64),"board":True}},
            "scene_id":f"cylinder_d1_h{height:03d}",
            "task":{"type":"force_closure","obj_name":"cylinder_thin"},
            "diameter_mm":1,"height_mm":height,"target_mass_kg":.2,
            "support_binding":"Base plane0; make_env applies explicit fixed shallow fixture without changing rod pose"}
        path.parent.mkdir(parents=True,exist_ok=True)
        if path.exists():
            existing=np.load(path,allow_pickle=True).item()
            if existing["height_mm"]!=height or existing.get("diameter_mm")!=1 or existing.get("target_mass_kg")!=.2 or not np.array_equal(existing["scene"]["cylinder_thin"]["scale"],scene["scene"]["cylinder_thin"]["scale"]) or not np.array_equal(existing["scene"]["cylinder_thin"]["pose"],scene["scene"]["cylinder_thin"]["pose"]) or not np.array_equal(existing["scene"]["table"]["pose"],scene["scene"]["table"]["pose"]):
                raise RuntimeError(f"Refusing different existing scene: {path}")
        else:
            with tempfile.NamedTemporaryFile(prefix=path.name+".",suffix=".tmp",dir=path.parent,delete=False) as stream:
                temp=Path(stream.name)
                np.save(stream,scene,allow_pickle=True)
            try:
                os.replace(temp,path)
            finally:
                temp.unlink(missing_ok=True)
        paths.append(path)
    return paths


def load_height_scene(height_mm):
    return np.load(scene_path(height_mm),allow_pickle=True).item()


def prepare_scene(input_path,mass=.2):
    data=np.load(input_path,allow_pickle=True).item()
    from dexonomy.util.file_util import load_scene_cfg
    scene=load_scene_cfg(data["scene_path"])
    normalize_density(scene,mass)
    return data,scene


def normalize_density(scene,mass):
    obj=scene["scene"][scene["task"]["obj_name"]]
    info=json.loads(Path(obj["info_path"]).read_text())
    volume=info["mass"]/(info["density"]*info["scale"]**3)
    obj["density"]=float(mass)/(volume*np.prod(obj["scale"]))
    return obj["density"]


def make_env(scene,hand_xml,fixture="plain",mass=.2,timestep=.001,mass_kg=None):
    from dexonomy.sim import HandCfg,MuJoCo_EvalCfg
    if mass_kg is not None:
        mass=mass_kg
    scene=copy.deepcopy(scene)
    obj=scene["scene"][scene["task"]["obj_name"]]
    diameter_mm=float(obj["scale"][0])*1000
    height_mm=float(obj["scale"][2])*4000
    if abs(diameter_mm-1)>1e-7 or abs(float(obj["scale"][1])-.001)>1e-10 or abs(height_mm-round(height_mm))>1e-7 or round(height_mm)<10:
        raise ValueError("Factory only accepts D1mm and integer H>=10mm")
    if not np.allclose(obj["pose"],[0,0,height_mm/2000,1,0,0,0],atol=1e-10):
        raise ValueError("Rod must begin upright at H/2, bottom z0")
    if abs(float(scene["scene"]["table"]["pose"][2]))>1e-12:
        raise ValueError("Base scene plane must be0; factory applies support offset once")
    api=fixture_module()
    base=frozen_module().SweepEnv
    cls=api.with_fixture_env_class(base,fixture)
    density=normalize_density(scene,mass)
    analytic_density=density
    env=None
    passes=0
    for _ in range(2):
        cfg=MuJoCo_EvalCfg(miu_coef=[.6,.02])
        cfg.timestep=float(timestep)
        env=cls(hand_cfg=HandCfg(str(hand_xml),freejoint=True),scene_cfg=scene,sim_cfg=cfg,debug_render=False,debug_view=False)
        passes+=1
        actual=float(env._model.body_subtreemass[env._obj_active_bodyid])
        if abs(actual-float(mass))<=1e-12:
            break
        density*=float(mass)/actual
        obj["density"]=density
    if abs(actual-float(mass))>1e-9:
        raise RuntimeError(f"Compiled mass mismatch {actual} vs {mass}")
    env._model.opt.disableflags&=~int(mujoco.mjtDisableBit.mjDSBL_GRAVITY)
    env._model.opt.gravity[:]=[0,0,-9.81]
    for i in range(env._model.ngeom):
        if env._model.body(int(env._model.geom_bodyid[i])).name.startswith("hand-"):
            env._model.geom_matid[i]=-1
            env._model.geom_rgba[i]=[.863157,.0865002,.0802199,1]
    env.fixture_definition=api.geometry_definition(fixture)
    env.fixture_definition.update(height_mm=height_mm,diameter_mm=1,
        object_initial_center_m=[0,0,height_mm/2000],object_initial_quaternion_wxyz=[1,0,0,0],
        support_policy="Rod bottom z=0 and center H/2; fixed shallow support or plain plane; support geometry is independent of rod height",
        exposed_upright_object_length_m=height_mm/1000-(.00075 if fixture=="shallow" else 0))
    env.fixture_geom_ids=[i for i in range(env._model.ngeom) if env._model.geom(i).name.startswith("fixture-")]
    env.density_calibration={"analytic_density_kg_m3":analytic_density,"effective_density_kg_m3":obj["density"],"compile_passes":passes,"actual_mass_kg":actual}
    env.height_mm=height_mm
    return env


def write_manifest():
    paths=generate_scenes()
    api=fixture_module()
    manifest={"diameter_mm":1,"heights_mm":list(HEIGHTS_MM),"target_mass_kg":.2,
        "base_plane_z_m":0,"shallow_plane_z_m":-.0002,
        "arbitrary_integer_height_min_mm":10,"lazy_scene_generation":True,
        "source_factory":str(SOURCE_FACTORY),"source_factory_sha256":SOURCE_FACTORY_SHA256,
        "fixture_source":str(FIXTURE_SOURCE),"fixture_source_sha256":FIXTURE_SHA256,
        "fixture_geometry":{**api.geometry_definition("shallow"),"support_policy":"Rod bottom z=0 and center H/2; fixed shallow support or plain plane; support geometry is independent of rod height"},
        "scene_factory_sha256":sha256(__file__),
        "height_is_only_geometry_variable":True,"fixture_height_fixed_m":.00075,
        "mass_policy":"Density recalculated for each nonuniform mesh scale, with compile mass calibration to0.2kg",
        "condition_id_schema":"h004_plain, h004_shallow, h006_plain, h006_shallow, ...",
        "scenes":[{"height_mm":h,"diameter_mm":1,"scene_id":f"cylinder_d1_h{h:03d}","path":str(p),"sha256":sha256(p),"initial_center_z_m":h/2000,"mesh_scale":[.001,.001,.001*h/4]} for h,p in zip(HEIGHTS_MM,paths)],
        "dependencies":{str(path):sha256(path) for path in (SOURCE_FACTORY,FIXTURE_SOURCE,api.FROZEN,ASSET_ROOT/"mesh/simplified.obj",ASSET_ROOT/"urdf/coacd.xml",ASSET_ROOT/"info/simplified.json")}}
    (ROOT/"scenes"/"scene-manifest.json").write_text(json.dumps(manifest,indent=2)+"\n")
    return manifest


if __name__=="__main__":
    print(json.dumps(write_manifest(),indent=2))
