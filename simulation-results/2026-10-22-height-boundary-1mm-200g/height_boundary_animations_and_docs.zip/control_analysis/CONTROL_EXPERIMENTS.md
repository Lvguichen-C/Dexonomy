# Φ1mm / 200g 长杆控制实验记录

这些是完整真实 MuJoCo 轨迹的控制对照，物体保持自由体并开启重力。原执行器、增益、力限、手根 weld、dim3 摩擦均未暗改。所有候选都从真实手物间距至少50mm的远处开始，完成接近、闭合、预载、5s提升100mm、5s持握、释放。当前仍按原严格姿态门判定；承载结果不能改称严格全部成功。

## 固定控制定义

- `normal_integrator_profile.py`：3N/指目标，6N安全退让，5ms周期；实际接触normal Jacobian通过原qpos→ctrl矩阵最小范数映射到原位置执行器。总命令每5ms每执行器变化≤0.002rad、相对捕获命令≤0.2rad，并保留原ctrl/force范围。已接触单侧保持，继续闭合未触侧。
- `normal_preload_profile.py`：同一控制，仅显式把提升前受力等待从1s改为5s；原5s提升/5s持握、接触/高度/姿态/释放门槛不变。
- `normal_contact_axis_profile.py`：5s预载；通过两侧实际接触点沿杆轴的高度差反馈，各向中点移动，50µm死区、轴向目标速度≤1mm/s。轴向增量在限幅前投影到局部法向任务零空间；分量限幅后不能声称严格正交。仍只驱动原TH/FF执行器。
- `normal_contact_twist_profile.py`：在法向/轴向任务之后，加入接触圆周速度补偿与实际自由杆绕轴角速度反馈。首版食指环向Jacobian病态而饱和，已真实失败并保留完整数据。
- `normal_contact_twist_conditioned_profile.py`：只对局部投影环向Jacobian≥0.005m/rad的手指启用额外任务，以免食指近奇异逆解破坏已建立法向夹力。

普通手根PI只补偿相对初始实际抓姿的偏差，界限1mm/2°，保持原weld物理参数。释放时所有附加指令清除，由候选的足量 `release_qpos` 真实开指。

## 已完成H60数据

|源/控制|支撑|实际最终抬升(mm)|严格full通过|释放通过|主要结果|
|---|---|---:|---|---|---|
|normal，1s预载|plain|-29.670|False|False|minimum_height_gain_throughout_hold,actual_object_lift_within_tolerance_throughout_hold,expected_position_error_throughout_hold,closure_rotation_throughout_hold,no_table_contacts_throughout_hold,at_least_two_final_hand_object_contacts|
|normal，1s预载|shallow|-29.897|False|False|minimum_height_gain_throughout_hold,actual_object_lift_within_tolerance_throughout_hold,expected_position_error_throughout_hold,closure_rotation_throughout_hold,no_table_contacts_throughout_hold,at_least_two_final_hand_object_contacts|
|normal，5s预载|plain|-29.671|False|False|minimum_height_gain_throughout_hold,actual_object_lift_within_tolerance_throughout_hold,expected_position_error_throughout_hold,closure_rotation_throughout_hold,no_table_contacts_throughout_hold,at_least_two_final_hand_object_contacts|
|normal，5s预载|shallow|-29.871|False|False|minimum_height_gain_throughout_hold,actual_object_lift_within_tolerance_throughout_hold,expected_position_error_throughout_hold,closure_rotation_throughout_hold,no_table_contacts_throughout_hold,at_least_two_final_hand_object_contacts|
|normal+axis，5s预载|plain|99.469|False|True|closure_rotation_throughout_hold,orientation_drift_throughout_hold|
|normal+axis，5s预载|shallow|100.677|False|True|closure_rotation_throughout_hold,orientation_drift_throughout_hold|
|normal+axis+twist首版|plain|-29.671|False|False|minimum_height_gain_throughout_hold,actual_object_lift_within_tolerance_throughout_hold,expected_position_error_throughout_hold,closure_rotation_throughout_hold,no_table_contacts_throughout_hold,at_least_two_final_hand_object_contacts|

`normal+axis` 的plain/shallow已真实达到约100mm提升、5s持握及松手；两侧正载荷连续，持握无桌面或托具支撑、穿透门通过。严格全流程仍失败，因为圆柱绕自身轴发生大幅旋转，使原完整四元数旋转/漂移门未过。不能把这两例改写成严格成功。

## 同步证据与边界

- 每条正式试验：exact `model.mjb`/XML，1ms `diagnostics.npz`，25Hz `trace.npz`。
- `normal_integrator_feedback.npz` 保存实际ctrl、nominalctrl、capture、真实Fn及执行器等价qpos；附加轴向/绕轴adapter各另存原始反馈NPZ和SHA。等价qpos不表示增设FFJ1/FFJ2独立驱动，物理控制以实际actuatorctrl为准。
- 成功/失败只来自正式连续物理轨迹，不以静态IK、零积分compile或仅 `mj_forward` 的几何快照代替。
- H60 normalmapped同一ID曾因调度消息交叉并发执行两次，最终MJB/feedback/metrics确定性哈希已核一致，只计一条正式结果，不作为独立复验。

## 此记录生成时的源码SHA256

- `normal_integrator_profile.py`: `93cd68aee4f9d67cab2f48c6e2f0333618d42606aa15d901464e97f12c296d97`
- `normal_preload_profile.py`: `22c2da008576fa90f6a7b18d37791bb4d7225f81d63988859ee5019a07cc9c17`
- `normal_contact_axis_profile.py`: `49923574ab307c1fd3541a560dd7d4cd62ad991959df6b1288bd2afb901cabe7`
- `normal_contact_twist_profile.py`: `df934d24278d8291d11deebc0617462df7cf8c33c775a2ecfaebac2fc4ec80b7`
- `normal_contact_twist_conditioned_profile.py`: `da57e08e9e129085dad4b7e2f31150c04749ae8a8e5ee21801c07cd80f6ccbd0`
- `anchored_root_control.py`: `16f5a5848d56baa666db1c0d2ff2f9354d7889eba69efdc9e13941b7a7fb24ac`
- `micro_contact_profile.py`: `2e3351b69b87bd16f4a53634cb831abc4bdcd482b48c3a59aa088f8baca4102f`

## 后续已冻结对照

|H60plain 控制|实际抬升mm|hold姿态最大漂移°|closure旋转最大°|严格full|释放|
|---|---:|---:|---:|---|---|
|normal_contact_axis_preload5|99.469|101.288|179.834|False|True|
|normal_contact_axis_twist_preload5|-29.671|1.270|91.273|False|False|
|normal_contact_axis_twist_conditioned_preload5|-29.697|7.593|90.433|False|False|
|normal_contact_axis_root_twist_preload5|99.907|48.966|84.081|False|True|
|normal_contact_axis_latch_preload5|98.732|9.865|161.148|False|True|

锁存对照在5s预载结束后停止法向/轴向目标积分，保持真实位置执行器目标不变（lift+hold实际ctrl变化精确0），无需对象外力或约束。持握姿态漂移降至9.865°，但closure到持握姿态旋转仍161.148°，原严格门仍判失败；不移动closure参考。

root-yaw对照的普通手根名义轨迹允许±180°独立运动，它不是原1mm/2°锚定PI的隐含扩大。实际运行碰角度限位时将yaw速度清零，最大加速度超过声明的常规5rad/s²斜率，必须保留此边界例外，不把该profile作为通过控制。完整数值见 `final-h060-control-comparison.json`。

新增源码SHA：

- `normal_root_twist_profile.py`: `5ef4ed89aba33f5a766d1b0d9a455baa0d91ecea4b039e8bc52354c8d28140ff`
- `normal_contact_latch_profile.py`: `ec1735d6474449ce82b7b23d4c90fb0e374ca89487602efbc5d44c7ff18e722e`

## 固定锁存控制的高度验证

H17/plain 同源top−2mm抓点在未改任何成功判据的情况下首次严格全流程通过：真实抬升99.737mm，整个5s持握99.716–99.782mm，closure到持握最大旋转6.630°，持握内最大姿态漂移0.111°，持握最大HO30.136µm、双指最小真实Fn2.877/3.193N。位置执行器在整个提升和持握期间actualctrl变化为0，保持位置伺服真实受力。初始真间距97.636mm，连续远离→接近→闭合→夹力预载5s→提升5s→持握5s→开指/退离/落桌。原 `full_sequence_passed=true`，包含释放。独立QA在单独qa目录记录，不能把本控制说明当独立QA。

H20/plain、H17/shallow、H20/shallow同控制也真实完成约100mm、5s稳持与释放，持握内姿态漂移分别1.644°、0.071°、0.125°；原strict仅closure参考旋转分别16.260°、43.521°、43.168°而判false，保持原判据。H60/plain为原mid家族，H17/H20为同源top−2mm家族，最终六格展示同一控制与按物体调整的抓点，不能作为仅高度变化的因果证明；更不能声称高度越大严格结果越好。最终原始数值和SHA见 `final-latch-six-cases.json`（六格完成后写出）。

## 最终六工况（同一字节冻结锁存控制）

|H mm|支撑|实际抬升mm|5s持握范围mm|hold姿态漂移°|原strict full|释放|
|---:|---|---:|---|---:|---|---|
|17|plain|99.737|99.716–99.782|0.111|True|True|
|17|shallow|99.683|99.663–99.730|0.071|False|True|
|20|plain|99.406|99.389–99.444|1.644|False|True|
|20|shallow|99.607|99.588–99.656|0.125|False|True|
|60|plain|98.732|98.720–98.815|9.865|False|True|
|60|shallow|99.394|99.382–99.446|6.508|False|True|

全部六工况的持握阶段均5000步双指正载荷、无桌面/浅托接触，持握最大手物穿透25.47–30.14µm。全部六条提升/持握阶段实际执行器目标峰峰值为0，表示保留原位置伺服受力而停止追加笛卡尔闭合积分。只有H17/plain满足原closure旋转门，其余五条仅该门失败，仍按false保留，不把补充任务达成改写为原strict通过。

H17/plain可复现入口（文件是完整已记录job，包含输入SHA、输出路径、控制/观测源码声明；原输出存在会被logger保护拒绝，复跑必须新ID/输出）：

```bash
python log_object_state_profile.py \
  --job control_analysis/jobs/plain__h017_matched_h060_topminus2_v1_normal_contact_axis_latch_preload5.json \
  --profile-script normal_contact_latch_profile.py
```

独立完整复跑由正式runner代理以新UUID单独执行，不覆盖首例，不将确定性同初值复跑称为扰动鲁棒性。
