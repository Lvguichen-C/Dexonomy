#!/usr/bin/env python3
"""Plot archived 1 ms measurements; no simulation or state changes."""
import hashlib
import json
from pathlib import Path
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import numpy as np

ROOT = Path(__file__).resolve().parent.parent
FOLDER = ROOT / 'control_analysis/figures'


def digest(p):
    return hashlib.sha256(Path(p).read_bytes()).hexdigest()


def main():
    FOLDER.mkdir(exist_ok=True)
    stem = 'h017_matched_h060_topminus2_v1_normal_contact_axis'
    cases = [('Continuous finger target integration', stem + '_preload5', '#c7761b'),
             ('Latched targets after preload', stem + '_latch_preload5', '#1766ac')]
    fig, axes = plt.subplots(2, 1, figsize=(10, 6), sharex=True, constrained_layout=True)
    sources = []
    for label, ident, color in cases:
        path = ROOT / 'trials/h017/plain' / ident
        m = json.loads((path / 'metrics.json').read_text())
        with np.load(path / 'diagnostics.npz', allow_pickle=False) as d:
            t = d['time_s']
            end = 18.2
            use = t <= end + 1e-8
            height = (d['object_z_m'] - m['initial_object_pose'][2]) * 1000
            axes[0].plot(t[use], height[use], color=color, lw=1.5, label=label)
            axes[1].plot(t[use], d['normal_hand_contact_force_sum_N'][use], color=color, lw=1.2)
        sources.append(dict(label=label, metrics=str(path / 'metrics.json'),
                            metrics_sha256=digest(path / 'metrics.json'),
                            diagnostics_sha256=digest(path / 'diagnostics.npz'),
                            input_sha256=digest(m['input']),
                            model_mjb_sha256=digest(path / 'model.mjb'),
                            full_sequence_passed=m['full_sequence_passed']))
    axes[0].axhspan(95, 105, color='#e3f2e5', zorder=-3, label='95–105 mm task band')
    for ax in axes:
        ax.axvspan(13.2, 18.2, color='#e5edf7', alpha=.45, zorder=-2)
        for t in [3.2, 8.2, 13.2]:
            ax.axvline(t, color='#78899a', ls=':', lw=.8)
        ax.grid(alpha=.2)
        ax.set_xlim(0, 18.2)
    axes[0].set_ylim(-16, 112)
    axes[0].set_ylabel('Actual object rise (mm)')
    axes[0].legend(loc='upper left', fontsize=8)
    axes[0].set_title('D1 mm / H17 mm / 200 g / no support — same grasp and contact model', fontsize=11)
    axes[0].text(15.7, 6, '5 s hold', ha='center', color='#4f637d', fontsize=9)
    axes[1].set_ylabel('Total hand normal force (N)')
    axes[1].set_xlabel('Recorded simulation time (s)')
    axes[1].set_ylim(bottom=0)
    for suffix in ['png', 'svg']:
        fig.savefig(FOLDER / f'h017_latch_comparison.{suffix}', dpi=180)
    plt.close(fig)
    source = dict(scope='Read-only plot from original 1 ms diagnostics, no integration/interpolation.',
                  same_input=sources[0]['input_sha256'] == sources[1]['input_sha256'],
                  same_model=sources[0]['model_mjb_sha256'] == sources[1]['model_mjb_sha256'],
                  sources=sources,
                  plot_sha256={name.name: digest(name) for name in FOLDER.glob('h017_latch_comparison.*')})
    (FOLDER / 'h017_latch_comparison_sources.json').write_text(json.dumps(source, indent=2) + '\n')
    print(json.dumps({k: source[k] for k in ['same_input', 'same_model', 'plot_sha256']}))


if __name__ == '__main__':
    main()
