#!/usr/bin/env python3
"""Compile-only dimensions/mass/inertia/freejoint audit; never mj_step."""
import json
from pathlib import Path
import sys

import mujoco
import numpy as np

ROOT=Path(__file__).resolve().parent.parent
sys.path.insert(0,str(ROOT))
import scene_factory as factory


def main():
    factory_sha=factory.sha256(factory.__file__)
    manifest_path=ROOT/"scenes/scene-manifest.json"
    manifest=json.loads(manifest_path.read_text())
    assert manifest["scene_factory_sha256"]==factory_sha
    for path,expected in manifest["dependencies"].items():
        assert factory.sha256(path)==expected,(path,"Frozen dependency changed")
    rows=[]
    reference_fixture=None
    for height in factory.HEIGHTS_MM:
        for support in ("plain","shallow"):
            env=factory.make_env(factory.load_height_scene(height),"/workspace/Dexonomy/assets/hand/shadow/right.xml",support,mass=.2,timestep=.001)
            m=env._model;b=env._obj_active_bodyid
            geoms=[i for i in range(m.ngeom) if int(m.geom_bodyid[i])==b]
            joints=[i for i in range(m.njnt) if int(m.jnt_bodyid[i])==b]
            assert len(joints)==1 and m.jnt_type[joints[0]]==mujoco.mjtJoint.mjJNT_FREE
            qadr=int(m.jnt_qposadr[joints[0]])
            half=m.geom_size[geoms[0]].copy()
            expected_I=np.array([.2*(3*.0005**2+(height/1000)**2)/12]*2+[.2*.0005**2/2])
            actual_I=m.body_inertia[b]
            relative_I=np.max(np.abs(np.sort(actual_I)/np.sort(expected_I)-1))
            assert abs(float(m.body_subtreemass[b])-.2)<1e-12
            assert abs(min(half)*2000-1)<1e-6 and abs(max(half)*2000-height)<1e-5
            assert abs(m.qpos0[qadr+2]-height/2000)<1e-8
            assert np.array_equal(m.qpos0[qadr+3:qadr+7],[1,0,0,0])
            assert relative_I<.01
            assert not m.opt.disableflags&int(mujoco.mjtDisableBit.mjDSBL_GRAVITY)
            assert np.array_equal(m.opt.gravity,[0,0,-9.81])
            assert all(b not in (m.eq_obj1id[i],m.eq_obj2id[i]) for i in range(m.neq))
            fixture=[]
            for g in env.fixture_geom_ids:
                assert m.geom_bodyid[g]==0
                fixture.append({"name":m.geom(g).name,**{key:getattr(m,"geom_"+key)[g].tolist() for key in ["type","size","pos","quat","friction","condim","priority","margin","gap","solref","solimp"]}})
            if support=="shallow":
                assert len(fixture)==33
                if reference_fixture is None: reference_fixture=fixture
                assert fixture==reference_fixture,"Fixture changed with height"
            else:
                assert not fixture
            row={"height_mm":height,"diameter_mm":1,"support":support,
                 "scene_path":str(factory.scene_path(height)),"scene_sha256":factory.sha256(factory.scene_path(height)),
                 "actual_mesh_half_extents_m":half.tolist(),"actual_diameter_mm":float(min(half)*2000),"actual_height_mm":float(max(half)*2000),
                 "actual_mass_kg":float(m.body_subtreemass[b]),"actual_body_inertia_kg_m2":actual_I.tolist(),
                 "analytic_circular_cylinder_inertia_kg_m2":expected_I.tolist(),"max_inertia_relative_error":float(relative_I),
                 "actual_initial_object_qpos":m.qpos0[qadr:qadr+7].tolist(),"nominal_initial_center_z_m":height/2000,
                 "object_freejoint":True,"no_object_equality":True,
                 "gravity_enabled":True,"gravity_m_s2":m.opt.gravity.tolist(),
                 "timestep_s":float(m.opt.timestep),"solver":{"integrator":int(m.opt.integrator),"solver":int(m.opt.solver),"iterations":int(m.opt.iterations),"noslip_iterations":int(m.opt.noslip_iterations),"tolerance":float(m.opt.tolerance),"impratio":float(m.opt.impratio)},
                 "fixture_definition":env.fixture_definition,"fixture_geoms":fixture,"fixture_source_sha256":factory.FIXTURE_SHA256,
                 "density_calibration":env.density_calibration,"physics_steps_executed":0,"not_a_stability_or_grasp_trial":True}
            rows.append(row)
            report={"scope":"Compile-only audit, no simulation steps; does not establish stability or grasp success","factory_sha256":factory_sha,"audit_script_sha256":factory.sha256(__file__),"scene_manifest_sha256":factory.sha256(manifest_path),"completed_cases":len(rows),"expected_cases":2*len(factory.HEIGHTS_MM),"same_shallow_fixture_across_all_heights":True,"rows":rows}
            path=ROOT/"scenes/compiled-audit.json";temp=path.with_suffix('.json.tmp');temp.write_text(json.dumps(report,indent=2)+'\n');temp.replace(path)
            print(json.dumps({"height_mm":height,"support":support,"mass_kg":row["actual_mass_kg"],"inertia_max_relative_error":row["max_inertia_relative_error"],"physics_steps":0}),flush=True)
            del env
    assert factory.sha256(factory.__file__)==factory_sha


if __name__=="__main__":main()
