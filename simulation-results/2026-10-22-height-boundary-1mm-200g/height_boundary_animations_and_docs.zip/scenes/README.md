# D1 mm / 200 g 任意整数高度场景

工厂为上级 `scene_factory.py`，冻结 SHA256：
`ea60a7eb47c0c74492834b6cb97db786d0c1ae211c0d5a7e2e75fd82b5750b72`。

```python
scene_path(H)                    # 任意整数 H>=10 mm；原子懒生成 h012.npy 等
load_height_scene(H)
prepare_scene(candidate_path, mass=.2)
make_env(scene, hand_xml, fixture="plain", mass=.2, timestep=.001)
frozen_module()
```

布尔、非整数、小于10 mm、非有限高度会被拒绝。初始 seed 高度为12、16、20、30、40、60、80、120、160、240 mm，`HEIGHTS_MM` 是这些 seed 的列表，不限制懒生成高度域。

所有高度固定直径1 mm、质量0.2 kg。沿原64边圆柱仅改变z缩放为`0.001*H/4`，xy始终0.001。对象初始底z=0、中心H/2、identity姿态；运行中保持freejoint，未增加对象约束或外力。密度按体积重算，并按实际编译质量校准；没有直接覆盖惯量数组。

plain地面z=0；shallow沿用冻结priority1浅托：内孔最小直径1.2 mm、外径5 mm、壁高0.75 mm、底厚0.2 mm，原33个world-static几何逐值保持一致，地面z=−0.2 mm、托底顶面z=0。浅托不随杆高加深。

`scene-manifest.json` 绑定初始10个seed NPY与旧源码/几何SHA；懒生成的其他高度不会自动改写这个seed manifest。正式trial或候选manifest须另外绑定其实际`scene_path` NPY SHA。继承的`condition_id_schema`旧示例只表示格式；实际工况以当前高度/job manifest为准。

`source-config.json` 补充原手XML及实际引用的9个公开mesh SHA。旧height-gradient的32次试验、factory、evaluator、fixture、原手资产均只读。

`compiled-audit.json` 是10个seed×plain/shallow的20次实际编译核验，记录网格尺寸、质量、惯量、初始位置、freejoint、重力、solver及完整托杯几何。圆柱解析惯量对照容差1%，允许64边多边形与理想圆的差异。没有执行`mj_step`、静置或正式抓取；编译通过不表示长杆稳定，也不表示抓取成功。
