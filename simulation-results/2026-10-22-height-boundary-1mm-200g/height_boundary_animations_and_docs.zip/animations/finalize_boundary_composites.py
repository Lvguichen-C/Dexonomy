#!/usr/bin/env python3
"""Assemble six explicitly selected, source-bound latch cases without re-simulation."""
from __future__ import annotations
import hashlib
import json
import os
from pathlib import Path
import subprocess

from PIL import Image,ImageDraw,ImageFont

OUT=Path(__file__).resolve().parent
ROOT=OUT.parent
FPS=10


def sha(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def font(size):return ImageFont.truetype('/usr/share/fonts/opentype/noto/NotoSansCJK-Regular.ttc',size)


def verify(path,frames,width,height):
    subprocess.run(['ffmpeg','-nostdin','-v','error','-xerror','-threads','1','-i',str(path),'-f','null','-'],check=True,capture_output=True)
    value=json.loads(subprocess.check_output(['ffprobe','-v','error','-count_frames','-show_entries','stream=width,height,r_frame_rate,avg_frame_rate,nb_read_frames,nb_frames','-show_entries','format=duration','-of','json',str(path)],text=True))
    stream=value['streams'][0]
    assert stream['width']==width and stream['height']==height
    assert stream['r_frame_rate']==stream['avg_frame_rate']=='10/1'
    assert int(stream['nb_read_frames'])==int(stream['nb_frames'])==frames
    assert abs(float(value['format']['duration'])-frames/FPS)<1e-6
    return value


def assemble(records,target,background,video_y,layout,frames):
    command=['ffmpeg','-nostdin','-y','-v','error','-filter_complex_threads','1']
    filters=[]
    for i,(_,record) in enumerate(records):
        command+=['-threads','1','-i',record['video']['path']]
        filters.append(f'[{i}:v]setpts=PTS-STARTPTS,setsar=1[v{i}]')
    command+=['-loop','1','-framerate','10','-i',str(background)]
    labels=''.join(f'[v{i}]' for i in range(len(records)))
    filters.append(f'{labels}xstack=inputs={len(records)}:layout={layout}:shortest=1[strip]')
    filters.append(f'[{len(records)}:v][strip]overlay=x=0:y={video_y}:shortest=1,setsar=1,setpts=N/(10*TB)[v]')
    command+=['-filter_complex',';'.join(filters),'-map','[v]','-an','-r','10','-fps_mode','cfr','-frames:v',str(frames),'-c:v','libx264','-preset','veryfast','-crf','18','-pix_fmt','yuv420p','-threads','1','-movflags','+faststart',str(target)]
    subprocess.run(command,check=True)


def main():
    cpus=sorted(os.sched_getaffinity(0));os.sched_setaffinity(0,{cpus[-1]})
    current=os.nice(0)
    if current<10:os.nice(10-current)
    selection_path=ROOT/'control_analysis/final-latch-six-cases.json'
    selection_hash=sha(selection_path);selection=json.loads(selection_path.read_text())
    assert selection['comparison_profile']=='normal_integrator_contact_axis_latch_preload5'
    cases=selection['cases'];assert len(cases)==6
    records={}
    for path in sorted((OUT/'presentation_v5').glob('*/render-index.json')):
        value=json.loads(path.read_text());records[Path(value['metrics']).resolve()]=(path,value)
    selected={}
    for case in cases:
        metric=Path(case['directory'])/'metrics.json'
        path,record=records[metric.resolve()]
        assert record['controller_profile']==selection['comparison_profile']
        assert record['source_sha256']['metrics']==case['files']['metrics.json']['sha256']==sha(metric)
        assert record['task_lift_hold_release_passed'] is True
        assert record['qualified_full_sequence_passed']==case['strict_full_sequence_passed']
        assert sha(record['video']['path'])==record['video']['sha256'] and record['video']['full_decode_passed']
        assert record['video']['width']==640 and record['video']['height']==480
        selected[(int(case['height_mm']),case['fixture'])]=(path,record)
    assert set(selected)=={(height,fixture) for height in (17,20,60) for fixture in ('plain','shallow')}
    frame_counts={record['video']['frames'] for _,record in selected.values()}
    assert len(frame_counts)==1;frames=next(iter(frame_counts))
    folder=OUT/'final_composites';folder.mkdir(exist_ok=True)
    videos=[];previews=[];dependencies=[{'path':str(Path(__file__).resolve()),'sha256':sha(__file__)},{'path':str(selection_path),'sha256':selection_hash}]
    ordered=[selected[(h,f)] for f in ('plain','shallow') for h in (17,20,60)]
    jobs=[('height_boundary_overview.mp4','overview',ordered,1920,1080,120,'0_0|640_0|1280_0|0_480|640_480|1280_480',None)]
    for height in (17,20,60):jobs.append((f'h{height:03d}_latch_plain_vs_shallow.mp4','height_pair',[selected[(height,f)] for f in ('plain','shallow')],1280,720,100,'0_0|640_0',height))
    axis_metric=ROOT/'trials/h017/plain/h017_matched_h060_topminus2_v1_normal_contact_axis_preload5/metrics.json'
    axis_matches=[]
    for path in OUT.glob('*/render-index.json'):
        value=json.loads(path.read_text())
        if value.get('metrics') and Path(value['metrics']).resolve()==axis_metric.resolve():axis_matches.append((path,value))
    assert len(axis_matches)==1
    axis=axis_matches[0];latch=selected[(17,'plain')]
    assert axis[1]['source_sha256']['input']==latch[1]['source_sha256']['input']
    assert axis[1]['source_sha256']['model_mjb']==latch[1]['source_sha256']['model_mjb']
    assert axis[1]['qualified_full_sequence_passed'] is False and latch[1]['qualified_full_sequence_passed'] is True
    assert axis[1]['video']['frames']==frames and sha(axis[1]['video']['path'])==axis[1]['video']['sha256']
    jobs.append(('h017_axis_vs_latch_plain.mp4','controller_comparison',[axis,latch],1280,720,100,'0_0|640_0',17))
    for name,kind,inputs,width,height,video_y,layout,object_height in jobs:
        background=folder/f'{Path(name).stem}_background.png'
        image=Image.new('RGB',(width,height),(17,24,34));draw=ImageDraw.Draw(image)
        if kind=='overview':
            draw.text((22,5),'Φ1 mm · 200 g｜H17 / H20 / H60 × 无托 / 浅托：同锁定控制策略',font=font(32),fill=(239,244,248))
            draw.text((22,48),'受力预载5s；H17/H20抓点距顶端2mm，H60为原中部抓点，不作只变高度的因果比较',font=font(25),fill=(181,199,215))
            draw.text((22,85),'绿字＝原严格通过；黄字＝举握释放事后诊断达成、原姿态门槛未过。各格保留原时刻/实际升高。',font=font(22),fill=(231,213,167))
        elif kind=='height_pair':
            draw.text((22,9),f'Φ1 × {object_height} mm · 200 g｜无托 / 浅托：同锁定控制策略',font=font(30),fill=(239,244,248))
            draw.text((22,53),'受力预载5s · 完整远离/接近/提升/持握/释放 · 原始状态等速并排',font=font(24),fill=(181,199,215))
            draw.text((22,590),'目标：提升100mm、持握5s、释放；以各例实际高度和独立原门槛审核为准',font=font(25),fill=(239,244,248))
            draw.text((22,635),'原严格PASS与事后任务达成分别显示，未将黄色状态称为原严格通过',font=font(24),fill=(231,213,167))
            draw.text((22,675),'物理几何不改形，不插值，不施加物体跟随；片中近景仅改变相机取景',font=font(21),fill=(168,187,204))
        else:
            draw.text((22,9),'Φ1 × 17 mm · 200 g｜持续接触轴积分 / 手指目标锁定',font=font(30),fill=(239,244,248))
            draw.text((22,53),'无托同输入、同编译模型 · 受力预载5s · 原始状态完整等速并排',font=font(24),fill=(181,199,215))
            draw.text((22,590),'左：持续更新手指目标；右：预载后锁定手指位置目标',font=font(27),fill=(239,244,248))
            draw.text((22,635),'左例持握期间落物；右例原严格全流程通过。未改物体物理状态或通过门槛。',font=font(24),fill=(231,213,167))
            draw.text((22,675),'同一MJB和输入文件的SHA一致性已核验；具体实际升高/接触/力见各画面',font=font(21),fill=(168,187,204))
        image.save(background);dependencies.append({'path':str(background),'sha256':sha(background)})
        target=OUT/name;assemble(inputs,target,background,video_y,layout,frames)
        probe=verify(target,frames,width,height)
        video={'kind':kind,'public_download':True,'download_name':name,'path':str(target),'width':width,'height':height,'frames':frames,'fps':FPS,'duration_s':frames/FPS,'sha256':sha(target),'source_trial_ids':[record['trial_id'] for _,record in inputs],'full_decode_passed':True,'probe':probe}
        if object_height is not None:video['height_mm']=object_height
        videos.append(video)
        for frame in (0,150,frames-1):
            preview=folder/f'{Path(name).stem}_frame_{frame:03d}.png'
            subprocess.run(['ffmpeg','-nostdin','-y','-v','error','-threads','1','-i',str(target),'-vf',f'select=eq(n\\,{frame})','-frames:v','1',str(preview)],check=True)
            previews.append({'path':str(preview),'sha256':sha(preview),'video':name,'frame':frame})
    sources=[]
    for path,record in [*ordered,axis]:
        assert sha(record['video']['path'])==record['video']['sha256']
        sources.append({'trial_id':record['trial_id'],'metrics':record['metrics'],'source_render_index':{'path':str(path),'sha256':sha(path)},'source_video':{'path':record['video']['path'],'sha256':record['video']['sha256']}})
    assert sha(selection_path)==selection_hash
    value={'schema_version':1,'selection_policy':'Fixed six-case latch/profile comparison with height-adapted grasp location, not a pure height causal comparison. Qualified strict and independently reviewed posthoc task outcomes remain distinct.','selected_conditions':[{'height_mm':h,'fixture':f,'trial_id':selected[(h,f)][1]['trial_id']} for f in ('plain','shallow') for h in (17,20,60)],'sources':sources,'videos':videos,'previews':previews,'dependencies':dependencies,'resource_policy':{'affinity_cpus':sorted(os.sched_getaffinity(0)),'nice':os.nice(0),'maximum_concurrent_trials':1}}
    path=folder/'render-index.json';path.write_text(json.dumps(value,ensure_ascii=False,indent=2)+'\n');print(path,flush=True)


if __name__=='__main__':main()
