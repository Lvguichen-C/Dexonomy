#!/usr/bin/env python3
"""Build the final animation inventory only after explicit pool freeze."""
from __future__ import annotations
import argparse
import hashlib
import json
from pathlib import Path

OUT=Path(__file__).resolve().parent
ROOT=OUT.parent


def sha(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def validate_source(value):
    for key,digest in value['source_sha256'].items():
        assert sha(value[key])==digest,(value['trial_id'],key)
    for binding in value.get('intervention_sources',[]):assert sha(binding['path'])==binding['sha256']
    for key in ('presentation_review','task_outcome_review'):
        binding=value.get(key)
        if binding:assert sha(binding['path'])==binding['sha256']
    video=value['video']
    assert video['full_decode_passed'] is True and video['fps']==10
    assert sha(video['path'])==video['sha256']
    assert abs(video['duration_s']-video['frames']/video['fps'])<1e-8
    assert sha(value['numerical_output']['path'])==value['numerical_output']['sha256']
    for preview in value['previews']:assert sha(preview['path'])==preview['sha256']


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--final-pool-frozen',action='store_true',required=True)
    parser.add_argument('--expected-trials',type=int,required=True)
    args=parser.parse_args()
    pool_path=ROOT/'trials/final-pool-freeze.json';pool=json.loads(pool_path.read_text())
    formal={p.resolve() for p in ROOT.glob('trials/*/*/*/metrics.json')}
    assert len(formal)==args.expected_trials,(len(formal),args.expected_trials)
    frozen_rows={Path(row['metrics']).resolve():row for row in pool['rows']}
    assert set(frozen_rows)==formal
    review_path=OUT/'outcome-review-final39-snapshot.json';review=json.loads(review_path.read_text())
    outcome_rows={Path(row['metrics_path']).resolve():row for row in review['rows']}
    assert set(outcome_rows)==formal
    options={}
    for path in OUT.rglob('render-index.json'):
        value=json.loads(path.read_text())
        if not value.get('metrics') or not value.get('video'):continue
        metric=Path(value['metrics']).resolve()
        if metric in formal:options.setdefault(metric,[]).append((path,value))
    assert set(options)==formal,{'missing':[str(x) for x in formal-set(options)]}
    sources=[];videos=[];previews=[];numerical=[];source_manifests=[]
    for metric in sorted(formal):
        candidates=options[metric]
        preferred=[item for item in candidates if any(part in ('presentation_v5','presentation_v6') for part in item[0].parts)]
        if preferred:assert len(preferred)==1;candidates=preferred
        assert len(candidates)==1,('Ambiguous final presentation',metric)
        path,value=candidates[0];validate_source(value)
        value=dict(value)
        archive=[]
        for name,digest in frozen_rows[metric]['files_sha256'].items():
            file=metric.parent/name;assert sha(file)==digest;archive.append({'path':str(file),'sha256':digest})
        outcome=outcome_rows[metric];assert outcome['metrics_sha256']==value['source_sha256']['metrics']
        assert outcome['original_full_sequence_passed']==value['qualified_full_sequence_passed']
        value['formal_archive_files']=archive
        value['task_lift_hold_release_passed']=outcome['user_task_lift_hold_release_passed']
        value['independent_outcome_review']={'path':str(review_path),'sha256':sha(review_path),'reviewed_trial':outcome}
        value['canonical_trial_path']=str(metric.parent.relative_to(ROOT))
        value['source_render_index']={'path':str(path),'sha256':sha(path)}
        alternatives=[{'path':str(p),'sha256':sha(p),'video':{'path':v['video']['path'],'sha256':v['video']['sha256']}} for p,v in options[metric] if p!=path]
        if alternatives:value['retained_original_presentations_not_additional_trials']=alternatives
        sources.append(value);source_manifests.append(value['source_render_index'])
        video={**value['video'],'kind':'trial','source_trial_ids':[value['trial_id']]}
        if metric.parent.name=='h017_matched_h060_topminus2_v1_normal_contact_axis_latch_preload5' and value['fixture']=='plain':
            assert value['qualified_full_sequence_passed'] is True
            video.update(public_download=True,download_name='h017_strict_success_plain.mp4')
        videos.append(video);previews.extend(value['previews']);numerical.append(value['numerical_output'])
    composite_path=OUT/'final_composites/render-index.json';composite=json.loads(composite_path.read_text())
    comparison_path=OUT/'h060_contact_axis_plain_vs_shallow/render-index.json';comparison=json.loads(comparison_path.read_text())
    composites=[*composite['videos'],comparison['video']]
    assert len(composites)==6
    trial_ids={value['trial_id'] for value in sources}
    for value in composites:
        assert set(value['source_trial_ids'])<=trial_ids
        assert value['full_decode_passed'] is True and sha(value['path'])==value['sha256']
        videos.append(value)
    previews.extend(composite['previews']);previews.extend(comparison['previews'])
    declared=[OUT/f'render_boundary{suffix}.py' for suffix in ('','_v2','_v3','_v4','_v5','_v6')]
    declared.extend([OUT/'make_contact_axis_comparison.py',OUT/'finalize_boundary_composites.py',Path(__file__).resolve(),OUT/'ANIMATION_METHOD.md',Path('/workspace/shadow-reproduction/video_writer.py'),Path('/workspace/shadow-reproduction/run_cpu.sh')])
    dependencies=[{'path':str(path),'sha256':sha(path)} for path in declared]
    dependencies.extend(composite['dependencies']);dependencies.extend(comparison['dependencies'])
    dependencies.extend([{'path':str(pool_path),'sha256':sha(pool_path)},{'path':str(review_path),'sha256':sha(review_path)}])
    value={'schema_version':3,'experiment':'Phi1mm_200g_height_boundary','formal_pool_frozen':True,'formal_trial_count':len(formal),'single_trial_video_count':len(sources),'composite_video_count':len(composites),'video_count':len(videos),'source_identity_policy':'One canonical metrics/output directory per retained formal trial. Independently archived UUID/reference outputs are not different physical conditions; collided writes to one output directory remain one retained trial.','selection_policy':composite['selection_policy'],'selected_conditions':composite['selected_conditions'],'sources':sources,'videos':videos,'previews':previews,'numerical_outputs':numerical,'source_manifests':source_manifests,'composite_manifests':[{'path':str(path),'sha256':sha(path)} for path in (composite_path,comparison_path)],'dependencies':dependencies,'scientific_outcome_policy':'Original qualified strict full-sequence gates retained. Approved posthoc task accomplishment is separately identified; declared latch/preload5 controller does not establish original1s-preload success. Final six use the same controller with height-adapted grasp locations, not a pure height causal experiment.','method':'Exact archived model MJB plus actual qpos/ctrl/mocap state replay using mj_forward only; no mj_step, physical-state interpolation, geometry inflation, object pose forcing or reset within a trial. Original saved25Hz states shown10fps with actual timestamps and final state included.'}
    value['original_strict_passed_records']=sum(bool(source['qualified_full_sequence_passed']) for source in sources)
    value['independent_task_lift_hold_release_passed_records']=sum(bool(source['task_lift_hold_release_passed']) for source in sources)
    value['task_only_excluding_original_strict_passed_records']=sum(bool(source['task_lift_hold_release_passed']) and not bool(source['qualified_full_sequence_passed']) for source in sources)
    value['formal_pool_freeze']={'path':str(pool_path),'sha256':sha(pool_path)}
    value['independent_outcome_review']={'path':str(review_path),'sha256':sha(review_path)}
    assert len(videos)==len(formal)+6
    path=OUT/'index.json';path.write_text(json.dumps(value,ensure_ascii=False,indent=2)+'\n');print(json.dumps({'index':str(path),'sha256':sha(path),'formal_trials':len(formal),'videos':len(videos)},ensure_ascii=False),flush=True)


if __name__=='__main__':main()
