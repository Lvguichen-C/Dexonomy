# Φ1 mm、200 g 高度边界搜索：真实试验动画

每个正式试验的影片均读取该试验实际归档的 MuJoCo `model.mjb`、25 Hz 状态轨迹与 1 kHz 原始诊断。恢复原记录的 `qpos`、`ctrl` 和 mocap 状态后只调用 `mj_forward` 显示几何，不调用 `mj_step`，不插值物体或手，也不预置物体跟随手移动。影片为 640×480、10 fps，字幕显示实际保存时刻，完整保留最终状态。

模型支持任意已声明正高度；直径始终 1 mm，编译质量核对为 0.2 kg。受力、抬升、持握与释放的严格判定来自原指标中的 qualified 字段及科学门槛，原冻结评价器的 raw 值另列；控制指令上移 100 mm 不能代替实际物体升高。未认证的粗平移种子明确标注，失败过程完整保留。

完整动作按每条轨迹自身的阶段边界播放：远离物体无接触静置 → 垂直接近 → 闭合夹紧 → 受力保持 → 提升 → 到位持握 → 张手 → 退离 → 释放后观察。初始远离量读取 `upright_protocol.approach_root_offset_m`，可大于 100 mm，不把较长杆的起点套成固定值；原记录的实际无接触检查必须通过。

左侧全景相机每帧由**整只手和整根有朝向圆柱的联合包围盒**计算，留有边界余量，适配长杆及较大的初始远离距离。整杆最低点按各例真实 `H/2` 和半径 0.5 mm 计算。全景与右侧近景分区显示，不用字幕或近景挡住主视图。

右侧明确标为**同状态杆身局部近景**。它只改变相机取景，不增粗物体。若原记录有手物接触，优先按重放几何中的实际接触区域取景；否则按所有真实手部碰撞几何与杆的最近点定位，包含中节、末节和手掌，未固定假设接触发生在指尖。长杆可超出局部近景边界，但始终完整保留在左侧全景。右侧另列原始接触体记录，画面中的法向力来自原物理求解诊断，不采用回放时重新计算的力。

“已离开托座”须原托座与桌面接触均为零，且整杆最低点高于实际杯壁顶 0.05 mm；普通桌面须桌面接触为零且最低点高于 0.05 mm。暂时零接触但未净空不称为已拔出。

为避免影响正在运行的物理搜索，渲染绑定**一个 CPU**、nice 10、单个串行试验，数值与渲染线程限制为 1；ffmpeg 子进程继承同一单核亲和性。只接受试验负责人明确确认冻结的指标路径或清单，每个试验单独写自己的 `render-index.json`，搜索进行中不反复改全局汇总索引。

每条索引绑定输入、指标、结果、MJB/XML、轨迹和完整诊断 SHA256，并核对源在渲染期间未改变。`per_frame.csv` 保存实际源下标、物体升高、接触／力／倾角，以及全景和近景的相机位置与取景依据。编码后完整解码并核对恒定帧率、实际帧数和时长；首末时刻差与媒体时长之间的一个帧周期差异来自包含最终端点。

首六例粗平移对照固定使用 `render_boundary.py`。新增控制试验使用独立的 `render_boundary_v2.py`，不改首六片及其源版本：阶段字幕时长从该试验归档阶段边界计算；例如 5 s 受力保持的试验完整保留 23.7 s 最终物理时刻，含双端点编码为 238 帧／23.8 s。新版索引另绑定指标明确引用的控制适配器与反馈文件，并保留各项 intervention 的原始说明。增加预加载或反馈不会改变原严格通过门槛。

H60 的首两个接触轴反馈试验使用独立 `render_boundary_v3.py`。它们实际完成约 100 mm 提升、5 s 持握和释放，原全四元数姿态门槛仍未通过；影片同时显示这两项事实，不称原严格全流程通过。任务达成是观察到轴向旋转结果后另列的**事后诊断**，受力预载为 5 s，不能视为原 1 s 受力保持方案已成功。独立审核原件的批准时 SHA 和完整内容保存在不可变 `task-axis-review-first2.json` 快照中，影片索引绑定其 SHA。未在字幕宣称两例均已获得完整的每毫秒对称轴姿态证书。

`make_contact_axis_comparison.py` 只将上述真实匹配的 plain/shallow 两个已编码影片等速并排。两侧原状态、时刻、字幕和几何比例保持，恒定 10 fps、238 帧、23.8 s；原两例完整远离、接近、受力、提升、持握与释放均保留。该对比单独写自己的 `render-index.json`，不代替最终全池索引。

额外的 twist、twist_conditioned、root_twist、latch 控制试验使用独立 `render_boundary_v4.py`。长名称在画面中截短以免越界，完整 ID、控制 profile 和 intervention 仍保存在各例索引；字幕只陈述原严格全流程门槛未通过并指向真实升高读数。未将新 root 旋转控制、其加速度例外或 latch 结果擅自列为合格主高度策略，任务解释仍以独立诊断为准。

首个真正通过原严格门槛的 H17 无托 latch 试验使用 `render_boundary_v5.py`，绿色标明“原严格全流程通过”，保留 5 s 受力预载说明；其独立 1 kHz 门槛复算保存在 `first-original-strict-review-snapshot.json`。该成功不依赖事后任务定义，也不表示未测试的高度界限或原 1 s 预载方案已成立。V5 影片放在独立 `presentation_v5/` 子目录，原有对照影片保持原字节。V5 同时支持经独立审核的任务达成／原姿态未过并列字幕，不能把该黄色状态称为原严格通过。

独立 UUID/reference 目录分别归档、分别出片并绑定各自实际源路径与 SHA；它们属于相同物理条件的独立保留执行，不能计作不同高度／支撑条件。同一个输出目录曾被多进程写入时，只有最后保留且可核验的一套数据入档，不虚构多份重复试验。

最终试验池由 `trials/final-pool-freeze.json` 冻结为 39 条正式保留记录。原严格通过记录为 H17 无托发现例及 3 条独立 UUID 复跑，共一个不同物理配置；复跑数值确定性一致，不作为稳健性证据。3 条复跑使用独立 `render_boundary_v6.py`，画面明确“确定性独立UUID复跑（非稳健性试验）”。39 行独立原门槛／后验任务诊断原件快照为 `outcome-review-final39-snapshot.json`，全局索引单列两种结果，不以任务诊断改写原指标。

最终 `index.json` 只列每条正式记录的一条选择影片，共 39 条单项，加 6 条合成，合计 45 条。H60 latch 的旧原判据字幕片作为原始附加源保留，主清单选 v5 的双结果说明片，不重复计作第二个试验。公开成功片 `h017_strict_success_plain.mp4` 是 H17 发现例既有影片的交付名称，也不额外增加计数。

主总览 `height_boundary_overview.mp4` 为 1920×1080 三列两行：列为 H17/H20/H60，行为无托/浅托；配套 `h017_latch_plain_vs_shallow.mp4`、`h020_latch_plain_vs_shallow.mp4`、`h060_latch_plain_vs_shallow.mp4` 为 1280×720。六格固定同一接触轴反馈后锁定控制策略、5 s 受力预载，H17/H20 抓点距顶端 2 mm，H60 为原中段抓点，不能视为只改变高度的因果实验。各格保持原严格通过或后验任务达成／原姿态未过的区别。

`h017_axis_vs_latch_plain.mp4` 对比同输入、同 MJB 的 H17 无托持续接触轴积分与锁定策略；脚本强制核验输入和 MJB SHA 一致，左侧保留持握期掉落，右侧保留原严格成功。旧首两例的 `h060_contact_axis_plain_vs_shallow.mp4` 及其已批准快照保持原字节。5 条最终新合成和旧 H60 对比共 6 条，全部通过实际解码帧数、恒定帧率和时长检查。

只有已测试、已冻结且有实际轨迹的结果入清单；H15/H16 与其他未启动的中心抓点方案标为 deferred，不生成或推测其影片，也不把 H17 称为硬件最小可抓高度。

```bash
# 只准备预览；metrics必须已由试验负责人明确确认冻结。
/workspace/shadow-reproduction/run_cpu.sh python render_boundary.py \
  --metrics /path/to/frozen/trial/metrics.json
# 单核低优先级逐片编码；匹配完整源SHA时可复用已有影片。
/workspace/shadow-reproduction/run_cpu.sh python render_boundary.py \
  --frozen-manifest source-freeze-first6.json --render --reuse
# 新控制试验：使用独立源版本及其明确冻结清单。
/workspace/shadow-reproduction/run_cpu.sh python render_boundary_v2.py \
  --frozen-manifest source-freeze-next10.json --render --reuse
# 最终五条 latch 说明片；首 H17 发现例使用其独立严格审核快照。
BOUNDARY_PRESENTATION_REVIEW=final-latch-and-strict-references-review-snapshot.json \
  /workspace/shadow-reproduction/run_cpu.sh python render_boundary_v5.py \
  --frozen-manifest source-freeze-final-latch-five.json --render --reuse
# 三条确定性严格复跑；随后从既有单片合成，不重新积分。
BOUNDARY_PRESENTATION_REVIEW=final-latch-and-strict-references-review-snapshot.json \
  /workspace/shadow-reproduction/run_cpu.sh python render_boundary_v6.py \
  --frozen-manifest source-freeze-final-strict-reference-three.json --render --reuse
/workspace/shadow-reproduction/run_cpu.sh python finalize_boundary_composites.py
/workspace/shadow-reproduction/run_cpu.sh python build_animation_index.py \
  --final-pool-frozen --expected-trials 39
```

后续汇总只包含真正完成的正式试验。条件未试齐时不制造平行对照；成功样本及完整结果总览须在试验池及源文件稳定后按最终清单组装。之前的高度梯度目录与已发布的 37 段动画保持只读。
