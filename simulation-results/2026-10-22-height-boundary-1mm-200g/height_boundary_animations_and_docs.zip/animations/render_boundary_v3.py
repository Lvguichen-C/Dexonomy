#!/usr/bin/env python3
"""One-CPU, low-priority replay of frozen arbitrary-height boundary trials.

Each trial writes only its own animation/manifest. No batch index is rebuilt
while physical search continues. qpos/ctrl/mocap are displayed with mj_forward;
the renderer never calls mj_step or interpolates a physical state.
"""
from __future__ import annotations

import argparse
import csv
from functools import lru_cache
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
import sys

os.environ.setdefault("MUJOCO_GL", "egl")
os.environ['LP_NUM_THREADS']='1'
os.environ['OMP_NUM_THREADS']='1'
os.environ['OPENBLAS_NUM_THREADS']='1'
os.environ['MKL_NUM_THREADS']='1'
sys.path.insert(0, "/workspace/shadow-reproduction")

import mujoco
import numpy as np
from PIL import Image, ImageDraw, ImageFont
from video_writer import VideoWriter

OUT = Path(__file__).resolve().parent
ROOT = OUT.parent
FPS, WIDTH, HEIGHT, TOL = 10, 640, 480, 1e-5
CONTEXT_WIDTH,CONTEXT_HEIGHT=400,302
PHASES = {"start_pause":"远离物体静置 0.5 s", "initial_hover":"远离物体静置 0.5 s", "approach":"垂直接近 2 s", "approach_close_squeeze":"闭合 / 夹紧", "loaded_hold":"受力保持 1 s", "lift":"提升指令 100 mm / 5 s", "postlift_hold":"抬升后持握 5 s", "release_open":"松开手指", "release_retreat":"手部退离", "release_settle":"释放后观察"}


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def write_json(path, value):
    Path(path).write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n")


@lru_cache(maxsize=32)
def font(size):
    return ImageFont.truetype("/usr/share/fonts/opentype/noto/NotoSansCJK-Regular.ttc", size)


def pick(record, keys, default=None):
    for key in keys:
        if key in record:
            return record[key]
    return default


def fixture_of(record, path):
    value = pick(record, ["fixture_name", "fixture", "condition"])
    if isinstance(value, dict):
        value = value.get("name")
    if value in ("plain", "shallow", "deep"):
        return value
    for name in ("plain", "shallow", "deep"):
        if name in str(path):
            return name
    raise ValueError(f"Fixture not declared: {path}")


def variant_of(record, path):
    value = pick(record, ["variant_id", "candidate_id", "variant", "candidate"])
    if isinstance(value, dict):
        value = value.get("id", value.get("name"))
    return str(value or path.parent.name)


def height_of(record,path):
    for value in [record.get('height_mm'),record.get('object_height_mm'),record.get('height_gradient',{}).get('height_mm'),record.get('height_sweep',{}).get('height_mm')]:
        if value is not None:
            height=float(value)
            assert np.isfinite(height) and height>0,(path,height)
            return height
    match=re.search(r'(?:height_?|h)0*(\d+)(?:[^0-9]|$)',str(path),re.IGNORECASE)
    if match:
        return int(match.group(1))
    raise ValueError(f'Height not explicitly declared: {path}')


def profile_of(record):
    return record.get('comparison_profile') or record.get('hand_controller_intervention',{}).get('profile') or 'baseline'


def identifier_of(record,path):
    base=f'h{height_of(record,path):g}__{fixture_of(record,path)}__{variant_of(record,path)}'
    profile=profile_of(record)
    if profile!='baseline':
        return f'{profile}__{base}'
    # Any future physical proposal outside the original14 has its own prefix.
    relative=path.resolve().relative_to(ROOT).parts
    return base if relative[0]=='trials' else f'{relative[0]}__{base}'


def replay(model, data, trace, index):
    data.qpos[:] = trace["qpos"][index]
    data.qvel[:] = 0
    data.ctrl[:] = trace["ctrl"][index]
    data.mocap_pos[:] = trace["mocap_pos"][index]
    data.mocap_quat[:] = trace["mocap_quat"][index]
    data.time = float(trace["time_s"][index])
    mujoco.mj_forward(model, data)


def frame_indices(times):
    times = np.asarray(times, dtype=float)
    assert np.all(np.diff(times) >= -1e-7), "Time reset in physical trace"
    grid = np.arange(0, float(times[-1]) + .5 / FPS, 1 / FPS)
    indices = np.clip(np.searchsorted(times, grid + TOL, side="right") - 1, 0, len(times) - 1)
    indices[-1] = len(times) - 1
    return grid, indices


def sampled_column(trace, index, names):
    for name in names:
        if name in trace:
            return float(trace[name][index])
    return None


def numerical_row(trace, index, frame, initial_z,height_mm):
    pose=np.asarray(trace['object_pose'][index],dtype=float)
    quaternion=pose[3:7]/np.linalg.norm(pose[3:7])
    matrix=np.empty(9);mujoco.mju_quat2Mat(matrix,quaternion)
    axis_z=float(matrix.reshape(3,3)[2,2])
    bottom=float(pose[2]-(height_mm*.0005*abs(axis_z)+.0005*np.sqrt(max(0.,1-axis_z**2))))
    return {"frame":frame, "height_mm":height_mm,"diameter_mm":1,"video_time_s":frame/FPS, "trace_index":int(index), "recorded_time_s":float(trace["time_s"][index]), "phase":str(trace["phase_names"][int(trace["phase_id"][index])]), "object_rise_mm":float((trace["object_pose"][index,2]-initial_z)*1000), "object_bottom_z_mm":bottom*1000, "hand_object_contacts":sampled_column(trace,index,["hand_object_contacts", "hand_object_contact_points", "ho_contacts"]), "object_fixture_contacts":sampled_column(trace,index,["object_fixture_contacts", "fixture_contacts", "rod_fixture_contacts", "rod_fixture_contact_points"]), "object_table_contacts":sampled_column(trace,index,["object_plane_contacts", "object_table_contacts", "rod_plane_contacts", "rod_plane_contact_points"]), "hand_fixture_contacts":sampled_column(trace,index,["hand_fixture_contacts", "hand_fixture_contact_points"]), "normal_hand_force_N":sampled_column(trace,index,["normal_hand_contact_force_sum_N", "hand_object_normal_force_N"]), "normal_fixture_force_N":sampled_column(trace,index,["normal_fixture_contact_force_sum_N", "fixture_normal_force_N", "rod_fixture_normal_force_N"]), "rod_tilt_deg":sampled_column(trace,index,["rod_tilt_deg", "object_tilt_deg", "tilt_deg"])}


def fit_camera(model,data,object_body,height_mm):
    """Enclose the entire real hand and oriented rod, including a far start."""
    camera = mujoco.MjvCamera()
    mujoco.mjv_defaultCamera(camera)
    ids=[i for i in range(model.ngeom) if model.body(int(model.geom_bodyid[i])).name.startswith('hand-')]
    p=data.geom_xpos[ids];r=model.geom_rbound[ids,None]
    lo=(p-r).min(axis=0);hi=(p+r).max(axis=0)
    center=data.xpos[object_body]
    axis=data.xmat[object_body].reshape(3,3)[:,2]
    extent=height_mm*.0005*np.abs(axis)+.0005*np.sqrt(np.maximum(0,1-axis**2))
    lo=np.minimum(lo,center-extent);hi=np.maximum(hi,center+extent)
    camera.lookat[:] = (lo+hi)/2
    radius=float(np.linalg.norm(hi-lo)/2)
    camera.distance=max(.20,1.20*radius/np.sin(np.radians(float(model.vis.global_.fovy)/2)))
    camera.azimuth, camera.elevation = 135,-20
    return camera


def contact_bodies(model,trace,index):
    if 'hand_object_contact_body_mask' not in trace:
        return []
    mask=int(trace['hand_object_contact_body_mask'][index])
    return [model.body(i).name for i in range(model.nbody) if mask & (1<<i)]


def near_focus(model,data,trace,index,object_body):
    """Use all real hand/object contacts or the actual nearest geom pair."""
    hand={i for i in range(model.ngeom) if model.body(int(model.geom_bodyid[i])).name.startswith('hand-') and (model.geom_contype[i] or model.geom_conaffinity[i])}
    obj={i for i in range(model.ngeom) if int(model.geom_bodyid[i])==object_body and (model.geom_contype[i] or model.geom_conaffinity[i])}
    points=[]
    if int(trace['hand_object_contacts'][index])>0:
        for contact in data.contact:
            pair={int(contact.geom1),int(contact.geom2)}
            if pair & hand and pair & obj:
                points.append(contact.pos.copy())
    if points:
        return np.mean(points,axis=0),'replayed HO contact geometry; original contact presence confirmed'
    best=float('inf');point=data.xpos[object_body].copy()
    for a in sorted(hand):
        for b in sorted(obj):
            segment=np.zeros(6)
            distance=float(mujoco.mj_geomDistance(model,data,a,b,10.,segment))
            if distance<best:
                best=distance;point=segment[3:6].copy()
    return point,'nearest real hand/rod geom pair, all hand segments considered'


def display_body(name):
    labels={'thdistal':'拇指末节','thmiddle':'拇指中节','thproximal':'拇指近节','ffdistal':'食指末节','ffmiddle':'食指中节','ffproximal':'食指近节','palm':'手掌'}
    suffix=name.removeprefix('hand-rh_')
    return labels.get(suffix,suffix)


def fitted_label(record,variant,good):
    status='严格全流程通过' if good else '未通过；保留真实失败过程'
    profile=profile_of(record)
    stage=record.get('candidate_proposal',{}).get('stage','')
    stage_label='粗平移种子 · ' if 'translated_coarse' in stage else ''
    prefix=f'{stage_label}{status} | '
    suffix='' if profile=='baseline' else f' [{profile}]'
    text=prefix+variant+suffix
    if font(16).getlength(text)<=620:
        return text
    value=variant
    while value and font(16).getlength(prefix+value+'…'+suffix)>620:
        value=value[:-1]
    return prefix+value+'…'+suffix


def low_priority_one_cpu():
    cpus=sorted(os.sched_getaffinity(0))
    os.sched_setaffinity(0,{cpus[-1]})
    current=os.nice(0)
    if current<10:
        os.nice(10-current)
    return {'affinity_cpus':sorted(os.sched_getaffinity(0)),'nice':os.nice(0),'LP_NUM_THREADS':1,'maximum_concurrent_trials':1}


def format_number(value, precision=0):
    return "?" if value is None else f"{value:.{precision}f}"


def support_text(row, fixture,wall_height_mm):
    points = row["object_fixture_contacts"]
    table = row["object_table_contacts"]
    if fixture == "plain":
        return "已离开桌面" if table == 0 and row['object_bottom_z_mm']>.05 else "桌面接触 / 未净空" if table is not None else "支持状态未记录"
    return "已离开托座" if points == 0 and table == 0 and row['object_bottom_z_mm']>wall_height_mm+.05 else "托座接触 / 未净空" if points is not None and table is not None else "支持状态未记录"


def phase_label(record,phase):
    labels={'start_pause':'远离物体静置','initial_hover':'远离物体静置','approach':'垂直接近','approach_close_squeeze':'闭合 / 夹紧','loaded_hold':'受力保持','lift':'提升指令 100 mm','postlift_hold':'抬升后持握','release_open':'松开手指','release_retreat':'手部退离','release_settle':'释放后观察'}
    boundaries=record['phase_boundaries']
    for i,boundary in enumerate(boundaries):
        if boundary['phase']==phase:
            end=float(boundaries[i+1]['time_s']) if i+1<len(boundaries) else float(record['simulation_duration_s'])
            duration=end-float(boundary['time_s'])
            return f"{labels.get(phase,phase)} {duration:g} s" if abs(duration-round(duration,3))<1e-6 else f"{labels.get(phase,phase)} {duration:.3f} s"
    return labels.get(phase,phase)


def intervention_paths(record):
    """Bind all archived feedback and adapter files explicitly named by metadata."""
    result={}
    def visit(value,prefix):
        if isinstance(value,dict):
            for key,item in value.items():
                name=f'{prefix}__{key}'
                if isinstance(item,str) and item.startswith('/') and Path(item).is_file():
                    result[name]=Path(item)
                elif isinstance(item,(dict,list)):
                    visit(item,name)
        elif isinstance(value,list):
            for i,item in enumerate(value):
                visit(item,f'{prefix}__{i}')
    for key,value in record.items():
        if key.endswith('_intervention'):
            visit(value,key)
    return result


def task_presentation(metrics_path):
    """Use an immutable snapshot of the independent task/axis review.

    The original full-quaternion result remains untouched and separately shown.
    An approved snapshot is prepared only after the independent reviewer GO.
    """
    snapshot=Path(os.environ.get('BOUNDARY_TASK_REVIEW',str(OUT/'task-axis-review-first2.json'))).resolve()
    review=json.loads(snapshot.read_text())
    matches=[row for row in review['presentation_trials'] if Path(row['metrics']).resolve()==metrics_path]
    assert len(matches)==1,('No unique independent task review',metrics_path)
    row=matches[0]
    assert row['metrics_sha256']==sha(metrics_path),('Task review source differs',metrics_path)
    assert row['task_lift_hold_release_passed'] is True
    assert row['original_full_sequence_passed'] is False
    return snapshot,sha(snapshot),row


def render_one(metrics_path, encode):
    resource_policy=low_priority_one_cpu()
    metrics_path = Path(metrics_path).resolve()
    record = json.loads(metrics_path.read_text())
    task_review_path,task_review_hash,task_row=task_presentation(metrics_path)
    folder = metrics_path.parent
    fixture = fixture_of(record,metrics_path)
    variant = variant_of(record,metrics_path)
    height_mm=height_of(record,metrics_path)
    wall_height_mm=float(record.get('fixture_definition',{}).get('wall_height_m',0))*1000
    trace_path = Path(record.get("trace",folder/"trace.npz"))
    model_path = Path(pick(record,["model_mjb", "model_binary", "mjb"],folder/"model.mjb"))
    model_xml = Path(record.get("model_xml",folder/"model.xml"))
    protocol=record.get('upright_protocol',{})
    frozen_paths={'metrics':metrics_path,'trace':trace_path,'model_mjb':model_path,'model_xml':model_xml,'diagnostics':Path(protocol['diagnostics']),'result':folder/'result.json'}
    if record.get('input'):
        frozen_paths['input']=Path(record['input'])
    extra_paths=intervention_paths(record)
    extra_hashes={key:sha(path) for key,path in extra_paths.items()}
    frozen_hashes={key:sha(path) for key,path in frozen_paths.items()}
    assert sha(model_path)==protocol['model_mjb_sha256']
    assert sha(model_xml)==protocol['model_xml_sha256']
    far_offset=float(protocol['approach_root_offset_m'])
    assert protocol['initial_visible_pause_s']==.5 and np.isfinite(far_offset) and far_offset>=.1
    assert (folder/'result.json').exists(),'Only complete, explicitly frozen formal trials may render'
    model = mujoco.MjModel.from_binary_path(str(model_path))
    assert abs(float(model.opt.timestep)-.001)<1e-12
    assert np.allclose(model.opt.gravity,[0,0,-9.81],atol=1e-12)
    object_bodies = [i for i in range(model.nbody) if model.body(i).name.startswith("obj-") and int(model.body_jntnum[i])>0]
    assert len(object_bodies)==1,object_bodies
    object_body = object_bodies[0]
    assert abs(float(model.body_subtreemass[object_body])-.2)<1e-6
    fixture_ids = [i for i in range(model.ngeom) if model.geom(i).name.startswith("fixture-")]
    assert bool(fixture_ids) == (fixture != "plain")
    if fixture_ids:
        assert np.all(model.geom_priority[fixture_ids]==1)
    with np.load(trace_path,allow_pickle=False) as archive:
        trace = {key:archive[key].copy() for key in archive.files}
    saved_hz=float(record['trace_fps'])
    assert trace["qpos"].shape[1]==model.nq and np.isfinite(trace["qpos"]).all()
    grid, indices = frame_indices(trace["time_s"])
    initial_z = float(record.get("initial_object_pose",trace["object_pose"][0])[2])
    rows = [numerical_row(trace,index,frame,initial_z,height_mm) for frame,index in enumerate(indices)]
    pause_rows = [row for row in rows if row["recorded_time_s"] < .5-TOL]
    assert pause_rows and all(row["hand_object_contacts"]==0 for row in pause_rows), "Initial hover must have no hand/object contact"
    data = mujoco.MjData(model)
    model.vis.global_.offwidth=max(CONTEXT_WIDTH,model.vis.global_.offwidth)
    model.vis.global_.offheight=max(CONTEXT_HEIGHT,model.vis.global_.offheight)
    renderer = mujoco.Renderer(model,height=CONTEXT_HEIGHT,width=CONTEXT_WIDTH)
    near = mujoco.MjvCamera()
    mujoco.mjv_defaultCamera(near)
    # Local rather than whole-pole zoom keeps a1mm diameter visible even when
    # the real pole is240mm tall. The context always includes the entire pole.
    near.distance,near.azimuth,near.elevation=.035,135,-12
    option = mujoco.MjvOption()
    option.flags[mujoco.mjtVisFlag.mjVIS_CONTACTPOINT]=False
    label = "无托座" if fixture=="plain" else "浅托座"
    identifier=identifier_of(record,metrics_path)
    controller_profile=profile_of(record)
    target_folder=OUT/identifier
    target_folder.mkdir(parents=True,exist_ok=True)
    target=target_folder/"full_sequence.mp4"
    good=bool(record.get("full_sequence_passed",False))
    status="全流程通过" if good else "未通过；保留真实失败过程"
    color=(69,216,135) if good else (255,148,132)
    assert not good
    display_label='100mm提升/持握5s/释放达成；原全姿态判据未通过'
    color=(246,210,112)

    def image_for(frame):
        row=rows[frame]
        replay(model,data,trace,int(indices[frame]))
        camera=fit_camera(model,data,object_body,height_mm)
        renderer.update_scene(data,camera=camera,scene_option=option)
        context=Image.fromarray(renderer.render().copy())
        image=Image.new('RGB',(WIDTH,HEIGHT),(17,24,34))
        image.paste(context,(0,72))
        focus,focus_method=near_focus(model,data,trace,int(indices[frame]),object_body)
        near.lookat[:]=focus
        renderer.update_scene(data,camera=near,scene_option=option)
        #400x300 central crop preserves a true4:3 image before scaling224x168.
        inset=Image.fromarray(renderer.render().copy()).crop((0,1,400,301)).resize((224,168),Image.Resampling.LANCZOS)
        image.paste(inset,(404,81))
        draw=ImageDraw.Draw(image)
        draw.rectangle((0,0,WIDTH,72),fill=(17,24,34))
        draw.text((10,2),f"Ø1 × {height_mm:g} mm · 200 g · {label} · {phase_label(record,row['phase'])}",font=font(19),fill=(239,244,248))
        draw.text((10,27),display_label,font=font(16),fill=color)
        draw.text((10,50),"法向接触轴反馈 · 受力预载5s · 任务达成为事后诊断",font=font(15),fill=(175,192,208))
        draw.rectangle((404,81,628,107),fill=(17,24,34))
        draw.text((409,83),"同一记录状态 · 杆身局部近景",font=font(14),fill=(237,241,245))
        bodies=contact_bodies(model,trace,int(indices[frame]))
        draw.text((410,258),f'起始远离 +{far_offset*1000:g} mm',font=font(15),fill=(199,215,229))
        draw.text((410,283),'原记录手物接触体：',font=font(14),fill=(199,215,229))
        names=[display_body(name) for name in bodies]
        for line,text in enumerate(names[:3] or ['无手物接触']):
            draw.text((410,305+line*20),text[:24],font=font(14),fill=(228,235,241))
        draw.rectangle((0,374,WIDTH,HEIGHT),fill=(17,24,34))
        draw.text((10,377),f"记录 t={row['recorded_time_s']:.2f}s   升高 {row['object_rise_mm']:.3f}mm   杆倾角 {format_number(row['rod_tilt_deg'],1)}°",font=font(17),fill=(239,244,248))
        draw.text((10,402),f"接触点 手/托/桌={format_number(row['hand_object_contacts'])}/{format_number(row['object_fixture_contacts'])}/{format_number(row['object_table_contacts'])}   {support_text(row,fixture,wall_height_mm)}",font=font(17),fill=(224,231,238))
        draw.text((10,427),f"手部法向力 {format_number(row['normal_hand_force_N'],3)}N   托座法向力 {format_number(row['normal_fixture_force_N'],3)}N",font=font(17),fill=(224,231,238))
        draw.text((10,453),f"实际状态回放 · 原保存{saved_hz:g}Hz / 视频10fps · 无插值",font=font(16),fill=(168,187,204))
        row.update({'camera_lookat_x_m':float(camera.lookat[0]),'camera_lookat_y_m':float(camera.lookat[1]),'camera_lookat_z_m':float(camera.lookat[2]),'camera_distance_m':float(camera.distance),'near_focus_x_m':float(focus[0]),'near_focus_y_m':float(focus[1]),'near_focus_z_m':float(focus[2]),'near_focus_method':focus_method,'recorded_contact_body_names':';'.join(bodies)})
        return image

    preview_frames={0,len(indices)-1}
    for phase in ("approach","approach_close_squeeze","lift","postlift_hold"):
        matching=[i for i,row in enumerate(rows) if row["phase"]==phase]
        if matching:
            preview_frames.add(matching[0])
    previews=[]
    for frame in sorted(preview_frames):
        path=target_folder/f"preview_{frame:03d}.png"
        image_for(frame).save(path)
        previews.append({"path":str(path),"sha256":sha(path),"frame":frame,"recorded_time_s":rows[frame]["recorded_time_s"]})
    if encode:
        with VideoWriter(target,fps=FPS) as writer:
            for frame in range(len(indices)):
                writer.append_data(np.asarray(image_for(frame)))
    renderer.close()
    csv_path=target_folder/"per_frame.csv"
    with csv_path.open("w",newline="") as file:
        writer=csv.DictWriter(file,fieldnames=list(rows[0]));writer.writeheader();writer.writerows(rows)
    source={"trial_id":identifier,"fixture":fixture,"variant":variant,"input":record.get("input"),"metrics":str(metrics_path),"trace":str(trace_path),"model_mjb":str(model_path),"model_xml":str(model_xml),"source_sha256":{"metrics":sha(metrics_path),"trace":sha(trace_path),"model_mjb":sha(model_path),"model_xml":sha(model_xml)},"mass_kg":float(model.body_subtreemass[object_body]),"physics_timestep_s":float(model.opt.timestep),"fixture_priority":1 if fixture_ids else None,"initial_hover_no_hand_contact":True,"final_trace_index":int(indices[-1]),"final_recorded_time_s":float(trace['time_s'][indices[-1]]),"full_sequence_passed":good,"lift_hold_passed":bool(record.get('lift_hold_passed',record.get('passed',False))),"measured_object_lift_mm":record.get('measured_object_lift_mm'),"phase_names":trace['phase_names'].tolist(),"video_frames":len(indices),"previews":previews,"numerical_output":{"path":str(csv_path),"sha256":sha(csv_path)}}
    if source['input']:
        source['source_sha256']['input']=sha(source['input'])
    source['diagnostics']=str(Path(protocol['diagnostics']))
    source['source_sha256']['diagnostics']=sha(source['diagnostics'])
    source['original_trace_hz']=saved_hz
    source['height_mm']=height_mm
    source['diameter_mm']=1
    source['fixture_wall_height_mm']=wall_height_mm
    source['selection_metrics']={key:record.get(key) for key in ['hold_criteria','maximum_absolute_lift_error_during_hold_mm','minimum_hold_height_gain_m','maximum_expected_position_error_during_hold_m','maximum_closure_rotation_during_hold_deg','postlift_hold_maximum_drift_m','postlift_hold_maximum_rotation_deg']}
    source['lift_hold_passed']=bool(record['qualified_lift_hold_passed'])
    source['qualified_full_sequence_passed']=good
    source['frozen_full_sequence_passed']=bool(record['frozen_full_sequence_passed'])
    source['frozen_lift_hold_passed']=bool(record['frozen_lift_hold_passed'])
    source['scientific_criteria']=protocol['scientific_criteria']
    source['camera']={'type':'Per-frame full-hand plus entire-oriented-rod AABB bound; all framing values saved in per_frame.csv','context_pixels':[0,72,400,374],'azimuth':135,'elevation':-20,'near_view':'Actual HO geometry when original contact present, otherwise nearest all-hand/rod geom pair; no fixed fingertip assumption','near_distance_m':.035,'near_pixels':[404,81,628,249]}
    source['upright_provenance']=record['upright_provenance']
    source['controller_profile']=controller_profile
    source['controller_intervention']=record.get('hand_controller_intervention')
    source['interventions']={key:value for key,value in record.items() if key.endswith('_intervention')}
    source['intervention_sources']=[{'key':key,'path':str(path),'sha256':extra_hashes[key]} for key,path in extra_paths.items()]
    source['phase_boundaries']=record['phase_boundaries']
    source['phase_caption_policy']='Actual duration from consecutive archived phase boundaries; final phase ends at recorded simulation duration.'
    source['renderer_sha256']=sha(__file__)
    source['upright_protocol_checks']=protocol['checks']
    source['actual_far_start_offset_m']=far_offset
    source['candidate_proposal']=record.get('candidate_proposal')
    source['candidate_class']='coarse_translated_seed' if 'translated_coarse' in record.get('candidate_proposal',{}).get('stage','') else record.get('candidate_proposal',{}).get('stage')
    source['display_label']=display_label
    source['task_lift_hold_release_passed']=True
    source['task_outcome_review']={'path':str(task_review_path),'sha256':task_review_hash,'reviewed_trial':task_row}
    source['presentation_outcome_policy']='Task lift/hold/release accomplishment from independent unchanged-source review is displayed separately from the original full-quaternion strict gate, which remains false. No physical state or original metric is modified.'
    source['result']=str(folder/'result.json')
    source['source_sha256']['result']=sha(source['result'])
    source['resource_policy']=resource_policy
    source['support_clearance_policy']='No fixture/plane contacts and lowest oriented cylinder point above(actual fixture wall top+0.05mm) or0.05mm(plain); bottom uses radius0.5mm and each actual H/2, from original observed pose.'
    if encode:
        source['video']={"path":str(target),"width":WIDTH,"height":HEIGHT,"frames":len(indices),"fps":FPS,"duration_s":len(indices)/FPS,"sha256":sha(target),"source_trial_id":identifier}
        source['video']['probe']=probe(target,len(indices))
        source['video']['full_decode_passed']=True
    for key,digest in source['source_sha256'].items():
        assert sha(source[key])==digest==frozen_hashes[key],('Source changed during rendering',key)
    for key,path in extra_paths.items():
        assert sha(path)==extra_hashes[key],('Intervention source changed during rendering',key)
    assert sha(task_review_path)==task_review_hash,'Task review snapshot changed during rendering'
    write_json(target_folder/"render-index.json",source)
    return source


def probe(path, frames):
    subprocess.run(["ffmpeg","-nostdin","-v","error","-xerror","-threads","1","-i",str(path),"-f","null","-"],check=True,capture_output=True)
    info=json.loads(subprocess.check_output(["ffprobe","-v","error","-count_frames","-show_entries","stream=width,height,r_frame_rate,avg_frame_rate,nb_read_frames,nb_frames","-show_entries","format=duration","-of","json",str(path)],text=True))
    stream=info['streams'][0]
    assert stream['r_frame_rate']==stream['avg_frame_rate']=='10/1'
    assert int(stream['nb_read_frames'])==int(stream['nb_frames'])==frames
    assert abs(float(info['format']['duration'])-frames/FPS)<1e-6
    return info


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--metrics',type=Path,action='append',help='Explicit source already confirmed frozen by trial owner')
    parser.add_argument('--frozen-manifest',type=Path,help='JSON trials:[{metrics,metrics_sha256}] confirmed frozen')
    parser.add_argument('--render',action='store_true',help='Encode complete10fps video, otherwise preview only')
    parser.add_argument('--reuse',action='store_true')
    parser.add_argument('--worker',type=Path,help=argparse.SUPPRESS)
    args=parser.parse_args()
    low_priority_one_cpu()
    if args.worker:
        result=render_one(args.worker,args.render)
        print(json.dumps({'trial_id':result['trial_id'],'video':result.get('video'),'manifest':str(OUT/result['trial_id']/'render-index.json')},ensure_ascii=False),flush=True)
        return
    entries=[]
    if args.frozen_manifest:
        manifest=json.loads(args.frozen_manifest.read_text())
        entries.extend(manifest['trials'])
    entries.extend({'metrics':str(path.resolve())} for path in args.metrics or [])
    if not entries:
        parser.error('Provide explicitly confirmed frozen --metrics or --frozen-manifest; active search outputs are not auto-scanned')
    for entry in entries:
        path=Path(entry['metrics']).resolve()
        if entry.get('metrics_sha256'):
            assert sha(path)==entry['metrics_sha256'],f'Frozen metric hash differs: {path}'
        record=json.loads(path.read_text())
        identifier=identifier_of(record,path)
        cached=OUT/identifier/'render-index.json'
        if args.render and args.reuse and cached.exists():
            prior=json.loads(cached.read_text())
            bindings=prior.get('source_sha256',{})
            if (prior.get('renderer_sha256')==sha(__file__)
                    and all(sha(prior[key])==digest for key,digest in bindings.items())
                    and prior.get('video',{}).get('full_decode_passed')
                    and sha(prior['video']['path'])==prior['video']['sha256']):
                print(json.dumps({'reused':identifier},ensure_ascii=False),flush=True)
                continue
        command=[sys.executable,str(Path(__file__).resolve()),'--worker',str(path)]
        if args.render:
            command.append('--render')
        subprocess.run(command,check=True)
    print(json.dumps({'completed_explicit_frozen_trials':len(entries),'batch_index_written':False,'resource_policy':{'maximum_concurrent_trials':1,'affinity_cpus':sorted(os.sched_getaffinity(0)),'nice':os.nice(0)}},ensure_ascii=False),flush=True)


if __name__=='__main__':
    main()

