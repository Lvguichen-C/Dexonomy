#!/usr/bin/env python3
"""Assemble the two already-rendered first task-accomplishment trials."""
from __future__ import annotations
import hashlib
import json
import os
from pathlib import Path
import subprocess

from PIL import Image, ImageDraw, ImageFont

OUT=Path(__file__).resolve().parent
FPS=10


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def main():
    cpus=sorted(os.sched_getaffinity(0));os.sched_setaffinity(0,{cpus[-1]})
    current=os.nice(0)
    if current<10:os.nice(10-current)
    manifests=[]
    for fixture in ('plain','shallow'):
        folder=OUT/f'normal_integrator_contact_axis_preload5__h60__{fixture}__h060_d5_normalmapped_release_squeeze0_normal_contact_axis_preload5'
        path=folder/'render-index.json';record=json.loads(path.read_text())
        assert record['task_lift_hold_release_passed'] is True
        assert record['qualified_full_sequence_passed'] is False
        assert record['video']['full_decode_passed'] is True
        assert sha(record['video']['path'])==record['video']['sha256']
        manifests.append((path,record))
    frames=manifests[0][1]['video']['frames']
    assert all(x['video']['frames']==frames and x['video']['fps']==FPS for _,x in manifests)
    folder=OUT/'h060_contact_axis_plain_vs_shallow';folder.mkdir(exist_ok=True)
    banner=folder/'comparison_background.png'
    im=Image.new('RGB',(1280,720),(17,24,34));draw=ImageDraw.Draw(im)
    font=lambda size:ImageFont.truetype('/usr/share/fonts/opentype/noto/NotoSansCJK-Regular.ttc',size)
    draw.text((22,10),'Φ1 × 60 mm · 200 g｜无托 / 浅托同策略完整对照',font=font(31),fill=(239,244,248))
    draw.text((22,55),'相同保存时刻并排 · 原始物理状态回放 · 全程含远离、接近、持握及释放',font=font(24),fill=(181,199,215))
    draw.text((22,590),'受力预载 5 s；实际升高约 100 mm、持握 5 s、释放达成',font=font(27),fill=(246,210,112))
    draw.text((22,635),'任务达成为事后诊断；原全四元数姿态门槛未通过，未称严格全流程通过',font=font(24),fill=(232,220,188))
    draw.text((22,675),'两侧均为同一接触轴反馈控制方案；未改写物体位置或原指标',font=font(21),fill=(168,187,204))
    im.save(banner)
    target=folder/'h060_contact_axis_plain_vs_shallow.mp4'
    command=['ffmpeg','-nostdin','-y','-v','error','-filter_complex_threads','1']
    for _,record in manifests:command+=['-threads','1','-i',record['video']['path']]
    command+=['-loop','1','-framerate','10','-i',str(banner),'-filter_complex','[0:v]setpts=PTS-STARTPTS,setsar=1[a];[1:v]setpts=PTS-STARTPTS,setsar=1[b];[a][b]hstack=inputs=2:shortest=1[strip];[2:v][strip]overlay=x=0:y=100:shortest=1,setsar=1,setpts=N/(10*TB)[v]','-map','[v]','-an','-r','10','-fps_mode','cfr','-frames:v',str(frames),'-c:v','libx264','-preset','veryfast','-crf','18','-pix_fmt','yuv420p','-threads','1','-movflags','+faststart',str(target)]
    subprocess.run(command,check=True)
    subprocess.run(['ffmpeg','-nostdin','-v','error','-xerror','-threads','1','-i',str(target),'-f','null','-'],check=True,capture_output=True)
    probe=json.loads(subprocess.check_output(['ffprobe','-v','error','-count_frames','-show_entries','stream=width,height,r_frame_rate,avg_frame_rate,nb_read_frames,nb_frames','-show_entries','format=duration','-of','json',str(target)],text=True))
    stream=probe['streams'][0]
    assert stream['width']==1280 and stream['height']==720
    assert stream['r_frame_rate']==stream['avg_frame_rate']=='10/1'
    assert int(stream['nb_read_frames'])==int(stream['nb_frames'])==frames
    assert abs(float(probe['format']['duration'])-frames/FPS)<1e-6
    preview=folder/'preview_hold.png'
    subprocess.run(['ffmpeg','-nostdin','-y','-v','error','-threads','1','-i',str(target),'-vf','select=eq(n\\,150)','-frames:v','1',str(preview)],check=True)
    sources=[]
    for path,record in manifests:
        assert sha(record['video']['path'])==record['video']['sha256']
        sources.append({'trial_id':record['trial_id'],'render_index':{'path':str(path),'sha256':sha(path)},'video':{'path':record['video']['path'],'sha256':record['video']['sha256']}})
    result={'schema_version':1,'kind':'matched_comparison','comparison_policy':'Only the two actually tested matched H60/support conditions under the same contact-axis/5s-preload policy. Posthoc task accomplishment and original strict quaternion failure remain distinct.','source_trial_ids':[record['trial_id'] for _,record in manifests],'sources':sources,'video':{'kind':'matched_comparison','public_download':True,'download_name':target.name,'path':str(target),'width':1280,'height':720,'frames':frames,'fps':FPS,'duration_s':frames/FPS,'sha256':sha(target),'source_trial_ids':[record['trial_id'] for _,record in manifests],'probe':probe,'full_decode_passed':True},'previews':[{'path':str(preview),'sha256':sha(preview),'frame':150}],'dependencies':[{'path':str(Path(__file__).resolve()),'sha256':sha(__file__)},{'path':str(banner),'sha256':sha(banner)}],'resource_policy':{'affinity_cpus':sorted(os.sched_getaffinity(0)),'nice':os.nice(0),'maximum_concurrent_trials':1}}
    index=folder/'render-index.json';index.write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n');print(index,flush=True)


if __name__=='__main__':main()
