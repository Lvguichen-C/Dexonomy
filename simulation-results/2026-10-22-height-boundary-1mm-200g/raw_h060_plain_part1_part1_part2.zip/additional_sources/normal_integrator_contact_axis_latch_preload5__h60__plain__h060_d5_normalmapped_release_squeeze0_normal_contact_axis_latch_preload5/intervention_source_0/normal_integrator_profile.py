#!/usr/bin/env python3
"""Contact-normal incremental position control using existing hand actuators.

Only actuator targets and ordinary root mocap commands change. The rod remains
free with gravity; no object state, external object force or model edit occurs.
"""
from __future__ import annotations
import argparse,json,subprocess,sys
from pathlib import Path
from types import MethodType
import mujoco,numpy as np
ROOT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT))
import run_height_trials as runner
from micro_contact_profile import make_env_micro
from anchored_root_control import AnchoredRootFeedback

SETTINGS=dict(target_normal_force_each_N=3.,hard_force_relief_threshold_N=6.,update_period_s=.005,
 force_error_to_normal_velocity_m_per_N_s=.001,maximum_normal_velocity_m_s=.002,
 maximum_control_increment_per_update_rad=.002,maximum_control_departure_from_capture_rad=.2,
 begin_close_feedback_after_s=.4,dual_force_imbalance_freeze_N=.3,
 single_contact_policy='Hold the already contacting side at its existing position target without relaxing to 0.1N. Continue closing the missing side. Force relief above6N remains enabled.',
 active_phases=['approach_close_squeeze','loaded_hold','lift','postlift_hold'])

class NormalIntegrator:
 def __init__(self,env):
  self.env=env;self.m=env._model;self.d=env._data;self.original_set=env.set_ctrl;self.original_step=env.step_sim
  self.B=np.asarray(env._hand_qpos2ctrl_mat[:,6:]);self.A=np.linalg.pinv(self.B)
  self.hand_nv=env._hand_nv;self.nominal=self.d.ctrl.copy();self.command=self.nominal.copy();self.capture=self.nominal.copy()
  self.nominal_q=env.get_hand_qpos().copy();self.engaged=False;self.steps=0;self.phase=None;self.phase_started=0.
  self.ids=[];self.tipids=[]
  for finger in ['th','ff']:
   ids=np.asarray([i for i in range(self.m.nu) if f'_A_{finger.upper()}J' in self.m.actuator(i).name],int)
   tips=[i for i in range(self.m.ngeom) if self.m.body(int(self.m.geom_bodyid[i])).name==f'hand-rh_{finger}distal' and (self.m.geom_contype[i] or self.m.geom_conaffinity[i])]
   if len(ids)==0 or not tips:raise RuntimeError(f'Missing {finger} hardware')
   self.ids.append(ids);self.tipids.append(tips)
  self.selected=np.concatenate(self.ids)
  self.objects={i for i in range(self.m.ngeom) if self.m.body(int(self.m.geom_bodyid[i])).name.startswith('obj-') and (self.m.geom_contype[i] or self.m.geom_conaffinity[i])}
  self.velocity=np.zeros(2);self.normal=np.zeros((2,3));self.gradient_norm=np.zeros(2);self.logs=[]
 def state(self):
  forces=np.zeros(2);counts=np.zeros(2,int);points=np.zeros((2,3));normals=np.zeros((2,3));weights=np.zeros(2);bodies=[None,None]
  for ci,c in enumerate(self.d.contact):
   gs=[int(c.geom1),int(c.geom2)]
   if not set(gs)&self.objects:continue
   for k,gi in enumerate(gs):
    name=self.m.body(int(self.m.geom_bodyid[gi])).name
    fi=0 if name.startswith('hand-rh_th') else 1 if name.startswith('hand-rh_ff') else None
    if fi is None:continue
    f=np.zeros(6);mujoco.mj_contactForce(self.m,self.d,ci,f);fn=max(0.,float(f[0]));weight=max(fn,1e-6)
    forces[fi]+=fn;counts[fi]+=1;points[fi]+=weight*c.pos
    normals[fi]+=weight*c.frame[:3]*(1 if k==0 else -1);weights[fi]+=weight
    bodies[fi]=int(self.m.geom_bodyid[gi])
  for fi in range(2):
   if weights[fi]>0:points[fi]/=weights[fi]
   else:
    best=np.inf;nearest=None;nearest_geom=None
    for hi in self.tipids[fi]:
     for oi in self.objects:
      segment=np.zeros(6);dist=float(mujoco.mj_geomDistance(self.m,self.d,hi,oi,.5,segment))
      if dist<best:best=dist;nearest=segment.copy();nearest_geom=hi
    points[fi]=nearest[:3];normals[fi]=nearest[3:]-nearest[:3];bodies[fi]=int(self.m.geom_bodyid[nearest_geom])
   size=np.linalg.norm(normals[fi])
   if size<1e-12:
    normals[fi]=self.d.xpos[self.env._obj_active_bodyid]-points[fi];size=np.linalg.norm(normals[fi])
   if size>0:normals[fi]/=size
  return forces,counts,points,normals,bodies
 def apply(self):
  self.d.ctrl[:]=self.nominal
  if self.engaged:self.d.ctrl[self.selected]=self.command[self.selected]
  # A minimal-norm hinge representation of the actual actuator-length target;
  # it does not create separately driven FFJ1/FFJ2 hardware.
  q=self.nominal_q.copy();q[7:]+=self.A@(self.d.ctrl-self.nominal)
  q[:3]=self.d.mocap_pos[0];q[3:7]=self.d.mocap_quat[0]
  if hasattr(self.env,'height_trial_target_qpos'):self.env.height_trial_target_qpos=q.copy()
  return q
 def update(self,forces,counts,points,normals,bodies):
  velocities=np.zeros(2);gradnorm=np.zeros(2)
  for fi in range(2):
   force=forces[fi];other=1-fi
   if counts[fi]>0 and counts[other]==0 and force<=SETTINGS['hard_force_relief_threshold_N']:
    velocity=0.
   elif counts[fi]>0 and force>forces[other]+SETTINGS['dual_force_imbalance_freeze_N'] and force<=SETTINGS['target_normal_force_each_N']:
    velocity=0.
   else:velocity=np.clip(SETTINGS['force_error_to_normal_velocity_m_per_N_s']*(SETTINGS['target_normal_force_each_N']-force),-SETTINGS['maximum_normal_velocity_m_s'],SETTINGS['maximum_normal_velocity_m_s'])
   jp=np.zeros((3,self.m.nv));jr=np.zeros((3,self.m.nv))
   mujoco.mj_jac(self.m,self.d,jp,jr,points[fi],bodies[fi])
   gradient=normals[fi]@jp[:,6:self.hand_nv]@self.A
   ids=self.ids[fi];g=gradient[ids];g2=float(np.dot(g,g));gradnorm[fi]=np.sqrt(g2)
   if g2<1e-12:continue
   du=g*(velocity*SETTINGS['update_period_s'])/(g2+1e-10)
   du=np.clip(du,-SETTINGS['maximum_control_increment_per_update_rad'],SETTINGS['maximum_control_increment_per_update_rad'])
   value=self.command[ids]+du
   value=np.clip(value,self.capture[ids]-SETTINGS['maximum_control_departure_from_capture_rad'],self.capture[ids]+SETTINGS['maximum_control_departure_from_capture_rad'])
   limited=self.m.actuator_ctrllimited[ids].astype(bool)
   value[limited]=np.clip(value[limited],self.m.actuator_ctrlrange[ids[limited],0],self.m.actuator_ctrlrange[ids[limited],1])
   self.command[ids]=value;velocities[fi]=velocity
  self.velocity,self.normal,self.gradient_norm=velocities,normals,gradnorm
 def install(self):
  c=self
  def set_control(env,qpos,ctrl_type='ee_pose',*args,**kwargs):
   c.original_set(qpos,ctrl_type,*args,**kwargs);c.nominal=env._data.ctrl.copy();c.nominal_q=np.asarray(qpos,float).copy()
   return c.apply()
  def step(env,substep):
   for _ in range(substep):
    phase=getattr(env.observer,'phase','inactive');now=float(env._data.time)
    if phase!=c.phase:c.phase=phase;c.phase_started=now
    forces,counts,points,normals,bodies=c.state()
    active=phase in SETTINGS['active_phases'] and (phase!='approach_close_squeeze' or now-c.phase_started>=SETTINGS['begin_close_feedback_after_s'])
    if active:
     if not c.engaged:c.engaged=True;c.command=c.nominal.copy();c.capture=c.command.copy()
     if c.steps%5==0:c.update(forces,counts,points,normals,bodies)
    else:c.engaged=False;c.command=c.nominal.copy();c.capture=c.nominal.copy();c.velocity[:]=0
    applied=c.apply();c.original_step(1)
    force_after,counts_after,_,_,_=c.state()
    c.logs.append((float(env._data.time),phase,c.engaged,c.nominal.copy(),env._data.ctrl.copy(),c.capture.copy(),force_after,counts_after,c.velocity.copy(),c.normal.copy(),c.gradient_norm.copy(),applied.copy()))
    c.steps+=1
  self.env.set_ctrl=MethodType(set_control,self.env);self.env.step_sim=MethodType(step,self.env)
 def finish(self,folder):
  names=['time_s','phase','feedback_active','nominal_actuator_ctrl','actual_actuator_ctrl','captured_actuator_ctrl','actual_normal_force_N','finger_contact_count','normal_approach_velocity_m_s','inward_normal_world','actuator_normal_jacobian_norm_m_rad','applied_equivalent_hand_qpos']
  arrays={n:np.asarray([r[i] for r in self.logs]) for i,n in enumerate(names)}
  arrays['actuator_names']=np.asarray([self.m.actuator(i).name for i in range(self.m.nu)]);arrays['finger_names']=np.asarray(['thumb','index'])
  np.savez_compressed(folder/'normal_integrator_feedback.npz',**arrays)
  stats={}
  for phase in SETTINGS['active_phases']:
   mask=arrays['phase']==phase
   if np.any(mask):stats[phase]={'samples':int(np.sum(mask)),'actual_force_mean_N':np.mean(arrays['actual_normal_force_N'][mask],axis=0).tolist(),'actual_force_max_N':np.max(arrays['actual_normal_force_N'][mask],axis=0).tolist(),'thumb_index_contact_fraction':float(np.mean(np.all(arrays['finger_contact_count'][mask]>0,axis=1)))}
  return {'adapter_source':str(Path(__file__).resolve()),'adapter_sha256':runner.sha(__file__),'settings':SETTINGS,'feedback_trace':str((folder/'normal_integrator_feedback.npz').resolve()),'feedback_sha256':runner.sha(folder/'normal_integrator_feedback.npz'),'phase_force_statistics':stats,'model_actuator_and_object_parameters_changed':False,'object_force_or_pose_control_added':False,'applied_qpos_interpretation':'Minimum-norm actuator-equivalent hinge target plus actual mocap command; actual actuatorctrl/length remain the physical control record.'}

def run_trial(job):
 factory=runner.load_fixture();original=factory.make_env;controls=[]
 def adapted(*args,**kwargs):
  factory.make_env=original
  try:env=make_env_micro(factory,*args,**kwargs)
  finally:factory.make_env=adapted
  normal=NormalIntegrator(env);normal.install();root=AnchoredRootFeedback(env);root.install();controls.append((normal,root))
  return env
 factory.make_env=adapted
 try:result=runner.run_trial(job)
 finally:factory.make_env=original
 folder=Path(job['output']);normal,root=controls[0];record=normal.finish(folder);rootrecord=root.finish(folder)
 m=json.loads((folder/'metrics.json').read_text());m.update(normal_integral_intervention=record,root_pose_feedback_intervention=rootrecord,micro_contact_intervention=normal.env.micro_contact_definition,comparison_profile='normal_integrator_micro_anchor')
 runner.write_json(folder/'metrics.json',m);runner.write_json(folder/'normal_integral_intervention.json',record);runner.write_json(folder/'root_pose_feedback_intervention.json',rootrecord)
 result.update(comparison_profile='normal_integrator_micro_anchor',normal_integrator_summary=record['phase_force_statistics']);runner.write_json(folder/'result.json',result);print(json.dumps(result,ensure_ascii=False),flush=True)
 return result

def main():
 p=argparse.ArgumentParser(description=__doc__);p.add_argument('--job',type=Path);p.add_argument('--manifest',type=Path,default=ROOT/'grasp_search/coarse-20-40-80-frozen.json');p.add_argument('--candidate',default='h040_coarse_top_v1');p.add_argument('--condition',choices=['plain','shallow'],default='plain');a=p.parse_args()
 if a.job:return run_trial(json.loads(a.job.read_text()))
 variant=next(v for v in json.loads(a.manifest.read_text())['variants'] if v['id']==a.candidate);variant=dict(variant);variant['id']+='_normal_integral'
 job={'variant':variant,'fixture':a.condition,'resume':False,'output':str((ROOT/'trials'/f"h{variant['height_mm']:03d}"/a.condition/variant['id']).resolve()),'provenance_sources':[str(Path(__file__).resolve()),str(ROOT/'anchored_root_control.py'),str(ROOT/'micro_contact_profile.py')]}
 out=ROOT/'control_analysis/jobs';out.mkdir(exist_ok=True);runner.write_json(out/f'{a.condition}__{variant["id"]}.json',job)
 return run_trial(job)
if __name__=='__main__':main()
