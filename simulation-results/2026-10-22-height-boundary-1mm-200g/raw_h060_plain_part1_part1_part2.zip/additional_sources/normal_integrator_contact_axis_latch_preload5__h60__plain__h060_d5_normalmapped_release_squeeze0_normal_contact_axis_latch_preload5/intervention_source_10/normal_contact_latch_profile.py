#!/usr/bin/env python3
"""After the five-second preload, hold the real position-servo targets fixed.

This isolates continued Cartesian target integration from passive grasp
retention. Original position actuators remain active; no object constraint,
force, model change, or successful-state reset is introduced.
"""
from __future__ import annotations
import argparse
import json
from pathlib import Path
import sys
import numpy as np

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT))
import normal_contact_axis_profile as axial
normal = axial.normal
Base = axial.ContactAxisIntegrator
SETTINGS = dict(latch_phases=['lift', 'postlift_hold'], loaded_hold_s=5.,
               latch_policy='Retain the selected original position-actuator targets reached at the end of the preload. Disable extra normal/axial integration during lift/hold; position servos and ordinary root tracking stay active. Release restores nominal open targets.',
               strict_success_conditions_changed=False)
PROFILE = 'normal_integrator_contact_axis_latch_preload5'


class LatchIntegrator(Base):
    def __init__(self, env):
        super().__init__(env)
        self.latch = None
        self.latch_logs = []

    def update(self, forces, counts, points, normals, bodies):
        if self.phase in SETTINGS['latch_phases']:
            if self.latch is None:
                self.latch = self.command[self.selected].copy()
            self.command[self.selected] = self.latch
            self.velocity[:] = 0.
            self.normal = normals.copy()
            self.latch_logs.append((float(self.d.time), str(self.phase), self.latch.copy(), forces.copy(), counts.copy()))
        else:
            super().update(forces, counts, points, normals, bodies)

    def finish(self, folder):
        record = super().finish(folder)
        names = ['time_s', 'phase', 'latched_selected_actuator_targets', 'actual_normal_force_N', 'finger_contact_count']
        np.savez_compressed(folder / 'latch_feedback.npz', **{name: np.asarray([row[i] for row in self.latch_logs]) for i, name in enumerate(names)})
        record['latch_intervention'] = dict(adapter_source=str(Path(__file__).resolve()), adapter_sha256=normal.runner.sha(__file__),
            settings=SETTINGS, selected_actuator_names=[self.m.actuator(int(i)).name for i in self.selected],
            feedback_trace=str((folder / 'latch_feedback.npz').resolve()), feedback_sha256=normal.runner.sha(folder / 'latch_feedback.npz'))
        return record


def run_trial(job):
    original = axial.ContactAxisIntegrator
    axial.ContactAxisIntegrator = LatchIntegrator
    try:
        result = axial.run_trial(job)
    finally:
        axial.ContactAxisIntegrator = original
    folder = Path(job['output'])
    metrics = json.loads((folder / 'metrics.json').read_text())
    metrics.update(comparison_profile=PROFILE, latch_intervention=metrics['normal_integral_intervention']['latch_intervention'])
    normal.runner.write_json(folder / 'metrics.json', metrics)
    result.update(comparison_profile=PROFILE)
    normal.runner.write_json(folder / 'result.json', result)
    print(json.dumps(result, ensure_ascii=False), flush=True)
    return result


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--job', type=Path)
    p.add_argument('--manifest', type=Path, default=ROOT / 'grasp_search/d5-h060-normalmapped-frozen.json')
    p.add_argument('--candidate', default='h060_d5_normalmapped_release_squeeze0')
    p.add_argument('--condition', choices=['plain', 'shallow'], default='plain')
    a = p.parse_args()
    if a.job:
        return run_trial(json.loads(a.job.read_text()))
    variant = dict(next(v for v in json.loads(a.manifest.read_text())['variants'] if v['id'] == a.candidate))
    variant['id'] += '_normal_contact_axis_latch_preload5'
    job = dict(variant=variant, fixture=a.condition, resume=False,
        output=str((ROOT / 'trials' / f"h{variant['height_mm']:03d}" / a.condition / variant['id']).resolve()),
        declared_control_settings=SETTINGS, declared_preload_duration_s=5.,
        provenance_sources=[str(Path(__file__).resolve()), str(Path(axial.__file__).resolve()), str(Path(normal.__file__).resolve()),
                            str(ROOT / 'anchored_root_control.py'), str(ROOT / 'micro_contact_profile.py')])
    out = ROOT / 'control_analysis/jobs'
    out.mkdir(exist_ok=True)
    normal.runner.write_json(out / f'{a.condition}__{variant["id"]}.json', job)
    return run_trial(job)


if __name__ == '__main__':
    main()
