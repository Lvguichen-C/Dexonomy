#!/usr/bin/env python3
"""Bounded contact-axis alignment using existing position actuators only.

This distinct control experiment retains the frozen incremental normal-force
controller, adds slow axial motion in its actuator normal-task null space, and
uses a declared five-second preload. It never moves or loads the object itself.
"""
from __future__ import annotations
import argparse
import json
from pathlib import Path
import sys
import mujoco
import numpy as np

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT))
import normal_integrator_profile as normal

SETTINGS = dict(loaded_hold_s=5., axial_error_deadband_m=50e-6,
               axial_error_gain_per_s=2., maximum_axial_velocity_m_s=.001,
               maximum_normal_axial_cosine=.7,
               require_actual_contacts_on_both_fingers=True,
               preserve_original_normal_task_in_kinematic_actuator_null_space=True,
               total_per_update_increment_rad=.002,
               controller_capture_departure_rad=.2,
               strict_success_conditions_changed=False)
PROFILE = 'normal_integrator_contact_axis_preload5'
BaseNormalIntegrator = normal.NormalIntegrator


class ContactAxisIntegrator(BaseNormalIntegrator):
    def __init__(self, env):
        super().__init__(env)
        self.axis_logs = []

    def update(self, forces, counts, points, normals, bodies):
        previous = self.command.copy()
        super().update(forces, counts, points, normals, bodies)
        axis = self.d.xmat[self.env._obj_active_bodyid].reshape(3, 3)[:, 2].copy()
        separation = float(axis @ (points[1] - points[0]))
        desired = np.zeros(2)
        applied = np.zeros_like(self.command)
        valid = bool(np.all(counts > 0) and np.max(np.abs(normals @ axis)) < SETTINGS['maximum_normal_axial_cosine'])
        if valid and abs(separation) > SETTINGS['axial_error_deadband_m']:
            correction = separation - np.sign(separation) * SETTINGS['axial_error_deadband_m']
            desired = np.clip(np.array([.5, -.5]) * correction * SETTINGS['axial_error_gain_per_s'],
                              -SETTINGS['maximum_axial_velocity_m_s'], SETTINGS['maximum_axial_velocity_m_s'])
            for fi in range(2):
                jp = np.zeros((3, self.m.nv))
                jr = np.zeros((3, self.m.nv))
                mujoco.mj_jac(self.m, self.d, jp, jr, points[fi], bodies[fi])
                cartesian = jp[:, 6:self.hand_nv] @ self.A
                ids = self.ids[fi]
                gn = (normals[fi] @ cartesian)[ids]
                ga = (axis @ cartesian)[ids]
                # Exact actuator-space projection under the same local J*A
                # approximation as the ordinary normal task. Physical motion
                # and force remain measured by the original MuJoCo stepping.
                direction = ga - gn * (float(gn @ ga) / (float(gn @ gn) + 1e-14))
                response = float(ga @ direction)
                if response <= 1e-12:
                    continue
                du = direction * (desired[fi] * normal.SETTINGS['update_period_s']) / (response + 1e-12)
                proposal = self.command[ids] + du
                proposal = previous[ids] + np.clip(proposal - previous[ids], -SETTINGS['total_per_update_increment_rad'], SETTINGS['total_per_update_increment_rad'])
                proposal = np.clip(proposal, self.capture[ids] - SETTINGS['controller_capture_departure_rad'], self.capture[ids] + SETTINGS['controller_capture_departure_rad'])
                limited = self.m.actuator_ctrllimited[ids].astype(bool)
                proposal[limited] = np.clip(proposal[limited], self.m.actuator_ctrlrange[ids[limited], 0], self.m.actuator_ctrlrange[ids[limited], 1])
                applied[ids] = proposal - self.command[ids]
                self.command[ids] = proposal
        self.axis_logs.append((float(self.d.time), str(self.phase), valid, axis, points.copy(), normals.copy(),
                               forces.copy(), counts.copy(), separation, desired, applied.copy()))

    def finish(self, folder):
        record = super().finish(folder)
        names = ['time_s', 'phase', 'bilateral_side_contact_eligible', 'rod_axis_world', 'finger_contact_or_witness_point_world',
                 'inward_normal_world', 'actual_normal_force_N', 'finger_contact_count',
                 'index_minus_thumb_axial_contact_separation_m', 'desired_axial_velocity_m_s', 'additional_actuator_target_increment_rad']
        np.savez_compressed(folder / 'contact_axis_feedback.npz', **{name: np.asarray([row[i] for row in self.axis_logs]) for i, name in enumerate(names)})
        record['contact_axis_intervention'] = dict(adapter_source=str(Path(__file__).resolve()),
            adapter_sha256=normal.runner.sha(__file__), settings=SETTINGS,
            feedback_trace=str((folder / 'contact_axis_feedback.npz').resolve()),
            feedback_sha256=normal.runner.sha(folder / 'contact_axis_feedback.npz'))
        return record


def run_trial(job):
    factory = normal.runner.load_fixture()
    frozen = factory.frozen_module()
    original_config = frozen.TestConfig
    original_class = normal.NormalIntegrator

    def config_with_preload(*args, **kwargs):
        kwargs['loaded_hold_s'] = SETTINGS['loaded_hold_s']
        return original_config(*args, **kwargs)

    frozen.TestConfig = config_with_preload
    normal.NormalIntegrator = ContactAxisIntegrator
    try:
        result = normal.run_trial(job)
    finally:
        frozen.TestConfig = original_config
        normal.NormalIntegrator = original_class
    folder = Path(job['output'])
    metrics = json.loads((folder / 'metrics.json').read_text())
    metrics.update(comparison_profile=PROFILE,
                   contact_axis_intervention=metrics['normal_integral_intervention']['contact_axis_intervention'])
    normal.runner.write_json(folder / 'metrics.json', metrics)
    result.update(comparison_profile=PROFILE, loaded_hold_s=SETTINGS['loaded_hold_s'])
    normal.runner.write_json(folder / 'result.json', result)
    print(json.dumps(result, ensure_ascii=False), flush=True)
    return result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--job', type=Path)
    parser.add_argument('--manifest', type=Path, default=ROOT / 'grasp_search/d5-h060-normalmapped-frozen.json')
    parser.add_argument('--candidate', default='h060_d5_normalmapped_release_squeeze0')
    parser.add_argument('--condition', choices=['plain', 'shallow'], default='plain')
    args = parser.parse_args()
    if args.job:
        return run_trial(json.loads(args.job.read_text()))
    variant = dict(next(v for v in json.loads(args.manifest.read_text())['variants'] if v['id'] == args.candidate))
    variant['id'] += '_normal_contact_axis_preload5'
    job = dict(variant=variant, fixture=args.condition, resume=False,
        output=str((ROOT / 'trials' / f"h{variant['height_mm']:03d}" / args.condition / variant['id']).resolve()),
        declared_control_settings=SETTINGS,
        provenance_sources=[str(Path(__file__).resolve()), str(Path(normal.__file__).resolve()),
                            str(ROOT / 'anchored_root_control.py'), str(ROOT / 'micro_contact_profile.py')])
    out = ROOT / 'control_analysis/jobs'
    out.mkdir(exist_ok=True)
    normal.runner.write_json(out / f'{args.condition}__{variant["id"]}.json', job)
    return run_trial(job)


if __name__ == '__main__':
    main()
