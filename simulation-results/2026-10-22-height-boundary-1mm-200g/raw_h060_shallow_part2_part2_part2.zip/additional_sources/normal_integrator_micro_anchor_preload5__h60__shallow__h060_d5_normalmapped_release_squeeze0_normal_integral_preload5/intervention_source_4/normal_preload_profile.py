#!/usr/bin/env python3
"""Fixed five-second force-building wait with the frozen normal controller.

Only the duration before the lift changes from the normal_integrator profile.
The same original five-second lift, five-second hold, contact/height/release
gates, position actuators, free rod, and declared micro contacts are retained.
"""
from __future__ import annotations
import argparse
import json
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT))
import normal_integrator_profile as normal

SETTINGS = dict(loaded_hold_s=5.0, baseline_loaded_hold_s=1.0,
               force_condition_before_lift=None,
               rationale='Allow the ordinary closed-loop position controller to establish contact force before the scheduled lift.',
               lift_s=5.0, postlift_hold_s=5.0, strict_success_conditions_changed=False)
PROFILE = 'normal_integrator_micro_anchor_preload5'


def run_trial(job):
    factory = normal.runner.load_fixture()
    frozen = factory.frozen_module()
    original_config = frozen.TestConfig

    def config_with_preload(*args, **kwargs):
        if 'loaded_hold_s' in kwargs and kwargs['loaded_hold_s'] != SETTINGS['loaded_hold_s']:
            raise ValueError('Conflicting declared preload duration')
        kwargs['loaded_hold_s'] = SETTINGS['loaded_hold_s']
        return original_config(*args, **kwargs)

    frozen.TestConfig = config_with_preload
    try:
        result = normal.run_trial(job)
    finally:
        frozen.TestConfig = original_config
    folder = Path(job['output'])
    metrics = json.loads((folder / 'metrics.json').read_text())
    record = dict(adapter_source=str(Path(__file__).resolve()),
                  adapter_sha256=normal.runner.sha(__file__), settings=SETTINGS,
                  underlying_controller_source=str(Path(normal.__file__).resolve()),
                  underlying_controller_sha256=normal.runner.sha(normal.__file__))
    metrics.update(comparison_profile=PROFILE, preload_duration_intervention=record)
    normal.runner.write_json(folder / 'metrics.json', metrics)
    normal.runner.write_json(folder / 'preload_duration_intervention.json', record)
    result.update(comparison_profile=PROFILE, loaded_hold_s=SETTINGS['loaded_hold_s'])
    normal.runner.write_json(folder / 'result.json', result)
    print(json.dumps(result, ensure_ascii=False), flush=True)
    return result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--job', type=Path)
    parser.add_argument('--manifest', type=Path, default=ROOT / 'grasp_search/d5-h060-normalmapped-frozen.json')
    parser.add_argument('--candidate', default='h060_d5_normalmapped_release_squeeze0')
    parser.add_argument('--condition', choices=['plain', 'shallow'], default='plain')
    args = parser.parse_args()
    if args.job:
        return run_trial(json.loads(args.job.read_text()))
    variant = next(v for v in json.loads(args.manifest.read_text())['variants'] if v['id'] == args.candidate)
    variant = dict(variant)
    variant['id'] += '_normal_integral_preload5'
    job = dict(variant=variant, fixture=args.condition, resume=False,
               output=str((ROOT / 'trials' / f"h{variant['height_mm']:03d}" / args.condition / variant['id']).resolve()),
               declared_preload_duration_s=SETTINGS['loaded_hold_s'],
               provenance_sources=[str(Path(__file__).resolve()), str(Path(normal.__file__).resolve()),
                                   str(ROOT / 'anchored_root_control.py'), str(ROOT / 'micro_contact_profile.py')])
    out = ROOT / 'control_analysis/jobs'
    out.mkdir(exist_ok=True)
    normal.runner.write_json(out / f'{args.condition}__{variant["id"]}.json', job)
    return run_trial(job)


if __name__ == '__main__':
    main()
