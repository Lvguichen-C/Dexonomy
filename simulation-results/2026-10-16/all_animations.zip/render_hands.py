"""Render native hand-control results; preserve failed tests and original models."""
from __future__ import annotations

import json
import math
import os
from pathlib import Path
import sys

os.environ.setdefault('MUJOCO_GL', 'egl')
import mujoco
import numpy as np
from PIL import Image

from dexonomy.sim import HandCfg, MuJoCo_OptCfg, MuJoCo_OptEnv

sys.path.insert(0, str(Path(__file__).resolve().parent))
from render_utils import FPS, FrameWriter

HERE = Path(__file__).resolve().parent
OUT = HERE / 'hands'
RESULTS = HERE.parent / 'hands'
REPOSITORY = Path('/workspace/Dexonomy')
XMLS = {'allegro': 'right.xml', 'leap': 'right.xml', 'unitree_g1': 'dex_3_1_r.xml', 'shadow': 'right.xml'}
LABELS = {'allegro': 'Allegro', 'leap': 'Leap', 'unitree_g1': 'Unitree G1', 'shadow': 'Shadow'}


def environment(hand, dt=0.002):
    return MuJoCo_OptEnv(HandCfg(f'assets/hand/{hand}/{XMLS[hand]}'),
                        sim_cfg=MuJoCo_OptCfg(timestep=dt))


def saved_trace(hand):
    with np.load(RESULTS / f'{hand}_trajectory.npz') as data:
        return {key: data[key].copy() for key in data.files}


def last_safe_index(trace, bounds):
    """Stop before corruption: reset, nonfinite state, or >0.01 rad limit breach."""
    q = trace['qpos']
    violations = np.maximum(np.maximum(bounds[:, 0] - q, q - bounds[:, 1]), 0).max(axis=1)
    finite = np.isfinite(q).all(axis=1)
    if 'qvel' in trace:
        finite &= np.isfinite(trace['qvel']).all(axis=1)
    resets = np.concatenate(([False], np.diff(trace['times']) <= 0))
    invalid = np.flatnonzero((violations > .01) | ~finite | resets)
    return int(invalid[0] - 1) if len(invalid) else len(q) - 1


def replay_shadow_retry(dt):
    """Reconstruct missing diagnostic traces without replacing test evidence."""
    env = environment('shadow', dt)
    model, data = env._model, env._data
    lo, hi = model.jnt_range.T
    initial = np.clip(np.zeros(model.nq), lo + .12, hi - .12)
    target = initial + .1 * (.5 * (lo + hi) - initial)
    env.reset_qpos(initial, set_ctrl=False)
    env.set_ctrl(initial, ctrl_type='joint_angle')
    times, positions, velocities, commands = [0.], [initial.copy()], [data.qvel.copy()], [initial.copy()]
    captured_warnings = []
    first_omitted = None
    mujoco.set_mju_user_warning(captured_warnings.append)
    try:
        for step in range(round(2.5 / dt)):
            progress = min((step + 1) * dt / .75, 1.)
            smooth = progress ** 2 * (3. - 2. * progress)
            command = initial + smooth * (target - initial)
            env.set_ctrl(command, ctrl_type='joint_angle')
            env.step_sim(1)
            q = data.qpos.copy()
            violation = float(np.maximum(np.maximum(lo - q, q - hi), 0).max())
            if captured_warnings or not np.isfinite(q).all() or data.time <= times[-1] or violation > .01:
                first_omitted = {'attempted_simulation_time_s': (step + 1) * dt,
                                 'clock_s': float(data.time),
                                 'joint_limit_violation_rad': violation,
                                 'warning_messages': list(captured_warnings)}
                break
            times.append(float(data.time))
            positions.append(q)
            velocities.append(data.qvel.copy())
            commands.append(command.copy())
    finally:
        mujoco.set_mju_user_warning(None)
    trace = {'times': np.asarray(times), 'qpos': np.asarray(positions),
             'qvel': np.asarray(velocities), 'command': np.asarray(commands),
             'actuator_target': env._hand_qpos2ctrl_mat @ target,
             'transmission_matrix': env._hand_qpos2ctrl_mat.copy()}
    return env, trace, first_omitted


def render_clip(hand, name, env, trace, status, rate=1., stop=None, annotation='', warning_time=None):
    model, data = env._model, env._data
    end = len(trace['times']) - 1 if stop is None else stop
    assert end >= 1, f'No safe dynamics to show for {name}'
    trace = {key: value[:end + 1] if key in ('times', 'qpos', 'qvel', 'command') else value
             for key, value in trace.items()}
    duration = float(trace['times'][-1] - trace['times'][0])
    frame_count = max(2, math.ceil(duration / rate * FPS))
    frame_times = np.linspace(trace['times'][0], trace['times'][-1], frame_count)
    sample_indices = np.searchsorted(trace['times'], frame_times)
    model.vis.headlight.active = 1
    model.vis.headlight.ambient[:] = [.75, .75, .75]
    model.vis.headlight.diffuse[:] = [.85, .85, .85]
    model.vis.headlight.specular[:] = [.2, .2, .2]
    camera = mujoco.MjvCamera()
    mujoco.mjv_defaultCamera(camera)
    camera.lookat[:] = model.stat.center
    camera.distance = max(.27, 1.45 * float(model.stat.extent))
    camera.azimuth = 125 if hand != 'unitree_g1' else 135
    camera.elevation = -25
    options = mujoco.MjvOption()
    # Native models use different visual groups. Showing collision meshes along
    # with coincident visual surfaces causes flicker without adding information.
    visual_geoms = (model.geom_contype == 0) & (model.geom_conaffinity == 0)
    visual_groups = np.unique(model.geom_group[visual_geoms])
    options.geomgroup[:] = 0
    for group in visual_groups:
        options.geomgroup[int(group)] = 1
    renderer = mujoco.Renderer(model, height=480, width=640)
    writer = FrameWriter(OUT / name, f'{LABELS[hand]} | native hand position control', status)
    matrix = trace['transmission_matrix']
    final_target = trace['actuator_target']
    first_frame = None
    try:
        for idx in sample_indices:
            data.qpos[:] = trace['qpos'][idx]
            data.qvel[:] = trace['qvel'][idx]
            data.time = float(trace['times'][idx])
            env.set_ctrl(trace['command'][idx], ctrl_type='joint_angle')
            mujoco.mj_forward(model, data)
            renderer.update_scene(data, camera=camera, scene_option=options)
            frame = renderer.render().copy()
            assert frame.std() > 2, f'Blank native render for {name}'
            if first_frame is None:
                first_frame = frame.copy()
            actual = matrix @ trace['qpos'][idx]
            command = matrix @ trace['command'][idx]
            command_error = float(np.sqrt(np.mean((actual - command) ** 2)))
            target_error = float(np.sqrt(np.mean((actual - final_target) ** 2)))
            lines = [f'Simulation t={data.time:.3f} s | playback {rate:g}x | timestep {model.opt.timestep * 1000:g} ms',
                     f'Actual vs command RMS {command_error:.4f} rad | final target {target_error:.4f} rad',
                     annotation or f'{model.nq} joints / {model.nu} actuators | saved native trajectory replay']
            writer.write(frame, lines)
        result = writer.close()
    finally:
        renderer.close()
    poster = OUT / f'{name}.png'
    Image.fromarray(first_frame).save(poster)
    result.update(hand=hand, scenario=name, simulation_start_s=float(trace['times'][0]),
                  simulation_end_s=float(trace['times'][-1]), simulation_duration_s=duration,
                  nominal_simulation_playback_factor=rate, physical_timestep_s=float(model.opt.timestep),
                  visible_native_visual_geom_groups=visual_groups.tolist(),
                  truncated_before_corruption=bool(status != 'pass'), reported_first_warning_time_s=warning_time,
                  displayed_annotation=annotation, poster=str(poster),
                  replay_source='saved validation trace' if 'retry' not in name else 'deterministic reconstruction of original diagnostic controls')
    print(json.dumps(result), flush=True)
    return result


def main():
    os.chdir(REPOSITORY)
    OUT.mkdir(parents=True, exist_ok=True)
    clips = []
    for hand in ('allegro', 'leap', 'unitree_g1'):
        env = environment(hand)
        clips.append(render_clip(hand, f'{hand}_control', env, saved_trace(hand), 'pass'))

    env = environment('shadow')
    trace = saved_trace('shadow')
    stop = last_safe_index(trace, env._model.jnt_range)
    clips.append(render_clip('shadow', 'shadow_control_failed', env, trace, 'failed', .1, stop,
                             annotation='FAILED: unstable QACC at 0.344 s; corrupted/reset states omitted', warning_time=.344))

    diagnostics = json.loads((RESULTS / 'shadow_diagnostics.json').read_text())
    for index, dt in enumerate((.002, .0005)):
        env, trace, first_omitted = replay_shadow_retry(dt)
        warning_text = diagnostics[index]['warning_messages'][0]
        warning_time = .170 if dt == .002 else .7295
        name = f'shadow_retry_{dt * 1000:g}ms_failed'.replace('.', 'p')
        np.savez_compressed(OUT / f'{name}_replay_trace.npz', **trace)
        # The 0.5 ms retry first exceeds the hard-limit cutoff at 0.012 s;
        # explicitly slow that brief safe prefix further so it remains legible.
        playback_rate = .01 if dt == .0005 else .1
        clip = render_clip('shadow', name, env, trace, 'failed', playback_rate,
                           annotation=f'FAILED: original QACC warning at {warning_time:.4f} s; unsafe states omitted', warning_time=warning_time)
        clip.update(first_omitted_state=first_omitted, original_warning=warning_text)
        clips.append(clip)

    mano = json.loads((RESULTS / 'mano.json').read_text())
    manifest = {'clips': clips, 'unrenderable': [{'hand': 'mano', 'status': 'unrenderable',
                 'native_error': mano['error'], 'reason': 'Native XML fails before MuJoCo model construction; no substitute animation created.'}],
                'rendering': 'MuJoCo EGL; native meshes and qpos states; brighter headlight affects illumination only; overlay reports actuator-space RMS tracking.',
                'failed_clip_policy': 'Only states before first warning, reset, nonfinite value, or hard-limit breach >0.01 rad are shown; failures remain labelled FAILED.',
                'mp4_gif_validation': 'Shared FrameWriter validates H264, decoded MP4 frame count/duration, and GIF displayed duration.'}
    (OUT / 'manifest.json').write_text(json.dumps(manifest, indent=2) + '\n')


if __name__ == '__main__':
    main()
