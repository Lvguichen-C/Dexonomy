"""Encode labelled native MuJoCo frames; no generated/imagined scene content."""
from pathlib import Path
import json
import subprocess

import numpy as np
from PIL import Image, ImageDraw, ImageFont

FPS = 25
WIDTH, HEIGHT = 640, 608


def font(size, bold=False):
    name = 'DejaVuSans-Bold.ttf' if bold else 'DejaVuSans.ttf'
    return ImageFont.truetype('/usr/share/fonts/truetype/dejavu/' + name, size)


class FrameWriter:
    def __init__(self, out_stem, title, status):
        self.stem = Path(out_stem)
        self.stem.parent.mkdir(parents=True, exist_ok=True)
        self.title, self.status = title, status
        self.frames = []
        self.color = (65, 211, 141) if status.lower() in ('pass', 'passed') else (255, 176, 79)
        self.title_font, self.small_font = font(18, True), font(14)
        self.proc = subprocess.Popen([
            'ffmpeg', '-hide_banner', '-loglevel', 'error', '-y',
            '-f', 'rawvideo', '-vcodec', 'rawvideo', '-pix_fmt', 'rgb24',
            '-s', f'{WIDTH}x{HEIGHT}', '-r', str(FPS), '-i', '-', '-an',
            '-c:v', 'libx264', '-threads', '2', '-preset', 'fast', '-crf', '20',
            '-pix_fmt', 'yuv420p', '-movflags', '+faststart', str(self.stem.with_suffix('.mp4')),
        ], stdin=subprocess.PIPE)

    def write(self, frame, lines):
        frame = np.asarray(frame, dtype=np.uint8)
        assert frame.shape == (480, 640, 3), frame.shape
        canvas = Image.new('RGB', (WIDTH, HEIGHT), '#111a27')
        canvas.paste(Image.fromarray(frame), (0, 64))
        draw = ImageDraw.Draw(canvas)
        draw.text((16, 10), self.title, font=self.title_font, fill='white')
        draw.text((16, 36), self.status.upper(), font=self.small_font, fill=self.color)
        for i, line in enumerate(lines[:3]):
            draw.text((16, 550 + i * 18), str(line), font=self.small_font, fill='#d8e5f3')
        self.proc.stdin.write(np.asarray(canvas).tobytes())
        self.frames.append(canvas)

    def close(self):
        self.proc.stdin.close()
        code = self.proc.wait(timeout=30)
        if code:
            raise RuntimeError(f'ffmpeg exited {code}: {self.stem}')
        assert self.frames, 'Empty animation'
        self.frames[0].save(self.stem.with_suffix('.gif'), save_all=True,
            append_images=self.frames[1:], duration=40, loop=0, disposal=2)
        probe = json.loads(subprocess.check_output([
            'ffprobe', '-v', 'error', '-count_frames', '-select_streams', 'v:0',
            '-show_entries', 'stream=codec_name,width,height,nb_read_frames,avg_frame_rate,duration',
            '-of', 'json', str(self.stem.with_suffix('.mp4')),
        ]))['streams'][0]
        assert probe['codec_name'] == 'h264'
        assert (int(probe['width']), int(probe['height'])) == (WIDTH, HEIGHT)
        assert int(probe['nb_read_frames']) == len(self.frames)
        assert abs(float(probe['duration']) - len(self.frames) / FPS) < 0.002
        # GIF encoders can merge identical frames; check total displayed time.
        with Image.open(self.stem.with_suffix('.gif')) as gif:
            total_ms = 0
            for i in range(gif.n_frames):
                gif.seek(i)
                total_ms += gif.info.get('duration', 0)
            assert total_ms == 40 * len(self.frames), total_ms
        result = {'title': self.title, 'status': self.status,
            'mp4': str(self.stem.with_suffix('.mp4')), 'gif': str(self.stem.with_suffix('.gif')),
            'frame_count': len(self.frames), 'fps': FPS,
            'video_duration_s': len(self.frames) / FPS, 'codec': probe['codec_name'],
            'width': WIDTH, 'height': HEIGHT, 'gif_duration_ms': total_ms}
        self.frames.clear()
        return result
