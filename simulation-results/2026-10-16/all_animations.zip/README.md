# 全部 MuJoCo 仿真结果动画

共 16 段真实仿真动画，另有 1 段 MANO 加载失败说明卡。包含成功、失败和失握负对照；没有为无法运行的模型编造运动。

[观看全部结果合集](all_results.mp4) · [离线画廊](index.html) · [全部文件下载](all_animations.zip)

| 项目 | 结果 | MP4 | GIF | 播放时长 |
|---|---|---|---|---:|
| 01. Allegro 关节控制 | pass | [MP4](hands/allegro_control.mp4) | [GIF](hands/allegro_control.gif) | 2.52 s |
| 02. Leap 关节控制 | pass | [MP4](hands/leap_control.mp4) | [GIF](hands/leap_control.gif) | 2.52 s |
| 03. Unitree G1 关节控制 | pass | [MP4](hands/unitree_g1_control.mp4) | [GIF](hands/unitree_g1_control.gif) | 2.52 s |
| 04. 球体自由落体、碰撞与支撑 | PASS | [MP4](physics/sphere_drop.mp4) | [GIF](physics/sphere_drop.gif) | 3.00 s |
| 05. Allegro 接触建立（方法演示） | METHOD: settling, not end-to-end synthesis | [MP4](physics/contact_establishment.mp4) | [GIF](physics/contact_establishment.gif) | 0.80 s |
| 06. Allegro 持握：+X 载荷 | PASS: post-contact retention | [MP4](physics/retention_plus_X.mp4) | [GIF](physics/retention_plus_X.gif) | 2.00 s |
| 07. Allegro 持握：−X 载荷 | PASS: post-contact retention | [MP4](physics/retention_minus_X.mp4) | [GIF](physics/retention_minus_X.gif) | 2.00 s |
| 08. Allegro 持握：+Y 载荷 | PASS: post-contact retention | [MP4](physics/retention_plus_Y.mp4) | [GIF](physics/retention_plus_Y.gif) | 2.00 s |
| 09. Allegro 持握：−Y 载荷 | PASS: post-contact retention | [MP4](physics/retention_minus_Y.mp4) | [GIF](physics/retention_minus_Y.gif) | 2.00 s |
| 10. Allegro 持握：+Z 载荷 | PASS: post-contact retention | [MP4](physics/retention_plus_Z.mp4) | [GIF](physics/retention_plus_Z.gif) | 2.00 s |
| 11. Allegro 持握：−Z 载荷 | PASS: post-contact retention | [MP4](physics/retention_minus_Z.mp4) | [GIF](physics/retention_minus_Z.gif) | 2.00 s |
| 12. 释放夹紧：失握负对照 | EXPECTED LOSS: negative control | [MP4](physics/released_grasp.mp4) | [GIF](physics/released_grasp.gif) | 2.00 s |
| 13. 原始候选轨迹：力闭合评估失败 | FAIL: eval_fc returns False | [MP4](physics/original_candidate_failure.mp4) | [GIF](physics/original_candidate_failure.gif) | 1.80 s |
| 14. Shadow 主场景：数值不稳定 | failed | [MP4](hands/shadow_control_failed.mp4) | [GIF](hands/shadow_control_failed.gif) | 3.32 s |
| 15. Shadow 温和重试：2 ms 步长 | failed | [MP4](hands/shadow_retry_2ms_failed.mp4) | [GIF](hands/shadow_retry_2ms_failed.gif) | 1.24 s |
| 16. Shadow 温和重试：0.5 ms 步长 | failed | [MP4](hands/shadow_retry_0p5ms_failed.mp4) | [GIF](hands/shadow_retry_0p5ms_failed.gif) | 1.16 s |
| 17. MANO：原生模型加载失败说明 | UNRUNNABLE: explanation card only | [MP4](mano_unavailable.mp4) | [GIF](mano_unavailable.gif) | 3.00 s |

持握六方向动画均为接触建立后的结果，使用仓库的重量等效外力评估。接触建立片段为方法演示。原始候选轨迹仍在原生力闭合评估中失败。

Shadow 的主场景及两个重试均保留失败结论，只展示发生数值问题前的有限有效状态；停止点、失败时刻和慢放倍率标在画面与 manifest.json 中。MANO 没有实际仿真帧。

失握动画同时显示固定机械手视角和物体跟随小窗，避免物体移出画面后丢失结果。所有视频使用 H.264/yuv420p；逐段完整解码、帧数、时长及 GIF 总时长已经核对。

复现：先 source /workspace/dexonomy-onboarding/activate.sh，再运行 render_physics.py、render_hands.py 和 package_results.py。源脚本在本目录中；详见 ../REPORT.md。
