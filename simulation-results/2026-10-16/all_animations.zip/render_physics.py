"""Replay all native MuJoCo physics scenarios and export their real frames."""
from pathlib import Path
import copy
import json
import os
import sys

os.environ.setdefault('MUJOCO_GL', 'egl')
os.environ.setdefault('LP_NUM_THREADS', '2')

import mujoco
import numpy as np
from PIL import Image, ImageDraw

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent
sys.path.insert(0, str(ROOT))
from validate_physics import (make_env, q_annotation, sphere_scene, healthy,
    contact_stats, np_get_delta_pose, get_planner)
from render_utils import FrameWriter, font

OUT = HERE / 'physics'
OUT.mkdir(parents=True, exist_ok=True)
ARCHIVE = json.loads((ROOT / 'physics_results.json').read_text())
MANIFEST = []


class View:
    def __init__(self, env, lookat=(0, 0, 0.075), distance=0.36):
        self.env = env
        env._model.vis.headlight.ambient[:] = [0.6, 0.6, 0.6]
        env._model.vis.headlight.diffuse[:] = [0.8, 0.8, 0.8]
        self.renderer = mujoco.Renderer(env._model, height=480, width=640)
        self.camera = mujoco.MjvCamera()
        mujoco.mjv_defaultCamera(self.camera)
        self.camera.lookat[:] = lookat
        self.camera.distance = distance
        self.camera.azimuth = 135
        self.camera.elevation = -25
        self.options = mujoco.MjvOption()
        self.options.flags[mujoco.mjtVisFlag.mjVIS_CONTACTPOINT] = True
        self.options.flags[mujoco.mjtVisFlag.mjVIS_CONTACTFORCE] = True

    def frame(self, track_object_inset=False):
        self.renderer.update_scene(self.env._data, camera=self.camera, scene_option=self.options)
        frame = self.renderer.render().copy()
        assert frame.std() > 2
        if track_object_inset:
            tracking = mujoco.MjvCamera()
            mujoco.mjv_defaultCamera(tracking)
            tracking.lookat[:] = self.env.get_active_obj_pose()[:3]
            tracking.distance, tracking.azimuth, tracking.elevation = 0.22, 135, -25
            self.renderer.update_scene(self.env._data, camera=tracking, scene_option=self.options)
            inset = Image.fromarray(self.renderer.render().copy()).resize((240, 180))
            canvas = Image.fromarray(frame)
            canvas.paste(inset, (392, 292))
            draw = ImageDraw.Draw(canvas)
            draw.rectangle((390, 270, 634, 474), outline='#8fd0ff', width=2)
            draw.rectangle((392, 272, 632, 292), fill='#111a27')
            draw.text((398, 273), 'Object-follow camera', font=font(12), fill='white')
            frame = np.asarray(canvas)
        return frame

    def close(self):
        self.renderer.close()


def register(writer, **metadata):
    entry = writer.close()
    entry.update(metadata)
    MANIFEST.append(entry)
    print(entry['title'], entry['frame_count'], 'frames', flush=True)


def drop():
    scene = sphere_scene('drop_ball', [0.3, 0, 0], 0.025,
                         0.1 / (4 * np.pi * 0.025 ** 3 / 3), ground=True)
    env = make_env(scene, timestep=0.002)
    env._model.opt.disableflags &= ~int(mujoco.mjtDisableBit.mjDSBL_GRAVITY)
    env.reset_qpos(q_annotation()[7:], set_ctrl=False)
    env.set_ctrl(q_annotation()[7:], ctrl_type='joint_angle')
    view = View(env, lookat=(0.3, 0, -0.1), distance=0.55)
    writer = FrameWriter(OUT / 'sphere_drop', 'Sphere: free fall, impact, static support', 'PASS')
    for i in range(1500):
        env.step_sim(1)
        healthy(env)
        if (i + 1) % 20 == 0:
            contact = contact_stats(env)
            writer.write(view.frame(), [f't = {env._data.time:.2f} s | g = -9.81 m/s^2 | mass = 0.100 kg',
                f'Height = {env.get_active_obj_pose()[2]:.4f} m | support = {contact["normal_force_N"]:.3f} N',
                'Real-time playback. Expected static support: 0.981 N.'])
    view.close()
    assert abs(env.get_active_obj_pose()[2] - ARCHIVE['sphere_drop']['final_height_m']) < 1e-7
    register(writer, scenario='sphere_drop', simulation_duration_s=3.0, playback_speed=1.0)


def grasp_cases():
    scene = sphere_scene('grasp_ball', [0.020, 0.0051, 0.0973], 0.0383, 300)
    q = q_annotation()
    squeeze = q.copy()
    squeeze[7:] += 0.05
    acquisition = make_env(scene, free_hand=True)
    acquisition.reset_qpos(q)
    acquisition.set_ctrl(squeeze)
    view = View(acquisition)
    writer = FrameWriter(OUT / 'contact_establishment', 'Allegro: physical contact establishment', 'METHOD: settling, not end-to-end synthesis')
    for i in range(100):
        acquisition.step_sim(1)
        healthy(acquisition)
        if (i + 1) % 5 == 0:
            c = contact_stats(acquisition)
            frame = view.frame()
            lines = [f'Simulation t = {acquisition._data.time:.3f} s | playback 0.5x',
                f'Squeeze target offset = 0.05 rad | contacts = {c["count"]}',
                f'Max penetration = {c["max_penetration_m"]*1000:.3f} mm']
            writer.write(frame, lines)
    view.close()
    register(writer, scenario='contact_establishment', simulation_duration_s=0.4, playback_speed=0.5)
    actual = acquisition.get_hand_qpos().copy()
    settled = acquisition.get_active_obj_pose().copy()
    settled_scene = copy.deepcopy(scene)
    settled_scene['scene']['ball']['pose'] = settled.tolist()
    plan = get_planner(scene['task']).plan_trajectory(settled, actual, actual, squeeze, None)
    for label, direction in [('+X', [1, 0, 0]), ('-X', [-1, 0, 0]), ('+Y', [0, 1, 0]),
                             ('-Y', [0, -1, 0]), ('+Z', [0, 0, 1]), ('-Z', [0, 0, -1])]:
        env = make_env(settled_scene, free_hand=True)
        env.reset_qpos(plan[0][0])
        env.run_trajectory(*plan[:3])
        env.set_active_obj_ext_fdir(np.asarray(direction, dtype=float))
        view = View(env)
        writer = FrameWriter(OUT / ('retention_' + label.replace('+', 'plus_').replace('-', 'minus_')),
            f'Allegro: established grasp, {label} load', 'PASS: post-contact retention')
        max_trans, max_rot = 0., 0.
        for i in range(500):
            env.step_sim(1)
            healthy(env)
            trans, rot = map(float, np_get_delta_pose(settled, env.get_active_obj_pose()))
            max_trans, max_rot = max(max_trans, trans), max(max_rot, rot)
            if (i + 1) % 10 == 0:
                c = contact_stats(env)
                writer.write(view.frame(), [f'Load t = {(i+1)*0.004:.2f} s | world {label}: 0.6919 N | playback 1x',
                    f'Displacement = {trans*1000:.3f} mm | rotation = {rot:.3f} deg | contacts = {c["count"]}',
                    'Gravity disabled; one weight-equivalent load. Limits: 50 mm / 15 deg.'])
        view.close()
        expected = ARCHIVE['grasp_retention']['six_axis_results'][label]
        assert abs(max_trans - expected['max_translation_m']) < 1e-6, (label, max_trans, expected)
        assert abs(max_rot - expected['max_rotation_deg']) < 0.002
        register(writer, scenario='retention', axis=label, simulation_duration_s=2., playback_speed=1.,
                 max_translation_m=max_trans, max_rotation_deg=max_rot)

    negative = make_env(settled_scene, free_hand=True)
    negative.reset_qpos(plan[0][0])
    negative.run_trajectory(*plan[:3])
    reference = negative.get_active_obj_pose().copy()
    negative.set_ctrl(q)
    negative.set_active_obj_ext_fdir(np.asarray([0., 0., -1.]))
    view = View(negative)
    writer = FrameWriter(OUT / 'released_grasp', 'Allegro: release squeeze under -Z load', 'EXPECTED LOSS: negative control')
    for i in range(500):
        negative.step_sim(1)
        healthy(negative)
        if (i + 1) % 10 == 0:
            trans, rot = map(float, np_get_delta_pose(reference, negative.get_active_obj_pose()))
            c = contact_stats(negative)
            writer.write(view.frame(track_object_inset=True), [f'Load t = {(i+1)*0.004:.2f} s | -Z force = 0.6919 N | playback 1x',
                f'Displacement = {trans:.3f} m | contacts = {c["count"]}',
                'Fixed hand view + object-follow inset. Loss is intentionally detected.'])
    view.close()
    assert abs(trans - ARCHIVE['grasp_retention']['negative_control']['translation_after_2s_m']) < 1e-6
    register(writer, scenario='negative_control', simulation_duration_s=2., playback_speed=1., translation_m=trans)

    # Instrument the actual evaluator; native stepping and decisions are unchanged.
    candidate = make_env(scene, free_hand=True)
    initial_pose = np.asarray(scene['scene']['ball']['pose'])
    candidate_plan = get_planner(scene['task']).plan_trajectory(initial_pose, q, q, squeeze, None)
    view = View(candidate)
    writer = FrameWriter(OUT / 'original_candidate_failure', 'Allegro: original candidate + native evaluator', 'FAIL: eval_fc returns False')
    original_step, original_force = candidate.step_sim, candidate.set_active_obj_ext_fdir
    state = {'step': 0, 'phase': 'original planned trajectory', 'load': None}
    def instrument_force(direction):
        state['phase'] = 'force-closure evaluation'
        state['load'] = list(map(float, direction))
        return original_force(direction)
    def instrument_step(substep):
        for _ in range(substep):
            original_step(1)
            healthy(candidate)
            state['step'] += 1
            if state['step'] % 5 == 0:
                trans, rot = map(float, np_get_delta_pose(initial_pose, candidate.get_active_obj_pose()))
                c = contact_stats(candidate)
                writer.write(view.frame(track_object_inset=True), [f'Sim t = {state["step"]*0.004:.3f} s | playback 0.5x | {state["phase"]}',
                    f'Displacement = {trans*1000:.2f} mm | rotation = {rot:.2f} deg | contacts = {c["count"]}',
                    'Original annotation candidate on analytic sphere; full synthesis was not run.'])
    candidate.step_sim = instrument_step
    candidate.set_active_obj_ext_fdir = instrument_force
    success, _, _ = candidate.eval_fc(*candidate_plan, 0.05, 15.)
    assert success is False or success == False
    assert bool(success) == ARCHIVE['grasp_retention']['original_annotation_planner']['eval_fc_passed']
    final_trans, final_rot = map(float, np_get_delta_pose(initial_pose, candidate.get_active_obj_pose()))
    last_frame = view.frame(track_object_inset=True)
    for _ in range(25):
        writer.write(last_frame, ['END STATE HELD for 1 s | native evaluator result: FAIL',
            f'Displacement = {final_trans*1000:.2f} mm | rotation = {final_rot:.2f} deg',
            f'Failure checked during {state["phase"]}. No invented successful motion.'])
    view.close()
    register(writer, scenario='original_candidate', simulation_duration_s=state['step']*0.004,
        playback_speed=0.5, end_hold_s=1., eval_fc_passed=False,
        final_translation_m=final_trans, final_rotation_deg=final_rot, failure_phase=state['phase'])


if __name__ == '__main__':
    drop()
    grasp_cases()
    (OUT / 'manifest.json').write_text(json.dumps(MANIFEST, indent=2))
    print(f'Exported {len(MANIFEST)} physics animations', flush=True)
