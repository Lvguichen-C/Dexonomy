"""Package and validate the complete native-MuJoCo animation collection."""
from pathlib import Path
import html
import json
import subprocess
import zipfile

import numpy as np
from PIL import Image, ImageDraw

from render_utils import FrameWriter, WIDTH, HEIGHT, font

HERE = Path(__file__).resolve().parent
DISPLAY_NAMES = {
    'allegro_control': 'Allegro 关节控制',
    'leap_control': 'Leap 关节控制',
    'unitree_g1_control': 'Unitree G1 关节控制',
    'sphere_drop': '球体自由落体、碰撞与支撑',
    'contact_establishment': 'Allegro 接触建立（方法演示）',
    'retention_plus_X': 'Allegro 持握：+X 载荷',
    'retention_minus_X': 'Allegro 持握：−X 载荷',
    'retention_plus_Y': 'Allegro 持握：+Y 载荷',
    'retention_minus_Y': 'Allegro 持握：−Y 载荷',
    'retention_plus_Z': 'Allegro 持握：+Z 载荷',
    'retention_minus_Z': 'Allegro 持握：−Z 载荷',
    'released_grasp': '释放夹紧：失握负对照',
    'original_candidate_failure': '原始候选轨迹：力闭合评估失败',
    'shadow_control_failed': 'Shadow 主场景：数值不稳定',
    'shadow_retry_2ms_failed': 'Shadow 温和重试：2 ms 步长',
    'shadow_retry_0p5ms_failed': 'Shadow 温和重试：0.5 ms 步长',
    'mano_unavailable': 'MANO：原生模型加载失败说明',
}


def ffprobe(path):
    return json.loads(subprocess.check_output(['ffprobe', '-v', 'error', '-count_frames',
        '-select_streams', 'v:0', '-show_entries',
        'stream=codec_name,pix_fmt,width,height,nb_read_frames,avg_frame_rate,duration',
        '-of', 'json', str(path)]))['streams'][0]


def card():
    canvas = Image.new('RGB', (640, 480), '#182332')
    draw = ImageDraw.Draw(canvas)
    text = [
        ('MANO native model did not load', 22),
        ('No real simulation animation can be generated.', 16),
        ('MuJoCo 3.3.3 reports:', 16),
        ('XML Error: Schema violation:', 16),
        ("unrecognized attribute 'noslip_stepations'", 16),
        ("Element 'option', line 5", 16),
        ('assets/hand/mano/right.xml', 16),
        ('Original model preserved; no replacement motion shown.', 15),
    ]
    y = 70
    for line, size in text:
        draw.text((28, y), line, font=font(size), fill='white')
        y += 42
    writer = FrameWriter(HERE / 'mano_unavailable', 'MANO: native XML loading failure', 'UNRUNNABLE: explanation card only')
    for _ in range(75):
        writer.write(np.asarray(canvas), ['Explanation held for 3 s; this is not a rendered MANO simulation.',
            'The unmodified repository model fails before integration.'])
    result = writer.close()
    result.update(scenario='mano_unavailable', simulation_duration_s=0, real_simulation=False)
    return result


def relative(path):
    return str(Path(path).relative_to(HERE))


def main():
    physics = json.loads((HERE / 'physics/manifest.json').read_text())
    hand_data = json.loads((HERE / 'hands/manifest.json').read_text())
    hands = hand_data if isinstance(hand_data, list) else hand_data['clips']
    assert len(physics) == 10 and len(hands) == 6, (len(physics), len(hands))
    passes = [h for h in hands if h['status'].lower() in ('pass', 'passed')]
    failures = [h for h in hands if h not in passes]
    mano = card()
    clips = passes + physics + failures + [mano]
    qa = []
    montage = Image.new('RGB', (4 * 320, 5 * 324), '#111a27')
    draw = ImageDraw.Draw(montage)
    for index, clip in enumerate(clips):
        path = Path(clip['mp4'])
        probe = ffprobe(path)
        assert probe['codec_name'] == 'h264' and probe['pix_fmt'] == 'yuv420p'
        assert (int(probe['width']), int(probe['height'])) == (WIDTH, HEIGHT)
        assert int(probe['nb_read_frames']) == clip['frame_count']
        assert abs(float(probe['duration']) - clip['video_duration_s']) < 0.002
        # Decode every frame; codec errors must fail this packaging run.
        subprocess.run(['ffmpeg', '-v', 'error', '-xerror', '-i', str(path),
            '-f', 'null', '-'], check=True, stdout=subprocess.DEVNULL)
        positions = sorted(set([0, clip['frame_count'] // 2, clip['frame_count'] - 1]))
        expression = '+'.join(f'eq(n\\,{p})' for p in positions)
        raw = subprocess.check_output(['ffmpeg', '-v', 'error', '-i', str(path),
            '-vf', 'select=' + expression, '-fps_mode', 'vfr',
            '-pix_fmt', 'rgb24', '-f', 'rawvideo', '-'])
        frames = np.frombuffer(raw, dtype=np.uint8).reshape(-1, HEIGHT, WIDTH, 3)
        assert len(frames) == len(positions)
        assert all(float(f.std()) > 2 for f in frames)
        thumbnail = Image.fromarray(frames[len(frames)//2]).resize((320, 304))
        x, y = (index % 4) * 320, (index // 4) * 324
        montage.paste(thumbnail, (x, y))
        draw.text((x+5, y+306), f'{index+1:02d}. {path.stem[:34]}', font=font(12), fill='white')
        clip['index'] = index + 1
        clip['display_name_zh'] = DISPLAY_NAMES[path.stem]
        clip['mp4_relative'], clip['gif_relative'] = relative(clip['mp4']), relative(clip['gif'])
        qa.append({'mp4': clip['mp4_relative'], 'full_decode': 'passed',
            'sampled_frames': positions, 'probe': probe})
    montage.save(HERE / 'all_results_contact_sheet.jpg', quality=90)

    concat_list = HERE / 'concat.txt'
    concat_list.write_text(''.join("file '" + c['mp4'].replace("'", "'\\''") + "'\n" for c in clips))
    subprocess.run(['ffmpeg', '-v', 'error', '-y', '-f', 'concat', '-safe', '0',
        '-i', str(concat_list), '-c', 'copy', '-movflags', '+faststart',
        str(HERE / 'all_results.mp4')], check=True)
    combined = ffprobe(HERE / 'all_results.mp4')
    assert int(combined['nb_read_frames']) == sum(c['frame_count'] for c in clips)
    subprocess.run(['ffmpeg', '-v', 'error', '-xerror', '-i', str(HERE / 'all_results.mp4'),
        '-f', 'null', '-'], check=True, stdout=subprocess.DEVNULL)
    manifest = {'real_simulation_clips': 16, 'unrunnable_explanation_cards': 1,
        'frame_width': WIDTH, 'frame_height': HEIGHT, 'fps': 25,
        'combined': {'file': 'all_results.mp4', **combined}, 'clips': clips,
        'notes': [
            'All scene frames are actual MuJoCo renders; captions identify results and playback speed.',
            'Hand-control clips replay saved native simulation states; Shadow stops before corrupted states.',
            'Successful retention begins after physical contact establishment, not end-to-end synthesis.',
            'Gravity is disabled for force-closure checks, with one weight-equivalent force at a time.',
            'MANO has an error explanation card and no simulated motion.',
        ]}
    (HERE / 'manifest.json').write_text(json.dumps(manifest, indent=2))
    (HERE / 'quality_checks.json').write_text(json.dumps(qa, indent=2))

    cards = []
    lines = ['# 全部 MuJoCo 仿真结果动画', '',
        '共 16 段真实仿真动画，另有 1 段 MANO 加载失败说明卡。包含成功、失败和失握负对照；没有为无法运行的模型编造运动。', '',
        '[观看全部结果合集](all_results.mp4) · [离线画廊](index.html) · [全部文件下载](all_animations.zip)', '',
        '| 项目 | 结果 | MP4 | GIF | 播放时长 |', '|---|---|---|---|---:|']
    for c in clips:
        title, status = html.escape(c['display_name_zh']), html.escape(c['status'])
        cards.append(f'<article><h2>{c["index"]:02d}. {title}</h2><p class="status">{status}</p>'
            f'<video controls preload="metadata" src="{c["mp4_relative"]}"></video>'
            f'<p><a href="{c["mp4_relative"]}" download>MP4</a> · '
            f'<a href="{c["gif_relative"]}" download>GIF</a> · {c["video_duration_s"]:.2f} s</p></article>')
        lines.append(f'| {c["index"]:02d}. {c["display_name_zh"]} | {c["status"]} | '
            f'[MP4]({c["mp4_relative"]}) | [GIF]({c["gif_relative"]}) | {c["video_duration_s"]:.2f} s |')
    lines += ['',
        '持握六方向动画均为接触建立后的结果，使用仓库的重量等效外力评估。接触建立片段为方法演示。原始候选轨迹仍在原生力闭合评估中失败。', '',
        'Shadow 的主场景及两个重试均保留失败结论，只展示发生数值问题前的有限有效状态；停止点、失败时刻和慢放倍率标在画面与 manifest.json 中。MANO 没有实际仿真帧。', '',
        '失握动画同时显示固定机械手视角和物体跟随小窗，避免物体移出画面后丢失结果。所有视频使用 H.264/yuv420p；逐段完整解码、帧数、时长及 GIF 总时长已经核对。', '',
        '复现：先 source /workspace/dexonomy-onboarding/activate.sh，再运行 render_physics.py、render_hands.py 和 package_results.py。源脚本在本目录中；详见 ../REPORT.md。']
    (HERE / 'README.md').write_text('\n'.join(lines) + '\n')
    document = '''<!doctype html><html lang="zh-CN"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>MuJoCo 全部结果动画</title><style>body{margin:0;background:#0b1220;color:#e5edf8;font:16px system-ui;line-height:1.6}main{max-width:1360px;margin:auto;padding:32px}h1{font-size:30px}a{color:#80c8ff}video{width:100%;background:#000;border-radius:6px}section{display:grid;grid-template-columns:repeat(auto-fit,minmax(320px,1fr));gap:20px}article{padding:18px;background:#162132;border-radius:12px}h2{font-size:18px;min-height:48px}.status{color:#ffd184}header{margin-bottom:28px}.overview{max-width:720px}small{color:#a8b7cd}</style><main><header><h1>全部 MuJoCo 仿真结果动画</h1><p>16 段真实仿真动画 + 1 段 MANO 加载失败说明卡。成功、失败与负对照均保留。</p><p><a href="all_animations.zip" download>下载全部动画 ZIP</a> · <a href="README.md">分项索引</a> · <a href="manifest.json">参数与时长</a></p><p><small>六方向持握从真实接触稳定后开始，采用重量等效外力；原始候选的完整力闭合评估仍失败。Shadow 在数值问题前停止显示，慢放与停止时间均在画面标注。MANO 无可运行的原生仿真。</small></p><video class="overview" controls preload="metadata" src="all_results.mp4"></video></header><section>'''
    (HERE / 'index.html').write_text(document + ''.join(cards) + '</section></main></html>')
    files = list(HERE.glob('*.py')) + [HERE / n for n in ['README.md', 'index.html', 'manifest.json',
        'quality_checks.json', 'all_results.mp4', 'all_results_contact_sheet.jpg', 'mano_unavailable.mp4', 'mano_unavailable.gif']]
    files += [Path(c[key]) for c in clips if c is not mano for key in ('mp4', 'gif')]
    files += [HERE / 'physics/manifest.json', HERE / 'hands/manifest.json']
    with zipfile.ZipFile(HERE / 'all_animations.zip', 'w', compression=zipfile.ZIP_DEFLATED) as z:
        for path in sorted(set(files)):
            z.write(path, arcname=relative(path))
        assert z.testzip() is None
    print(json.dumps({'native_animations': 16, 'explanation_cards': 1,
        'combined_duration_s': combined['duration'], 'combined_frames': combined['nb_read_frames'],
        'zip_bytes': (HERE/'all_animations.zip').stat().st_size}, indent=2))


if __name__ == '__main__':
    main()
