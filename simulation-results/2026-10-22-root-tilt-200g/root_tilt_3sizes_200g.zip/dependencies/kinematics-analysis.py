#!/usr/bin/env python3
"""Read-only vertical-motion decomposition for the published 5/90/100 mm cases.

The actual hand-root freejoint address is discovered from each compiled model.
No evaluation file is modified and no simulation step is executed.
"""
from __future__ import annotations

from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path

import mujoco
import numpy as np


ROOT = Path("/workspace/shadow-lift-sweep-200g")
OLD = Path("/workspace/shadow-lift-sweep")
OUT = ROOT / "height-diagnosis-20261022"
STAGES = [
    ("initial", "initial_object_pose", "approach"),
    ("closure_end", "closure_object_pose", "loaded_hold"),
    ("loaded_hold_end_lift_start", "loaded_object_pose", "lift"),
    ("lift_end", "lift_end_object_pose", "postlift_hold"),
    ("postlift_hold_end", "held_object_pose", "release_open"),
]
STAGE_LABELS = {
    "initial": "初始", "closure_end": "闭合/挤压结束", "loaded_hold_end_lift_start": "受力保持末/抬升开始",
    "lift_end": "抬升末", "postlift_hold_end": "后5秒持握末",
}


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def read(path):
    return json.loads(Path(path).read_text())


def normalized_quaternion(value):
    value = np.asarray(value, dtype=np.float64)
    return value / np.linalg.norm(value)


def rotation_matrix(quaternion):
    matrix = np.empty(9, dtype=np.float64)
    mujoco.mju_quat2Mat(matrix, normalized_quaternion(quaternion))
    return matrix.reshape(3, 3)


def angle_deg(q1, q2):
    cosine = abs(normalized_quaternion(q1) @ normalized_quaternion(q2))
    return float(np.degrees(2 * np.arccos(np.clip(cosine, 0.0, 1.0))))


def locate_coordinates(model):
    hand_body = model.body("hand-world").id
    free = int(mujoco.mjtJoint.mjJNT_FREE)
    hand_joints = [j for j in range(model.njnt) if int(model.jnt_bodyid[j]) == hand_body and int(model.jnt_type[j]) == free]
    assert len(hand_joints) == 1, hand_joints
    hand_joint = hand_joints[0]
    hand_address = int(model.jnt_qposadr[hand_joint])
    welds = []
    for eq in range(model.neq):
        if int(model.eq_type[eq]) != int(mujoco.mjtEq.mjEQ_WELD):
            continue
        bodies = [int(model.eq_obj1id[eq]), int(model.eq_obj2id[eq])]
        if hand_body in bodies:
            other = bodies[1] if bodies[0] == hand_body else bodies[0]
            mocap_slot = int(model.body_mocapid[other])
            if mocap_slot >= 0:
                welds.append((eq, other, mocap_slot))
    assert len(welds) == 1, welds
    eq, mocap_body, mocap_slot = welds[0]
    assert np.allclose(model.eq_data[eq, 6:10], [1, 0, 0, 0], rtol=0, atol=1e-12)
    object_joints = [j for j in range(model.njnt) if int(model.jnt_type[j]) == free
                     and model.body(int(model.jnt_bodyid[j])).name.startswith("obj-")]
    assert len(object_joints) == 1, object_joints
    obj_joint = object_joints[0]
    obj_body = int(model.jnt_bodyid[obj_joint])
    obj_address = int(model.jnt_qposadr[obj_joint])
    return {
        "nq": int(model.nq), "nv": int(model.nv),
        "hand_body_id": hand_body, "hand_body_name": model.body(hand_body).name,
        "hand_root_joint_id": hand_joint, "hand_root_joint_name": model.joint(hand_joint).name,
        "hand_root_joint_type": "free", "hand_root_qpos_address": hand_address,
        "hand_root_z_qpos_address": hand_address + 2,
        "weld_equality_id": eq, "mocap_body_id": mocap_body,
        "mocap_body_name": model.body(mocap_body).name, "mocap_array_slot": mocap_slot,
        "weld_equality_data": model.eq_data[eq].tolist(),
        "weld_solimp": model.eq_solimp[eq].tolist(), "weld_solref": model.eq_solref[eq].tolist(),
        "weld_relative_orientation_identity_verified": True,
        "object_joint_id": obj_joint, "object_joint_name": model.joint(obj_joint).name,
        "object_body_id": obj_body, "object_body_name": model.body(obj_body).name,
        "object_qpos_address": obj_address, "object_z_qpos_address": obj_address + 2,
        "compiled_object_mass_kg": float(model.body_subtreemass[obj_body]),
    }


def analyze_one(path, model_path, mass_label):
    record = read(path)
    trace_path, input_path = Path(record["trace"]), Path(record["input"])
    model = mujoco.MjModel.from_xml_path(str(model_path))
    address = locate_coordinates(model)
    with np.load(trace_path, allow_pickle=False) as archive:
        trace = {key: np.asarray(archive[key]).copy() for key in archive.files}
    assert trace["qpos"].shape[1] == model.nq
    phases = [str(name) for name in trace["phase_names"]]
    phase_times = {row["phase"]: row["time_s"] for row in record["phase_boundaries"]}
    source_hashes = {"metrics_sha256": sha(path), "trace_sha256": sha(trace_path),
                     "model_xml_sha256": sha(model_path), "input_grasp_sha256": sha(input_path)}
    data = mujoco.MjData(model)
    rows = []
    for label, metric_key, boundary_phase in STAGES:
        time = float(phase_times[boundary_phase])
        select = ((np.abs(np.asarray(trace["time_s"], dtype=float) - time) < 1e-4)
                  & (trace["phase_id"] == phases.index(boundary_phase)))
        indices = np.flatnonzero(select)
        assert len(indices), (path, label, time)
        index = int(indices[-1])
        qpos = np.asarray(trace["qpos"][index], dtype=np.float64)
        data.qpos[:] = qpos
        data.mocap_pos[:] = trace["mocap_pos"][index]
        data.mocap_quat[:] = trace["mocap_quat"][index]
        # Kinematic consistency only: mj_forward does not advance time and is
        # not represented as another physical trial or used to alter outcomes.
        mujoco.mj_forward(model, data)
        hand_z = float(qpos[address["hand_root_z_qpos_address"]])
        object_qpos_z = float(qpos[address["object_z_qpos_address"]])
        assert abs(float(data.xpos[address["hand_body_id"], 2]) - hand_z) < 1e-12
        assert abs(float(data.xpos[address["object_body_id"], 2]) - object_qpos_z) < 1e-12
        object_metric_z = float(record[metric_key][2])
        object_trace_z = float(trace["object_pose"][index, 2])
        assert abs(object_metric_z - object_trace_z) < 1e-7, (label, object_metric_z, object_trace_z)
        mocap_z = float(trace["mocap_pos"][index, address["mocap_array_slot"], 2])
        adr = address["hand_root_qpos_address"]
        hand_quat = normalized_quaternion(qpos[adr + 3:adr + 7])
        mocap_quat = normalized_quaternion(trace["mocap_quat"][index, address["mocap_array_slot"]])
        hand_R = rotation_matrix(hand_quat)
        assert np.allclose(hand_R, data.xmat[address["hand_body_id"]].reshape(3, 3), rtol=0, atol=1e-7)
        rows.append({
            "stage": label, "stage_label": STAGE_LABELS[label], "time_s": time,
            "recorded_trace_time_s": float(trace["time_s"][index]), "trace_index": index,
            "object_z_mm": object_metric_z * 1000,
            "object_xyz_mm": (np.asarray(record[metric_key][:3]) * 1000).tolist(),
            "object_z_source": f"metrics.{metric_key}[2] (float64 observation)",
            "object_z_recorded_trace_mm": object_trace_z * 1000,
            "object_freejoint_qpos_z_mm": object_qpos_z * 1000,
            "object_qpos_minus_observed_pose_z_mm": (object_qpos_z - object_metric_z) * 1000,
            "actual_hand_root_z_mm": hand_z * 1000,
            "actual_hand_root_xyz_mm": (qpos[adr:adr + 3] * 1000).tolist(),
            "actual_hand_root_quaternion_wxyz": hand_quat.tolist(),
            "actual_hand_root_R_world_from_local": hand_R.tolist(),
            "mocap_target_quaternion_wxyz": mocap_quat.tolist(),
            "root_orientation_error_relative_to_mocap_deg": angle_deg(hand_quat, mocap_quat),
            "actual_hand_root_z_qpos_address": address["hand_root_z_qpos_address"],
            "mocap_target_z_mm": mocap_z * 1000,
            "mocap_array_slot": address["mocap_array_slot"],
            "hand_root_minus_mocap_z_mm": (hand_z - mocap_z) * 1000,
            "object_minus_hand_root_z_mm": (object_metric_z - hand_z) * 1000,
            "hand_object_contact_points": int(trace["hand_object_contacts"][index]),
            "object_table_contact_points": int(trace["object_table_contacts"][index]),
            "source_sha256": source_hashes,
        })
    initial, closure, loaded, lifted, held = rows
    early = loaded["object_z_mm"] - initial["object_z_mm"]
    root_lift = held["actual_hand_root_z_mm"] - loaded["actual_hand_root_z_mm"]
    relative = held["object_minus_hand_root_z_mm"] - loaded["object_minus_hand_root_z_mm"]
    total = held["object_z_mm"] - initial["object_z_mm"]
    command = held["mocap_target_z_mm"] - loaded["mocap_target_z_mm"]
    R0, R1 = np.asarray(loaded["actual_hand_root_R_world_from_local"]), np.asarray(held["actual_hand_root_R_world_from_local"])
    o0, o1 = np.asarray(loaded["object_xyz_mm"]), np.asarray(held["object_xyz_mm"])
    h0, h1 = np.asarray(loaded["actual_hand_root_xyz_mm"]), np.asarray(held["actual_hand_root_xyz_mm"])
    r0, r1 = R0.T @ (o0 - h0), R1.T @ (o1 - h1)
    rotation_term = R1 @ r0 - R0 @ r0
    local_term = R1 @ (r1 - r0)
    assert abs(relative - rotation_term[2] - local_term[2]) < 1e-9
    reconstructed = early + root_lift + relative
    assert abs(total - reconstructed) < 1e-9
    assert abs(total - record["measured_object_lift_mm"]) < 1e-9
    # Exact deficit decomposition against the nominal 100 mm object target.
    early_contribution, root_contribution, relative_contribution = -early, 100.0 - root_lift, -relative
    assert abs((100.0 - total) - (early_contribution + root_contribution + relative_contribution)) < 1e-9
    return {
        "mass_label": mass_label, "mass_kg": record["config"]["mass_kg"],
        "diameter_mm": int(record["scene_id"].rsplit("_", 1)[1]), "template": record["template"],
        "input": str(input_path), "metrics": str(path), "trace": str(trace_path), "model_xml": str(model_path),
        "source_sha256": source_hashes, "coordinate_mapping_verified_from_model": address,
        "coordinate_mapping_validation": "Joint/body addresses discovered from compiled model; mj_forward confirms freejoint z equals body world z. No mj_step performed.",
        "stages": rows,
        "decomposition_mm": {
            "prelift_object_change_initial_to_loaded_end": early,
            "actual_hand_root_change_loaded_end_to_hold_end": root_lift,
            "object_relative_to_hand_root_change_loaded_end_to_hold_end": relative,
            "rigid_hand_root_rotation_contribution_z": float(rotation_term[2]),
            "hand_local_relative_rearrangement_contribution_z": float(local_term[2]),
            "sum_of_four_components": float(early + root_lift + rotation_term[2] + local_term[2]),
            "sum_of_three_components": reconstructed, "actual_object_rise_initial_to_hold_end": total,
            "decomposition_residual": total - reconstructed,
            "nominal_object_target": 100.0, "recorded_mocap_target_rise": command,
            "object_shortfall_from_nominal_100mm": 100.0 - total,
            "shortfall_contributions": {
                "negative_prelift_object_change": early_contribution,
                "nominal_100mm_minus_actual_hand_root_rise": root_contribution,
                "negative_object_relative_to_root_change": relative_contribution,
                "negative_rigid_root_rotation_contribution": float(-rotation_term[2]),
                "negative_hand_local_rearrangement_contribution": float(-local_term[2]),
                "sum": early_contribution + root_contribution + relative_contribution,
            },
        },
        "root_rotation_and_relative_geometry": {
            "R0_world_from_hand_at_lift_start": R0.tolist(), "R1_world_from_hand_at_hold_end": R1.tolist(),
            "r0_object_in_hand_root_coordinates_mm": r0.tolist(), "r1_object_in_hand_root_coordinates_mm": r1.tolist(),
            "r1_minus_r0_hand_local_mm": (r1 - r0).tolist(),
            "local_relative_displacement_norm_mm": float(np.linalg.norm(r1 - r0)),
            "r0_lever_arm_norm_mm": float(np.linalg.norm(r0)),
            "rigid_root_rotation_delta_xyz_world_mm": rotation_term.tolist(),
            "local_relative_rearrangement_delta_xyz_world_mm": local_term.tolist(),
            "actual_root_rotation_change_deg": angle_deg(loaded["actual_hand_root_quaternion_wxyz"], held["actual_hand_root_quaternion_wxyz"]),
            "mocap_target_rotation_change_deg": angle_deg(loaded["mocap_target_quaternion_wxyz"], held["mocap_target_quaternion_wxyz"]),
            "root_to_mocap_error_lift_start_deg": loaded["root_orientation_error_relative_to_mocap_deg"],
            "root_to_mocap_error_hold_end_deg": held["root_orientation_error_relative_to_mocap_deg"],
            "formula": "C_z=(R1*r0-R0*r0)_z+[R1*(r1-r0)]_z; r=R^T*(object-handroot)",
        },
        "final_five_second_hold": {
            "minimum_object_rise_mm": record["minimum_hold_height_gain_m"] * 1000,
            "maximum_object_rise_mm": record["maximum_hold_height_gain_m"] * 1000,
            "net_object_z_change_from_lift_end_mm": held["object_z_mm"] - lifted["object_z_mm"],
            "maximum_object_translation_drift_mm": record["postlift_hold_maximum_drift_m"] * 1000,
            "maximum_object_orientation_drift_deg": record["postlift_hold_maximum_rotation_deg"],
            "duration_s": record["config"]["postlift_hold_s"],
            "every_physics_step_holding_criteria": record["hold_criteria"],
        },
        "whole_sequence_passed": record["full_sequence_passed"],
        "units": "Millimeters except explicitly named seconds/degrees/kg; values are simulation state quantities, not hardware measurement accuracy",
    }


def write_markdown(report):
    lines = [
        "# 200 g 精选 5 / 90 / 100 mm 样本的高度分解", "",
        "只读检查三个已发布精选样本及其同候选、同控制字节的 100 g 配对结果。没有执行 mj_step，也没有改动已发布的模型、指标或轨迹。", "",
        "主要可证实差额来自**实际手根在抬升负载期间发生小角度转动，通过约 157–165 mm 的物体—手根距离产生竖直杠杆位移**。不能将世界坐标下物体相对手根下降的全部 5–7 mm 直接叫作手内滑移。", "",
        "## 四项分解", "",
        "总升高 = 前期物体变化 A + 实际手根上移 B + 根转动刚性杠杆项 D + 手局部相对重排项 E。", "",
        "令抬升开始/持握末手根世界位姿为 `(h0,R0)` / `(h1,R1)`，物体位置为 `o0/o1`。`r0=R0ᵀ(o0-h0)`、`r1=R1ᵀ(o1-h1)`；`D=(R1*r0-R0*r0).z`，`E=[R1*(r1-r0)].z`。A+B+D+E 与已发布实际升高精确相符。以下单位均为 mm。", "",
        "| 直径/质量 | 前期A | 实际根上移B | 根旋转杠杆D | 局部重排E | 实际总升高 | 5秒最大持握漂移 |",
        "|---|---:|---:|---:|---:|---:|---:|",
    ]
    for case in report["cases"]:
        for key in ("100g", "200g"):
            item, d = case[key], case[key]["decomposition_mm"]
            fields = [d["prelift_object_change_initial_to_loaded_end"], d["actual_hand_root_change_loaded_end_to_hold_end"],
                      d["rigid_hand_root_rotation_contribution_z"], d["hand_local_relative_rearrangement_contribution_z"],
                      d["actual_object_rise_initial_to_hold_end"], item["final_five_second_hold"]["maximum_object_translation_drift_mm"]]
            lines.append(f"| {case['diameter_mm']}/{key} | " + " | ".join(f"{x:.6f}" for x in fields) + " |")
    lines += ["", "## 200 g 不足100 mm的来源", "",
              "不足量 = -A + (100-B) - D - E。负数表示该项反而增加物体总升高。", "",
              "| 直径 | 前期贡献-A | 根平移不足100-B | 根旋转贡献-D | 局部重排贡献-E | 合计不足 | 实际mocap目标变化 |",
              "|---:|---:|---:|---:|---:|---:|---:|"]
    for case in report["cases"]:
        d = case["200g"]["decomposition_mm"]
        c = d["shortfall_contributions"]
        fields = [c["negative_prelift_object_change"], c["nominal_100mm_minus_actual_hand_root_rise"],
                  c["negative_rigid_root_rotation_contribution"], c["negative_hand_local_rearrangement_contribution"],
                  c["sum"], d["recorded_mocap_target_rise"]]
        lines.append(f"| {case['diameter_mm']} | " + " | ".join(f"{x:.6f}" for x in fields) + " |")
    lines += ["", "## 实际手根朝向与固定目标的误差", "",
              "| 直径/质量 | 实际根转角° | mocap目标转角° | 起点root对目标误差° | 终点误差° | r0长度mm | 局部相对位移模长mm |",
              "|---|---:|---:|---:|---:|---:|---:|"]
    for case in report["cases"]:
        for key in ("100g", "200g"):
            g = case[key]["root_rotation_and_relative_geometry"]
            fields = [g["actual_root_rotation_change_deg"], g["mocap_target_rotation_change_deg"],
                      g["root_to_mocap_error_lift_start_deg"], g["root_to_mocap_error_hold_end_deg"],
                      g["r0_lever_arm_norm_mm"], g["local_relative_displacement_norm_mm"]]
            lines.append(f"| {case['diameter_mm']}/{key} | " + " | ".join(f"{x:.6f}" for x in fields) + " |")
    lines += [
        "", "模型中实际自由根通过 mocap 焊接等式跟踪目标。编译后参考相对朝向验证为单位四元数，因此直接比较两个世界朝向有效。`solimp=[0.9,0.95,0.001,0.5,2]`、`solref=[0.02,1]`，并不是每步把实际根刚性重设到目标；记录确有朝向残差，抬升阶段目标朝向本身不变。", "",
        "同候选的 200 g 与 100 g 对比显示，增加负载后实际根的转角和向下杠杆项都更大。5 mm 所选的这条控制在 100 g 下也只有 94.482903 mm，不能拿 100 g 另一个成功候选作为它的配对基线。", "",
        "可以确认：指令目标约100 mm；实际根平移仅少约0.23–0.48 mm；根旋转带来约5.23–6.51 mm竖直损失；手局部重排的净竖直贡献仅约0.03–0.09 mm。不能确认：该小余项中多少来自手指关节形变、接触滑移、物体局部转动或重新就位，也不能用总法向力替代逐点摩擦/力矩容量分析。局部位移其它方向也可能不为零，不能据很小的竖直余项断言完全没有局部形变。", "",
        "后5秒漂移很小，只表示物体稳定在已达到的高度附近，不会自动补足前面产生的位移损失。该轨迹对手根给定固定上移目标，没有用物体实际高度作闭环补偿。", "",
        "## 各阶段坐标与来源", "",
        "下表为世界z（mm）；M/T/XML分别为原metrics、trace、模型SHA256前12位。JSON中每行含完整来源SHA、坐标地址、三维位置和四元数。", "",
        "| 直径/质量/阶段 | t(s) | 物体z | 实际根z | mocap目标z | root对目标朝向误差° | M / T / XML |",
        "|---|---:|---:|---:|---:|---:|---|",
    ]
    for case in report["cases"]:
        for key in ("100g", "200g"):
            for s in case[key]["stages"]:
                h = s["source_sha256"]
                short = " / ".join(h[k][:12] for k in ("metrics_sha256", "trace_sha256", "model_xml_sha256"))
                lines.append(f"| {case['diameter_mm']}/{key}/{s['stage_label']} | {s['time_s']:.3f} | {s['object_z_mm']:.6f} | {s['actual_hand_root_z_mm']:.6f} | {s['mocap_target_z_mm']:.6f} | {s['root_orientation_error_relative_to_mocap_deg']:.6f} | `{short}` |")
    lines += [
        "", "实际手根由编译模型中 hand-world 上的自由关节定位，再沿焊接约束定位 mocap 槽；没有假定首7个qpos。使用只做运动学的 mj_forward 核对 freejoint z=手根世界z、四元数旋转矩阵=手根世界旋转矩阵；无mj_step。", "",
        "物体坐标使用metrics的float64阶段观测，与公开实际升高一致；根与mocap来自精确阶段边界保存的float32状态。MuJoCo积分后qpos与本步运动学位置可能相差一个子步；JSON保留物体freejoint z和object_pose z以供复核。使用trace float32而非metrics float64重算的差别仅在末位，不改变结论。数值是本仿真状态，并非实体硬件测量精度声明。", "",
        "完整结果与来源：kinematics-decomposition.json。全部来源读取后再次核对SHA256未变。", "",
    ]
    (OUT / "kinematics-decomposition.md").write_text("\n".join(lines))


def main():
    selection_path = ROOT / "animations/index.json"
    selection = read(selection_path)
    cases = []
    source_files = {str(selection_path): sha(selection_path)}
    for displayed in selection["representatives"]:
        diameter = displayed["diameter_mm"]
        if diameter not in (5, 90, 100):
            continue
        new_path = Path(displayed["metrics"])
        relative = new_path.relative_to(ROOT / "lift-evaluation")
        old_path = OLD / "lift-evaluation" / relative
        new_model = new_path.parents[2] / "model.xml"
        old_model = old_path.parents[2] / "model.xml"
        heavy = analyze_one(new_path, new_model, "200g")
        baseline = analyze_one(old_path, old_model, "100g_same_candidate")
        assert heavy["source_sha256"]["input_grasp_sha256"] == baseline["source_sha256"]["input_grasp_sha256"]
        delta_fields = ("prelift_object_change_initial_to_loaded_end", "actual_hand_root_change_loaded_end_to_hold_end",
                        "object_relative_to_hand_root_change_loaded_end_to_hold_end", "actual_object_rise_initial_to_hold_end",
                        "rigid_hand_root_rotation_contribution_z", "hand_local_relative_rearrangement_contribution_z")
        difference = {field: heavy["decomposition_mm"][field] - baseline["decomposition_mm"][field] for field in delta_fields}
        cases.append({"diameter_mm": diameter, "selected_200g_case_key": str(relative.parent),
                      "same_grasp_bytes_verified": True, "200g": heavy, "100g": baseline,
                      "200g_minus_100g_mm": difference})
        for record in (heavy, baseline):
            for path_field in ("input", "metrics", "trace", "model_xml"):
                source_files[record[path_field]] = sha(record[path_field])
    assert len(cases) == 3
    assert all(sha(path) == digest for path, digest in source_files.items())
    report = {
        "schema_version": 1, "generated_at_utc": datetime.now(timezone.utc).isoformat(),
        "analysis_script_sha256": sha(__file__), "selected_from": str(selection_path),
        "source_files_unchanged": True, "physics_steps_executed": 0,
        "formula": "object_rise=prelift_object_change+actual_handroot_rise+(R1*r0-R0*r0)_z+[R1*(r1-r0)]_z; r=R^T*(object-handroot)",
        "notes": [
            "Actual hand-root z uses the compiled model freejoint qpos address and is verified against its body world position; it is not assumed to be the first seven coordinates.",
            "Object z uses float64 stage observations saved in metrics to match published measured rise; qpos/mocap come from saved float32 traces at exact phase boundaries.",
            "MuJoCo mj_step updates qpos after kinematic fields. The trace's object freejoint qpos z and observed object_pose z can therefore differ by one integration step; both are reported. Decomposition uses the same saved observed object z consistently.",
            "World-relative object-to-root z includes a rigid root-rotation lever-arm term; it must not be identified with local contact slip or finger deflection. Root rotation and hand-local rearrangement are reported separately.",
            "Small postlift drift does not correct the under-travel accumulated before the hold starts.",
        ],
        "sources_sha256": source_files, "cases": sorted(cases, key=lambda row: row["diameter_mm"]),
    }
    (OUT / "kinematics-decomposition.json").write_text(json.dumps(report, indent=2, ensure_ascii=False) + "\n")
    write_markdown(report)
    print(json.dumps({"cases": [{"diameter_mm": c["diameter_mm"], "100g": c["100g"]["decomposition_mm"], "200g": c["200g"]["decomposition_mm"]} for c in report["cases"]],
                      "source_files_unchanged": True, "physics_steps_executed": 0}, indent=2))


if __name__ == "__main__":
    main()
