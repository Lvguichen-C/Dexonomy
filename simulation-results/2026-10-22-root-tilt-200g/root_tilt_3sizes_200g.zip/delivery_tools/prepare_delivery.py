#!/usr/bin/env python3
"""Build the explicit selected-three-case delivery locally (no network).

Do not execute until renderer QA is complete. Index numbers are verified against
the actual video streams; no expected frame count/duration is hard-coded here.
"""
from __future__ import annotations
import argparse
from fractions import Fraction
import json
from pathlib import Path
import shutil
import subprocess
import zipfile
from common import CAP_BYTES, digest, plain_name, safe_source, write_json


def resolve_path(value, base):
    value = value["path"] if isinstance(value, dict) else value
    path = Path(value)
    return safe_source(path if path.is_absolute() else base/path)


def probe(path):
    # Independent QA already decodes the video. Read encoded MP4 metadata here
    # without repeating that complete decode during packaging.
    command=["ffprobe","-v","error","-select_streams","v:0","-show_entries","stream=width,height,r_frame_rate,avg_frame_rate,nb_frames,duration","-of","json",str(path)]
    stream=json.loads(subprocess.check_output(command,text=True))["streams"][0]
    return {"width":int(stream["width"]),"height":int(stream["height"]),"frames":int(stream["nb_frames"]),"fps":float(Fraction(stream["avg_frame_rate"])),"avg_frame_rate":float(Fraction(stream["avg_frame_rate"])),"r_frame_rate":float(Fraction(stream["r_frame_rate"])),"duration_s":float(stream["duration"])}


def main():
    root=Path(__file__).resolve().parent.parent
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root",type=Path,default=root)
    parser.add_argument("--index",type=Path)
    parser.add_argument("--report",type=Path)
    parser.add_argument("--outdir",type=Path)
    parser.add_argument("--include-spec",type=Path,help="Optional JSON list of exact extra ZIP entries: [{source,path}]")
    args=parser.parse_args()
    root=args.root.resolve()
    index_path=safe_source(args.index or root/"index.json")
    report=safe_source(args.report or root/"ROOT_TILT_ANIMATION.md")
    out=(args.outdir or root/"newdeliverables").resolve()
    index=json.loads(index_path.read_text())
    videos=index.get("videos",[])
    if not videos:
        raise SystemExit("Renderer index has no completed videos")
    top={"ROOT_TILT_ANIMATION.md":report,"index.json":index_path}
    archive={"renderer/index.json":index_path,"renderer/ROOT_TILT_ANIMATION.md":report}
    checks=[]
    for video in videos:
        path=resolve_path(video["path"],index_path.parent)
        actual=probe(path)
        for key in ("width","height","frames"):
            if actual[key]!=video[key]:
                raise SystemExit(f"Video {key} mismatch: {path.name}")
        if abs(actual["fps"]-float(video["fps"]))>1e-6 or abs(actual["r_frame_rate"]-float(video["fps"]))>1e-6 or abs(actual["duration_s"]-float(video["duration_s"]))>0.015:
            raise SystemExit(f"Video timebase mismatch: {path.name}")
        if video.get("sha256") and digest(path)!=video["sha256"]:
            raise SystemExit(f"Video hash mismatch: {path.name}")
        name=plain_name(path.name)
        if name in top:
            raise SystemExit(f"Duplicate top-level delivery: {name}")
        top[name]=path
        archive[f"renderer/{name}"]=path
        checks.append({"file":name,**actual,"playback_speed":video.get("playback_speed"),"source_time_start_s":video.get("source_time_start_s"),"source_time_end_s":video.get("source_time_end_s")})
    for entry in [*index.get("numerical_outputs",[]),*index.get("previews",[])]:
        path=resolve_path(entry["path"],index_path.parent)
        if entry.get("sha256") and digest(path)!=entry["sha256"]:
            raise SystemExit(f"Renderer metadata/preview hash mismatch: {path.name}")
        name=plain_name(path.name)
        if name in top:
            raise SystemExit(f"Duplicate renderer output basename: {name}")
        top[name]=path
        archive[f"renderer/{name}"]=path
    sources=index.get("sources",[])
    if sorted(int(item["diameter_mm"]) for item in sources)!=[5,90,100]:
        raise SystemExit("Expected exactly the selected 5/90/100 mm source cases")
    for item in sources:
        d=int(item["diameter_mm"])
        for key in ("input","metrics","trace"):
            path=resolve_path(item[key],index_path.parent)
            expected=item.get("source_sha256",{}).get(f"{key}_sha256")
            if expected and digest(path)!=expected:
                raise SystemExit(f"Selected source hash mismatch: d{d} {key}")
            archive[f"selected_sources/d{d:03d}/{key}/{path.name}"]=path
    for path in root.glob("*.py"):
        archive[f"renderer/{path.name}"]=safe_source(path)
    renderer=index.get("renderer")
    if renderer and index.get("renderer_sha256") and digest(resolve_path(renderer,index_path.parent))!=index["renderer_sha256"]:
        raise SystemExit("Frozen renderer source hash changed")
    for dependency,expected in index.get("dependencies",{}).items():
        if digest(resolve_path(dependency,index_path.parent))!=expected:
            raise SystemExit(f"Frozen dependency hash changed: {dependency}")
    for path in Path(__file__).parent.glob("*.py"):
        archive[f"delivery_tools/{path.name}"]=safe_source(path)
    if args.include_spec:
        for entry in json.loads(args.include_spec.read_text()):
            target=Path(entry["path"])
            if target.is_absolute() or ".." in target.parts:
                raise SystemExit("Invalid explicit ZIP entry")
            if str(target) in archive:
                raise SystemExit(f"Duplicate ZIP entry: {target}")
            archive[str(target)]=safe_source(entry["source"])
    out.mkdir(parents=True,exist_ok=True)
    for name,path in top.items():
        if path.resolve()!=(out/name).resolve():
            shutil.copy2(path,out/name)
    check_path=out/"video-verification.json"
    write_json(check_path,{"renderer_index_sha256":digest(index_path),"actual_video_streams":checks,"source_case_count":len(sources),"index_numbers_verified_against_actual_video":True})
    top[check_path.name]=check_path
    archive["renderer/video-verification.json"]=check_path
    archive_name="root_tilt_3sizes_200g.zip"
    with zipfile.ZipFile(out/archive_name,"w",compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
        for name,path in sorted(archive.items()):
            z.write(path,name)
        z.writestr("PACKAGE_README.txt","Selected 5/90/100 mm, 200 g original-state replay. Video timing/schematic amplification are described in renderer/ROOT_TILT_ANIMATION.md. The selected metrics/input/trace bytes are preserved under selected_sources/. No original user attachment, credential, Python environment, or unrelated candidate is included. Reconstructing the MuJoCo scene requires the original frozen Dexonomy hand/model assets referenced by the input and source index.\n")
    with zipfile.ZipFile(out/archive_name) as z:
        if z.testzip() is not None:
            raise SystemExit("ZIP CRC validation failed")
    names=[*top,archive_name]
    rows=[{"name":name,"bytes":(out/name).stat().st_size,"sha256":digest(out/name)} for name in names]
    if any(row["bytes"]>=CAP_BYTES for row in rows):
        raise SystemExit("A delivery reaches the 95 MB cap; split before publishing")
    manifest={"scope":"Own renderer outputs and exact selected-three-case source data only","renderer_index_sha256":digest(index_path),"actual_video_streams":checks,"zip_entries":len(archive)+1,"files":rows}
    write_json(out/"delivery_manifest.json",manifest)
    print(json.dumps({"outdir":str(out),"files":len(rows),"zip_bytes":(out/archive_name).stat().st_size,"actual_video_streams":checks},ensure_ascii=False,indent=2))


if __name__=="__main__":
    main()
