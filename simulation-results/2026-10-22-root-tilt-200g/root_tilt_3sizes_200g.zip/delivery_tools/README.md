# Root-tilt delivery tools

These tools are generic for the selected 5/90/100 mm 200 g animation delivery. They do not import the older 12-diameter sweep summary or repeat its success claims. No network operation occurs without running the publisher with `--publish`, or explicitly running the anonymous verification tool.

Wait for the renderer's QA approval and completed `index.json`. The index supplies the actual file names, source times, frame counts, dimensions, rates, and playback speeds. `prepare_delivery.py` probes the actual encoded video streams and checks the index values, rather than assuming a particular frame count or duration. It expects `sources` to contain the three cases with plain paths or `{path:...}` values for `input`, `metrics`, and `trace`.

After the root agent gives the build go-ahead:

```bash
python delivery_tools/prepare_delivery.py
python delivery_tools/publish_delivery.py
```

The first command prepares `newdeliverables/`, an explicit selected-source ZIP, stream validation, and `delivery_manifest.json`. The second command only validates local bytes/SHA256 and writes a publication plan. An optional `--include-spec extra_entries.json` can add exact model/dependency files to the ZIP using a list of `{source,path}` entries; no directory is recursively added. Original attachments, credentials, Python environments and unrelated input candidates are excluded.

The root agent may then perform the already-authorized publication and verify all public downloads:

```bash
python delivery_tools/publish_delivery.py --publish
python delivery_tools/verify_publication.py
```

Publication uploads Git blobs, creates a tree based on the current expected result-branch head, creates a commit, advances only that branch without force, and creates a new public Release from `ROOT_TILT_ANIMATION.md`. An existing Release with the requested tag is refused before any mutation. All file links use the created immutable commit. The source `main` reference is read before/after but never updated.

Defaults are result branch `mujoco-animation-results-20261016-assets`, expected parent `524944961701d5a558e21e82e469f28bfb7522bc`, prefix `simulation-results/2026-10-22-root-tilt-200g`, and new tag `shadow-root-tilt-3sizes-200g-20261022`. If the result branch changed, inspect it before explicitly changing `--expected-parent`.

Verification uses curl with local curl configuration disabled and no authentication headers. It checks every public file's byte count and SHA256, then anonymously fetches the Release JSON and verifies its public/non-draft state, exact tag, URL, and all download links. Results go to `public-download-verification.json`.
