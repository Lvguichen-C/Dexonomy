#!/usr/bin/env python3
"""Render the original three 200 g cases; state replay only, never mj_step."""
from __future__ import annotations

import argparse
import csv
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import subprocess
import sys

os.environ.setdefault("MUJOCO_GL", "egl")
os.environ.setdefault("LP_NUM_THREADS", "2")
ROOT = Path("/workspace/shadow-lift-sweep-200g")
OUT = Path(__file__).resolve().parent
sys.path[:0] = [str(ROOT), "/workspace/shadow-reproduction", "/workspace/Dexonomy"]

import mujoco
import numpy as np
from PIL import Image, ImageDraw, ImageFont
from evaluate_lifts import make_env, prepare_scene
from video_writer import VideoWriter

spec = importlib.util.spec_from_file_location("read_only_kinematics", ROOT / "height-diagnosis-20261022/kinematics-analysis.py")
kinematics = importlib.util.module_from_spec(spec)
spec.loader.exec_module(kinematics)

WIDTH, HEIGHT, FPS = 1920, 1080, 10
DIAMETERS = [5, 90, 100]
START, LIFT_START, LIFT_END, END = 2.7, 3.7, 8.7, 13.7
TOL = 1e-5
HAND_XML = Path("/workspace/Dexonomy/assets/hand/shadow/right.xml")
CYAN, GOLD, WHITE = (68, 216, 241), (255, 195, 91), (237, 242, 247)


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def write_json(path, value):
    Path(path).write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n")


def font(size):
    return ImageFont.truetype("/usr/share/fonts/opentype/noto/NotoSansCJK-Regular.ttc", size)


def replay(env, trace, index):
    data = env._data
    data.qpos[:] = trace["qpos"][index]
    data.qvel[:] = 0
    data.ctrl[:] = trace["ctrl"][index]
    data.mocap_pos[:] = trace["mocap_pos"][index]
    data.mocap_quat[:] = trace["mocap_quat"][index]
    data.time = float(trace["time_s"][index])
    mujoco.mj_forward(env._model, data)


def matching_index(trace, time):
    times = np.asarray(trace["time_s"], dtype=np.float64)
    index = int(np.searchsorted(times, time + TOL, side="right") - 1)
    assert index >= 0 and abs(float(times[index]) - time) < TOL, (time, times[index])
    return index


def phase_label(time):
    if time >= END - TOL:
        return "持握结束（释放前）"
    if time >= LIFT_END - TOL:
        return "到位持握 5 s"
    if time >= LIFT_START - TOL:
        return "抬升 100 mm / 5 s"
    return "受力保持 1 s"


class Case:
    def __init__(self, row):
        self.row = row
        self.diameter = row["diameter_mm"]
        self.record = json.loads(Path(row["metrics"]).read_text())
        self.hashes = {"selection_sha256": sha(ROOT / "animations/selection.json"), "input_sha256": sha(row["input"]), "metrics_sha256": sha(row["metrics"]), "trace_sha256": sha(row["trace"])}
        assert self.hashes["metrics_sha256"] == row["metrics_sha256"]
        assert self.hashes["trace_sha256"] == row["trace_sha256"]
        assert self.hashes["input_sha256"] == row["input_sha256"]
        assert self.record["config"]["mass_kg"] == .2
        with np.load(row["trace"], allow_pickle=False) as data:
            self.trace = {key: data[key].copy() for key in data.files}
        _, scene = prepare_scene(row["input"], .2)
        self.env = make_env(scene, HAND_XML)
        self.mapping = kinematics.locate_coordinates(self.env._model)
        assert abs(self.mapping["compiled_object_mass_kg"] - .2) < 1e-6
        self.address = self.mapping["hand_root_qpos_address"]
        self.slot = self.mapping["mocap_array_slot"]
        self.grid = np.round(START + np.arange(111) / FPS, 10)
        self.indices = np.array([matching_index(self.trace, value) for value in self.grid], dtype=int)
        assert abs(float(self.trace["time_s"][self.indices[-1]]) - END) < TOL
        self.start_index = matching_index(self.trace, LIFT_START)
        self.q0 = kinematics.normalized_quaternion(self.trace["qpos"][self.start_index, self.address + 3:self.address + 7])
        self.R0 = kinematics.rotation_matrix(self.q0)
        self.h0 = self.trace["qpos"][self.start_index, self.address:self.address + 3].astype(float)
        self.o0 = np.array(self.record["loaded_object_pose"][:3], dtype=float)
        self.r0 = self.R0.T @ (self.o0 - self.h0)
        self.initial_z = float(self.record["initial_object_pose"][2])
        self.boundary_objects = {}
        for time, key in [(START, "closure_object_pose"), (LIFT_START, "loaded_object_pose"), (LIFT_END, "lift_end_object_pose"), (END, "held_object_pose")]:
            self.boundary_objects[matching_index(self.trace, time)] = (np.asarray(self.record[key][:3], dtype=float), key)
        self.rows = [self.numerics(index, i) for i, index in enumerate(self.indices)]
        self.env._model.vis.global_.offwidth = max(616, self.env._model.vis.global_.offwidth)
        self.env._model.vis.global_.offheight = max(440, self.env._model.vis.global_.offheight)
        self.renderer = mujoco.Renderer(self.env._model, height=440, width=616)
        self.option = mujoco.MjvOption()
        self.option.flags[mujoco.mjtVisFlag.mjVIS_CONTACTPOINT] = False
        self.camera = self.fit_camera()

    def numerics(self, index, frame):
        qpos = self.trace["qpos"][index].astype(float)
        q = kinematics.normalized_quaternion(qpos[self.address + 3:self.address + 7])
        targetq = self.trace["mocap_quat"][index, self.slot]
        R = kinematics.rotation_matrix(q)
        obj, source = self.boundary_objects.get(int(index), (self.trace["object_pose"][index, :3].astype(float), "trace.object_pose"))
        current = float(self.trace["time_s"][index])
        started = current >= LIFT_START - TOL
        return {"frame": frame, "diameter_mm": self.diameter, "video_time_1x_s": frame / FPS, "grid_time_s": float(self.grid[frame]), "recorded_time_s": current, "trace_index": int(index), "recorded_phase": str(self.trace["phase_names"][int(self.trace["phase_id"][index])]), "display_phase": phase_label(current), "lift_reference_started": started, "root_rotation_since_lift_start_deg": kinematics.angle_deg(self.q0, q) if started else None, "root_to_mocap_orientation_error_deg": kinematics.angle_deg(q, targetq), "root_rotation_contribution_world_z_mm": float(((R - self.R0) @ self.r0)[2] * 1000) if started else None, "object_rise_since_initial_mm": float((obj[2] - self.initial_z) * 1000), "object_position_source": source, "root_world_x_m": float(qpos[self.address]), "root_world_y_m": float(qpos[self.address + 1]), "root_world_z_m": float(qpos[self.address + 2]), "root_qw": float(q[0]), "root_qx": float(q[1]), "root_qy": float(q[2]), "root_qz": float(q[3]), "hand_object_contact_points": int(self.trace["hand_object_contacts"][index])}

    def fit_camera(self):
        camera = mujoco.MjvCamera()
        mujoco.mjv_defaultCamera(camera)
        ids = [i for i in range(self.env._model.ngeom) if self.env._model.body(int(self.env._model.geom_bodyid[i])).name.startswith(("hand-", "obj-"))]
        cloud = []
        for index in self.indices[::10]:
            replay(self.env, self.trace, index)
            positions = self.env._data.geom_xpos[ids]
            radii = self.env._model.geom_rbound[ids, None]
            cloud.extend([positions - radii, positions + radii])
        bounds = np.concatenate(cloud)
        lo, hi = bounds.min(axis=0), bounds.max(axis=0)
        camera.lookat[:] = (lo + hi) / 2
        camera.distance = max(.48, float(np.max(hi - lo)) * 1.85)
        camera.azimuth, camera.elevation = 135, -20
        return camera

    def physical_image(self, frame):
        index = self.indices[frame]
        replay(self.env, self.trace, index)
        self.renderer.update_scene(self.env._data, camera=self.camera, scene_option=self.option)
        # A display marker at the actual root body origin; original qpos is intact.
        scene = self.renderer.scene
        geom = scene.geoms[scene.ngeom]
        mujoco.mjv_initGeom(geom, mujoco.mjtGeom.mjGEOM_SPHERE, np.array([.007, .007, .007]), self.env._data.xpos[self.mapping["hand_body_id"]], np.eye(3).reshape(9), np.array([.2, .85, .95, 1.]))
        scene.ngeom += 1
        return Image.fromarray(self.renderer.render().copy())

    def close(self):
        self.renderer.close()


def draw_plot(draw, case, frame, left):
    x0, y0, x1, y1 = left + 55, 850, left + 608, 979
    draw.text((left + 16, 805), "真实转角曲线（°，未放大物理姿态）", font=font(23), fill=WHITE)
    for value in (0, 3, 6):
        y = y1 - value / 6 * (y1 - y0)
        draw.line((x0, y, x1, y), fill=(54, 66, 82), width=1)
        draw.text((left + 24, y - 15), str(value), font=font(20), fill=(167, 180, 196))
    for time in (2.7, 3.7, 8.7, 13.7):
        x = x0 + (time - START) / (END - START) * (x1 - x0)
        draw.line((x, y0, x, y1), fill=(48, 59, 74), width=1)
        draw.text((x - 20, y1 + 4), f"{time:g}", font=font(18), fill=(167, 180, 196))
    for name, color in [("root_rotation_since_lift_start_deg", CYAN), ("root_to_mocap_orientation_error_deg", GOLD)]:
        points = []
        for row in case.rows[:frame + 1]:
            value = row[name]
            if value is not None:
                points.append((x0 + (row["grid_time_s"] - START) / (END - START) * (x1 - x0), y1 - value / 6 * (y1 - y0)))
        if len(points) >= 2:
            draw.line(points, fill=color, width=4)
        elif points:
            x, y = points[0]
            draw.ellipse((x-3, y-3, x+3, y+3), fill=color)
    row = case.rows[frame]
    xx = x0 + (row["grid_time_s"] - START) / (END - START) * (x1 - x0)
    draw.line((xx, y0, xx, y1), fill=(235, 239, 242), width=1)
    draw.text((left + 78, 1020), "青：相对抬升起点", font=font(21), fill=CYAN)
    draw.text((left + 340, 1020), "金：相对目标姿态", font=font(21), fill=GOLD)


def compose(cases, frame):
    image = Image.new("RGB", (WIDTH, HEIGHT), (16, 23, 33))
    draw = ImageDraw.Draw(image)
    draw.text((22, 7), "200 g 负载下的手根转动 · 三工况原状态并排回放", font=font(35), fill=WHITE)
    draw.text((24, 57), "物理视图姿态 1× · 青色球标记实际手根 · 原始保存状态 10 Hz · 无插值、无重新物理积分", font=font(24), fill=(172, 189, 207))
    for column, case in enumerate(cases):
        left = column * 640
        row = case.rows[frame]
        draw.rounded_rectangle((left + 9, 102, left + 631, 794), radius=10, fill=(24, 33, 46))
        draw.text((left + 20, 108), f"Ø{case.diameter} mm  ·  t={row['recorded_time_s']:.2f} s", font=font(30), fill=WHITE)
        draw.text((left + 20, 148), row["display_phase"], font=font(25), fill=(193, 207, 223))
        image.paste(case.physical_image(frame), (left + 12, 191))
        draw = ImageDraw.Draw(image)
        metrics = [("相对抬升起点总转角", row["root_rotation_since_lift_start_deg"], "°", CYAN), ("对目标姿态误差", row["root_to_mocap_orientation_error_deg"], "°", GOLD), ("根转动项 · 世界z", row["root_rotation_contribution_world_z_mm"], " mm", (238, 164, 173)), ("物体实际升高（自初始）", row["object_rise_since_initial_mm"], " mm", WHITE)]
        # The 440px physical view ends at631. Four rows have38px spacing.
        for number, (label, value, unit, color) in enumerate(metrics):
            y = 634 + number * 38
            draw.text((left + 20, y), label, font=font(24), fill=(187, 202, 219))
            text = "未开始" if value is None else f"{value:.3f}{unit}"
            draw.text((left + 613, y - 2), text, font=font(27), fill=color, anchor="ra")
        draw_plot(draw, case, frame, left)
        if column:
            draw.line((left, 100, left, 1060), fill=(61, 76, 94), width=2)
    return speed_badge(image, 1.0)


def speed_badge(image, speed):
    draw = ImageDraw.Draw(image)
    draw.rounded_rectangle((1670, 10, 1898, 59), radius=9, fill=(42, 62, 84))
    draw.text((1784, 11), f"播放 {speed:g}×", font=font(30), fill=WHITE, anchor="mt")
    return image


def probe_video(path, expected_frames):
    subprocess.run(["ffmpeg", "-nostdin", "-v", "error", "-xerror", "-threads", "1", "-i", str(path), "-f", "null", "-"], check=True, capture_output=True)
    probe = json.loads(subprocess.check_output(["ffprobe", "-v", "error", "-count_frames", "-show_entries", "stream=width,height,r_frame_rate,avg_frame_rate,nb_frames,nb_read_frames", "-show_entries", "format=duration", "-of", "json", str(path)], text=True))
    stream = probe["streams"][0]
    assert stream["width"] == WIDTH and stream["height"] == HEIGHT
    assert stream["avg_frame_rate"] == stream["r_frame_rate"] == "10/1"
    assert int(stream["nb_read_frames"]) == int(stream["nb_frames"]) == expected_frames
    assert abs(float(probe["format"]["duration"]) - expected_frames / FPS) < 1e-6
    return probe


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--render", action="store_true", help="Only after preview review; encode both speeds.")
    args = parser.parse_args()
    selection = json.loads((ROOT / "animations/selection.json").read_text())
    cases = [Case(next(row for row in selection["representatives"] if row["diameter_mm"] == diameter)) for diameter in DIAMETERS]
    try:
        sources = []
        for case in cases:
            sources.append({"diameter_mm": case.diameter, "input": case.row["input"], "metrics": case.row["metrics"], "trace": case.row["trace"], "source_sha256": case.hashes, "compiled_coordinates": case.mapping, "first_trace_index": int(case.indices[0]), "last_trace_index": int(case.indices[-1]), "final_values": case.rows[-1], "camera": {"lookat": case.camera.lookat.tolist(), "distance": float(case.camera.distance), "azimuth": float(case.camera.azimuth), "elevation": float(case.camera.elevation)}})
        rows = [row for case in cases for row in case.rows]
        with (OUT / "per_frame.csv").open("w", newline="") as file:
            writer = csv.DictWriter(file, fieldnames=list(rows[0]))
            writer.writeheader()
            writer.writerows(rows)
        numeric_names = [key for key, value in rows[0].items() if isinstance(value, (int, float, bool)) or value is None]
        np.savez_compressed(OUT / "per_frame.npz", **{name: np.asarray([np.nan if row[name] is None else row[name] for row in rows]) for name in numeric_names})
        previews = []
        for name, frame in [("preview_loaded.png", 0), ("preview_lift_start.png", 10), ("preview_held.png", 110)]:
            path = OUT / name
            compose(cases, frame).save(path)
            previews.append({"path": str(path), "sha256": sha(path), "frame": frame})
        index = {"schema_version": 1, "benchmark_mass_kg": .2, "source_time_start_s": START, "source_time_end_s": END, "lift_reference_time_s": LIFT_START, "source_samples_per_case":111, "rendering": "Original saved qpos/ctrl/mocap replay followed by mj_forward only. No mj_step; physical orientation scale1x. Cyan root sphere is a display annotation.", "timestamp_matching_tolerance_s": TOL, "angle_definition": "Normalized quaternion shortest rotation angle 2*acos(abs(q0 dot qt)); total orientation change, not pitch alone.", "rotation_z_definition": "r0=R0.T@(o0-h0), Dz=((Rt-R0)@r0).z; liftstart3.7s. This is a kinematic decomposition, not a counterfactual simulation.", "object_position_source": "Original trace.object_pose; exact stage endpoints use corresponding original metrics float64 object poses, never interpolated.", "prelift_display": "Relative-to-liftstart angle and rotation term are absent before3.7s; no future-referenced prelift curve.", "held_endpoint_policy": "13.7s original release_open boundary is the held state before opening integration; displaylabel heldend(before release).", "renderer": str(Path(__file__).resolve()), "renderer_sha256": sha(__file__), "dependencies": {str(ROOT / "evaluate_lifts.py"):sha(ROOT / "evaluate_lifts.py"), str(HAND_XML):sha(HAND_XML), str(ROOT / "height-diagnosis-20261022/kinematics-analysis.py"):sha(ROOT / "height-diagnosis-20261022/kinematics-analysis.py")}, "sources": sources, "previews": previews, "numerical_outputs": [{"path":str(OUT/name), "sha256":sha(OUT/name)} for name in ["per_frame.csv", "per_frame.npz"]], "videos": []}
        if args.render:
            paths = [OUT / "root_tilt_3cases_1x.mp4", OUT / "root_tilt_3cases_0p5x.mp4"]
            with VideoWriter(paths[0], fps=FPS) as normal, VideoWriter(paths[1], fps=FPS) as slow:
                for frame in range(111):
                    picture = compose(cases, frame)
                    normal.append_data(np.asarray(picture))
                    slow_pixels = np.asarray(speed_badge(picture.copy(), .5))
                    slow.append_data(slow_pixels)
                    slow.append_data(slow_pixels)
            for path, frames, speed in [(paths[0],111,1.0),(paths[1],222,.5)]:
                probe = probe_video(path, frames)
                index["videos"].append({"path":str(path), "sha256":sha(path), "width":WIDTH, "height":HEIGHT, "fps":FPS, "frames":frames, "duration_s":frames/FPS, "playback_speed":speed, "source_time_start_s":START, "source_time_end_s":END, "slowdown_policy":"Repeat each saved-state image twice, no interpolation" if speed==.5 else "One saved state per frame", "full_decode_passed":True, "probe":probe})
        write_json(OUT / "index.json", index)
        for source in sources:
            for key, digest in source["source_sha256"].items():
                path = ROOT / "animations/selection.json" if key == "selection_sha256" else source[key.removesuffix("_sha256")]
                assert sha(path) == digest, (key, path)
        print(json.dumps({"index":str(OUT / "index.json"), "videos":index["videos"], "final_values":[s["final_values"] for s in sources]}, ensure_ascii=False, indent=2), flush=True)
    finally:
        for case in cases:
            case.close()


if __name__ == "__main__":
    main()
