#!/usr/bin/env python3
"""Independently derive original selected-trace root-rotation geometry.

No simulation is performed. XML/metrics/NPZ inputs are read-only; this script
writes only its own audit JSON in the newly created tilt-overview directory.
Quaternion rotation matrices are calculated explicitly rather than importing
the existing diagnosis implementation.
"""
from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path

import mujoco
import numpy as np


def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def quaternion(value):
    value = np.asarray(value, dtype=np.float64)
    norm = float(np.linalg.norm(value))
    if not np.isfinite(norm) or norm <= 0:
        raise ValueError("Invalid quaternion")
    return value / norm


def matrix(value):
    w, x, y, z = quaternion(value)
    return np.array([
        [1 - 2 * (y*y + z*z), 2 * (x*y - w*z), 2 * (x*z + w*y)],
        [2 * (x*y + w*z), 1 - 2 * (x*x + z*z), 2 * (y*z - w*x)],
        [2 * (x*z - w*y), 2 * (y*z + w*x), 1 - 2 * (x*x + y*y)],
    ])


def degrees(a, b):
    return float(np.rad2deg(2 * np.arccos(np.clip(abs(quaternion(a) @ quaternion(b)), 0, 1))))


def coordinates(model):
    body = model.body("hand-world").id
    joints = [j for j in range(model.njnt) if int(model.jnt_bodyid[j]) == body and int(model.jnt_type[j]) == int(mujoco.mjtJoint.mjJNT_FREE)]
    assert len(joints) == 1
    joint = joints[0]
    found = []
    for i in range(model.neq):
        if int(model.eq_type[i]) != int(mujoco.mjtEq.mjEQ_WELD):
            continue
        first, second = int(model.eq_obj1id[i]), int(model.eq_obj2id[i])
        if first == body or second == body:
            other = second if first == body else first
            slot = int(model.body_mocapid[other])
            if slot >= 0:
                found.append((i, other, slot))
    assert len(found) == 1
    equality, mocap_body, mocap_slot = found[0]
    assert np.allclose(model.eq_data[equality, 6:10], [1, 0, 0, 0], atol=1e-12, rtol=0)
    return {
        "body_id": body, "body_name": model.body(body).name,
        "freejoint_id": joint, "freejoint_name": model.joint(joint).name,
        "qpos_position_address": int(model.jnt_qposadr[joint]),
        "qpos_quaternion_address": int(model.jnt_qposadr[joint]) + 3,
        "mocap_body_id": mocap_body, "mocap_body_name": model.body(mocap_body).name,
        "mocap_slot": mocap_slot, "weld_equality_id": equality,
        "weld_reference_relative_quaternion_wxyz": model.eq_data[equality, 6:10].tolist(),
        "weld_solref": model.eq_solref[equality].tolist(),
        "weld_solimp": model.eq_solimp[equality].tolist(),
    }


def boundary(record, archive, phase):
    exact_time = next(float(row["time_s"]) for row in record["phase_boundaries"] if row["phase"] == phase)
    phase_id = list(archive["phase_names"]).index(phase)
    candidates = np.flatnonzero((np.abs(archive["time_s"].astype(float) - exact_time) <= 1e-4) & (archive["phase_id"] == phase_id))
    assert len(candidates), phase
    return int(candidates[-1]), exact_time


def endpoint(trace, coordinate, index, object_pose):
    address, slot = coordinate["qpos_position_address"], coordinate["mocap_slot"]
    hand_position = np.asarray(trace["qpos"][index, address:address+3], dtype=float)
    hand_q = quaternion(trace["qpos"][index, address+3:address+7])
    mocap_q = quaternion(trace["mocap_quat"][index, slot])
    return {"p": hand_position, "q": hand_q, "R": matrix(hand_q), "m": mocap_q,
            "o": np.asarray(object_pose[:3], dtype=float),
            "mocap_position": np.asarray(trace["mocap_pos"][index, slot], dtype=float)}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root", type=Path, default=Path("/workspace/shadow-lift-sweep-200g"))
    parser.add_argument("--output", type=Path, default=Path(__file__).resolve().with_name("independent-tilt-audit.json"))
    args = parser.parse_args()
    index_path = args.root / "animations/index.json"
    selected = json.loads(index_path.read_text())["representatives"]
    source_hashes = {str(index_path): digest(index_path)}
    rows = []
    for selection in selected:
        d = selection["diameter_mm"]
        if d not in [5, 90, 100]:
            continue
        metrics_path = Path(selection["metrics"])
        record = json.loads(metrics_path.read_text())
        trace_path = Path(record["trace"])
        model_path = args.root / "lift-evaluation" / record["scene_id"] / "model.xml"
        for path in (metrics_path, trace_path, model_path):
            source_hashes[str(path)] = digest(path)
        assert digest(metrics_path) == selection["metrics_sha256"]
        assert digest(trace_path) == selection["trace_sha256"]
        model = mujoco.MjModel.from_xml_path(str(model_path))
        coordinate = coordinates(model)
        with np.load(trace_path, allow_pickle=False) as archive:
            trace = {key: np.asarray(archive[key]).copy() for key in archive.files}
        start_i, start_t = boundary(record, trace, "lift")
        end_i, end_t = boundary(record, trace, "release_open")
        lift_end_i, lift_end_t = boundary(record, trace, "postlift_hold")
        start = endpoint(trace, coordinate, start_i, record["loaded_object_pose"])
        end = endpoint(trace, coordinate, end_i, record["held_object_pose"])
        r0 = start["R"].T @ (start["o"] - start["p"])
        r1 = end["R"].T @ (end["o"] - end["p"])
        rotation_xyz = (end["R"] - start["R"]) @ r0
        local_xyz = end["R"] @ (r1 - r0)
        early = start["o"][2] - float(record["initial_object_pose"][2])
        root_rise = end["p"][2] - start["p"][2]
        observed = end["o"][2] - float(record["initial_object_pose"][2])
        components = early + root_rise + rotation_xyz[2] + local_xyz[2]
        assert abs(components - observed) <= 1e-12
        assert abs(observed * 1000 - record["measured_object_lift_mm"]) <= 1e-8
        # Independent forward-kinematics cross-check, with no time integration.
        data = mujoco.MjData(model)
        for i, state in ((start_i, start), (end_i, end)):
            data.qpos[:] = trace["qpos"][i]
            data.mocap_pos[:] = trace["mocap_pos"][i]
            data.mocap_quat[:] = trace["mocap_quat"][i]
            mujoco.mj_forward(model, data)
            assert np.allclose(data.xpos[coordinate["body_id"]], state["p"], rtol=0, atol=1e-12)
            assert np.allclose(data.xmat[coordinate["body_id"]].reshape(3, 3), state["R"], rtol=0, atol=1e-7)
        # Series values use only saved observations; the endpoint above uses
        # phase metrics' original float64 object observations for exact closure.
        series = []
        for i, time in enumerate(trace["time_s"]):
            if float(time) < start_t - 1e-4 or float(time) > end_t + 1e-4:
                continue
            state = endpoint(trace, coordinate, i, trace["object_pose"][i])
            series.append({"trace_index": i, "time_s": float(time),
                           "root_orientation_change_from_lift_start_deg": degrees(start["q"], state["q"]),
                           "root_to_mocap_orientation_error_deg": degrees(state["q"], state["m"]),
                           "mocap_orientation_change_from_lift_start_deg": degrees(start["m"], state["m"]),
                           "rigid_root_rotation_world_z_contribution_mm": float(((state["R"] - start["R"]) @ r0)[2] * 1000),
                           "actual_object_rise_from_initial_mm": float(state["o"][2] - record["initial_object_pose"][2]) * 1000})
        rows.append({"diameter_mm": d, "coordinates": coordinate,
                     "source": {"input": record["input"], "metrics": str(metrics_path), "trace": str(trace_path), "model": str(model_path)},
                     "phase_boundary_indices": {"lift_start": start_i, "lift_end": lift_end_i, "hold_end_before_release": end_i},
                     "phase_boundary_times_s": {"lift_start": start_t, "lift_end": lift_end_t, "hold_end_before_release": end_t},
                     "root_orientation_change_from_lift_start_deg": degrees(start["q"], end["q"]),
                     "root_to_mocap_orientation_error_at_lift_start_deg": degrees(start["q"], start["m"]),
                     "root_to_mocap_orientation_error_at_hold_end_deg": degrees(end["q"], end["m"]),
                     "mocap_orientation_change_during_lift_and_hold_deg": degrees(start["m"], end["m"]),
                     "lever_arm_norm_at_lift_start_mm": float(np.linalg.norm(r0) * 1000),
                     "r0_root_local_object_center_mm": (r0 * 1000).tolist(),
                     "r1_root_local_object_center_mm": (r1 * 1000).tolist(),
                     "decomposition_mm": {"object_pre_lift_change": early * 1000, "actual_root_translation": root_rise * 1000, "rigid_root_rotation_world_z": float(rotation_xyz[2] * 1000), "root_local_rearrangement_world_z": float(local_xyz[2] * 1000), "sum": components * 1000, "actual_object_rise": observed * 1000},
                     "time_series": series})
    assert len(rows) == 3
    assert all(digest(path) == expected for path, expected in source_hashes.items())
    result = {"scope": "Read-only algebra and mj_forward kinematics on original selected 200 g traces. No mj_step, new simulation, controller edits, success-label edits or source artifact mutations.",
              "angle_definitions": {"root_change": "2acos(abs(normalize(q_lift_start) dot normalize(q_t))); total 3D orientation change, not pitch relative to world vertical", "root_to_mocap": "2acos(abs(normalize(q_t) dot normalize(mocap_q_t))); different from the lift-start-relative angle"},
              "geometry_formula": "r_s=R_s^T(o_s-p_s); r_e=R_e^T(o_e-p_e). object rise=[o_s-o_initial]_z+[p_e-p_s]_z+[(R_e-R_s)r_s]_z+[R_e(r_e-r_s)]_z",
              "sampling_limits": "Trace positions/quaternions are float32 at 10 Hz plus exact boundaries. Endpoint object observations use original float64 phase metrics; no claim about unsaved 250 Hz intermediate tilt. Local rearrangement is not a direct contact-slip measurement.",
              "source_sha256_before_and_after_verified": source_hashes, "rows": rows}
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(result, ensure_ascii=False, indent=2) + "\n")
    print(json.dumps({"audit": str(args.output), "source_files_unchanged": True, "rows": [{"diameter_mm": row["diameter_mm"], "root_rotation_deg": row["root_orientation_change_from_lift_start_deg"], "mocap_error_deg": row["root_to_mocap_orientation_error_at_hold_end_deg"], "rotation_world_z_mm": row["decomposition_mm"]["rigid_root_rotation_world_z"], "actual_rise_mm": row["decomposition_mm"]["actual_object_rise"]} for row in rows]}, indent=2))


if __name__ == "__main__":
    main()
