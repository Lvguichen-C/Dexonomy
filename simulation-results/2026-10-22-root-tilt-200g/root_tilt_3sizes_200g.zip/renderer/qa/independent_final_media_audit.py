#!/usr/bin/env python3
"""Independent numeric/state/media integrity audit. Writes only this qa subtree."""
from pathlib import Path
import ast
import csv
import hashlib
import json
import subprocess

import numpy as np
from PIL import Image

OUT = Path('/workspace/shadow-lift-sweep-200g/height-diagnosis-20261022/tilt-overview')
QA = OUT / 'qa'


def read(path):
    return json.loads(Path(path).read_text())


def sha(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b''):
            h.update(chunk)
    return h.hexdigest()


def norm(q):
    q = np.asarray(q, dtype=float)
    return q / np.linalg.norm(q)


def angle(a, b):
    return float(np.degrees(2 * np.arccos(np.clip(abs(norm(a) @ norm(b)), 0, 1))))


def rotation(q):
    w, x, y, z = norm(q)
    return np.array([[1 - 2 * (y*y + z*z), 2 * (x*y - z*w), 2 * (x*z + y*w)],
                     [2 * (x*y + z*w), 1 - 2 * (x*x + z*z), 2 * (y*z - x*w)],
                     [2 * (x*z - y*w), 2 * (y*z + x*w), 1 - 2 * (x*x + y*y)]])


def media_probe(path, expected_frames):
    result = json.loads(subprocess.check_output([
        'ffprobe', '-v', 'error', '-count_frames', '-select_streams', 'v:0',
        '-show_entries', 'stream=codec_name,pix_fmt,width,height,avg_frame_rate,r_frame_rate,nb_read_frames,nb_frames:format=duration',
        '-of', 'json', str(path)]))
    stream = result['streams'][0]
    assert stream['codec_name'] == 'h264' and stream['pix_fmt'] == 'yuv420p'
    assert (stream['width'], stream['height']) == (1920, 1080)
    assert stream['avg_frame_rate'] == stream['r_frame_rate'] == '10/1'
    assert int(stream['nb_read_frames']) == int(stream['nb_frames']) == expected_frames
    assert abs(float(result['format']['duration']) - expected_frames / 10) < 1e-6
    subprocess.run(['ffmpeg', '-nostdin', '-v', 'error', '-xerror', '-threads', '1',
                    '-i', str(path), '-f', 'null', '-'], check=True, capture_output=True)
    return {'probe': result, 'full_decode': 'passed'}


def main():
    index = read(OUT / 'index.json')
    numeric = read(QA / 'independent-numeric-source-audit.json')
    assert numeric['all_checks_passed']
    assert index['renderer_sha256'] == sha(index['renderer'])
    source_text = Path(index['renderer']).read_text()
    parsed = ast.parse(source_text)
    forbidden = [n.func.attr for n in ast.walk(parsed) if isinstance(n, ast.Call)
                 and isinstance(n.func, ast.Attribute) and n.func.attr in ('mj_step', 'mj_step1', 'mj_step2', 'step_sim')]
    assert not forbidden, forbidden
    assert index['source_time_start_s'] == 2.7 and index['source_time_end_s'] == 13.7
    assert index['lift_reference_time_s'] == 3.7 and index['source_samples_per_case'] == 111
    assert index['benchmark_mass_kg'] == .2
    for path, digest in index['dependencies'].items():
        assert sha(path) == digest
    cases = {c['diameter_mm']: c for c in index['sources']}
    assert sorted(cases) == [5, 90, 100]
    for artifact in index['numerical_outputs'] + index['previews']:
        assert sha(artifact['path']) == artifact['sha256']
    with (OUT / 'per_frame.csv').open(newline='') as f:
        rows = list(csv.DictReader(f))
    assert len(rows) == 333
    checks = []
    for d, case in cases.items():
        record = read(case['metrics'])
        for key, digest in case['source_sha256'].items():
            path = Path('/workspace/shadow-lift-sweep-200g/animations/selection.json') if key == 'selection_sha256' else case[key.removesuffix('_sha256')]
            assert sha(path) == digest
        adr = case['compiled_coordinates']['hand_root_qpos_address']
        slot = case['compiled_coordinates']['mocap_array_slot']
        group = [r for r in rows if int(r['diameter_mm']) == d]
        assert len(group) == 111 and [int(r['frame']) for r in group] == list(range(111))
        with np.load(case['trace'], allow_pickle=False) as z:
            times = z['time_s'].astype(float)
            grid = np.round(2.7 + np.arange(111) / 10, 10)
            indices = np.searchsorted(times, grid + 1e-5, side='right') - 1
            lift_idx = int(np.searchsorted(times, 3.7 + 1e-5, side='right') - 1)
            R0 = rotation(z['qpos'][lift_idx, adr + 3:adr + 7])
            h0 = z['qpos'][lift_idx, adr:adr + 3].astype(float)
            o0 = np.asarray(record['loaded_object_pose'][:3], dtype=float)
            r0 = R0.T @ (o0 - h0)
            boundaries = {0: 'closure_object_pose', 10: 'loaded_object_pose', 60: 'lift_end_object_pose', 110: 'held_object_pose'}
            max_angle_error = max_rotation_z_error = max_rise_error = 0.
            for f, row in enumerate(group):
                i = int(row['trace_index'])
                assert i == int(indices[f]) and abs(float(row['recorded_time_s']) - times[i]) < 1e-10
                assert abs(float(row['grid_time_s']) - grid[f]) < 1e-10
                q = z['qpos'][i, adr + 3:adr + 7]
                xyz = np.array([float(row[f'root_world_{axis}_m']) for axis in ('x', 'y', 'z')])
                assert np.allclose(xyz, z['qpos'][i, adr:adr + 3], rtol=0, atol=1e-12)
                csvq = np.array([float(row[f'root_q{axis}']) for axis in ('w', 'x', 'y', 'z')])
                assert np.allclose(csvq, norm(q), rtol=0, atol=1e-12)
                target_error = angle(q, z['mocap_quat'][i, slot])
                max_angle_error = max(max_angle_error, abs(target_error - float(row['root_to_mocap_orientation_error_deg'])))
                if f < 10:
                    assert row['root_rotation_since_lift_start_deg'] == '' and row['root_rotation_contribution_world_z_mm'] == ''
                else:
                    turn = angle(z['qpos'][lift_idx, adr + 3:adr + 7], q)
                    Dz = float(((rotation(q) - R0) @ r0)[2] * 1000)
                    max_angle_error = max(max_angle_error, abs(turn - float(row['root_rotation_since_lift_start_deg'])))
                    max_rotation_z_error = max(max_rotation_z_error, abs(Dz - float(row['root_rotation_contribution_world_z_mm'])))
                oz = float(record[boundaries[f]][2]) if f in boundaries else float(z['object_pose'][i, 2])
                rise = (oz - record['initial_object_pose'][2]) * 1000
                max_rise_error = max(max_rise_error, abs(rise - float(row['object_rise_since_initial_mm'])))
            assert max_angle_error < 1e-5 and max_rotation_z_error < 1e-6 and max_rise_error < 1e-6
            assert abs(float(group[-1]['recorded_time_s']) - 13.7) < 1e-5
            assert group[-1]['recorded_phase'] == 'release_open'
            assert group[-1]['display_phase'] == '持握结束（释放前）'
            assert int(group[-1]['trace_index']) == case['last_trace_index']
            checks.append({'diameter_mm': d, 'saved_state_rows_checked': 111, 'all_state_positions_and_quaternions_match_original': True,
                           'maximum_angle_error_deg': max_angle_error, 'maximum_rotation_z_error_mm': max_rotation_z_error,
                           'maximum_object_rise_error_mm': max_rise_error, 'exact_held_boundary_included': True})
    videos = index['videos']
    assert len(videos) == 2
    media = []
    for video in videos:
        assert sha(video['path']) == video['sha256']
        expected_frames = 111 if video['playback_speed'] == 1 else 222
        assert video['frames'] == expected_frames
        result = {'path': video['path'], 'sha256': video['sha256'], 'playback_speed': video['playback_speed'],
                  **media_probe(video['path'], expected_frames)}
        last = expected_frames - 1
        middle = expected_frames // 2
        raw = subprocess.check_output(['ffmpeg', '-nostdin', '-v', 'error', '-threads', '1', '-i', video['path'],
                                       '-vf', f'select=eq(n\\,{middle})+eq(n\\,{last})', '-fps_mode', 'vfr', '-pix_fmt', 'rgb24', '-f', 'rawvideo', '-'])
        frames = np.frombuffer(raw, dtype=np.uint8).reshape(2, 1080, 1920, 3)
        for label, frame in zip(('mid', 'last'), frames):
            suffix = '1x' if video['playback_speed'] == 1 else '0p5x'
            output = QA / f'decoded_{label}_{suffix}.png'
            Image.fromarray(frame).save(output)
            result[f'decoded_{label}_frame'] = str(output)
        media.append(result)
    baseline = read(QA / 'independent-original-files-baseline.json')
    differences = []
    for path, saved in baseline['files'].items():
        p = Path(path)
        if not p.is_file() or p.stat().st_size != saved['bytes'] or sha(p) != saved['sha256']:
            differences.append(path)
    assert not differences, differences
    report = {'scope': 'Read-only independent source,333frame-row and2video decode audit. No physics rerun.',
              'source_index_sha256': sha(OUT / 'index.json'), 'renderer_sha256': sha(index['renderer']),
              'cases': checks, 'videos': media, 'physics_steps_executed': 0,
              'original_file_preservation': {'file_count': baseline['file_count'], 'bytes': baseline['total_bytes'], 'all_original_sha256_match': True, 'differences': differences},
              'all_automated_checks_passed': True, 'assistant_visual_review': 'Pending final decoded-last-frame review; previews already inspected.'}
    path = QA / 'independent-final-media-audit.json'
    path.write_text(json.dumps(report, ensure_ascii=False, indent=2) + '\n')
    print(json.dumps({'all_automated_checks_passed': True, 'frame_rows_checked': 333, 'decoded_videos': 2,
                      'original_files_preserved': baseline['file_count'], 'output': str(path)}, indent=2))


if __name__ == '__main__':
    main()
