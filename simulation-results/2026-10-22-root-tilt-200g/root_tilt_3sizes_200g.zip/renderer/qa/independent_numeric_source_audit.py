#!/usr/bin/env python3
"""Read original selected states and validate tilt endpoints; never integrates."""
from pathlib import Path
import hashlib
import json

import mujoco
import numpy as np

ROOT = Path('/workspace/shadow-lift-sweep-200g')
OUT = ROOT / 'height-diagnosis-20261022/tilt-overview/qa'
EXPECTED = {
    5: [2.765036, 4.634176, -6.513609, 92.800207],
    90: [2.118286, 5.005167, -5.689621, 94.652095],
    100: [1.935868, 4.918270, -5.225135, 94.821749],
}


def read(path):
    return json.loads(Path(path).read_text())


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def normalized(q):
    q = np.asarray(q, dtype=np.float64)
    return q / np.linalg.norm(q)


def matrix(q):
    m = np.empty(9)
    mujoco.mju_quat2Mat(m, normalized(q))
    return m.reshape(3, 3)


def angle(a, b):
    return float(np.degrees(2 * np.arccos(np.clip(abs(normalized(a) @ normalized(b)), 0, 1))))


def main():
    selection_path = ROOT / 'animations/selection.json'
    selected = {r['diameter_mm']: r for r in read(selection_path)['representatives']}
    diagnosis_path = ROOT / 'height-diagnosis-20261022/kinematics-decomposition.json'
    diagnosis = read(diagnosis_path)
    cases = {r['diameter_mm']: r['200g'] for r in diagnosis['cases']}
    rows = []
    for d, expected in EXPECTED.items():
        selected_row, source = selected[d], cases[d]
        assert selected_row['metrics'] == source['metrics']
        assert selected_row['trace'] == source['trace']
        record = read(source['metrics'])
        for key, path in [('metrics_sha256', source['metrics']), ('trace_sha256', source['trace']),
                          ('model_xml_sha256', source['model_xml']), ('input_grasp_sha256', source['input'])]:
            assert sha(path) == source['source_sha256'][key]
        assert sha(source['metrics']) == selected_row['metrics_sha256']
        assert sha(source['trace']) == selected_row['trace_sha256']
        assert record['config']['mass_kg'] == .2
        model = mujoco.MjModel.from_xml_path(source['model_xml'])
        free = int(mujoco.mjtJoint.mjJNT_FREE)
        hand_body = int(model.body('hand-world').id)
        joints = [j for j in range(model.njnt) if int(model.jnt_bodyid[j]) == hand_body and int(model.jnt_type[j]) == free]
        assert len(joints) == 1 and int(model.body_parentid[hand_body]) == 0
        joint = joints[0]
        adr = int(model.jnt_qposadr[joint])
        assert model.joint(joint).name == 'hand_freejoint'
        welds = []
        for eq in range(model.neq):
            bodies = [int(model.eq_obj1id[eq]), int(model.eq_obj2id[eq])]
            if int(model.eq_type[eq]) == int(mujoco.mjtEq.mjEQ_WELD) and hand_body in bodies:
                other = bodies[1] if bodies[0] == hand_body else bodies[0]
                slot = int(model.body_mocapid[other])
                if slot >= 0:
                    welds.append((eq, slot))
        assert len(welds) == 1
        weld, slot = welds[0]
        assert np.allclose(model.eq_data[weld, 6:10], [1, 0, 0, 0], rtol=0, atol=1e-12)
        assert np.isclose(model.body_subtreemass[source['coordinate_mapping_verified_from_model']['object_body_id']], .2, rtol=1e-6)
        with np.load(source['trace'], allow_pickle=False) as z:
            t = z['time_s'].astype(np.float64)
            phases = [str(s) for s in z['phase_names']]
            def at(time, phase):
                indices = np.flatnonzero((abs(t - time) < 1e-5) & (z['phase_id'] == phases.index(phase)))
                assert len(indices)
                return int(indices[-1])
            first, lift, held = at(2.7, 'loaded_hold'), at(3.7, 'lift'), at(13.7, 'release_open')
            R0, R1 = matrix(z['qpos'][lift, adr + 3:adr + 7]), matrix(z['qpos'][held, adr + 3:adr + 7])
            o0 = np.asarray(record['loaded_object_pose'][:3], dtype=float)
            h0 = z['qpos'][lift, adr:adr + 3].astype(float)
            r0 = R0.T @ (o0 - h0)
            root_angle = angle(z['qpos'][lift, adr + 3:adr + 7], z['qpos'][held, adr + 3:adr + 7])
            error = angle(z['qpos'][held, adr + 3:adr + 7], z['mocap_quat'][held, slot])
            rotation_z = float(((R1 - R0) @ r0)[2] * 1000)
            object_rise = float((record['held_object_pose'][2] - record['initial_object_pose'][2]) * 1000)
            actual = [root_angle, error, rotation_z, object_rise]
            assert np.allclose(actual, expected, rtol=0, atol=1e-6), (d, actual, expected)
            data = mujoco.MjData(model)
            data.qpos[:] = z['qpos'][held]
            data.mocap_pos[:] = z['mocap_pos'][held]
            data.mocap_quat[:] = z['mocap_quat'][held]
            mujoco.mj_forward(model, data)
            assert np.allclose(data.xmat[hand_body].reshape(3, 3), R1, rtol=0, atol=1e-7)
            assert np.allclose(data.xpos[hand_body], z['qpos'][held, adr:adr + 3], rtol=0, atol=1e-12)
            target_quats = z['mocap_quat'][lift:held + 1, slot]
            max_target_angle = max(angle(q, target_quats[0]) for q in target_quats)
            assert max_target_angle < 1e-5
            window = np.flatnonzero((t >= 2.7 - 1e-5) & (t <= 13.7 + 1e-5))
            rows.append({'diameter_mm': d, 'metrics': source['metrics'], 'trace': source['trace'],
                         'model_xml': source['model_xml'], 'source_sha256': source['source_sha256'],
                         'hand_joint_id': joint, 'hand_joint_name': model.joint(joint).name,
                         'hand_qpos_address': adr, 'mocap_slot': slot, 'weld_id': weld,
                         'window_start_time_s': float(t[first]), 'lift_reference_time_s': float(t[lift]),
                         'window_end_time_s': float(t[held]), 'window_start_index': first,
                         'lift_reference_index': lift, 'window_end_index': held,
                         'window_saved_states_including_phase_duplicates': len(window),
                         'terminal_source_phase': phases[int(z['phase_id'][held])],
                         'terminal_phase_interpretation': 'Exact hold-end/pre-release state; before any release integration.',
                         'root_rotation_relative_lift_start_deg': root_angle,
                         'root_to_mocap_target_error_deg': error,
                         'root_rotation_lever_world_z_mm': rotation_z,
                         'actual_object_rise_mm': object_rise,
                         'maximum_target_rotation_during_lift_and_hold_deg': max_target_angle,
                         'mocap_weld_relative_quaternion_identity': True,
                         'compiled_object_mass_kg': float(model.body_subtreemass[source['coordinate_mapping_verified_from_model']['object_body_id']]),
                         'checks_passed': True})
    report = {'scope': 'Independent read-only numerical/model/source QA for three-column original200g tilt visualization',
              'physics_steps_executed': 0, 'selection_sha256': sha(selection_path),
              'kinematics_diagnosis_sha256': sha(diagnosis_path), 'cases': rows,
              'all_checks_passed': True,
              'display_requirement': 'Physical replay uses original qpos unamplified. Any10x angular illustration must be separately and explicitly labelled as a schematic, not actual physics.'}
    out = OUT / 'independent-numeric-source-audit.json'
    out.write_text(json.dumps(report, ensure_ascii=False, indent=2) + '\n')
    print(json.dumps({'all_checks_passed': True, 'cases': [{k: r[k] for k in ['diameter_mm', 'root_rotation_relative_lift_start_deg', 'root_to_mocap_target_error_deg', 'root_rotation_lever_world_z_mm', 'actual_object_rise_mm']} for r in rows], 'output': str(out)}, indent=2))


if __name__ == '__main__':
    main()
