#!/usr/bin/env python3
"""Compare fresh 100 g and 200 g trials paired by identical candidate controls.

Read-only on both evaluation trees. Success labels must already include the
same final sampled-lift protocol; this script never applies or changes labels.
"""
from __future__ import annotations

import argparse
from collections import Counter
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import re

import numpy as np

DIAMETERS = [1, 5, 10, 20, 30, 40, 50, 60, 70, 80, 90, 100]
CONTROL_FIELDS = ["time_s", "phase_id", "ctrl", "mocap_pos", "mocap_quat"]


def sha256(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def read(path, default=None):
    path = Path(path)
    return json.loads(path.read_text()) if path.is_file() else default


def candidate_identity(record):
    # Path suffix disambiguates any byte-identical proposal duplicated by quota
    # padding. Both SHA and relative identity must match in the paired pools.
    return str(record["input_sha256"]) + "::" + "/".join(Path(record["input"]).parts[-3:])


def load_records(root):
    result, duplicates = {}, []
    for path in sorted(root.rglob("metrics.json")):
        record = read(path)
        if record.get("schema_version") != 1 or "hold_criteria" not in record:
            continue
        key = candidate_identity(record)
        if key in result:
            duplicates.append({"identity": key, "metrics": str(path)})
        result[key] = {**record, "metrics_path": str(path.resolve()), "metrics_sha256": sha256(path)}
    return result, duplicates


def control_digest(record):
    trace = Path(record["trace"])
    digest = hashlib.sha256()
    arrays = {}
    with np.load(trace, allow_pickle=False) as archive:
        # Candidate targets are fixed through lift and hold. Release retreat is
        # computed by the unchanged policy from the measured held-object pose,
        # so load-dependent retreat outputs are expected and are not a tuning
        # change. Compare the planned phases, not that feedback response.
        phase_names = [str(value) for value in archive["phase_names"]]
        release_id = phase_names.index("release_open")
        planned = np.asarray(archive["phase_id"]) < release_id
        for key in CONTROL_FIELDS:
            array = np.asarray(archive[key])[planned]
            arrays[key] = array
            digest.update(key.encode())
            digest.update(str(array.dtype).encode())
            digest.update(str(array.shape).encode())
            digest.update(array.tobytes())
    return digest.hexdigest(), arrays


def equal_protocol(a, b):
    left, right = dict(a["config"]), dict(b["config"])
    left.pop("mass_kg", None)
    right.pop("mass_kg", None)
    basic = left == right and all(a.get(k) == b.get(k) for k in ("dt_s", "gravity_enabled", "friction", "object_freejoint", "hand_root", "evaluator_sha256"))
    sampled = a.get("motion_protocol", {}).get("thresholds") == b.get("motion_protocol", {}).get("thresholds")
    scope = a.get("motion_protocol", {}).get("sampled_scope") == b.get("motion_protocol", {}).get("sampled_scope")
    return basic and sampled and scope


def finite_value(value):
    try:
        number = float(value)
        return number if np.isfinite(number) else None
    except (TypeError, ValueError):
        return None


def delta(a, b, key, multiplier=1):
    old, new = finite_value(a.get(key)), finite_value(b.get(key))
    return None if old is None or new is None else multiplier * (new - old)


def transition(records, key):
    counts = Counter((bool(row["baseline"][key]), bool(row["new"][key])) for row in records)
    return {"pass_both": counts[(True, True)], "pass_to_fail": counts[(True, False)], "fail_to_pass": counts[(False, True)], "fail_both": counts[(False, False)]}


def selected_rows(root):
    index = read(root.parent / "animations/index.json", {})
    return {int(row["diameter_mm"]): {"template": row.get("template"), "input": row.get("input"), "input_sha256": row.get("input_sha256"), "status": row.get("status"), "metrics": row.get("metrics")} for row in index.get("representatives", [])}


def compare(args):
    baseline_root, new_root = args.baseline_root.resolve(), args.new_root.resolve()
    baseline, duplicate_old = load_records(baseline_root)
    new, duplicate_new = load_records(new_root)
    shared = sorted(set(baseline) & set(new))
    protocol_errors, input_errors, mass_errors, control_errors = [], [], [], []
    pairs = []
    for identity in shared:
        old, current = baseline[identity], new[identity]
        input_valid = sha256(old["input"]) == old["input_sha256"] and sha256(current["input"]) == current["input_sha256"] and old["input_sha256"] == current["input_sha256"]
        if not input_valid:
            input_errors.append(identity)
        if not equal_protocol(old, current):
            protocol_errors.append(identity)
        mass_valid = abs(float(old["config"]["mass_kg"]) - .1) < 1e-9 and abs(float(current["config"]["mass_kg"]) - .2) < 1e-9 and abs(float(old["object_mass_kg"]) - .1) < 1e-5 and abs(float(current["object_mass_kg"]) - .2) < 2e-5
        if not mass_valid:
            mass_errors.append(identity)
        old_digest, old_controls = control_digest(old)
        new_digest, new_controls = control_digest(current)
        same_fields = {key: old_controls[key].shape == new_controls[key].shape and bool(np.array_equal(old_controls[key], new_controls[key], equal_nan=True)) for key in CONTROL_FIELDS}
        if not all(same_fields.values()):
            control_errors.append({"identity": identity, "fields": same_fields})
        d = int(re.search(r"_(\d+)$", old["scene_id"]).group(1))
        fields = ["lift_hold_passed", "release_passed", "full_sequence_passed", "measured_object_lift_mm", "minimum_hold_height_gain_m", "maximum_expected_position_error_during_hold_m", "maximum_closure_rotation_during_hold_deg", "postlift_hold_maximum_drift_m", "postlift_hold_maximum_rotation_deg", "loaded_hold_contact_force_sum_mean_N", "loaded_hold_peak_single_contact_normal_force_N", "object_mass_kg"]
        def scope(record):
            return {"input": record["input"], "metrics": record["metrics_path"], "metrics_sha256": record["metrics_sha256"], "trace": record["trace"], **{key: record.get(key) for key in fields}, "base_evaluator_outcomes": record.get("base_evaluator_outcomes"), "motion_protocol_passed": record.get("motion_protocol", {}).get("passed")}
        pairs.append({"identity": identity, "input_sha256": old["input_sha256"], "relative_candidate": "/".join(Path(old["input"]).parts[-3:]), "diameter_mm": d, "template": old.get("template"), "baseline": scope(old), "new": scope(current), "same_input_verified": input_valid, "same_protocol_except_mass": identity not in protocol_errors, "control_trace_arrays_identical": same_fields, "baseline_control_trace_sha256": old_digest, "new_control_trace_sha256": new_digest,
                      "new_minus_baseline": {"actual_object_lift_mm": delta(old, current, "measured_object_lift_mm"), "minimum_hold_lift_margin_above_95mm": delta(old, current, "minimum_hold_height_gain_m", 1000), "maximum_expected_position_error_mm": delta(old, current, "maximum_expected_position_error_during_hold_m", 1000), "position_error_margin_to_20mm": None if delta(old, current, "maximum_expected_position_error_during_hold_m", 1000) is None else -delta(old, current, "maximum_expected_position_error_during_hold_m", 1000), "maximum_closure_rotation_deg": delta(old, current, "maximum_closure_rotation_during_hold_deg"), "posthold_drift_mm": delta(old, current, "postlift_hold_maximum_drift_m", 1000), "clamp_normal_force_mean_N": delta(old, current, "loaded_hold_contact_force_sum_mean_N")}})
    old_audit = read(baseline_root.parent / "motion-protocol-summary.json", {})
    new_audit = read(new_root.parent / "motion-protocol-summary.json", {})
    missing_protocol = [identity for identity in shared if "motion_protocol" not in baseline[identity] or "motion_protocol" not in new[identity]]
    accounting = len(baseline) == len(new) == len(shared) == args.expected_candidates and not duplicate_old and not duplicate_new and not input_errors and not protocol_errors and not mass_errors and not control_errors and not missing_protocol and bool(old_audit.get("applied")) and bool(new_audit.get("applied")) and old_audit.get("candidate_count") == new_audit.get("candidate_count") == args.expected_candidates
    old_selected, new_selected = selected_rows(baseline_root), selected_rows(new_root)
    per_diameter = []
    for d in DIAMETERS:
        rows = [row for row in pairs if row["diameter_mm"] == d]
        per_diameter.append({"diameter_mm": d, "paired_candidates": len(rows), "baseline_lift_hold_passed": sum(bool(row["baseline"]["lift_hold_passed"]) for row in rows), "new_lift_hold_passed": sum(bool(row["new"]["lift_hold_passed"]) for row in rows), "baseline_full_sequence_passed": sum(bool(row["baseline"]["full_sequence_passed"]) for row in rows), "new_full_sequence_passed": sum(bool(row["new"]["full_sequence_passed"]) for row in rows), "lift_hold_transitions": transition(rows, "lift_hold_passed"), "full_sequence_transitions": transition(rows, "full_sequence_passed"), "baseline_displayed_representative": old_selected.get(d), "new_displayed_representative": new_selected.get(d)})
    result = {"schema_version": 1, "generated_at_utc": datetime.now(timezone.utc).isoformat(), "baseline_root": str(baseline_root), "new_root": str(new_root), "baseline_mass_kg": .1, "new_mass_kg": .2,
              "design": "Matched candidate control targets and identical controller logic. Candidate NPY files are byte-identical; recorded approach/closure/clamp/lift/hold targets are compared at matching physical times. Only runtime object mass is changed. The unchanged release policy computes retreat from measured held-object pose, so its realized retreat direction can differ with load. New success and display choices come from fresh 200 g physics, without new controller tuning or mass-specific synthesis.",
              "control_array_comparison_scope": "Approach through end of postlift hold, excluding release. Feedback-dependent release-retreat outputs are intentionally not required to be frame-identical.",
              "pairing": "Both input SHA-256 and template/scene/filename suffix must match. The path suffix disambiguates any duplicate numerical payload.", "expected_candidates": args.expected_candidates, "paired_candidates": len(pairs),
              "integrity": {"complete_strict_matched_control_comparison": accounting, "baseline_duplicates": duplicate_old, "new_duplicates": duplicate_new, "missing_new_candidates": sorted(set(baseline) - set(new)), "unexpected_new_candidates": sorted(set(new) - set(baseline)), "candidate_hash_errors": input_errors, "protocol_mismatches_except_mass": protocol_errors, "compiled_mass_errors": mass_errors, "recorded_control_array_mismatches": control_errors, "missing_final_protocol": missing_protocol, "baseline_motion_audit_applied": old_audit.get("applied"), "new_motion_audit_applied": new_audit.get("applied")},
              "totals": {"baseline_lift_hold_passed": sum(bool(row["baseline"]["lift_hold_passed"]) for row in pairs), "new_lift_hold_passed": sum(bool(row["new"]["lift_hold_passed"]) for row in pairs), "baseline_full_sequence_passed": sum(bool(row["baseline"]["full_sequence_passed"]) for row in pairs), "new_full_sequence_passed": sum(bool(row["new"]["full_sequence_passed"]) for row in pairs), "lift_hold_transitions": transition(pairs, "lift_hold_passed"), "full_sequence_transitions": transition(pairs, "full_sequence_passed")},
              "per_diameter": per_diameter, "pairs": pairs,
              "sampling_limit": "Lift stability uses the same saved trace sampling and exact boundaries in both loads; postlift-hold gates use every physics step. This comparison adds no observation between saved lift samples."}
    if not accounting and not args.allow_partial:
        raise SystemExit("Paired load comparison is incomplete or not strictly mass-only; use --allow-partial only for labeled diagnostics, then inspect integrity fields")
    return result


def markdown(result):
    t = result["totals"]
    lines = ["# 同一控制候选的 100 g / 200 g 配对比较", "", "本比较复用同一组候选控制目标与相同控制逻辑，200 g 条件重新进行全部动力学仿真。没有把 100 g 的成功标签或轨迹当作 200 g 结果，也没有为 200 g 重新调参或合成新的控制。释放退离方向由同一策略根据实际持握物体位姿计算，因此允许随负载响应变化，不声称所有阶段的每帧输出完全相同。", "", f"严格核对：`{result['integrity']['complete_strict_matched_control_comparison']}`；配对 {result['paired_candidates']} / {result['expected_candidates']} 个候选。逐文件 SHA、接近至持握结束的同时间控制/mocap 数组、除质量外的协议、冻结评价器和实际模型质量均核对；释放阶段的反馈响应不要求逐帧恒同。", "", "| 直径 mm | 配对候选 | 100 g 抬升持握通过 | 200 g 抬升持握通过 | 100 g 全流程通过 | 200 g 全流程通过 | 全流程通过→失败 | 失败→通过 |", "|---|---:|---:|---:|---:|---:|---:|---:|"]
    for row in result["per_diameter"]:
        lines.append(f"| {row['diameter_mm']} | {row['paired_candidates']} | {row['baseline_lift_hold_passed']} | {row['new_lift_hold_passed']} | {row['baseline_full_sequence_passed']} | {row['new_full_sequence_passed']} | {row['full_sequence_transitions']['pass_to_fail']} | {row['full_sequence_transitions']['fail_to_pass']} |")
    lines += [f"| 合计 | {result['paired_candidates']} | {t['baseline_lift_hold_passed']} | {t['new_lift_hold_passed']} | {t['baseline_full_sequence_passed']} | {t['new_full_sequence_passed']} | {t['full_sequence_transitions']['pass_to_fail']} | {t['full_sequence_transitions']['fail_to_pass']} |", "", "个别候选在增重后从失败变为通过也会如实保留；接触系统的离散模式变化使结果不必逐个单调，但这不构成更大负载普遍更容易的结论。逐候选实际升高、最小持握高度余量、最大位置/角度误差、持握漂移和夹紧力变化见 [load-comparison.json](load-comparison.json)。", "", "每个负载条件的展示样本分别从其全部实际结果选择，因此代表视频可能更换抓型或候选；候选池与输入控制本身没有改变。比较表统计全部配对候选，并不只比较两段最好的视频。", "", "提升稳定性沿用两轮相同的保存状态采样复核与阶段边界；到位后持握按原来的每个物理步检查。采样比较不能证明未保存的提升子步。", ""]
    return "\n".join(lines)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--baseline-root", type=Path, default=Path("/workspace/shadow-lift-sweep/lift-evaluation"))
    parser.add_argument("--new-root", type=Path, default=Path("/workspace/shadow-lift-sweep-200g/lift-evaluation"))
    parser.add_argument("--outdir", type=Path, default=Path("/workspace/shadow-lift-sweep-200g"))
    parser.add_argument("--expected-candidates", type=int, default=314)
    parser.add_argument("--allow-partial", action="store_true")
    args = parser.parse_args()
    result = compare(args)
    args.outdir.mkdir(parents=True, exist_ok=True)
    (args.outdir / "load-comparison.json").write_text(json.dumps(result, ensure_ascii=False, indent=2) + "\n")
    (args.outdir / "LOAD_COMPARISON.md").write_text(markdown(result))
    print(json.dumps({"paired_candidates": result["paired_candidates"], "strict_matched_control_comparison": result["integrity"]["complete_strict_matched_control_comparison"], "totals": result["totals"]}, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
