#!/usr/bin/env python3
"""Verify final 200 g animation source bindings and decode every delivery video."""
from __future__ import annotations

import argparse
from concurrent.futures import ThreadPoolExecutor
import hashlib
import json
from pathlib import Path
import subprocess

import numpy as np


def sha256(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--animation-root", type=Path, default=Path("/workspace/shadow-lift-sweep-200g/animations"))
    args = parser.parse_args()
    folder = args.animation_root.resolve()
    index = json.loads((folder / "index.json").read_text())
    assert index["individual_videos"] == 12
    assert {row["diameter_mm"] for row in index["representatives"]} == {1, 5, 10, 20, 30, 40, 50, 60, 70, 80, 90, 100}
    bindings = []
    renderer_sha = sha256(folder.parent / "render_sweep.py")
    for row in index["representatives"]:
        record = json.loads(Path(row["metrics"]).read_text())
        assert sha256(row["metrics"]) == row["metrics_sha256"]
        assert sha256(row["input"]) == row["input_sha256"] == record["input_sha256"]
        assert sha256(row["trace"]) == row["trace_sha256"] == record["motion_protocol"]["trace_sha256"]
        assert sha256(row["video"]) == row["video_sha256"]
        assert row["renderer_sha256"] == renderer_sha
        with np.load(row["trace"], allow_pickle=False) as trace:
            assert row["final_trace_index"] == len(trace["time_s"]) - 1
            assert row["final_trace_time_s"] == float(trace["time_s"][-1])
        assert row["displayed_time_source"] == "Recorded trace timestamp, not video grid"
        config = record["config"]
        assert config["mass_kg"] == 0.2
        assert config["lift_s"] == config["postlift_hold_s"] == 5.0
        assert config["lift_m"] == 0.1 and config["target_lift_tolerance_m"] == 0.005
        assert abs(record["object_mass_kg"] - 0.2) < 1e-6
        if not row.get("diagnostic_card"):
            assert abs(row["rendered_object_mass_kg"] - record["object_mass_kg"]) < 1e-6
        assert row["motion_protocol_present"]
        assert (row["status"] == "full_sequence_pass") == bool(record["full_sequence_passed"])
        if record["full_sequence_passed"]:
            assert record["motion_protocol"]["passed"]
            assert record["minimum_hold_height_gain_m"] >= .095 - 1e-7
            assert record["maximum_hold_height_gain_m"] <= .105 + 1e-7
        bindings.append({"diameter_mm": row["diameter_mm"], "full_sequence_passed": bool(record["full_sequence_passed"]), "recorded_mass_kg": record["object_mass_kg"], "rendered_mass_kg": row.get("rendered_object_mass_kg"), "diagnostic_card": bool(row.get("diagnostic_card")), "input_sha256": row["input_sha256"], "metrics_sha256": row["metrics_sha256"], "trace_sha256": row["trace_sha256"]})
    assert sha256(index["montage"]["path"]) == index["montage"]["sha256"]
    paths = [row["video"] for row in index["representatives"]] + [index["montage"]["path"]]

    def decode(path):
        subprocess.run(["ffmpeg", "-nostdin", "-hide_banner", "-loglevel", "error", "-xerror", "-threads", "1", "-i", path, "-f", "null", "-"], check=True, capture_output=True, timeout=60)
        info = json.loads(subprocess.check_output(["ffprobe", "-v", "error", "-count_frames", "-show_entries", "stream=width,height,r_frame_rate,avg_frame_rate,nb_frames,nb_read_frames", "-show_entries", "format=duration", "-of", "json", path], text=True))
        stream = info["streams"][0]
        expected = index["montage"] if path == index["montage"]["path"] else next(row for row in index["representatives"] if row["video"] == path)
        assert (stream["width"], stream["height"]) == (1280, 720)
        assert stream["r_frame_rate"] == stream["avg_frame_rate"] == "10/1"
        assert int(stream["nb_read_frames"]) == int(stream["nb_frames"]) == expected["frames"]
        assert abs(float(info["format"]["duration"]) - expected["duration_s"]) < 1e-6
        return {"path": path, "sha256": sha256(path), "fully_decoded": True, **info}

    with ThreadPoolExecutor(max_workers=2) as pool:
        files = list(pool.map(decode, paths))
    report = {"benchmark_mass_kg": 0.2, "individual_videos": 12, "montage_videos": 1, "diagnostic_cards": sum(row["diagnostic_card"] for row in bindings), "all_selected_metrics_input_trace_hashes_bound": True, "all_selected_metrics_use_final_motion_protocol": True, "all_rendered_model_masses_match_200g_metrics": True, "all_final_recorded_states_included": True, "all_videos_hd_1280x720_10fps": True, "all_videos_exact_cfr_frame_count_duration": True, "all_representatives_match_frozen_renderer_sha256": True, "full_sequence_pass_representatives": sum(row["full_sequence_passed"] for row in bindings), "representatives": bindings, "files": files}
    (folder / "verification.json").write_text(json.dumps(report, indent=2) + "\n")
    print(json.dumps({key: value for key, value in report.items() if key not in ("files", "representatives")}, indent=2))


if __name__ == "__main__":
    main()
