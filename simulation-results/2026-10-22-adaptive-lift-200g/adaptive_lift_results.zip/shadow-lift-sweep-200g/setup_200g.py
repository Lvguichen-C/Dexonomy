#!/usr/bin/env python3
"""Freeze the same candidate controls for a fresh 200 g comparison.

Copies candidate NPY files byte-for-byte. No geometry, scene path, numeric array,
controller, source experiment, or old evaluation result is changed/reused.
Only the new descriptive asset manifest records the 0.2 kg runtime mass override.
"""
from __future__ import annotations

import argparse
from collections import Counter
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import shutil


DIAMETERS_MM = [1, 5, 10, 20, 30, 40, 50, 60, 70, 80, 90, 100]


def sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def write_json(path: Path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, indent=2) + "\n")


def copy_identical(source: Path, target: Path):
    source_hash = sha256(source)
    target.parent.mkdir(parents=True, exist_ok=True)
    if target.exists():
        if sha256(target) != source_hash:
            raise RuntimeError(f"Refusing to overwrite differing destination: {target}")
    else:
        shutil.copy2(source, target)
    target_hash = sha256(target)
    assert source_hash == target_hash
    return {"source": str(source.resolve()), "destination": str(target.resolve()),
            "source_sha256": source_hash, "destination_sha256": target_hash,
            "bytes": target.stat().st_size, "byte_identical": True}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--source-root", type=Path, default=Path("/workspace/shadow-lift-sweep"))
    parser.add_argument("--root", type=Path, default=Path(__file__).resolve().parent)
    parser.add_argument("--no-initializations", action="store_true")
    args = parser.parse_args()
    source_root, root = args.source_root.resolve(), args.root.resolve()
    source_experiment = source_root / "output/diameter_sweep_shadow"
    destination = root / "output/diameter_sweep_200g_shadow"
    if source_root == root or source_root in root.parents:
        raise SystemExit("The 200 g experiment must be isolated from the 100 g source tree")
    root.mkdir(parents=True, exist_ok=True)
    source_manifest_path = source_root / "assets-manifest.json"
    source_manifest_hash = sha256(source_manifest_path)
    geometry = json.loads(source_manifest_path.read_text())
    if geometry["diameters_mm"] != DIAMETERS_MM or geometry["height_to_diameter_ratio"] != 4:
        raise SystemExit("Source geometry does not match the frozen 12-diameter height=4d experiment")
    if geometry["target_mass_kg"] != 0.1:
        raise SystemExit("Expected a 100 g source geometry manifest")
    stage_specs = [("grasp_data",314)]
    if not args.no_initializations:
        stage_specs.append(("init_data",520))
    source_sets = {}
    for stage, expected in stage_specs:
        files = sorted((source_experiment/stage).rglob("*.npy"))
        if len(files) != expected:
            raise SystemExit(f"Frozen source {stage} count is {len(files)}, expected {expected}")
        source_sets[stage] = files
    files, counts = [], {}
    for stage, _ in stage_specs:
        stage_counts = Counter()
        for source in source_sets[stage]:
            relative = source.relative_to(source_experiment)
            row = copy_identical(source, destination/relative)
            row.update(stage=stage, relative_path=str(relative), unchanged_fields="All bytes, including every numeric value and scene_path")
            files.append(row)
            stage_counts[source.parent.name] += 1
        counts[stage] = {"total":len(source_sets[stage]), "per_scene":dict(sorted(stage_counts.items()))}
        target_files = list((destination/stage).rglob("*.npy"))
        if len(target_files) != len(source_sets[stage]):
            raise SystemExit(f"Unexpected extra files in isolated {stage}; refusing to mix pools")
    # The geometry asset files remain referenced read-only at their original
    # paths. This separate manifest changes descriptive mass fields only.
    manifest = json.loads(source_manifest_path.read_text())
    manifest["target_mass_kg"] = 0.2
    manifest["mass_policy"] = "The same 0.2 kg mass is applied at every diameter by the fresh evaluator; geometry and candidate controls are frozen from the 100 g experiment. Density varies with volume, not a common real material."
    manifest["mass_applied_by"] = "Frozen evaluate_lifts.py --mass 0.2; prepare_scene sets density before compiling the new free-object model"
    manifest["source_geometry_manifest"] = str(source_manifest_path)
    manifest["source_geometry_manifest_sha256"] = source_manifest_hash
    manifest["source_manifest_mass_kg"] = 0.1
    manifest["runtime_mass_override_kg"] = 0.2
    manifest["geometry_assets_modified"] = False
    manifest["candidate_npy_fields_modified"] = []
    for scene in manifest["scenes"]:
        scene["source_manifest_target_mass_kg"] = scene["target_mass_kg"]
        scene["target_mass_kg"] = 0.2
        scene["required_density_kg_m3"] *= 2.0
        scene["runtime_mass_override_kg"] = 0.2
    write_json(root/"assets-manifest.json",manifest)
    plan_records = []
    for name in ("adaptive-plan.json","adaptive-jobs.json"):
        source = source_root/name
        if source.is_file():
            row = copy_identical(source,root/name)
            row["use"] = "Frozen geometry-based candidate-selection provenance only; any 0.1kg field describes the source experiment, not the new runtime mass"
            plan_records.append(row)
    evaluator = source_root/"evaluate_lifts.py"
    pool_fingerprint = hashlib.sha256("\n".join(
        row["relative_path"]+":"+row["source_sha256"] for row in files if row["stage"]=="grasp_data").encode()).hexdigest()
    provenance = {
        "generated_at_utc":datetime.now(timezone.utc).isoformat(),
        "comparison":"Fresh 200g evaluation of the exact same 314 synthesis-filtered candidate controls as 100g",
        "source_root":str(source_root), "source_experiment":str(source_experiment),
        "destination_root":str(root), "destination_experiment":str(destination),
        "diameters_mm":DIAMETERS_MM,"height_to_diameter_ratio":4,
        "source_mass_kg":0.1,"target_mass_kg":0.2,"runtime_mass_override_kg":0.2,
        "source_geometry_manifest_sha256":source_manifest_hash,
        "new_asset_manifest_sha256":sha256(root/"assets-manifest.json"),
        "candidate_control_pool_fingerprint_sha256":pool_fingerprint,
        "counts":counts,"all_candidate_files_byte_identical":True,
        "candidate_scene_paths_changed":False,"numeric_arrays_changed":False,
        "old_assets_changed":False,"old_experiment_changed":False,
        "old_outcomes_reused":False,"physics_launched_by_setup":False,
        "reuse_rationale":"Geometry is unchanged. These controls were synthesized with fixed objects and force-closure target external wrench zero. Frozen-control comparison isolates the mass change; it is not a new optimization of maximum 200g hand capability.",
        "new_evaluation_required":"All 314 candidates must be evaluated again with gravity on and actual compiled mass 0.2kg; no 100g success state, trace, or label is evidence of a 200g result",
        "protocol":{"mass_kg":0.2,"lift_distance_m":0.1,"lift_duration_s":5.0,"loaded_hold_duration_s":1.0,"postlift_hold_duration_s":5.0,"release_after_hold":True},
        "evaluator":{"path":str(evaluator),"sha256":sha256(evaluator),"modified_by_setup":False,"mass_cli":"--mass 0.2"},
        "adaptive_plans":plan_records,"files":files,
    }
    write_json(root/"setup-provenance.json",provenance)
    assert sha256(source_manifest_path)==source_manifest_hash
    print(json.dumps({"ready":True,"root":str(root),"experiment":str(destination),"counts":counts,
        "all_files_byte_identical":True,"mass_kg":0.2,"old_outcomes_reused":False,
        "pool_fingerprint_sha256":pool_fingerprint,"provenance":str(root/"setup-provenance.json")},indent=2))


if __name__=="__main__":
    main()
