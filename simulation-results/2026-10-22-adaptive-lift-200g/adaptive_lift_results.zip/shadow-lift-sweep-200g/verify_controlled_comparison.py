#!/usr/bin/env python3
"""Read-only verification of the 100 g to 200 g controlled comparison.

Candidate bytes must be identical. Evaluation protocol and source must match;
only object mass/density changes. This tool never edits candidates or metrics.
"""
from __future__ import annotations

import argparse
from collections import Counter
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import xml.etree.ElementTree as ET


FROZEN_EVALUATOR_SHA = "164fd4e4eab1472a7cf4eb92bf5abf88747f78c1df58b19a0667ce8ce75f5d50"


def sha256(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def read(path):
    return json.loads(Path(path).read_text())


def inventory(root):
    return {str(path.relative_to(root)): path for path in root.rglob("*.npy")}


def metrics(root):
    rows, errors = [], []
    for path in root.rglob("metrics.json"):
        try:
            row = read(path)
            if "hold_criteria" in row:
                rows.append((path, row))
        except Exception as error:
            errors.append({"path": str(path), "error": str(error)})
    return rows, errors


def construction_xml(folder):
    preserved = folder / "construction_model.xml"
    return preserved if preserved.is_file() else folder / "model.xml"


def normalized_model(path):
    tree = ET.fromstring(path.read_bytes())
    densities = []
    for body in tree.iter("body"):
        if body.get("name", "").startswith("obj-"):
            for geom in body.iter("geom"):
                if "density" in geom.attrib:
                    densities.append(float(geom.attrib.pop("density")))
    return ET.tostring(tree, encoding="utf-8"), densities


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root", type=Path, default=Path("/workspace/shadow-lift-sweep-200g"))
    parser.add_argument("--reference-root", type=Path, default=Path("/workspace/shadow-lift-sweep"))
    parser.add_argument("--grasp-root", type=Path)
    parser.add_argument("--reference-grasp-root", type=Path)
    parser.add_argument("--evaluation-root", type=Path)
    parser.add_argument("--expected-candidates", type=int, default=314)
    parser.add_argument("--require-complete", action="store_true")
    args = parser.parse_args()
    old_grasps = args.reference_grasp_root or args.reference_root / "output/diameter_sweep_shadow/grasp_data"
    new_grasps = args.grasp_root or args.root / "output/diameter_sweep_200g_shadow/grasp_data"
    new_evaluation = args.evaluation_root or args.root / "lift-evaluation"
    old_evaluation = args.reference_root / "lift-evaluation"
    original, copied = inventory(old_grasps), inventory(new_grasps)
    issues = []
    if set(original) != set(copied):
        issues.append({"candidate_set_mismatch": {"missing": sorted(set(original) - set(copied)), "extra": sorted(set(copied) - set(original))}})
    if len(original) != args.expected_candidates:
        issues.append({"unexpected_reference_count": len(original), "expected": args.expected_candidates})
    candidate_rows = []
    for key in sorted(set(original) & set(copied)):
        old_sha, new_sha = sha256(original[key]), sha256(copied[key])
        identical = old_sha == new_sha
        candidate_rows.append({"relative_path": key, "reference_sha256": old_sha, "new_sha256": new_sha, "byte_identical": identical})
        if not identical:
            issues.append({"candidate_changed": key})
    reference_dependencies = args.reference_root / "motion-protocol-dependency-baseline.json"
    dependency_issues = []
    if reference_dependencies.is_file():
        for name, expected in read(reference_dependencies).get("files", {}).items():
            path = Path(name)
            if not path.is_file() or sha256(path) != expected:
                dependency_issues.append(name)
        issues.extend({"reference_dependency_changed": name} for name in dependency_issues)
    source = args.root / "evaluate_lifts.py"
    source = source if source.is_file() else args.reference_root / "evaluate_lifts.py"
    source_sha = sha256(source)
    if source_sha != FROZEN_EVALUATOR_SHA:
        issues.append({"evaluator_source_changed": source_sha})
    old_metrics, old_errors = metrics(old_evaluation)
    new_metrics, new_errors = metrics(new_evaluation)
    reference_config = old_metrics[0][1]["config"] if old_metrics else {}
    expected_config = {**reference_config, "mass_kg": 0.2}
    physics_rows = []
    measured_keys = ("dt_s", "gravity_enabled", "friction", "hand_root", "object_freejoint", "object_external_force_N", "mujoco_version")
    reference_physics = {key: old_metrics[0][1].get(key) for key in measured_keys} if old_metrics else {}
    evaluated_inputs = []
    for path, row in new_metrics:
        input_path = Path(row["input"])
        candidate_key = str(input_path.relative_to(new_grasps)) if input_path.is_relative_to(new_grasps) else None
        ok = row.get("config") == expected_config
        physics_match = {key: row.get(key) for key in measured_keys} == reference_physics
        mass_match = abs(float(row.get("object_mass_kg", 0)) - 0.2) <= 1e-6
        sha_match = row.get("evaluator_sha256") == FROZEN_EVALUATOR_SHA
        input_match = candidate_key in copied and row.get("input_sha256") == sha256(copied[candidate_key])
        all_ok = ok and physics_match and mass_match and sha_match and input_match
        physics_rows.append({"metrics": str(path.resolve()), "relative_candidate": candidate_key,
                             "config_only_mass_changed": ok, "physics_flags_unchanged": physics_match,
                             "compiled_object_mass_kg": row.get("object_mass_kg"), "compiled_mass_is_200g": mass_match,
                             "frozen_evaluator_sha_matches": sha_match, "candidate_hash_matches": input_match, "verified": all_ok})
        if candidate_key:
            evaluated_inputs.append(candidate_key)
        if not all_ok:
            issues.append({"evaluation_setting_mismatch": str(path)})
    duplicate_inputs = [key for key, count in Counter(evaluated_inputs).items() if count > 1]
    if duplicate_inputs:
        issues.append({"duplicate_evaluation_inputs": duplicate_inputs})
    model_rows = []
    for folder in sorted(new_evaluation.glob("cylinder_thin_table_*")):
        new_model = construction_xml(folder)
        old_model = construction_xml(old_evaluation / folder.name)
        if not new_model.is_file() or not old_model.is_file():
            continue
        old_structure, old_density = normalized_model(old_model)
        new_structure, new_density = normalized_model(new_model)
        structure_same = old_structure == new_structure
        # MjSpec XML rounds densities to about six significant digits. Compare
        # the exported text within that precision; actual compiled mass is
        # checked separately against 0.2 kg using each trial's runtime value.
        density_ratio_tolerance = 1e-5
        density_doubled = bool(old_density) and len(old_density) == len(new_density) and all(abs(new / old - 2.0) <= density_ratio_tolerance for old, new in zip(old_density, new_density))
        model_rows.append({"scene_id": folder.name, "reference_model_sha256": sha256(old_model),
                           "new_model_sha256": sha256(new_model), "all_non_object_density_xml_unchanged": structure_same,
                           "object_density_doubled": density_doubled, "exported_density_ratio_tolerance": density_ratio_tolerance,
                           "reference_densities": old_density, "new_densities": new_density})
        if not structure_same or not density_doubled:
            issues.append({"model_configuration_mismatch": folder.name})
    complete = set(evaluated_inputs) == set(copied) and len(new_metrics) == len(copied) and not new_errors
    if args.require_complete and not complete:
        issues.append({"evaluation_incomplete": {"candidate_count": len(copied), "metrics_count": len(new_metrics), "missing": sorted(set(copied) - set(evaluated_inputs))}})
    report = {"schema_version": 1, "generated_at_utc": datetime.now(timezone.utc).isoformat(),
              "reference_root": str(args.reference_root.resolve()), "new_root": str(args.root.resolve()),
              "verification_script_sha256": sha256(__file__), "evaluator_sha256": source_sha,
              "expected_candidate_count": args.expected_candidates, "reference_candidates": len(original), "new_candidates": len(copied),
              "all_candidate_controls_byte_identical": set(original) == set(copied) and all(row["byte_identical"] for row in candidate_rows),
              "reference_dependency_files_unchanged": not dependency_issues,
              "old_metrics_count": len(old_metrics), "new_metrics_count": len(new_metrics), "evaluation_complete": complete,
              "reference_config": reference_config, "required_new_config": expected_config,
              "reference_physics_flags": reference_physics, "reference_metrics_read_errors": old_errors, "new_metrics_read_errors": new_errors,
              "candidate_hashes": candidate_rows, "evaluation_setting_checks": physics_rows, "model_xml_checks": model_rows,
              "issues": issues, "verified": not issues,
              "scope": "Paired benchmark reuses the same 314 candidate-control NPY files. Only free-object mass/density increases from 100 g to 200 g; planned grasp/squeeze targets, hand actuation, friction, mocap constraints and solver settings remain unchanged. The same controller policy computes release retreat from each trial's measured held-object pose, so its realized retreat direction may respond to load-dependent motion. Candidate selection for display may differ after physical evaluation.",
              "mass_note": "Object gravitational weight rises from approximately 0.981 N to 1.962 N. Stored squeeze controls were not re-optimized for 200 g, making this a controlled load comparison rather than a new mass-specific synthesis campaign."}
    args.root.mkdir(parents=True, exist_ok=True)
    (args.root / "controlled-comparison-verification.json").write_text(json.dumps(report, indent=2, ensure_ascii=False) + "\n")
    print(json.dumps({**{key: report[key] for key in ("reference_candidates", "new_candidates", "all_candidate_controls_byte_identical", "new_metrics_count", "evaluation_complete", "verified")}, "issue_count": len(issues), "first_issues": issues[:3]}, indent=2))
    if issues:
        raise SystemExit(1)


if __name__ == "__main__":
    main()
