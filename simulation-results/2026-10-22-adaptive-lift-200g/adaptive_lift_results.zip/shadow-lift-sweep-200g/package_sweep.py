#!/usr/bin/env python3
"""Package own adaptive sweep results locally; never uploads anything."""
from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path
import re
import shutil
import tempfile
import zipfile

ALLOWED = {".py", ".sh", ".md", ".json", ".yaml", ".yml", ".npy", ".npz", ".log", ".txt", ".obj", ".xml", ".urdf", ".mp4", ".png"}


def sha256(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def files(root):
    root = Path(root)
    if not root.is_dir():
        return
    for path in sorted(root.rglob("*")):
        parts = path.relative_to(root).parts
        if path.is_file() and path.suffix.lower() in ALLOWED and not any(part in {"__pycache__", ".git", ".venv", "venv", "deliverables", "publication-state"} or "smoke" in part.lower() for part in parts):
            yield path


def write_zip(target, entries):
    with zipfile.ZipFile(target, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=6) as archive:
        for name, path in sorted(entries.items()):
            archive.write(path, name)
        archive.writestr("PACKAGE_README.txt", "Own Shadow adaptive lift sweep results. See shadow-lift-sweep-200g/ADAPTIVE_LIFT_REPORT.md. Each test uses actual continuous physics under gravity; animations replay recorded states and do not determine success. All diameters have the same test mass, not the same material density. Original user attachments, credentials, Python environments and repository caches are excluded. Absolute scene/input paths describe the original cloud workspace; relocate them when using another checkout.\n")


def diameter_from_name(name):
    match = re.search(r"cylinder_thin_table_(\d+)(?:/|$)|/d(\d{3})(?:/|_)|(?:/|^)d(\d+)\.npy$", name)
    return int(next(value for value in match.groups() if value is not None)) if match else None


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root", type=Path, default=Path("/workspace/shadow-lift-sweep-200g"))
    parser.add_argument("--evaluation-root", type=Path, required=True)
    parser.add_argument("--experiment", type=Path, default=Path("/workspace/shadow-lift-sweep-200g/output/diameter_sweep_200g_shadow"))
    parser.add_argument("--animation-root", type=Path, default=Path("/workspace/shadow-lift-sweep-200g/animations"))
    parser.add_argument("--repo", type=Path, default=Path("/workspace/Dexonomy"))
    parser.add_argument("--output", type=Path)
    parser.add_argument("--include", type=Path, action="append", default=[], help="Additional own diagnostic directory inside this sweep root")
    parser.add_argument("--allow-partial", action="store_true")
    parser.add_argument("--max-archive-mb", type=float, default=90)
    args = parser.parse_args()
    root = args.root.resolve()
    output = (args.output or root / "deliverables").resolve()
    output.mkdir(parents=True, exist_ok=True)
    summary_path = root / "adaptive_lift_summary.json"
    report_path = root / "ADAPTIVE_LIFT_REPORT.md"
    summary = json.loads(summary_path.read_text())
    animation = json.loads((args.animation_root / "index.json").read_text())
    if not args.allow_partial:
        assert summary["integrity"]["candidate_accounting_complete"], "Some generated grasps have not been evaluated"
        assert not summary["integrity"]["unreadable_metrics"]
        assert not summary["integrity"]["missing_trace"]
        assert summary["integrity"].get("motion_protocol_applied_and_complete"), "Apply final sampled-lift protocol audit after the final evaluation resume"
        assert summary["integrity"].get("strict_matched_load_comparison_complete"), "Complete the paired 100 g / 200 g control comparison before packaging"
        accounting = summary["provenance_accounting"]["integrity"]
        assert accounting["pool_partition_disjoint"] and accounting["pool_partition_matches_actual_grasp_files"], "Candidate provenance must partition the actual pool"
        assert not accounting["merged_payload_hash_mismatches"], "Merged tiny candidates changed since provenance recording"
        assert animation["individual_videos"] == 12, "Need all twelve diameter videos or diagnostic cards"
    top = {"adaptive_lift_summary.json": summary_path, "ADAPTIVE_LIFT_REPORT.md": report_path}
    for name in ("PROTOCOL_REVIEW.md", "motion-protocol-summary.json", "LOAD_COMPARISON.md", "load-comparison.json", "MASS_VALIDATION.md", "mass-validation.json", "controlled-comparison-verification.json", "FAILURE_ANALYSIS.md", "FAILURE_ANALYSIS.json"):
        path = root / name
        if path.is_file():
            top[name] = path
        elif not args.allow_partial:
            raise SystemExit(f"Required final protocol artifact missing: {path}")
    if not args.allow_partial:
        assert sha256(root / "motion-protocol-summary.json") == summary["motion_protocol_audit"]["summary_sha256"], "Protocol audit changed after summary generation"
        assert sha256(root / "load-comparison.json") == summary["matched_load_comparison"]["summary_sha256"], "Load comparison changed after summary generation"
        verification = json.loads((root / "controlled-comparison-verification.json").read_text())
        assert verification.get("verified") and verification.get("evaluation_complete"), "Independent mass/control audit must cover the complete 200 g evaluation"
        assert sha256(root / "FAILURE_ANALYSIS.json") == summary["failure_analysis"]["source_sha256"]
        media_audit = json.loads((root / "audit_animation_delivery_200g.json").read_text())
        assert media_audit["source_and_media_audit"] == "passed", "Complete final video audit before packaging"
    if animation.get("montage"):
        top["all_12_diameters.mp4"] = Path(animation["montage"]["path"])
    for row in animation.get("representatives", []):
        if row.get("metrics") and not args.allow_partial:
            assert sha256(row["metrics"]) == row["metrics_sha256"], "Representative video selection predates final protocol metrics"
            assert "motion_protocol" in json.loads(Path(row["metrics"]).read_text()), "Representative needs final motion protocol audit"
        assert sha256(row["video"]) == row["video_sha256"], "Representative video changed after rendering"
        top[f"d{row['diameter_mm']:03d}_full_sequence.mp4"] = Path(row["video"])
    for name, path in top.items():
        assert path.is_file(), path
        shutil.copy2(path, output / name)
    entries = {}
    excluded_root = {"publication.json", "publication-plan.json", "public-download-verification.json"}
    for path in root.iterdir():
        if path.is_file() and path.suffix in {".py", ".sh", ".md", ".json"} and path.name not in excluded_root:
            entries[f"shadow-lift-sweep-200g/{path.name}"] = path
    for name in ("audit", "asset-validation", "mass-validation", "runtime"):
        for path in files(root / name):
            entries[f"shadow-lift-sweep-200g/{name}/{path.relative_to(root / name).as_posix()}"] = path
    for name in ("init_data", "grasp_data", "log"):
        for path in files(args.experiment / name):
            entries[f"shadow-lift-sweep-200g/output/{args.experiment.name}/{name}/{path.relative_to(args.experiment / name).as_posix()}"] = path
    for path in files(args.evaluation_root):
        entries[f"shadow-lift-sweep-200g/lift-evaluation/{path.relative_to(args.evaluation_root).as_posix()}"] = path
    for path in files(args.animation_root):
        entries[f"shadow-lift-sweep-200g/animations/{path.relative_to(args.animation_root).as_posix()}"] = path
    for directory in args.include:
        directory = directory.resolve()
        if root not in directory.parents or directory == output or output in directory.parents:
            raise SystemExit(f"Additional diagnostic directory must be inside sweep root: {directory}")
        for path in files(directory):
            entries[f"shadow-lift-sweep-200g/{directory.relative_to(root).as_posix()}/{path.relative_to(directory).as_posix()}"] = path
    asset = args.repo / "assets/object/cylinder_sweep_20261022"
    for path in files(asset):
        entries[f"Dexonomy/assets/object/cylinder_sweep_20261022/{path.relative_to(asset).as_posix()}"] = path
    for path in files(args.repo / "assets/hand/shadow/init_tmpl"):
        entries[f"Dexonomy/assets/hand/shadow/init_tmpl/{path.name}"] = path
    compatibility = Path("/workspace/shadow-reproduction")
    for name in ("run_pipeline.py", "run_cpu.sh", "video_writer.py", "audit_grasp.py"):
        if (compatibility / name).is_file():
            entries[f"shadow-reproduction/{name}"] = compatibility / name
    for path in files(compatibility / "runtime"):
        entries[f"shadow-reproduction/runtime/{path.relative_to(compatibility / 'runtime').as_posix()}"] = path
    for name in top:
        entries[f"delivery/{name}"] = output / name
    cap = int(args.max_archive_mb * 1_000_000)
    archive_names = []
    temp = output / "adaptive_lift_results.zip.tmp"
    write_zip(temp, entries)
    if temp.stat().st_size < cap:
        target = output / "adaptive_lift_results.zip"
        temp.replace(target)
        archive_names.append(target.name)
    else:
        temp.unlink()
        common, by_diameter = {}, {}
        for name, path in entries.items():
            d = diameter_from_name(name)
            if d is None:
                common[name] = path
            else:
                by_diameter.setdefault(d, {})[name] = path
        target = output / "adaptive_lift_code_assets.zip"
        write_zip(target, common)
        if target.stat().st_size >= cap:
            raise SystemExit("Common result files exceed archive cap; review package contents")
        archive_names.append(target.name)
        for d, group in sorted(by_diameter.items()):
            chunks, current, estimate = [], {}, 0
            for name, path in sorted(group.items()):
                if current and estimate + path.stat().st_size > cap * .8:
                    chunks.append(current)
                    current, estimate = {}, 0
                current[name] = path
                estimate += path.stat().st_size
            if current:
                chunks.append(current)
            for i, chunk in enumerate(chunks):
                suffix = f"_part{i+1:02d}" if len(chunks) > 1 else ""
                target = output / f"adaptive_lift_d{d:03d}{suffix}.zip"
                write_zip(target, chunk)
                if target.stat().st_size >= cap:
                    raise SystemExit(f"Result chunk exceeds archive cap: {target}")
                archive_names.append(target.name)
    # Online report links only to real flattened delivery files; all code/data
    # references remain literal paths, and archives provide their full contents.
    online = output / "ADAPTIVE_LIFT_REPORT.md"
    def fix_link(match):
        label, target = match.groups()
        if target.startswith(("https://", "http://", "#")) or target in top:
            return match.group(0)
        if Path(target).name in top:
            return f"[{label}]({Path(target).name})"
        return f"`{target}`" if label == target else f"{label}（`{target}`）"
    notice = "> 在线交付版。完整代码、资产、全部指标与轨迹见以下结果包；解压后阅读 `shadow-lift-sweep-200g/ADAPTIVE_LIFT_REPORT.md`。\n\n"
    notice += "\n".join(f"- [{name}]({name})" for name in archive_names) + "\n\n"
    online.write_text(notice + re.sub(r"\[([^\]]+)\]\(([^)]+)\)", fix_link, report_path.read_text()))
    names = list(top) + archive_names
    manifest = {"schema_version": 1, "scope": "Only own generated adaptive Shadow sweep outputs; excludes uploaded attachments, credentials and environments", "archive_entries": len(entries) + 1, "archives": archive_names, "files": [{"name": name, "bytes": (output / name).stat().st_size, "sha256": sha256(output / name)} for name in names]}
    (output / "delivery_manifest.json").write_text(json.dumps(manifest, indent=2, ensure_ascii=False) + "\n")
    print(json.dumps(manifest, indent=2, ensure_ascii=False))


if __name__ == "__main__":
    main()
