#!/usr/bin/env python3
"""Compose approved individual sweep videos with an exact CFR frame count.

Only the montage and its index entry are changed. Individual videos, renderer
source, measurements and physical trajectories remain untouched.
"""
from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path
import subprocess


def sha256(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def probe(path):
    data = json.loads(subprocess.check_output([
        "ffprobe", "-v", "error", "-count_frames", "-show_entries",
        "stream=width,height,r_frame_rate,avg_frame_rate,nb_read_frames,nb_frames:format=duration",
        "-of", "json", str(path),
    ], text=True))
    return data, data["streams"][0]


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--animation-root", type=Path, default=Path("/workspace/shadow-lift-sweep-200g/animations"))
    args = parser.parse_args()
    root = args.animation_root.resolve()
    index_path = root / "index.json"
    index = json.loads(index_path.read_text())
    rows = index["representatives"]
    assert len(rows) == 12
    inputs = []
    for row in rows:
        assert sha256(row["video"]) == row["video_sha256"]
        info, stream = probe(row["video"])
        assert (stream["width"], stream["height"]) == (1280, 720)
        assert stream["r_frame_rate"] == stream["avg_frame_rate"] == "10/1"
        inputs.append({"path": row["video"], "sha256": row["video_sha256"], "frames": int(stream["nb_read_frames"])})
    fps = 10
    frames = max(row["frames"] for row in inputs)
    duration = frames / fps
    temporary = root / "all_12_diameters.finalizing.mp4"
    command = ["ffmpeg", "-nostdin", "-hide_banner", "-loglevel", "error", "-y", "-filter_complex_threads", "1"]
    for row in inputs:
        command += ["-threads", "1", "-i", row["path"]]
    filters = []
    # Keep two extra end frames in every branch so framesync cannot discard
    # the real final frame when its longest input reaches EOF.
    for i in range(12):
        filters.append(f"[{i}:v]fps={fps},scale=320:240:force_original_aspect_ratio=decrease,pad=320:240:(ow-iw)/2:(oh-ih)/2,setsar=1,tpad=stop_mode=clone:stop={frames+2},trim=end_frame={frames+2},settb=AVTB,setpts=N/({fps}*TB)[v{i}]")
    layout = "|".join(f"{(i % 4) * 320}_{(i // 4) * 240}" for i in range(12))
    filters.append("".join(f"[v{i}]" for i in range(12)) + f"xstack=inputs=12:layout={layout}:fill=black:shortest=1,fps={fps},trim=end_frame={frames},settb=AVTB,setpts=N/({fps}*TB)[out]")
    command += ["-filter_complex", ";".join(filters), "-map", "[out]", "-an", "-r", str(fps), "-fps_mode", "cfr", "-frames:v", str(frames), "-c:v", "libx264", "-threads", "2", "-preset", "fast", "-crf", "21", "-pix_fmt", "yuv420p", "-movflags", "+faststart", str(temporary)]
    subprocess.run(command, check=True)
    info, stream = probe(temporary)
    assert int(stream["nb_read_frames"]) == frames, (stream, frames)
    assert stream["r_frame_rate"] == stream["avg_frame_rate"] == "10/1", stream
    assert abs(float(info["format"]["duration"]) - duration) < 1e-6
    subprocess.run(["ffmpeg", "-nostdin", "-hide_banner", "-loglevel", "error", "-xerror", "-threads", "1", "-i", str(temporary), "-f", "null", "-"], check=True)
    target = root / "all_12_diameters.mp4"
    temporary.replace(target)
    montage = {"path": str(target), "sha256": sha256(target), "fps": fps, "frames": frames, "duration_s": duration, "rows": 3, "columns": 4, "width": 1280, "height": 720, "finalizer": str(Path(__file__).resolve()), "finalizer_sha256": sha256(__file__), "timebase_policy": "Input clocks N/(10*TB), two EOF guard frames before framesync, output CFR 10 fps and exact longest-input frame count", "individual_videos_unchanged": True, "inputs": inputs, "probe": info}
    index["montage"] = montage
    replacement = index_path.with_suffix(".finalizing.json")
    replacement.write_text(json.dumps(index, ensure_ascii=False, indent=2) + "\n")
    replacement.replace(index_path)
    (root / "montage-finalization.json").write_text(json.dumps(montage, ensure_ascii=False, indent=2) + "\n")
    print(json.dumps({key: value for key, value in montage.items() if key not in ("inputs", "probe")}, indent=2))


if __name__ == "__main__":
    main()
