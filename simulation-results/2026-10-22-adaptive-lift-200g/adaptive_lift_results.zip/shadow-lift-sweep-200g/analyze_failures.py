#!/usr/bin/env python3
"""Read-only failure classification of the completed, protocol-audited 200 g run.

Categories describe recorded contact/motion events. They do not infer contact
friction or torque capacity from summed normal contact forces.
"""
from __future__ import annotations

from collections import Counter
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path

import numpy as np


ROOT = Path(__file__).resolve().parent
BASELINE = Path("/workspace/shadow-lift-sweep")
DIAMETERS = [1, 5, 10, 20, 30, 40, 50, 60, 70, 80, 90, 100]
CATEGORY_LABELS = {
    "passed": "全流程通过",
    "numeric_or_protocol_integrity": "数值或记录完整性问题",
    "initial_contact_shortfall": "夹持稳定末接触不足2点",
    "no_effective_lift": "有初始接触但未有效抬起",
    "lift_then_contact_loss": "已上升后接触不足/高度回落",
    "lift_height_precision": "仅100±5mm到位精度未达标",
    "orientation_offset": "闭合参考朝向偏差超15°",
    "hold_drift": "后5秒持握漂移超限",
    "release_after_valid_lift": "有效抬升后的释放失败",
    "other_lift_or_hold": "其他抬升/持握判据失败",
}


def read(path):
    return json.loads(Path(path).read_text())


def sha256(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def load_profile(path):
    record = read(path)
    trace_path = Path(record["trace"])
    trace_hash = sha256(trace_path)
    with np.load(trace_path, allow_pickle=False) as a:
        times = np.asarray(a["time_s"], dtype=np.float64)
        poses = np.asarray(a["object_pose"], dtype=np.float64)
        qpos = np.asarray(a["qpos"], dtype=np.float64)
        contacts = np.asarray(a["hand_object_contacts"], dtype=int)
        tables = np.asarray(a["object_table_contacts"], dtype=int)
        mocap = np.asarray(a["mocap_pos"], dtype=np.float64)
    phase = {p["phase"]: p["time_s"] for p in record["phase_boundaries"]}
    lift = (times >= phase["lift"] - 1e-4) & (times <= phase["postlift_hold"] + 1e-4)
    rise = (poses[lift, 2] - record["initial_object_pose"][2]) * 1000
    lift_indices = np.flatnonzero(lift)
    inadequate = lift_indices[contacts[lift] < 2]
    initial_contacts = int(record["loaded_hold_final_hand_object_contacts"])
    hold_failures = [key for key, value in record["hold_criteria"].items() if not value]
    motion_failures = [key for key, value in record["motion_protocol"]["checks"].items() if not value]
    min_rise = record["minimum_hold_height_gain_m"] * 1000
    max_rise = record["maximum_hold_height_gain_m"] * 1000
    peak = float(np.max(rise))
    if record["full_sequence_passed"]:
        category = "passed"
    elif (not record["finite_states"] or record["unexpected_time_resets"]
          or any(record["maximum_warning_counts"])):
        category = "numeric_or_protocol_integrity"
    elif initial_contacts < 2:
        category = "initial_contact_shortfall"
    elif len(inadequate):
        category = "lift_then_contact_loss" if peak >= 20 else "no_effective_lift"
    elif hold_failures == ["actual_object_lift_within_tolerance_throughout_hold"] and not motion_failures:
        category = "lift_height_precision"
    elif not record["hold_criteria"]["closure_rotation_throughout_hold"]:
        category = "orientation_offset"
    elif (not record["hold_criteria"]["position_drift_throughout_hold"]
          or not record["hold_criteria"]["orientation_drift_throughout_hold"]):
        category = "hold_drift"
    elif record["lift_hold_passed"] and not record["release_passed"]:
        category = "release_after_valid_lift"
    else:
        category = "other_lift_or_hold"
    loaded_index = np.flatnonzero(np.abs(times - phase["lift"]) <= 1e-4)[-1]
    held_index = np.flatnonzero(np.abs(times - phase["release_open"]) <= 1e-4)[-1]
    root_rise = float((qpos[held_index, 2] - qpos[loaded_index, 2]) * 1000)
    object_loaded_rise = float((poses[held_index, 2] - poses[loaded_index, 2]) * 1000)
    release = record["release"]
    release_failed_components = []
    if not record["release_passed"]:
        if release["final_hand_contacts"]:
            release_failed_components.append("hand_contact_remains")
        if not release["final_table_contacts"]:
            release_failed_components.append("table_contact_missing")
        if release["drop_m"] < 0.02:
            release_failed_components.append("additional_fall_below_20mm")
    key = str(path.relative_to(ROOT / "lift-evaluation"))
    old_path = BASELINE / "lift-evaluation" / key
    old = read(old_path)
    assert old["input_sha256"] == record["input_sha256"], path
    return {
        "case_key": key.removesuffix("/metrics.json"), "diameter_mm": int(record["scene_id"].rsplit("_", 1)[1]),
        "template": record["template"], "candidate_file": str(Path(record["input"]).relative_to(ROOT)),
        "metrics": str(path.relative_to(ROOT)), "metrics_sha256": sha256(path),
        "trace": str(trace_path.relative_to(ROOT)), "trace_sha256": trace_hash,
        "input_sha256": record["input_sha256"], "baseline_metrics": str(old_path),
        "baseline_metrics_sha256": sha256(old_path),
        "baseline_100g_full_passed": bool(old["full_sequence_passed"]),
        "200g_lift_hold_passed": bool(record["lift_hold_passed"]),
        "200g_release_passed": bool(record["release_passed"]),
        "200g_full_sequence_passed": bool(record["full_sequence_passed"]),
        "primary_observed_category": category,
        "primary_observed_category_label": CATEGORY_LABELS[category],
        "failed_hold_criteria": hold_failures, "failed_sampled_lift_criteria": motion_failures,
        "loaded_hold_final_hand_contact_points": initial_contacts,
        "sampled_lift_maximum_height_gain_mm": peak,
        "sampled_lift_minimum_hand_contact_points": int(np.min(contacts[lift])),
        "sampled_lift_any_table_free_states": bool(np.any(tables[lift] == 0)),
        "sampled_first_inadequate_hand_contact_time_s": float(times[inadequate[0]]) if len(inadequate) else None,
        "sampled_maximum_downward_excursion_mm": record["motion_protocol"]["maximum_downward_excursion_from_reached_height_mm"],
        "hold_minimum_height_gain_mm": min_rise, "hold_maximum_height_gain_mm": max_rise,
        "hold_final_height_gain_mm": record["measured_object_lift_mm"],
        "shortfall_below_95mm_at_worst_mm": max(0.0, 95.0 - min_rise),
        "hold_maximum_position_drift_mm": record["postlift_hold_maximum_drift_m"] * 1000,
        "hold_maximum_orientation_drift_deg": record["postlift_hold_maximum_rotation_deg"],
        "hold_maximum_closure_relative_rotation_deg": record["maximum_closure_rotation_during_hold_deg"],
        "hand_root_rise_from_loaded_hold_to_release_start_mm": root_rise,
        "object_rise_from_loaded_hold_to_release_start_mm": object_loaded_rise,
        "object_relative_to_hand_root_net_vertical_change_mm": object_loaded_rise - root_rise,
        "commanded_mocap_root_rise_mm": float((mocap[held_index, 0, 2] - mocap[loaded_index, 0, 2]) * 1000),
        "release_failed_components": release_failed_components,
        "object_had_table_contact_before_release": bool(record["final_object_table_contacts"] > 0),
        "release_fall_mm": release["drop_m"] * 1000,
        "release_final_hand_contacts": release["final_hand_contacts"],
        "release_final_table_contacts": release["final_table_contacts"],
        "actual_object_mass_kg": record["object_mass_kg"],
        "100g_minimum_hold_height_gain_mm": old["minimum_hold_height_gain_m"] * 1000,
        "100g_final_height_gain_mm": old["measured_object_lift_mm"],
        "sampled_contact_semantics": "Contact points, not unique fingers; times are recorded trace samples, not exact 250Hz failure onset",
    }


def mm_range(rows, field):
    values = [r[field] for r in rows]
    return [min(values), max(values)] if values else None


def main():
    protocol = read(ROOT / "motion-protocol-summary.json")
    assert protocol["applied"] and protocol["candidate_count"] == 314
    paths = sorted((ROOT / "lift-evaluation").rglob("metrics.json"))
    assert len(paths) == 314
    profiles = [load_profile(path) for path in paths]
    assert all(abs(r["actual_object_mass_kg"] - 0.2) < 1e-7 for r in profiles)
    failures = [p for p in profiles if not p["200g_full_sequence_passed"]]
    totals = Counter(p["primary_observed_category"] for p in profiles)
    paired = Counter(f"{int(p['baseline_100g_full_passed'])}->{int(p['200g_full_sequence_passed'])}" for p in profiles)
    groups = []
    for diameter in DIAMETERS:
        rows = [p for p in profiles if p["diameter_mm"] == diameter]
        failed = [p for p in rows if not p["200g_full_sequence_passed"]]
        precision = [p for p in rows if p["primary_observed_category"] == "lift_height_precision"]
        groups.append({
            "diameter_mm": diameter, "tested": len(rows),
            "100g_full_sequence_passed": sum(p["baseline_100g_full_passed"] for p in rows),
            "200g_full_sequence_passed": sum(p["200g_full_sequence_passed"] for p in rows),
            "100g_pass_to_200g_fail": sum(p["baseline_100g_full_passed"] and not p["200g_full_sequence_passed"] for p in rows),
            "primary_observed_failures": dict(Counter(p["primary_observed_category"] for p in failed)),
            "all_failed_hold_criteria": dict(Counter(k for p in failed for k in p["failed_hold_criteria"])),
            "all_failed_sampled_lift_criteria": dict(Counter(k for p in failed for k in p["failed_sampled_lift_criteria"])),
            "precision_only_failure_minimum_height_range_mm": mm_range(precision, "hold_minimum_height_gain_mm"),
            "precision_only_failure_maximum_height_range_mm": mm_range(precision, "hold_maximum_height_gain_mm"),
            "precision_only_failure_maximum_hold_drift_mm": max((p["hold_maximum_position_drift_mm"] for p in precision), default=None),
            "worst_hold_drift_all_trials_mm": max((p["hold_maximum_position_drift_mm"] for p in rows), default=None),
            "release_flags_false": sum(not p["200g_release_passed"] for p in rows),
            "release_failure_after_valid_lift": sum(p["200g_lift_hold_passed"] and not p["200g_release_passed"] for p in rows),
        })
    near_fail = sorted([p for p in failures if p["primary_observed_category"] == "lift_height_precision"], key=lambda p: p["hold_minimum_height_gain_mm"], reverse=True)[:12]
    near_pass = sorted([p for p in profiles if p["200g_full_sequence_passed"]], key=lambda p: p["hold_minimum_height_gain_mm"])[:8]
    release_false = [p for p in profiles if not p["200g_release_passed"]]
    release_components = Counter(k for p in release_false for k in p["release_failed_components"])
    assert sum(totals.values()) == 314
    assert totals["passed"] == protocol["final_full_sequence_passed"] == 125
    assert sum(p["200g_lift_hold_passed"] and not p["200g_release_passed"] for p in profiles) == 0
    assert all(sha256(ROOT / p["metrics"]) == p["metrics_sha256"] and sha256(ROOT / p["trace"]) == p["trace_sha256"] for p in profiles)
    report = {
        "schema_version": 1, "generated_at_utc": datetime.now(timezone.utc).isoformat(),
        "analysis_script_sha256": sha256(__file__), "metrics_and_traces_unchanged_by_analysis": True,
        "protocol_applied": True, "motion_protocol_summary_sha256": sha256(ROOT / "motion-protocol-summary.json"),
        "tested": 314, "100g_full_sequence_passed": sum(p["baseline_100g_full_passed"] for p in profiles),
        "200g_full_sequence_passed": totals["passed"], "200g_failed": len(failures),
        "paired_transitions_100g_to_200g": dict(paired),
        "primary_observed_categories": dict(totals), "category_labels": CATEGORY_LABELS,
        "classification_rules": {
            "semantics": "Mutually exclusive observed-event categories, ordered by phase; not unique causal diagnoses",
            "initial_contact_shortfall": "Fewer than 2 contact points at the end of the 1-second clamp settle; says contact-point shortfall, not number of fingers",
            "no_effective_lift": "At least 2 initial points, later lift samples have fewer than 2, and sampled peak rise <20mm",
            "lift_then_contact_loss": "At least 2 initial points, sampled peak rise >=20mm and fewer than 2 points later; height traces provide the observed drop evidence",
            "effective_lift_diagnostic_threshold_mm": 20,
            "diagnostic_threshold_is_not_an_acceptance_rule": True,
            "lift_height_precision": "Only failed hold criterion is 100±5mm throughout hold and all sampled lift checks pass",
            "numerical_boundary": "The original strict 95mm lower bound is preserved; no rounding or new tolerance is applied",
        },
        "release_false_flags": len(release_false), "release_false_components": dict(release_components),
        "release_failure_after_valid_lift": 0,
        "release_false_already_table_supported_before_open": sum(p["object_had_table_contact_before_release"] for p in release_false),
        "per_diameter": groups, "closest_precision_failures": near_fail, "closest_height_passes": near_pass,
        "evidence_limits": [
            "Lift-event timing/peak/contact observations use saved 10Hz states plus phase boundaries; they do not claim exact 250Hz failure onset.",
            "Five-second hold extrema and pass criteria come from evaluator metrics observed every 4ms physics step, not rounded video measurements.",
            "Summed normal contact force alone does not determine tangential friction margin, per-contact forces or resisting torques; no such capacity inference is made.",
            "This comparison reuses frozen controls and changes only object mass, so it is not a new optimized maximum-capacity test of the hand.",
        ],
        "candidates": profiles,
    }
    (ROOT / "FAILURE_ANALYSIS.json").write_text(json.dumps(report, indent=2, ensure_ascii=False) + "\n")
    lines = [
        "# 200 g 失败类型分析", "",
        "本分析只读取完整 314 个候选的最终 `metrics.json` 和真实物理轨迹，等待运动协议审计完成后分类；没有修改轨迹、判据、模型或控制参数。100 g 的 266 个全流程通过样本在 200 g 下保留 125 个，141 个由通过变为未通过，48 个在两种质量下都未通过，没有由未通过变为通过的样本。", "",
        f"189 个未通过结果不能统称为掉落：其中 {totals['lift_height_precision']} 个只差实际抬升到位精度，提升轨迹、5 秒持握和释放均满足其余条件。", "",
        "## 按直径的主要观测类型", "",
        "| 直径mm | 100g通过 | 200g通过/测试 | 夹持末接触不足 | 有接触但未有效抬起 | 上升后接触丢失 | 仅到位精度失败 | 朝向偏差 |",
        "|---:|---:|---:|---:|---:|---:|---:|---:|---:|",
    ]
    for group in groups:
        c = group["primary_observed_failures"]
        lines.append(f"| {group['diameter_mm']} | {group['100g_full_sequence_passed']} | {group['200g_full_sequence_passed']}/{group['tested']} | {c.get('initial_contact_shortfall',0)} | {c.get('no_effective_lift',0)} | {c.get('lift_then_contact_loss',0)} | {c.get('lift_height_precision',0)} | {c.get('orientation_offset',0)} |")
    lines += [
        "", "“夹持末接触不足”指 1 秒夹持稳定结束时少于 2 个手物接触点，不把接触点等同于不同手指。“有接触但未有效抬起”指初始至少 2 点，随后提升样本出现接触不足、观测最高升高不足 20 mm。“上升后接触丢失”要求观测上升至少 20 mm，并出现接触点不足；20 mm 只是区分失败过程的描述阈值，不是新的通过判据。", "",
        "提升过程的时刻、峰值和接触变化基于保存的 10 Hz 状态及阶段边界，不能精确定位未保存的 250 Hz 子步。5 秒持握期间的最低高度和最大漂移来自测试器每个 4 ms 物理步的原始统计。", "",
        "## 10、20、30、80 mm 的变化", "",
        "- **10 mm：15→2 个通过。** 32 个失败中，29 个在夹持稳定末有至少 2 点接触，但没有有效随手抬起；2 个确实先升高再失去接触并回落；另 1 个实际到位且持握漂移很小，但相对闭合参考的朝向超过 15°。这三种现象不同。", 
        "- **20 mm：57→7 个通过。** 50 个失败均在提升中失去足够接触，采样峰值升高不足 20 mm，最终回到/留在桌面。不能把它们称为已在高处持握 5 秒后才掉落。", 
        "- **30 mm：60→28 个通过。** 32 个失败只违反实际升高必须在 100±5 mm 内的条件；没有提升阶段接触/方向不稳、持握漂移或释放失败。", 
        "- **80 mm：20→11 个通过。** 9 个失败也只因实际升高低于严格的 95 mm 下限，其他阶段判据均满足。", "",
        "5 mm 中也有实际抬起而非掉落的样本：`9_Palmar_Pinch/scaledfull20_0_4_grasp` 最终升高 92.800207 mm，最低 92.784637 mm，仅到位精度失败；另一个 `scaledfull20_0_6_grasp` 最终升高 92.850314 mm，但同时存在最大 15.961429° 的闭合参考朝向偏差，不能把它也算为“仅精度不足”。", "",
        "在固定控制下，加重后的运动结果确实变差，但“总法向夹持力”本身没有提供每个接触的切向摩擦余量、方向或抗力矩信息，不能单凭总数断言摩擦容量足够或不足。这里只报告接触和运动证据，不把它们强行归结为某一个未测量的接触机理。", "",
        "## 95 mm 边界与稳定但不足量的抬升", "",
        "| 候选 | 5秒最低升高mm | 最高升高mm | 最终升高mm | 结论 |",
        "|---|---:|---:|---:|---|",
    ]
    for p in near_fail[:5]:
        lines.append(f"| `{p['case_key']}` | {p['hold_minimum_height_gain_mm']:.6f} | {p['hold_maximum_height_gain_mm']:.6f} | {p['hold_final_height_gain_mm']:.6f} | 仅到位精度未达标 |")
    p = near_fail[0]
    lines += [
        "", f"最近的未通过边界样本为 `{p['case_key']}`：最低 {p['hold_minimum_height_gain_mm']:.9f} mm，只比 95 mm 少 {p['shortfall_below_95mm_at_worst_mm']:.9f} mm；最终已到 {p['hold_final_height_gain_mm']:.9f} mm。但锁定规则要求全部 5 秒都不低于 95 mm，因此仍记未通过，不用四舍五入更改结果。这是当前离散模型的判据比较，不代表真实硬件测量有微米级精度。", "",
        f"最接近下限的通过样本为 `{near_pass[0]['case_key']}`，5 秒最低升高 {near_pass[0]['hold_minimum_height_gain_mm']:.9f} mm。", "",
    ]
    for diameter in [30, 80, 90, 100]:
        group = next(g for g in groups if g["diameter_mm"] == diameter)
        precision = [p for p in profiles if p["diameter_mm"] == diameter and p["primary_observed_category"] == "lift_height_precision"]
        if precision:
            low = min(p["hold_minimum_height_gain_mm"] for p in precision)
            high = max(p["hold_maximum_height_gain_mm"] for p in precision)
            drift = max(p["hold_maximum_position_drift_mm"] for p in precision)
            lines.append(f"{diameter} mm 的 {len(precision)} 个仅精度失败样本在持握中的升高范围为 {low:.6f}–{high:.6f} mm，最大持握位置漂移 {drift:.6f} mm。")
    lines += [
        "", "90/100 mm 的本轮未通过并不是掉落：所有候选都有稳定提升的采样记录，且能够释放，实际升高约 92–95 mm，未达到严格 95 mm 下限。手根目标上移 100 mm 不等于物体实际精确升高 100 mm；各候选的真实手根位移和物体相对手根的净位移已记录在 JSON 中。仅凭这些数据仍不能区分全部相对位移来自关节弹性变形、接触滑移还是几何重排。", "",
        "## 持握漂移与释放", "",
        "本轮没有样本因后 5 秒的位置/朝向漂移阈值单独失败。已经回到桌面的物体也可能几乎不动，因此很小的后段漂移不等于夹持成功；必须同时看抬升高度、桌面接触和手物接触。", "",
        f"`release_passed=false` 共 {len(release_false)} 个，但没有任何有效抬升通过样本发生独立的释放失败。这 {len(release_false)} 个释放标志均因张开后没有新增至少 20 mm 的下降而失败；它们在张开前已经有桌面接触。最终全部手物接触为零、都有物桌接触，因此不能把这些标志描述为粘住、无法松手或释放机构失效。", "",
        "详细的逐候选分类、未通过原始判据、真实高度、接触事件、配对 100 g 结果和源文件 SHA256 见 `FAILURE_ANALYSIS.json`。分析结束后再次核对了全部 metrics/trace 的 SHA256，未发生修改。", "",
    ]
    (ROOT / "FAILURE_ANALYSIS.md").write_text("\n".join(lines))
    print(json.dumps({"tested": 314, "passed": totals["passed"], "failed": len(failures), "primary_categories": dict(totals), "release_false": len(release_false), "release_after_valid_lift": 0, "metrics_and_traces_unchanged": True}, indent=2))


if __name__ == "__main__":
    main()
