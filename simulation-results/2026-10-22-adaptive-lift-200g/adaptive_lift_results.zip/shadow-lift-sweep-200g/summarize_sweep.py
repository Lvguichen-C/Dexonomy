#!/usr/bin/env python3
"""Summarize actual adaptive-cylinder trial files without inferring video success."""
from __future__ import annotations

import argparse
from collections import Counter
from datetime import datetime, timezone
import hashlib
import importlib.metadata
import json
from pathlib import Path
import platform
import re
import subprocess

DIAMETERS = [1, 5, 10, 20, 30, 40, 50, 60, 70, 80, 90, 100]


def sha256(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def diameter(scene_id):
    match = re.search(r"_(\d+)$", str(scene_id))
    return int(match.group(1)) if match else None


def read(path, default=None):
    return json.loads(Path(path).read_text()) if Path(path).is_file() else default


def count_files(root):
    result = Counter()
    if Path(root).is_dir():
        for path in Path(root).rglob("*.npy"):
            for part in path.parts:
                d = diameter(part) if part.startswith("cylinder_thin_table_") else None
                if d in DIAMETERS:
                    result[d] += 1
                    break
    return result


def provenance_accounting(root, experiment):
    """Keep proposal identities, optimization runs and copied pool files distinct."""
    main_init = {str(path.resolve()) for path in (experiment / "init_data").rglob("*.npy")}
    main_grasp = {str(path.resolve()) for path in (experiment / "grasp_data").rglob("*.npy")}
    setup_path = root / "setup-provenance.json"
    setup = read(setup_path, {})
    if setup.get("target_mass_kg") == 0.2:
        candidate_rows = [row for row in setup.get("files", []) if row.get("stage") == "grasp_data"]
        expected = {str(Path(row["destination"]).resolve()) for row in candidate_rows}
        mismatches = []
        for row in candidate_rows:
            source, destination = Path(row["source"]), Path(row["destination"])
            if not source.is_file() or not destination.is_file() or sha256(source) != row.get("source_sha256") or sha256(destination) != row.get("destination_sha256") or row.get("source_sha256") != row.get("destination_sha256"):
                mismatches.append(str(destination))
        source_summary_path = Path(setup["source_root"]) / "adaptive_lift_summary.json"
        source_summary = read(source_summary_path, {})
        return {
            "scope": "200 g matched-control re-evaluation only. All stored proposals and all 314 candidate controls are inherited byte-for-byte from the frozen 100 g source pool. No new synthesis, optimization, or controller tuning is performed for 200 g.",
            "main_pool_initial_proposal_files": len(main_init), "main_pool_reused_initial_proposals": len(main_init), "main_pool_new_initial_proposals": 0,
            "native_optimizer_ledger_attempts": 0, "native_optimizer_scientific_completed_attempts": 0, "native_optimizer_status_counts": {}, "native_optimizer_reused_proposal_retries": 0, "native_optimizer_new_proposal_attempts": 0,
            "main_pool_grasp_candidate_files": len(main_grasp),
            "pool_partition": {"reused_valid_grasps": len(expected), "new_native_valid_grasps": 0, "supplemental_tiny_valid_grasps": 0},
            "tiny_diagnostics": {},
            "budget_interpretation": "This run changes mass only and repeats the same candidate controls. The uneven 100 g source synthesis budget is historical provenance, not new 200 g optimization or an estimate of maximum 200 g hand capability.",
            "integrity": {"pool_partition_disjoint": True, "pool_partition_matches_actual_grasp_files": expected == main_grasp, "overlaps": {}, "unattributed_grasp_files": sorted(main_grasp - expected), "attributed_grasp_files_missing": sorted(expected - main_grasp), "merged_payload_hash_mismatches": mismatches},
            "frozen_control_comparison": {"setup_provenance_path": str(setup_path), "setup_provenance_sha256": sha256(setup_path), "source_root": setup.get("source_root"), "source_mass_kg": setup.get("source_mass_kg"), "target_mass_kg": setup.get("target_mass_kg"), "candidate_control_pool_fingerprint_sha256": setup.get("candidate_control_pool_fingerprint_sha256"), "all_candidate_files_byte_identical_verified": not mismatches, "new_optimizer_runs": 0, "source_outcomes_reused": False},
            "historical_source_synthesis_accounting": source_summary.get("provenance_accounting", {}),
            "sources": {"setup-provenance.json": sha256(setup_path)},
        }
    reuse_path, ledger_path, merge_path = root / "reuse-manifest.json", root / "grasp-attempt-ledger.json", root / "merge/provenance.json"
    reuse = read(reuse_path, {})
    ledger = read(ledger_path, {})
    merge = read(merge_path, {})
    reused_init = {str(Path(row["destination"]).resolve()) for row in reuse.get("files", []) if row.get("stage") == "init_data"}
    reused_grasp = {str(Path(row["destination"]).resolve()) for row in reuse.get("files", []) if row.get("stage") == "grasp_data"}
    attempts = list(ledger.get("attempts", {}).values())
    saved_native = {str(Path(row["output_path"]).resolve()) for row in attempts if row.get("status") == "grasp_saved"}
    merged_rows = merge.get("candidates", [])
    merged = {str(Path(row["merged_grasp"]).resolve()) for row in merged_rows}
    controlled = read(root / "tiny-adaptation/input-snapshot.json", [])
    controlled_sources = {str(Path(row["input"]).resolve()) for row in controlled}
    fallback = read(root / "tiny-fallback-adaptation/input-snapshot.json", [])
    fallback_sources = {str(Path(row["original_initialization"]).resolve()) for row in fallback}
    audits_by_mode = {}
    for directory in (root / "tiny-adaptation", root / "tiny-fallback-adaptation"):
        if directory.is_dir():
            for audit in sorted(directory.glob("*/audit")):
                records = [path for path in audit.glob("*.json") if path.name != "summary.json"]
                audits_by_mode[str(audit.relative_to(root))] = len(records)
    controlled_runs = sum(count for name, count in audits_by_mode.items() if name.startswith("tiny-adaptation/") and name.split("/")[1] in {"baseline", "scaled_plane", "scaled_plane_full20"})
    targeted_runs = sum(count for name, count in audits_by_mode.items() if name.startswith("tiny-adaptation/") and name.split("/")[1] not in {"baseline", "scaled_plane", "scaled_plane_full20"})
    fallback_runs = sum(count for name, count in audits_by_mode.items() if name.startswith("tiny-fallback-adaptation/"))
    merge_hash_mismatches = []
    for row in merged_rows:
        target = Path(row["merged_grasp"])
        if not target.is_file() or sha256(target) != row.get("grasp_sha256"):
            merge_hash_mismatches.append(str(target))
    pool_union = reused_grasp | saved_native | merged
    overlaps = {"reused_and_native": sorted(reused_grasp & saved_native), "reused_and_tiny": sorted(reused_grasp & merged), "native_and_tiny": sorted(saved_native & merged)}
    status_counts = dict(Counter(row.get("status", "unknown") for row in attempts))
    return {
        "scope": "Path identities of stored proposals, native optimizer ledger attempts, supplemental variant reruns, and copied valid grasp candidates are separate accounting units. A padded initialization file is not a certified grasp or necessarily a unique numerical pose.",
        "main_pool_initial_proposal_files": len(main_init),
        "main_pool_reused_initial_proposals": len(main_init & reused_init),
        "main_pool_new_initial_proposals": len(main_init - reused_init),
        "native_optimizer_ledger_attempts": len(attempts),
        "native_optimizer_scientific_completed_attempts": sum(bool(row.get("scientific_attempt_completed")) for row in attempts),
        "native_optimizer_status_counts": status_counts,
        "native_optimizer_reused_proposal_retries": sum(str(Path(row["source"]).resolve()) in reused_init for row in attempts),
        "native_optimizer_new_proposal_attempts": sum(str(Path(row["source"]).resolve()) not in reused_init for row in attempts),
        "main_pool_grasp_candidate_files": len(main_grasp),
        "pool_partition": {"reused_valid_grasps": len(reused_grasp), "new_native_valid_grasps": len(saved_native), "supplemental_tiny_valid_grasps": len(merged)},
        "tiny_diagnostics": {"distinct_controlled_input_paths": len(controlled_sources), "controlled_inputs_already_in_main_pool": len(controlled_sources & main_init), "new_fallback_input_paths_outside_main_pool": len(fallback_sources - main_init), "distinct_input_paths_total": len(controlled_sources | fallback_sources), "controlled_three_variant_optimizer_runs": controlled_runs, "targeted_long_budget_optimizer_runs": targeted_runs, "fresh_fallback_optimizer_runs": fallback_runs, "optimizer_runs_total": controlled_runs + targeted_runs + fallback_runs, "audit_records_by_mode": audits_by_mode, "merged_valid_grasps": len(merged), "declared_merge_optimization_runs": merge.get("optimization_runs"), "declared_merge_distinct_proposals": merge.get("independent_initial_proposals")},
        "budget_interpretation": "Reused Tip_Pinch reference scenes retain 50 proposals each, while new main template/diameter jobs normally retain 10 each; tiny fallback jobs retain 5 each. Counts describe this finite uneven search budget, not equal-budget statistical success rates across diameters.",
        "integrity": {"pool_partition_disjoint": not any(overlaps.values()), "pool_partition_matches_actual_grasp_files": pool_union == main_grasp, "overlaps": overlaps, "unattributed_grasp_files": sorted(main_grasp - pool_union), "attributed_grasp_files_missing": sorted(pool_union - main_grasp), "merged_payload_hash_mismatches": merge_hash_mismatches},
        "sources": {str(path.relative_to(root)): sha256(path) for path in (reuse_path, ledger_path, merge_path, root / "tiny-fallback-summary.json", root / "TINY_ADAPTATION.md") if path.is_file()},
    }


def summarize(args):
    root, evaluation = args.root.resolve(), args.evaluation_root.resolve()
    asset = read(root / "assets-manifest.json", {})
    planned = read(root / "adaptive-plan.json", {})
    motion_path = root / "motion-protocol-summary.json"
    motion_summary = read(motion_path, {})
    assets_by_d = {int(row["diameter_mm"]): row for row in asset.get("scenes", [])}
    records, unreadable, errors = [], [], []
    for path in sorted(evaluation.rglob("metrics.json")):
        try:
            item = read(path)
            if item.get("schema_version") == 1 and "hold_criteria" in item:
                item = {**item, "metrics_path": str(path.resolve()), "metrics_sha256": sha256(path)}
                trace = Path(item.get("trace", path.with_name("trace.npz")))
                item["trace_exists"] = trace.is_file()
                item["trace_sha256"] = sha256(trace) if trace.is_file() else None
                records.append(item)
        except (ValueError, OSError, TypeError) as error:
            unreadable.append({"path": str(path), "error": str(error)})
    for path in sorted(evaluation.glob("*/summary.json")):
        scene = read(path, {})
        for row in scene.get("candidates", []):
            if row.get("error"):
                errors.append({"scene_id": scene.get("scene_id"), **row})
    init_counts = count_files(args.experiment / "init_data")
    grasp_counts = count_files(args.experiment / "grasp_data")
    initial_budgets = Counter()
    for path in (args.experiment / "init_data").rglob("*.npy"):
        relative = path.relative_to(args.experiment / "init_data")
        if len(relative.parts) >= 3:
            initial_budgets[(diameter(relative.parts[1]), relative.parts[0])] += 1
    per_diameter = []
    for d in DIAMETERS:
        group = [r for r in records if diameter(r["scene_id"]) == d]
        group_errors = [e for e in errors if diameter(e.get("scene_id")) == d]
        templates = sorted({r.get("template", "unknown") for r in group})
        per_template = []
        for template in templates:
            rows = [r for r in group if r.get("template", "unknown") == template]
            per_template.append({"template": template, "tested": len(rows), "lift_hold_passed": sum(bool(r.get("lift_hold_passed")) for r in rows), "release_passed": sum(bool(r.get("release_passed")) for r in rows), "full_sequence_passed": sum(bool(r.get("full_sequence_passed")) for r in rows)})
        failed_criteria = Counter(key for r in group for key, valid in r.get("hold_criteria", {}).items() if not valid)
        sampled_failures = Counter(key for r in group for key, valid in r.get("motion_protocol", {}).get("checks", {}).items() if not valid)
        per_diameter.append({
            "diameter_mm": d, "height_mm": assets_by_d.get(d, {}).get("height_mm"),
            "initializations": init_counts[d], "grasp_candidates": grasp_counts[d],
            "tested": len(group), "exceptions": len(group_errors),
            "lift_hold_passed": sum(bool(r.get("lift_hold_passed")) for r in group),
            "release_passed": sum(bool(r.get("release_passed")) for r in group),
            "full_sequence_passed": sum(bool(r.get("full_sequence_passed")) for r in group),
            "base_evaluator_lift_hold_passed": sum(bool(r.get("base_evaluator_outcomes", {}).get("lift_hold_passed", r.get("lift_hold_passed"))) for r in group),
            "base_evaluator_full_sequence_passed": sum(bool(r.get("base_evaluator_outcomes", {}).get("full_sequence_passed", r.get("full_sequence_passed"))) for r in group),
            "motion_protocol_audited": sum("motion_protocol" in r for r in group),
            "sampled_lift_stability_passed": sum(bool(r.get("motion_protocol", {}).get("passed")) for r in group),
            "failed_sampled_lift_criteria": dict(sampled_failures),
            "templates": per_template, "failed_hold_criteria": dict(failed_criteria),
            "main_initial_proposals_by_template": {template: count for (value, template), count in initial_budgets.items() if value == d},
            "status": "no_synthesized_grasp" if not grasp_counts[d] else "no_evaluated_trial" if not group else "evaluated",
        })
    totals = {key: sum(row[key] for row in per_diameter) for key in ("initializations", "grasp_candidates", "tested", "exceptions", "lift_hold_passed", "release_passed", "full_sequence_passed", "base_evaluator_lift_hold_passed", "base_evaluator_full_sequence_passed", "motion_protocol_audited", "sampled_lift_stability_passed")}
    config = records[0].get("config", {}) if records else read(evaluation / "summary.json", {}).get("config", {})
    evaluated_inputs = {str(Path(r["input"]).resolve()) for r in records} | {str(Path(e["input"]).resolve()) for e in errors if e.get("input")}
    expected_inputs = {str(path.resolve()) for path in (args.experiment / "grasp_data").rglob("*.npy")}
    motion_inputs = {str(Path(row["input"]).resolve()) for row in motion_summary.get("candidates", [])}
    metric_inputs = {str(Path(row["input"]).resolve()) for row in records}
    motion_trace_mismatches = [r["metrics_path"] for r in records if r.get("motion_protocol", {}).get("trace_sha256") != r.get("trace_sha256")]
    motion_complete = bool(motion_summary.get("applied") and motion_summary.get("candidate_count") == len(records)
                           and totals["motion_protocol_audited"] == len(records) and motion_inputs == metric_inputs
                           and not motion_trace_mismatches
                           and motion_summary.get("final_lift_hold_passed") == totals["lift_hold_passed"]
                           and motion_summary.get("final_full_sequence_passed") == totals["full_sequence_passed"])
    inventory = {str(path.relative_to(root)): {"bytes": path.stat().st_size, "sha256": sha256(path)} for path in root.iterdir() if path.is_file() and path.suffix in {".py", ".sh", ".json"} and path.name not in {"adaptive_lift_summary.json", "publication.json", "public-download-verification.json"}}
    versions = {"python": platform.python_version()}
    for package in ("mujoco", "torch", "warp-lang", "numpy", "trimesh", "qpsolvers"):
        try:
            versions[package] = importlib.metadata.version(package)
        except importlib.metadata.PackageNotFoundError:
            versions[package] = None
    def git(*values):
        return subprocess.check_output(["git", "-C", str(args.repo), *values], text=True).strip()
    source_status = git("status", "--porcelain=v1", "--untracked-files=no")
    result = {
        "schema_version": 1, "generated_at_utc": datetime.now(timezone.utc).isoformat(),
        "evaluation_root": str(evaluation), "experiment": str(args.experiment.resolve()),
        "diameters_mm": DIAMETERS, "config": config,
        "assets": {"height_to_diameter_ratio": asset.get("height_to_diameter_ratio"), "fixed_height_mm": asset.get("fixed_height_mm", asset.get("height_mm")), "mass_policy": asset.get("mass_policy"), "target_mass_kg": asset.get("target_mass_kg"), "canonical_mesh_sections": asset.get("canonical_mesh_sections")},
        "adaptive_selection": {"method": planned.get("selection_method"), "limitations": planned.get("geometry_fit_limitations")},
        "provenance_accounting": provenance_accounting(root, args.experiment),
        "totals": totals, "per_diameter": per_diameter,
        "semantics": {"lift_hold_passed": "Final flag: original evaluator lift/hold pass AND sampled five-second-lift protocol gate. LIFT stability uses saved trace samples (normally 10 Hz plus exact phase boundaries); POSTLIFT HOLD uses every 4 ms physics step (250 Hz), including actual rise 95-105 mm throughout 5 s. Neither video replay nor sampled audit observes unsaved lift substeps.", "base_evaluator_outcomes": "Frozen original evaluator outcomes are preserved per record before sampled-lift gating; compare them to final flags rather than overwriting their meaning.", "release_passed": "Recorded release criterion is evaluated separately; a failed grip that simply leaves the object on the table is not a full-sequence pass.", "full_sequence_passed": "base_evaluator full-sequence pass AND sampled-lift stability pass; equivalent to final lift_hold_passed AND release_passed", "representative_videos": "Representative selection uses final audited results; the report retains every tested outcome. Video state replay does not compute success."},
        "motion_protocol_audit": {"summary_path": str(motion_path), "summary_sha256": sha256(motion_path) if motion_path.is_file() else None,
                                  **{key: value for key, value in motion_summary.items() if key not in ("candidates", "dependencies")},
                                  "record_trace_rates_hz": dict(Counter(str(r.get("motion_protocol", {}).get("trace_fps")) for r in records if "motion_protocol" in r)),
                                  "coverage_and_final_counts_verified": motion_complete},
        "source": {"commit": git("rev-parse", "HEAD"), "tracked_status": source_status, "tracked_source_unchanged": not source_status},
        "environment": versions, "records": records, "evaluation_exceptions": errors,
        "integrity": {"unreadable_metrics": unreadable, "missing_trace": [r["metrics_path"] for r in records if not r["trace_exists"]], "grasp_inputs_not_evaluated": sorted(expected_inputs - evaluated_inputs), "evaluated_inputs_outside_grasp_root": sorted(evaluated_inputs - expected_inputs), "candidate_accounting_complete": expected_inputs == evaluated_inputs,
                      "motion_protocol_applied_and_complete": motion_complete, "motion_protocol_trace_hash_mismatches": motion_trace_mismatches},
        "script_and_manifest_hashes": inventory,
    }
    return result


def report(summary, animation):
    config, assets = summary["config"], summary["assets"]
    t = summary["totals"]
    comparison = summary.get("matched_load_comparison", {})
    comparison_totals = comparison.get("totals", {})
    failure = summary.get("failure_analysis", {})
    categories = failure.get("primary_observed_categories", {})
    lines = ["# Shadow 200 g 圆柱抓取、抬升持握与释放复测", "",
             "本轮覆盖直径 1、5、10、20、30、40、50、60、70、80、90、100 mm；每个圆柱高度为直径的 4 倍、质量为 200 g。沿用已经冻结的 314 个候选控制目标与同一控制逻辑，仅将自由物体质量从 100 g 改为 200 g，重新执行全部动力学仿真，没有新增合成、优化或调参。", "",
             "原 100 g 的成功标签、轨迹和展示样本不能作为 200 g 的结果；本报告只以新 200 g 测试指标和新轨迹为依据。释放退离方向仍由相同策略根据实际持握物体位姿计算，因此可随负载响应改变，不要求所有阶段逐帧控制输出完全相同。", "",
             "## 新 200 g 实际结果", "",
             "| 直径 / 高度 mm | 继承初始提案 | 冻结控制候选 | 新测候选 | 抬升持握通过 | 释放通过 | 全流程通过 |",
             "|---|---:|---:|---:|---:|---:|---:|"]
    for row in summary["per_diameter"]:
        lines.append(f"| {row['diameter_mm']} / {row['height_mm']} | {row['initializations']} | {row['grasp_candidates']} | {row['tested']} | {row['lift_hold_passed']} | {row['release_passed']} | {row['full_sequence_passed']} |")
    lines += [f"| 合计 | {t['initializations']} | {t['grasp_candidates']} | {t['tested']} | {t['lift_hold_passed']} | {t['release_passed']} | {t['full_sequence_passed']} |", "",
              f"原评价器在本轮 200 g 下的抬升持握通过数为 {t['base_evaluator_lift_hold_passed']}，全流程通过数为 {t['base_evaluator_full_sequence_passed']}；附加提升过程采样门后，最终对应为 {t['lift_hold_passed']} 和 {t['full_sequence_passed']}。原始标志保存在 base_evaluator_outcomes 中。", "",
              "每个尺寸的成功数描述这批冻结控制在 200 g 下的表现，不是重新优化后 Shadow 的最大 200 g 操作能力。初始提案数只是控制来源的历史文件数，不表示本轮重新优化；旧候选生成预算本来不均，不能当成各直径统一搜索预算下的统计成功率。", "",
              "## 动作流程与物理判据", "",
              f"全部测试开启重力，实际编译物体质量应为 {config.get('mass_kg', .2)} kg。动作流程：接近 {config.get('approach_s')} s → 按选定抓型闭合和夹紧 → 夹紧目标受力保持 {config.get('loaded_hold_s')} s → 在 {config.get('lift_s')} s 内平稳提升手根目标 100 mm → 到位持握 {config.get('postlift_hold_s')} s → 松指 {config.get('release_open_s')} s → 退离 {config.get('release_retreat_s')} s → 释放后观察 {config.get('release_settle_s')} s。", "",
              "100 mm 是手根控制目标，物体的实际升高另行测量。到位后完整 5 s 持握阶段，每个 4 ms 物理步（250 Hz）都检查：物体实际升高 95–105 mm、相对预期位置误差及持握平移漂移小于 20 mm、相应旋转误差和漂移小于 15°、不接触桌面、结束时至少 2 个手物接触点、状态有限且无警告或意外时间重置。", "",
              "5 s 提升过程另按保存的实际状态样本复核，通常 10 Hz 并含准确阶段边界：三维 smoothstep 位置跟踪误差不超过 20 mm、相对闭合姿态转角不超过 15°、从已达到高度向下回滑不超过 2 mm、每个提升样本至少 2 个手物接触点、样本及阶段覆盖完整。接触点数不等于独立手指数，刚离桌前可仍有桌面接触。", "",
              "提升阶段的采样复核不能证明未保存的 4 ms 子步也满足条件；它与到位后 250 Hz 逐步持握检查不同。最终抬升持握与全流程标志必须同时通过原评价器和提升采样门。释放通过独立要求手物接触清零、物体实际落回桌面且相对开始松指时下落至少 20 mm；完整流程要求两项都通过。", "",
              "夹紧受力保持阶段记录实际法向接触力；物体在离桌前仍可能由桌面承重，未人为添加侧向外力。200 g 重力载荷约 1.962 N；原有 squeeze 控制没有为加倍负载重新调强。", "",
              "## 失败类型", "",
              f"本轮 {failure.get('200g_failed')} 个未通过结果中，{categories.get('lift_height_precision')} 个仅实际升高不足 95 mm，其余提升、持握和释放条件均通过；{categories.get('orientation_offset')} 个存在朝向偏差，其中一个兼高度不足。另有 {categories.get('initial_contact_shortfall')} 个夹持末接触不足、{categories.get('no_effective_lift')} 个有初始接触但未有效抬起、{categories.get('lift_then_contact_loss')} 个先上升后失去接触并回落。", "",
              "5、90、100 mm 展示样本实际升高分别约 92.80、94.65、94.82 mm，因此未通过高度判据；1 mm 展示样本未离桌。失败不能全部解释为掉落，也不能据此断言其他控制方案必然无法完成。", "",
              "- [逐尺寸失败分析](FAILURE_ANALYSIS.md)", "- [全部候选的分类与证据](FAILURE_ANALYSIS.json)", "",
              "## 同一候选的 100 g / 200 g 配对比较", "",
              f"配对检查完成：`{comparison.get('integrity', {}).get('complete_strict_matched_control_comparison')}`。100 g 与 200 g 最终抬升持握通过数分别为 {comparison_totals.get('baseline_lift_hold_passed')} / {comparison_totals.get('new_lift_hold_passed')}，全流程通过数分别为 {comparison_totals.get('baseline_full_sequence_passed')} / {comparison_totals.get('new_full_sequence_passed')}。", "",
              "候选文件按 SHA-256 和相对候选身份一一配对，核对接近至持握结束的控制目标、除质量外的协议及实际模型质量。释放退离的反馈响应不要求逐帧恒同。逐尺寸通过→失败、失败→通过和逐候选实际升高、持握余量变化见下列比较文件。代表动画会根据各负载的新结果重新选择，可能更换候选，但整个候选控制集合不变。", "",
              "- [负载配对比较说明](LOAD_COMPARISON.md)", "- [全部配对数值](load-comparison.json)",
              "- [控制和模型配置独立审计](controlled-comparison-verification.json)",
              "- [新 200 g 实际模型质量核验](MASS_VALIDATION.md)", "- [模型质量数值](mass-validation.json)", "",
              "## 候选来源与复现边界", "",
              "本轮 314 个控制和 520 个历史初始化文件逐字节继承自 100 g 实验，包括 scene_path 和全部数值数组；新仿真在编译模型前显式使用 --mass 0.2 重算密度。没有复制旧评价标签或轨迹。几何资产保持原样；统一质量而非统一材料密度，故不同尺寸的密度不同。", "",
              "几何自适应模板选择与合成属于 100 g 控制来源的历史过程，本轮没有再次执行。原 adaptive-plan.json 中的 0.1 kg 字段也仅描述历史来源，不是本轮实际质量。setup-provenance.json 记录 314 个控制及初始化的来源 SHA；新的 mass-validation.json 与运行时模型文件验证实际质量为 0.2 kg。", "",
              "在同一控制集合上复测可以比较质量变化的影响，但不能据此断言重新规划、重新调参或采用其他模板时某一尺寸必然无法完成。全部失败仍保留于结果文件。", "",
              "## 新动画与完整数据", "", "- [12 种直径 200 g 总览](animations/all_12_diameters.mp4)", "- [新 200 g 完整数值汇总](adaptive_lift_summary.json)"]
    for row in animation.get("representatives", []):
        d = row["diameter_mm"]
        label = {"full_sequence_pass": "全流程通过", "failed_trial": "未通过（真实试验）"}.get(row.get("status"), row.get("status"))
        lines.append(f"- [直径 {d} mm 的新 200 g 动画](animations/d{d:03d}/d{d:03d}_full_sequence.mp4)：{label}")
    lines += ["", "本轮每个尺寸都有实际物理轨迹，动画展示记录的真实状态；回放不重新积分，也不以画面判定成功。全部候选指标与失败、完整轨迹、模型、候选控制和复现代码保留于结果包。所有视频按新 200 g 指标重新选择，未复用旧 100 g 动画。", "",
              "## 协议审计、环境与采样范围", "",
              f"提升采样审计覆盖 {t['motion_protocol_audited']} 个新候选，应用与最终计数核对为 `{summary.get('motion_protocol_audit', {}).get('coverage_and_final_counts_verified')}`。资产和协议依赖的指纹用于检查缓存失效；该指纹不能反向证明更早未记录的状态。", "",
              "- [新协议审查](PROTOCOL_REVIEW.md)", "- [新提升采样审计](motion-protocol-summary.json)", "",
              f"基线源码：`{summary['source']['commit']}`；Git 跟踪源码未改动：`{summary['source']['tracked_source_unchanged']}`。", "", "```json", json.dumps(summary["environment"], ensure_ascii=False, indent=2), "```", ""]
    baseline_url = summary.get("baseline_reference", {}).get("release_url")
    lines += ["## 从已打包控制复现", "",
              "本包已含同一组控制和冻结评价器，不需要重新合成抓取。新机器先克隆 Lvguichen-C/Dexonomy，检出本报告列出的基线提交，初始化 third_party/mujoco_menagerie 子模块，并按上面的环境版本安装 CPU 依赖。该基线提交记录了子模块版本；MuJoCo、Torch、Warp、NumPy 的版本应与报告一致。", "",
              "以下命令面向当前云环境；解压到其他目录时先重定位候选 NPY 中绝对 scene_path 和场景引用的网格路径，并相应修改启动器、代码中的 /workspace 路径及已安装环境。新包的 setup-provenance.json 保存原 SHA 和来源，重定位后的文件应重新建立清单，不应冒称仍与原始包逐字节相同。", "",
              "```bash", "R=/workspace/shadow-lift-sweep-200g", "CPU=/workspace/shadow-reproduction/run_cpu.sh",
              "EVALUATOR=$R/evaluate_lifts.py",
              "# 当前环境保留同一冻结源文件；解压包已将其放入新目录。",
              "if [ ! -f \"$EVALUATOR\" ]; then EVALUATOR=/workspace/shadow-lift-sweep/evaluate_lifts.py; fi",
              '"$CPU" python "$EVALUATOR" --grasp-root "$R/output/diameter_sweep_200g_shadow/grasp_data" --outdir "$R/lift-evaluation" --mass 0.2 --workers 2',
              '"$CPU" python "$R/verify_controlled_comparison.py" --root "$R" --require-complete',
              '"$CPU" python "$R/validate_motion_protocol.py" --root "$R" --evaluation-root "$R/lift-evaluation" --apply',
              '"$CPU" python "$R/finalize_runtime_models.py" --root "$R" --evaluation-root "$R/lift-evaluation" --mass 0.2 --apply',
              '"$CPU" python "$R/render_sweep.py" --evaluation-root "$R/lift-evaluation" --outdir "$R/animations" --fps 10 --reuse',
              '"$CPU" python "$R/finalize_montage.py"',
              '"$CPU" python "$R/compare_loads.py" --baseline-root /workspace/shadow-lift-sweep/lift-evaluation --new-root "$R/lift-evaluation" --outdir "$R"',
              '"$CPU" python "$R/summarize_sweep.py" --evaluation-root "$R/lift-evaluation"', "```", "",
              "协议应用必须等最后一个评价进程结束后执行；否则新写入的指标会缺少提升门。总览后处理器只组合已有单项视频，固定 10 fps 和完整帧数，不修改物理轨迹或单项视频。包内评价目录使用 lift-evaluation，与本环境一致；100 g 基线旧包若使用 evaluation 名称，应先将该目录重命名为 lift-evaluation，并重定位其中指标记录的绝对输入和轨迹路径。运行时模型导出、接触几何回放和视频都不能替代实际 200 g 仿真。运行顺序与参数解释另见包内 PROTOCOL_REVIEW.md、MASS_VALIDATION.md、ANIMATION_METHOD.md。", ""]
    if baseline_url:
        lines += [f"100 g 对照基线：[已发布的原实验 Release]({baseline_url})。配对比较需要原基线的完整指标和轨迹；新包不把旧物理轨迹混作 200 g 输出。", ""]
    contact = summary.get("selected_contact_diagnostics", {})
    if contact:
        rows = contact.get("representatives", [])
        passed = [row for row in rows if row.get("full_sequence_passed")]
        hold_max = max((row["by_phase"]["postlift_hold"]["hand_object"]["maximum_penetration_mm"] for row in passed), default=0)
        lift_max = max((row["by_phase"]["lift"]["hand_object"]["maximum_penetration_mm"] for row in passed), default=0)
        lines += ["## 本轮 200 g 展示样本的接触数值局限", "",
                  f"仅使用新 200 g 轨迹的接触复核，共 {len(rows)} 个展示样本，其中 {len(passed)} 个全流程通过。通过样本提升阶段的最大手物重叠为 {lift_max:.3f} mm，持握阶段为 {hold_max:.3f} mm。", "",
                  "MuJoCo 采用软接触；这些数值不是严格刚性几何的无穿透证明。接触几何复核采用保存状态采样，不构成新的动力学执行或未保存子步观测。完整分阶段数值见本轮 contact-diagnostics.json；没有复制旧 100 g 的接触数字。", ""]
    return "\n".join(lines)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root", type=Path, default=Path("/workspace/shadow-lift-sweep-200g"))
    parser.add_argument("--evaluation-root", type=Path, required=True)
    parser.add_argument("--experiment", type=Path, default=Path("/workspace/shadow-lift-sweep-200g/output/diameter_sweep_200g_shadow"))
    parser.add_argument("--repo", type=Path, default=Path("/workspace/Dexonomy"))
    parser.add_argument("--animation-root", type=Path, default=Path("/workspace/shadow-lift-sweep-200g/animations"))
    args = parser.parse_args()
    summary = summarize(args)
    animation = read(args.animation_root / "index.json", {})
    summary["representative_animations"] = animation
    summary["selected_contact_diagnostics"] = read(args.root / "contact-diagnostics.json", {})
    load_comparison = read(args.root / "load-comparison.json", {})
    summary["matched_load_comparison"] = {key: value for key, value in load_comparison.items() if key != "pairs"}
    summary["matched_load_comparison"]["summary_sha256"] = sha256(args.root / "load-comparison.json") if (args.root / "load-comparison.json").is_file() else None
    failure_analysis = read(args.root / "FAILURE_ANALYSIS.json", {})
    summary["failure_analysis"] = {key: value for key, value in failure_analysis.items() if key != "candidates"}
    summary["failure_analysis"]["source_sha256"] = sha256(args.root / "FAILURE_ANALYSIS.json")
    summary["integrity"]["strict_matched_load_comparison_complete"] = bool(load_comparison.get("integrity", {}).get("complete_strict_matched_control_comparison"))
    setup = read(args.root / "setup-provenance.json", {})
    baseline_root = Path(setup.get("source_root", "/workspace/shadow-lift-sweep"))
    baseline_publication = read(baseline_root / "publication.json", {})
    summary["baseline_reference"] = {key: baseline_publication.get(key) for key in ("published", "commit", "release_url")}
    (args.root / "adaptive_lift_summary.json").write_text(json.dumps(summary, ensure_ascii=False, indent=2) + "\n")
    (args.root / "ADAPTIVE_LIFT_REPORT.md").write_text(report(summary, animation))
    print(json.dumps({"totals": summary["totals"], "candidate_accounting_complete": summary["integrity"]["candidate_accounting_complete"], "report": str(args.root / "ADAPTIVE_LIFT_REPORT.md")}, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
