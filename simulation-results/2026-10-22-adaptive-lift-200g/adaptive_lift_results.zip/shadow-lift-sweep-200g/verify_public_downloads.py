#!/usr/bin/env python3
"""Fetch published immutable public URLs and verify local delivery hashes."""
from __future__ import annotations

import argparse
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import subprocess


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--root', type=Path, default=Path('/workspace/shadow-lift-sweep-200g'))
    args = parser.parse_args()
    publication = json.loads((args.root / 'publication.json').read_text())
    assert publication['published'] and publication['main_unchanged']
    output = args.root / 'download-verified'
    output.mkdir(exist_ok=True)

    def verify(row):
        name = row['name']
        assert name == Path(name).name
        url = row['raw_url']
        assert url.startswith('https://raw.githubusercontent.com/Lvguichen-C/Dexonomy/' + publication['commit'] + '/')
        target = output / name
        temporary = target.with_name(target.name + '.partial')
        subprocess.run(['curl', '--fail', '--silent', '--show-error', '--location',
                        '--retry', '3', '--connect-timeout', '20', '--max-time', '180',
                        '--output', str(temporary), url], check=True)
        digest = hashlib.sha256(temporary.read_bytes()).hexdigest()
        size = temporary.stat().st_size
        correct = digest == row['sha256'] and size == row['bytes']
        result = {'name': name, 'url': url, 'bytes': size, 'sha256': digest,
                  'expected_bytes': row['bytes'], 'expected_sha256': row['sha256'],
                  'verified': correct}
        if correct:
            temporary.replace(target)
        return result

    with ThreadPoolExecutor(max_workers=4) as pool:
        rows = list(pool.map(verify, publication['files']))
    report = {'generated_at_utc': datetime.now(timezone.utc).isoformat(),
              'commit': publication['commit'], 'release_url': publication.get('release_url'),
              'file_count': len(rows), 'all_verified': all(row['verified'] for row in rows),
              'total_bytes': sum(row['bytes'] for row in rows), 'files': rows}
    (args.root / 'public-download-verification.json').write_text(
        json.dumps(report, ensure_ascii=False, indent=2) + '\n')
    print(json.dumps({key: value for key, value in report.items() if key != 'files'}, ensure_ascii=False, indent=2))
    if not report['all_verified']:
        raise SystemExit('Public download integrity mismatch')


if __name__ == '__main__':
    main()
