#!/usr/bin/env python3
"""Display recorded MuJoCo states from the adaptive Shadow lift sweep.

This is a renderer, never a physics evaluator. Metrics come from the original
continuous set_ctrl/mj_step trials. State assignment and mj_forward here only
display those recorded states, including genuine failures and releases.
"""
from __future__ import annotations

import argparse
from concurrent.futures import ThreadPoolExecutor
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
import sys

os.environ.setdefault("MUJOCO_GL", "egl")
os.environ.setdefault("LP_NUM_THREADS", "2")
sys.path.insert(0, "/workspace/shadow-reproduction")
sys.path.insert(0, "/workspace/Dexonomy")
# Prefer this benchmark's frozen evaluator; the previous source is a read-only
# fallback until the primary agent copies the identical evaluator here.
sys.path.insert(0, str(Path(__file__).resolve().parent))
sys.path.append("/workspace/shadow-lift-sweep")

import mujoco
import numpy as np
from PIL import Image, ImageDraw, ImageFont

from video_writer import VideoWriter
from evaluate_lifts import make_env, prepare_scene

DIAMETERS = [1, 5, 10, 20, 30, 40, 50, 60, 70, 80, 90, 100]
PHASE_LABELS = {
    "approach": "接近",
    "approach_close_squeeze": "自适应闭合 / 夹紧",
    "loaded_hold": "夹紧受力保持",
    "lift": "平稳提升 100 mm / 5 s",
    "postlift_hold": "到位持握 5 s",
    "release_open": "松开手指",
    "release_retreat": "释放 / 手部退离",
    "release_settle": "释放后观察",
}


def sha256(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def font(size):
    try:
        return ImageFont.truetype("/usr/share/fonts/opentype/noto/NotoSansCJK-Regular.ttc", size)
    except OSError:
        return ImageFont.truetype("/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf", size)


def write_json(path, value):
    Path(path).write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n")


def diameter_of(record):
    return int(re.search(r"_(\d+)$", record["scene_id"]).group(1))


def finite_number(value, fallback=1e6):
    try:
        number = float(value)
        return number if np.isfinite(number) else fallback
    except (ValueError, TypeError):
        return fallback


def selection_key(record):
    """Prefer full valid execution, then lift/hold, then measured safety margin."""
    constraints = dict(record.get("hold_criteria", {}))
    motion = record.get("motion_protocol", {})
    constraints.update({"sampled_lift_" + key: value for key, value in motion.get("checks", {}).items()})
    error = finite_number(record.get("maximum_expected_position_error_during_hold_m")) / 0.02
    angle = finite_number(record.get("maximum_closure_rotation_during_hold_deg")) / 15
    drift = finite_number(record.get("postlift_hold_maximum_drift_m")) / 0.02
    rotation = finite_number(record.get("postlift_hold_maximum_rotation_deg")) / 15
    lift_error = finite_number(record.get("maximum_absolute_lift_error_during_hold_mm"), fallback=0.0) / 5
    motion_position = finite_number(motion.get("maximum_smoothstep_position_error_mm"), fallback=0.0) / 20
    motion_rotation = finite_number(motion.get("maximum_closure_relative_rotation_deg"), fallback=0.0) / 15
    motion_drawdown = finite_number(motion.get("maximum_downward_excursion_from_reached_height_mm"), fallback=0.0) / 2
    return (
        not bool(record.get("full_sequence_passed")),
        not bool(record.get("lift_hold_passed", record.get("passed"))),
        -sum(bool(value) for value in constraints.values()),
        max(lift_error, error, angle, drift, rotation, motion_position, motion_rotation, motion_drawdown),
        lift_error + error + angle + drift + rotation + motion_position + motion_rotation + motion_drawdown,
        str(record.get("input", "")),
    )


def select_representatives(root, output, expected_mass=0.2):
    grouped = {d: [] for d in DIAMETERS}
    for path in sorted(Path(root).rglob("metrics.json")):
        record = json.loads(path.read_text())
        if record.get("schema_version") != 1 or "hold_criteria" not in record:
            continue
        if not np.isclose(record["config"]["mass_kg"], expected_mass, rtol=1e-9, atol=1e-12):
            raise ValueError(f"Wrong mass in benchmark metrics: {path}")
        trace = Path(record.get("trace", path.with_name("trace.npz")))
        if not trace.is_file():
            continue
        diameter = diameter_of(record)
        if diameter in grouped:
            grouped[diameter].append((record, path, trace))
    selected = []
    for diameter, entries in grouped.items():
        if not entries:
            selected.append({"diameter_mm": diameter, "evaluated_candidates": 0, "status": "no_evaluated_candidate", "metrics": None, "trace": None})
            continue
        entries.sort(key=lambda row: selection_key(row[0]))
        record, metrics, trace = entries[0]
        selected.append({
            "diameter_mm": diameter,
            "evaluated_candidates": len(entries),
            "lift_hold_passed_count": sum(bool(row[0].get("lift_hold_passed")) for row in entries),
            "full_sequence_passed_count": sum(bool(row[0].get("full_sequence_passed")) for row in entries),
            "status": "full_sequence_pass" if record.get("full_sequence_passed") else "lift_hold_pass_release_fail" if record.get("lift_hold_passed") else "failed_trial",
            "template": record.get("template"),
            "input": record["input"],
            "input_sha256": record["input_sha256"],
            "object_mass_kg": record["config"]["mass_kg"],
            "motion_protocol_present": "motion_protocol" in record,
            "motion_protocol_passed": record.get("motion_protocol", {}).get("passed"),
            "motion_protocol_sample_hz": record.get("motion_protocol", {}).get("trace_fps"),
            "metrics": str(metrics.resolve()),
            "metrics_sha256": sha256(metrics),
            "trace": str(trace.resolve()),
            "trace_sha256": sha256(trace),
            "selection_key": list(selection_key(record)),
        })
    result = {
        "benchmark_mass_kg": expected_mass,
        "selection_policy": "All evaluated candidates remain in the results. Each diameter's displayed representative prefers a full-sequence pass after any applied sampled-motion gate, then lift/hold pass, then most satisfied hold and sampled-motion criteria, then smallest normalized worst lift-distance/position/orientation/drawdown error (5 mm final lift, 20 mm tracking/drift, 15 deg orientation, 2 mm lift drawdown tolerances). Input path breaks exact ties.",
        "rendering": "Recorded physical-state replay only. No physics is inferred from video or rerun during replay.",
        "representatives": selected,
    }
    write_json(output, result)
    return result


def apply_frame(env, trace, index):
    data = env._data
    data.qpos[:] = trace["qpos"][index]
    data.qvel[:] = 0  # Display only; integration is never performed here.
    if "ctrl" in trace:
        data.ctrl[:] = trace["ctrl"][index]
    if data.mocap_pos.size and "mocap_pos" in trace:
        data.mocap_pos[:] = trace["mocap_pos"][index]
        data.mocap_quat[:] = trace["mocap_quat"][index]
    data.time = float(trace["time_s"][index])
    mujoco.mj_forward(env._model, data)


def camera_for_trace(env, trace, record):
    camera = mujoco.MjvCamera()
    mujoco.mjv_defaultCamera(camera)
    geom_indices = [i for i in range(env._model.ngeom) if env._model.body(int(env._model.geom_bodyid[i])).name.startswith(("hand-", "obj-"))]
    cloud = []
    for index in np.unique(np.linspace(0, len(trace["time_s"]) - 1, min(24, len(trace["time_s"]))).astype(int)):
        apply_frame(env, trace, index)
        centers = env._data.geom_xpos[geom_indices]
        radii = env._model.geom_rbound[geom_indices, None]
        cloud.extend([centers - radii, centers + radii])
    bounds = np.concatenate(cloud)
    lo, hi = bounds.min(axis=0), bounds.max(axis=0)
    lo[2] = min(lo[2], 0)
    camera.lookat[:] = (lo + hi) / 2
    camera.distance = max(0.48, float(np.max(hi - lo)) * 2.0)
    camera.azimuth, camera.elevation = 135, -20
    return camera


def trace_indices(times, fps):
    """Match recorded states with float32 time tolerance, without interpolation."""
    times = np.asarray(times, dtype=np.float64)
    tolerance = 1e-5  # Covers float32 timestamp roundoff, not a physical interval.
    grid = np.arange(0, float(times[-1]) + 0.5 / fps, 1 / fps)
    indices = np.searchsorted(times, grid + tolerance, side="right") - 1
    indices = np.clip(indices, 0, len(times) - 1)
    indices[-1] = len(times) - 1  # Always show the real recorded final state.
    return grid, indices


def render_trial(job):
    row = job["representative"]
    out = Path(job["outdir"])
    out.mkdir(parents=True, exist_ok=True)
    record = json.loads(Path(row["metrics"]).read_text())
    expected_mass = float(record["config"]["mass_kg"])
    assert np.isclose(expected_mass, job["expected_mass_kg"], rtol=1e-9, atol=1e-12)
    assert sha256(row["metrics"]) == row["metrics_sha256"]
    assert sha256(row["trace"]) == row["trace_sha256"]
    assert sha256(record["input"]) == record["input_sha256"]
    trace_file = np.load(row["trace"], allow_pickle=False)
    trace = {key: trace_file[key] for key in trace_file.files}
    if not np.isfinite(trace["qpos"]).all():
        job["representative"]["diagnostic_reason"] = "记录到非有限状态，完整轨迹无法渲染"
        return render_missing(job, float(record.get("simulation_duration_s", 20.0)))
    if np.any(np.diff(trace["time_s"]) < -1e-6) or record.get("unexpected_time_resets"):
        job["representative"]["diagnostic_reason"] = "仿真发生非预期时间重置"
        return render_missing(job, 20.0)
    _, scene = prepare_scene(record["input"], record["config"]["mass_kg"])
    env = make_env(scene, Path(job["hand_xml"]))
    rendered_mass = float(env._model.body_subtreemass[env._obj_active_bodyid])
    assert np.isclose(rendered_mass, expected_mass, rtol=1e-6, atol=1e-8), (rendered_mass, expected_mass)
    assert np.isclose(rendered_mass, record["object_mass_kg"], rtol=1e-6, atol=1e-8)
    width, height, fps = job["width"], job["height"], job["fps"]
    env._model.vis.global_.offwidth = max(width, env._model.vis.global_.offwidth)
    env._model.vis.global_.offheight = max(height, env._model.vis.global_.offheight)
    renderer = mujoco.Renderer(env._model, height=height, width=width)
    camera = camera_for_trace(env, trace, record)
    option = mujoco.MjvOption()
    option.flags[mujoco.mjtVisFlag.mjVIS_CONTACTPOINT] = False
    large, normal, small = font(max(20, width // 34)), font(max(16, width // 43)), font(max(13, width // 51))
    timeline, indices = trace_indices(trace["time_s"], fps)
    initial_z = float(record["initial_object_pose"][2])
    diameter = row["diameter_mm"]
    # A genuine close-up of the same recorded state helps inspect tiny objects.
    object_config = scene["scene"][scene["task"]["obj_name"]]
    object_height = float(np.asarray(object_config["scale"])[2] * 4)
    closeup = mujoco.MjvCamera()
    mujoco.mjv_defaultCamera(closeup)
    closeup.azimuth, closeup.elevation = 135, -18
    closeup.distance = max(0.055, object_height * 1.8, diameter * 0.001 * 4)
    good = bool(record.get("full_sequence_passed"))
    color = (62, 217, 126) if good else (255, 125, 113)
    status = "全流程通过" if good else "抬升持握通过 / 释放未通过" if record.get("lift_hold_passed") else "未通过"
    target = out / f"d{diameter:03d}_full_sequence.mp4"
    with VideoWriter(target, fps=fps) as writer:
        for frame_number, (clock, index) in enumerate(zip(timeline, indices)):
            apply_frame(env, trace, index)
            renderer.update_scene(env._data, camera=camera, scene_option=option)
            im = Image.fromarray(renderer.render().copy())
            if diameter <= 10:
                closeup.lookat[:] = trace["object_pose"][index, :3]
                renderer.update_scene(env._data, camera=closeup, scene_option=option)
                inset = Image.fromarray(renderer.render().copy()).resize((width // 3, height // 3), Image.Resampling.LANCZOS)
                left, upper = width - width // 3 - 10, round(height * 0.18)
                im.paste(inset, (left, upper))
                inset_draw = ImageDraw.Draw(im)
                inset_draw.rectangle((left, upper, left + width // 3, upper + max(23, small.size + 10)), fill=(17, 22, 30))
                inset_draw.text((left + 4, upper + 2), "同一时刻的物体近景", font=small, fill=(235, 235, 235))
            draw = ImageDraw.Draw(im)
            top = round(height * 0.16)
            bottom = round(height * 0.16)
            draw.rectangle((0, 0, width, top), fill=(17, 22, 30))
            phase = str(trace["phase_names"][int(trace["phase_id"][index])])
            draw.text((12, 5), f"Shadow · Ø{diameter} mm · {expected_mass * 1000:g} g · {PHASE_LABELS.get(phase, phase)}", font=large, fill=(245, 245, 245))
            draw.text((12, top // 2), f"抓型 {record.get('template')}   |   {status}", font=normal, fill=color)
            draw.rectangle((0, height - bottom, width, height), fill=(17, 22, 30))
            rise = (float(trace["object_pose"][index, 2]) - initial_z) * 1000
            hp, tp = int(trace["hand_object_contacts"][index]), int(trace["object_table_contacts"][index])
            force = float(trace["normal_hand_contact_force_sum_N"][index])
            actual_time = float(trace["time_s"][index])
            footer_y = [height - bottom + round(bottom * fraction) for fraction in (0.05, 0.35, 0.65)]
            draw.text((12, footer_y[0]), f"记录 t={actual_time:.2f} s  物体升高 {rise:.1f} mm  手/桌接触 {hp}/{tp}  法向力合计 {force:.2f} N", font=small, fill=(240, 240, 240))
            draw.text((12, footer_y[1]), "重力开启 · 抬升指令 100 mm / 5 s · 到位持握 5 s · 释放", font=small, fill=(225, 229, 233))
            draw.text((12, footer_y[2]), f"实际仿真轨迹回放 · 状态采样 {record.get('trace_fps')} Hz · 未在回放中重新积分", font=small, fill=(165, 180, 194))
            writer.append_data(np.asarray(im))
            if frame_number == 0:
                im.save(out / f"d{diameter:03d}_first.png")
        im.save(out / f"d{diameter:03d}_last.png")
    renderer.close()
    result = {**row, "video": str(target.resolve()), "video_sha256": sha256(target), "renderer_sha256": job["renderer_sha256"], "frames": len(indices), "fps": fps, "source_trace_frames": len(trace["time_s"]), "duration_s": len(indices) / fps, "rendered_object_mass_kg": rendered_mass, "recorded_object_mass_kg": record["object_mass_kg"], "final_trace_index": int(indices[-1]), "final_trace_time_s": float(trace["time_s"][indices[-1]]), "final_video_grid_time_s": float(timeline[-1]), "displayed_time_source": "Recorded trace timestamp, not video grid", "trace_time_matching_tolerance_s": 1e-5, "camera": {"lookat": camera.lookat.tolist(), "distance": float(camera.distance), "azimuth": float(camera.azimuth), "elevation": float(camera.elevation)}}
    write_json(out / "render-index.json", result)
    return result


def render_missing(job, duration):
    row, out = job["representative"], Path(job["outdir"])
    out.mkdir(parents=True, exist_ok=True)
    width, height, fps = job["width"], job["height"], job["fps"]
    diameter = row["diameter_mm"]
    im = Image.new("RGB", (width, height), (24, 31, 40))
    draw = ImageDraw.Draw(im)
    draw.text((width // 12, height // 8), f"Shadow · Ø{diameter} mm", font=font(width // 22), fill=(244, 244, 244))
    reason = row.get("diagnostic_reason", "无已评价的可执行抓取轨迹")
    draw.text((width // 12, height // 3), reason, font=font(width // 28), fill=(255, 145, 130))
    detail = "原始失败指标及轨迹已保留" if row.get("metrics") else "未合成候选 / 候选未进入物理测试"
    draw.text((width // 12, height // 2), detail, font=font(width // 34), fill=(220, 225, 233))
    draw.text((width // 12, height * 3 // 5), "此卡片不代表执行了成功抓取或抬升", font=font(width // 36), fill=(180, 192, 205))
    target = out / f"d{diameter:03d}_full_sequence.mp4"
    duration = max(2.0, duration)
    frames = round(duration * fps)
    with VideoWriter(target, fps=fps) as writer:
        for _ in range(frames):
            writer.append_data(np.asarray(im))
    result = {**row, "video": str(target.resolve()), "video_sha256": sha256(target), "frames": frames, "fps": fps, "duration_s": duration, "diagnostic_card": True, "rendering": "Static diagnostic card only; no fabricated simulation trajectory"}
    write_json(out / "render-index.json", result)
    return result


def montage(results, outdir, fps):
    outdir = Path(outdir)
    target = outdir / "all_12_diameters.mp4"
    args = ["ffmpeg", "-hide_banner", "-loglevel", "error", "-y", "-filter_complex_threads", "1"]
    for row in results:
        args.extend(["-threads", "1", "-i", row["video"]])
    duration = max(row["duration_s"] for row in results)
    filters = []
    for i in range(len(results)):
        filters.append(f"[{i}:v]scale=320:240:force_original_aspect_ratio=decrease,pad=320:240:(ow-iw)/2:(oh-ih)/2,setsar=1,fps={fps},tpad=stop_mode=clone:stop_duration={duration},trim=duration={duration},setpts=PTS-STARTPTS[v{i}]")
    layout = "|".join(f"{(i % 4) * 320}_{(i // 4) * 240}" for i in range(len(results)))
    filters.append("".join(f"[v{i}]" for i in range(len(results))) + f"xstack=inputs={len(results)}:layout={layout}:fill=black[out]")
    args.extend(["-filter_complex", ";".join(filters), "-map", "[out]", "-an", "-c:v", "libx264", "-preset", "fast", "-crf", "21", "-pix_fmt", "yuv420p", "-threads", "2", "-movflags", "+faststart", str(target)])
    subprocess.run(args, check=True)
    return {"path": str(target.resolve()), "sha256": sha256(target), "fps": fps, "duration_s": duration, "rows": 3, "columns": 4}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--evaluation-root", type=Path)
    parser.add_argument("--selection", type=Path)
    parser.add_argument("--outdir", type=Path, required=True)
    parser.add_argument("--hand-xml", type=Path, default=Path("/workspace/Dexonomy/assets/hand/shadow/right.xml"))
    parser.add_argument("--fps", type=int, default=25)
    parser.add_argument("--width", type=int, default=1280)
    parser.add_argument("--height", type=int, default=720)
    parser.add_argument("--expected-mass-kg", type=float, default=0.2)
    parser.add_argument("--diameter", type=int, action="append")
    parser.add_argument("--exclude-diameter", type=int, action="append", default=[])
    parser.add_argument("--select-only", action="store_true")
    parser.add_argument("--reuse", action="store_true")
    parser.add_argument("--workers", type=int, choices=(1, 2), default=2, help="Independent renderer subprocesses")
    parser.add_argument("--worker-job", type=Path, help=argparse.SUPPRESS)
    args = parser.parse_args()
    if args.worker_job:
        job = json.loads(args.worker_job.read_text())
        return render_trial(job)
    args.outdir.mkdir(parents=True, exist_ok=True)
    if args.selection:
        selection = json.loads(args.selection.read_text())
    elif args.evaluation_root:
        selection = select_representatives(args.evaluation_root, args.outdir / "selection.json", args.expected_mass_kg)
    else:
        parser.error("--selection or --evaluation-root is required")
    if args.select_only:
        print(json.dumps(selection, ensure_ascii=False))
        return
    selected = [row for row in selection["representatives"] if (not args.diameter or row["diameter_mm"] in args.diameter) and row["diameter_mm"] not in args.exclude_diameter]
    def render_one(row):
        out = args.outdir / f"d{row['diameter_mm']:03d}"
        out.mkdir(exist_ok=True)
        job = {"representative": row, "outdir": str(out.resolve()), "hand_xml": str(args.hand_xml.resolve()), "fps": args.fps, "width": args.width, "height": args.height, "expected_mass_kg": args.expected_mass_kg, "renderer_sha256": sha256(__file__)}
        job_path = out / "job.json"
        previous = out / "render-index.json"
        if args.reuse and job_path.is_file() and previous.is_file() and json.loads(job_path.read_text()) == job:
            prior = json.loads(previous.read_text())
            if Path(prior["video"]).is_file() and sha256(prior["video"]) == prior["video_sha256"]:
                return prior
        write_json(job_path, job)
        if not row["metrics"]:
            result = render_missing(job, 20.0)
        else:
            worker_env = dict(os.environ)
            worker_env.update(LP_NUM_THREADS="1", OMP_NUM_THREADS="1", OPENBLAS_NUM_THREADS="1")
            with (out / "render.log").open("w") as log:
                proc = subprocess.run([sys.executable, str(Path(__file__).resolve()), "--outdir", str(args.outdir.resolve()), "--worker-job", str(job_path)], stdout=log, stderr=subprocess.STDOUT, env=worker_env)
            if proc.returncode:
                raise RuntimeError(f"Renderer failed: {out / 'render.log'}")
            result = json.loads(previous.read_text())
        print(json.dumps({"diameter_mm": row["diameter_mm"], "rendered": True, "status": row["status"]}, ensure_ascii=False), flush=True)
        return result
    with ThreadPoolExecutor(max_workers=args.workers) as pool:
        results = list(pool.map(render_one, selected))
    combined = montage(results, args.outdir, args.fps) if len(results) == 12 else None
    report = {"rendering": selection["rendering"], "selection_policy": selection["selection_policy"], "representatives": results, "montage": combined, "individual_videos": len(results), "diagnostic_cards": sum(bool(row.get("diagnostic_card")) for row in results)}
    write_json(args.outdir / "index.json", report)
    print(json.dumps({"individual_videos": len(results), "montage": combined}, ensure_ascii=False))


if __name__ == "__main__":
    main()
