#!/usr/bin/env python3
"""Independent read-only source/media audit; writes only audit_animation_* files."""
from __future__ import annotations

import hashlib
import importlib.util
import json
from pathlib import Path
import subprocess

import numpy as np
from PIL import Image, ImageDraw

ROOT = Path('/workspace/shadow-lift-sweep-200g')
EXPECTED = [1, 5, 10, 20, 30, 40, 50, 60, 70, 80, 90, 100]


def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def read(path):
    return json.loads(Path(path).read_text())


def within(path, parent):
    return Path(path).resolve().is_relative_to(Path(parent).resolve())


def probe_decode(path):
    probe = json.loads(subprocess.check_output([
        'ffprobe', '-v', 'error', '-count_frames', '-select_streams', 'v:0',
        '-show_entries', 'stream=codec_name,pix_fmt,width,height,avg_frame_rate,nb_read_frames,duration',
        '-of', 'json', str(path),
    ]))['streams'][0]
    subprocess.run(['ffmpeg', '-v', 'error', '-xerror', '-threads', '1',
                    '-i', str(path), '-f', 'null', '-'], check=True,
                   stdout=subprocess.DEVNULL, stderr=subprocess.PIPE)
    assert probe['codec_name'] == 'h264', probe
    assert probe['pix_fmt'] == 'yuv420p', probe
    assert int(probe['nb_read_frames']) > 0, probe
    return {**probe, 'full_decode': 'passed'}


def sampled_frames(path, probe):
    n = int(probe['nb_read_frames'])
    indices = sorted({0, n // 2, n - 1})
    expr = '+'.join(f'eq(n\\,{i})' for i in indices)
    data = subprocess.check_output([
        'ffmpeg', '-v', 'error', '-threads', '1', '-i', str(path),
        '-vf', 'select=' + expr, '-fps_mode', 'vfr', '-pix_fmt', 'rgb24',
        '-f', 'rawvideo', '-'])
    frames = np.frombuffer(data, dtype=np.uint8).reshape(-1, int(probe['height']), int(probe['width']), 3)
    assert len(frames) == len(indices)
    assert all(float(frame.std()) > 2 for frame in frames)
    return indices, frames


def main():
    index = read(ROOT / 'animations/index.json')
    checkpoint_path = ROOT / 'audit_animation_decode_checkpoint_200g.json'
    checkpoint = read(checkpoint_path) if checkpoint_path.exists() else {}
    passed_decodes = {row['diameter_mm']: row for row in checkpoint.get('representatives', [])}
    spec = importlib.util.spec_from_file_location('_audit_renderer_200g', ROOT / 'render_sweep.py')
    renderer_module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(renderer_module)
    reps = index['representatives']
    assert sorted(row['diameter_mm'] for row in reps) == EXPECTED
    assert index['individual_videos'] == 12
    assert index['diagnostic_cards'] == 0, 'All twelve diameters have recorded physical trials'
    audit = {'scope': 'Independent source binding and full decoding of fresh 200 g animations; no physics rerun',
             'source_index_sha256': digest(ROOT / 'animations/index.json'), 'representatives': []}
    contact = Image.new('RGB', (960, 5 * 264), '#111a27')
    draw = ImageDraw.Draw(contact)
    image_row = 0
    for row in reps:
        d = row['diameter_mm']
        video = Path(row['video'])
        assert within(video, ROOT / 'animations')
        assert digest(video) == row['video_sha256']
        assert row['renderer_sha256'] == digest(ROOT / 'render_sweep.py')
        result = {'diameter_mm': d, 'status': row['status'], 'video': str(video),
                  'video_sha256': digest(video), 'diagnostic_card': bool(row.get('diagnostic_card'))}
        if row.get('metrics'):
            assert within(row['metrics'], ROOT / 'lift-evaluation')
            assert within(row['trace'], ROOT / 'lift-evaluation')
            assert digest(row['metrics']) == row['metrics_sha256']
            assert digest(row['trace']) == row['trace_sha256']
            record = read(row['metrics'])
            assert within(record['input'], ROOT / 'output')
            assert digest(record['input']) == record['input_sha256'] == row['input_sha256']
            assert np.isclose(record['config']['mass_kg'], .2, rtol=1e-9, atol=1e-12)
            assert np.isclose(record['object_mass_kg'], .2, rtol=1e-6, atol=1e-8)
            assert 'motion_protocol' in record
            if not row.get('diagnostic_card'):
                assert np.isclose(row['rendered_object_mass_kg'], .2, rtol=1e-6, atol=1e-8)
                assert bool(record['full_sequence_passed']) == (row['status'] == 'full_sequence_pass')
                with np.load(row['trace'], allow_pickle=False) as trace:
                    names = [str(x) for x in trace['phase_names']]
                    seen = [names[int(x)] for x in np.unique(trace['phase_id'])]
                    required = ['approach', 'approach_close_squeeze', 'loaded_hold', 'lift',
                                'postlift_hold', 'release_open', 'release_retreat', 'release_settle']
                    assert all(phase in seen for phase in required), (d, seen)
                    assert np.isfinite(trace['qpos']).all()
                    assert np.all(np.diff(trace['time_s']) >= -1e-6)
                    fps = int(row['fps'])
                    expected_frames = len(np.arange(0, float(trace['time_s'][-1]) + .5 / fps, 1 / fps))
                    assert int(row['frames']) == expected_frames
                    timeline, source_indices = renderer_module.trace_indices(trace['time_s'], fps)
                    assert int(source_indices[-1]) == len(trace['time_s']) - 1, 'Final actual state omitted'
                    assert float(np.max(trace['time_s'][source_indices] - timeline)) <= 1e-5
                    displayed_phases = {names[int(x)] for x in trace['phase_id'][source_indices]}
                    assert all(phase in displayed_phases for phase in required), (d, displayed_phases)
                    phase_boundaries = np.flatnonzero(np.r_[True, trace['phase_id'][1:] != trace['phase_id'][:-1]])
                    boundary_checks = []
                    for boundary in phase_boundaries:
                        instant = float(trace['time_s'][boundary])
                        frame = int(np.argmin(np.abs(timeline - instant)))
                        coincides = bool(abs(float(timeline[frame]) - instant) <= 1e-5)
                        if coincides:
                            assert int(trace['phase_id'][source_indices[frame]]) == int(trace['phase_id'][boundary])
                        boundary_checks.append({'source_index': int(boundary), 'source_time_s': instant,
                                                'phase': names[int(trace['phase_id'][boundary])],
                                                'coincides_with_frame': coincides})
                    result.update(trace_end_s=float(trace['time_s'][-1]), phases_seen=seen,
                                  recorded_mass_kg=record['object_mass_kg'], rendered_mass_kg=row['rendered_object_mass_kg'],
                                  final_outcome=record['full_sequence_passed'],
                                  final_state_included=True, frame_phase_boundaries=boundary_checks,
                                  maximum_frame_clock_lag_s=float(np.max(timeline - trace['time_s'][source_indices])))
        else:
            assert row.get('diagnostic_card'), row
        saved_decode = passed_decodes.get(d)
        if saved_decode and saved_decode['video_sha256'] == digest(video):
            probe = saved_decode['media']
        else:
            probe = probe_decode(video)
        assert (int(probe['width']), int(probe['height'])) == (1280, 720)
        assert int(probe['nb_read_frames']) == int(row['frames'])
        assert abs(float(probe['duration']) - row['duration_s']) < .003
        assert abs(float(probe['duration']) - int(row['frames']) / row['fps']) < .003
        result['media'] = probe
        if d in (1, 5, 20, 90, 100):
            indices, frames = sampled_frames(video, probe)
            result['sampled_video_frames'] = indices
            for col, frame in enumerate(frames):
                thumb = Image.fromarray(frame).resize((320, 240))
                x, y = col * 320, image_row * 264
                contact.paste(thumb, (x, y))
                draw.text((x + 4, y + 242), f'd={d}mm frame={indices[col]}', fill='white')
            image_row += 1
        audit['representatives'].append(result)
        print(f'PASS source and decode: d={d} mm', flush=True)
    montage = index['montage']
    assert montage
    assert digest(montage['path']) == montage['sha256']
    audit['montage'] = {'path': montage['path'], 'sha256': digest(montage['path']),
                        'media': probe_decode(montage['path'])}
    assert (int(audit['montage']['media']['width']), int(audit['montage']['media']['height'])) == (1280, 720)
    assert abs(float(audit['montage']['media']['duration']) - max(row['duration_s'] for row in reps)) < .003
    contact.save(ROOT / 'audit_animation_contact_sheet_200g.jpg', quality=92)
    oldroot = Path('/workspace/shadow-lift-sweep')
    oldsummary = read(oldroot / 'adaptive_lift_summary.json')
    oldindex = read(oldroot / 'animations/index.json')
    oldchecks = []
    for name, saved in oldsummary.get('script_and_manifest_hashes', {}).items():
        path = oldroot / name
        oldchecks.append({'path': str(path), 'sha256_matches_original_summary': digest(path) == saved['sha256']})
    for row in oldindex['representatives']:
        oldchecks.append({'path': row['video'], 'sha256_matches_original_animation_index': digest(row['video']) == row['video_sha256']})
    oldmontage = oldindex.get('montage')
    if oldmontage:
        oldchecks.append({'path': oldmontage['path'], 'sha256_matches_original_animation_index': digest(oldmontage['path']) == oldmontage['sha256']})
    assert all(all(value for key, value in entry.items() if key != 'path') for entry in oldchecks), oldchecks
    audit['old_100g_preservation'] = oldchecks
    audit['new_200g_renderer_sha256'] = digest(ROOT / 'render_sweep.py')
    if checkpoint.get('initial_montage_issue'):
        audit['initial_montage_issue_corrected'] = checkpoint['initial_montage_issue']
    audit['full_decode_count'] = 13
    audit['source_and_media_audit'] = 'passed'
    (ROOT / 'audit_animation_delivery_200g.json').write_text(json.dumps(audit, ensure_ascii=False, indent=2) + '\n')
    print('PASS: 12 representative videos plus montage; fresh 200 g source binding', flush=True)


if __name__ == '__main__':
    main()
