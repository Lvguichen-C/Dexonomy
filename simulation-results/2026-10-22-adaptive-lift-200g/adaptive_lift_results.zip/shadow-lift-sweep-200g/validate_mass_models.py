#!/usr/bin/env python3
"""Compile and audit the 200 g lift models through the frozen evaluator API.

This does not modify control targets, model gains, or previously recorded data.
Each cylinder model is compiled in an isolated subprocess.
"""
from __future__ import annotations

import argparse
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import subprocess
import sys


DIAMETERS = [1, 5, 10, 20, 30, 40, 50, 60, 70, 80, 90, 100]
ROOT = Path(__file__).resolve().parent
ASSET_ROOT = Path("/workspace/Dexonomy/assets/object/cylinder_sweep_20261022")
HAND_XML = Path("/workspace/Dexonomy/assets/hand/shadow/right.xml")
EXPECTED_EVALUATOR_SHA256 = "164fd4e4eab1472a7cf4eb92bf5abf88747f78c1df58b19a0667ce8ce75f5d50"


def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def worker(args):
    import mujoco
    import numpy as np
    from evaluate_lifts import TestConfig, make_env, prepare_scene

    scene_path = ASSET_ROOT / "scene_cfg/cylinder_thin/table_top" / f"d{args.diameter}.npy"
    probe = ROOT / "mass-validation/model-probe-inputs" / f"d{args.diameter}.npy"
    probe.parent.mkdir(parents=True, exist_ok=True)
    np.save(probe, {"scene_path": str(scene_path)})
    _, scene = prepare_scene(probe, args.mass)
    env = make_env(scene, HAND_XML)
    model = env._model
    body = env._obj_active_bodyid
    mass = float(model.body_subtreemass[body])
    object_joints = list(range(int(model.body_jntadr[body]), int(model.body_jntadr[body] + model.body_jntnum[body])))
    object_freejoint = any(model.jnt_type[j] == int(mujoco.mjtJoint.mjJNT_FREE) for j in object_joints)
    object_welds = [index for index in range(model.neq)
                    if model.eq_type[index] == int(mujoco.mjtEq.mjEQ_WELD)
                    and body in (int(model.eq_obj1id[index]), int(model.eq_obj2id[index]))]
    inertias = np.asarray(model.body_inertia[body]).copy()
    assert abs(mass - args.mass) < 1e-7, (args.diameter, mass)
    assert object_freejoint, args.diameter
    assert not object_welds, (args.diameter, object_welds)
    assert np.isfinite(inertias).all() and (inertias > 0).all(), (args.diameter, inertias)
    assert not (model.opt.disableflags & int(mujoco.mjtDisableBit.mjDSBL_GRAVITY))
    assert np.allclose(model.opt.gravity, [0, 0, -9.81], rtol=0, atol=1e-12)
    assert abs(model.opt.timestep - 0.004) < 1e-12
    configured = TestConfig(mass_kg=args.mass)
    assert configured.mass_kg == args.mass
    report = {
        "diameter_mm": args.diameter, "height_mm": args.diameter * 4,
        "scene_id": scene["scene_id"], "scene_path": str(scene_path),
        "configured_mass_kg": configured.mass_kg,
        "compiled_object_subtree_mass_kg": mass,
        "mass_error_kg": mass - args.mass,
        "body_name": model.body(body).name,
        "body_inertia_kg_m2": inertias.tolist(), "positive_finite_inertia": True,
        "object_freejoint": object_freejoint, "object_weld_count": len(object_welds),
        "gravity_enabled": True, "gravity_m_s2": model.opt.gravity.tolist(),
        "timestep_s": float(model.opt.timestep),
        "normalization_density_kg_m3": float(scene["scene"][scene["task"]["obj_name"]]["density"]),
        "actuator_gain_sha256": hashlib.sha256(model.actuator_gainprm.tobytes()).hexdigest(),
        "actuator_bias_sha256": hashlib.sha256(model.actuator_biasprm.tobytes()).hexdigest(),
        "actuator_force_range_sha256": hashlib.sha256(model.actuator_forcerange.tobytes()).hexdigest(),
        "evaluator_sha256": digest(ROOT / "evaluate_lifts.py"),
        "mujoco_version": mujoco.__version__, "validation_passed": True,
    }
    if args.diameter == 20:
        _, baseline_scene = prepare_scene(probe, 0.1)
        baseline = make_env(baseline_scene, HAND_XML)
        same = {
            name: bool(np.array_equal(getattr(model, name), getattr(baseline._model, name)))
            for name in ("actuator_gainprm", "actuator_biasprm", "actuator_forcerange", "actuator_ctrlrange", "eq_solimp", "eq_solref")
        }
        assert all(same.values()), same
        report["100g_to_200g_control_model_comparison"] = {
            "baseline_object_mass_kg": float(baseline._model.body_subtreemass[baseline._obj_active_bodyid]),
            "unchanged_parameters": same,
            "semantics": "Mass normalization changes only the object density/inertia; actuator gains, force limits, controls and weld solver parameters are unchanged",
        }
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(report, indent=2) + "\n")


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--mass", type=float, default=0.2)
    parser.add_argument("--workers", type=int, default=2)
    parser.add_argument("--worker", action="store_true")
    parser.add_argument("--diameter", type=int)
    parser.add_argument("--output", type=Path)
    args = parser.parse_args()
    assert digest(ROOT / "evaluate_lifts.py") == EXPECTED_EVALUATOR_SHA256
    if args.worker:
        return worker(args)
    directory = ROOT / "mass-validation"
    directory.mkdir(exist_ok=True)

    def launch(diameter):
        output = directory / f"model-d{diameter}.json"
        with (directory / f"model-d{diameter}.log").open("w") as log:
            subprocess.run([sys.executable, __file__, "--worker", "--diameter", str(diameter), "--mass", str(args.mass), "--output", str(output)], check=True, stdout=log, stderr=subprocess.STDOUT)
        return json.loads(output.read_text())

    with ThreadPoolExecutor(max_workers=max(1, args.workers)) as pool:
        rows = list(pool.map(launch, DIAMETERS))
    report = {
        "generated_at_utc": datetime.now(timezone.utc).isoformat(),
        "expected_mass_kg": args.mass, "diameters_mm": DIAMETERS,
        "evaluator_sha256": EXPECTED_EVALUATOR_SHA256,
        "evaluator_file": str(ROOT / "evaluate_lifts.py"),
        "model_count": len(rows), "all_models_validated": all(r["validation_passed"] for r in rows),
        "mass_cli_argument_required": "--mass 0.2",
        "models": rows,
    }
    target = ROOT / "mass-validation.json"
    target.write_text(json.dumps(report, indent=2) + "\n")
    print(json.dumps({key: value for key, value in report.items() if key != "models"}, indent=2))


if __name__ == "__main__":
    main()
