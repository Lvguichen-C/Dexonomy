#!/usr/bin/env python3
"""Classify geometric penetration in recorded representative states.

No trajectory is simulated. Each stored qpos/mocap state is displayed with
mj_forward, and signed contact distances are grouped by phase and object pair.
This samples the saved trace; it is not a reconstruction of unsaved substeps.
"""
from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path
import sys

sys.path.insert(0, "/workspace/shadow-lift-sweep-200g")

import mujoco
import numpy as np

from evaluate_lifts import make_env, prepare_scene


KINDS = ("hand_object", "hand_hand", "hand_table", "object_table", "other")


def sha256(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def category(names):
    hand = [name.startswith("hand-") for name in names]
    obj = [name.startswith("obj-") for name in names]
    if any(hand) and any(obj):
        return "hand_object"
    if all(hand):
        return "hand_hand"
    if any(hand) and "world" in names:
        return "hand_table"
    if any(obj) and "world" in names:
        return "object_table"
    return "other"


def blank():
    return {"maximum_penetration_mm": 0.0, "negative_contact_observations": 0, "maximum_example": None}


def update(target, penetration, example):
    target["negative_contact_observations"] += 1
    if penetration > target["maximum_penetration_mm"]:
        target["maximum_penetration_mm"] = penetration
        target["maximum_example"] = example


def audit(row, hand_xml):
    metrics = json.loads(Path(row["metrics"]).read_text())
    assert sha256(row["input"]) == metrics["input_sha256"]
    assert sha256(row["trace"]) == row["trace_sha256"]
    archive = np.load(row["trace"], allow_pickle=False)
    _, scene = prepare_scene(metrics["input"], metrics["config"]["mass_kg"])
    env = make_env(scene, hand_xml)
    phases = {str(phase): {kind: blank() for kind in KINDS} for phase in archive["phase_names"]}
    global_types = {kind: blank() for kind in KINDS}
    all_maximum = blank()
    sample_counts = {str(phase): 0 for phase in archive["phase_names"]}
    for index in range(len(archive["time_s"])):
        env._data.qpos[:] = archive["qpos"][index]
        env._data.qvel[:] = 0
        env._data.ctrl[:] = archive["ctrl"][index]
        env._data.mocap_pos[:] = archive["mocap_pos"][index]
        env._data.mocap_quat[:] = archive["mocap_quat"][index]
        mujoco.mj_forward(env._model, env._data)
        phase = str(archive["phase_names"][int(archive["phase_id"][index])])
        sample_counts[phase] += 1
        for contact in env._data.contact:
            if contact.dist >= 0:
                continue
            names = [env._model.body(int(env._model.geom_bodyid[g])).name for g in (contact.geom1, contact.geom2)]
            kind = category(names)
            penetration = -float(contact.dist) * 1000
            example = {"phase": phase, "time_s": float(archive["time_s"][index]), "trace_index": index,
                       "bodies": names, "geoms": [env._model.geom(int(g)).name for g in (contact.geom1, contact.geom2)],
                       "contact_position_m": contact.pos.tolist(), "penetration_mm": penetration}
            update(phases[phase][kind], penetration, example)
            update(global_types[kind], penetration, example)
            update(all_maximum, penetration, example)
    diameter = int(row["diameter_mm"])
    held = phases["postlift_hold"]["hand_object"]["maximum_penetration_mm"]
    result = {
        "diameter_mm": diameter, "template": metrics["template"],
        "full_sequence_passed": metrics["full_sequence_passed"], "lift_hold_passed": metrics["lift_hold_passed"],
        "input": metrics["input"], "input_sha256": metrics["input_sha256"],
        "metrics": row["metrics"], "metrics_sha256": sha256(row["metrics"]),
        "trace": row["trace"], "trace_sha256": sha256(row["trace"]), "trace_fps": metrics["trace_fps"],
        "sample_count": len(archive["time_s"]), "samples_per_phase": sample_counts,
        "original_evaluator_maximum_observed_penetration_mm": metrics["maximum_observed_penetration_m"] * 1000,
        "replayed_sample_global_maximum": all_maximum, "by_phase": phases, "by_contact_type": global_types,
        "held_hand_object_maximum_as_fraction_of_diameter": held / diameter,
        "held_hand_object_maximum_as_fraction_of_radius": held / (diameter / 2),
        "runtime_gravity_enabled": not bool(env._model.opt.disableflags & int(mujoco.mjtDisableBit.mjDSBL_GRAVITY)),
        "object_mass_kg": float(env._model.body_subtreemass[env._obj_active_bodyid]),
        "scope": "Signed contact distances from mj_forward on saved qpos/mocap states; no mj_step or new physical evaluation",
        "timing_limit": "Original evaluator observes derived contacts/xpos after mj_step; replay uses stored integrated qpos. A one-physics-step offset and trace sampling mean these maxima need not exactly equal the evaluator's original scalar maximum.",
    }
    del env
    return result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root", type=Path, default=Path("/workspace/shadow-lift-sweep-200g"))
    parser.add_argument("--selection", type=Path, default=Path("/workspace/shadow-lift-sweep-200g/animations/selection.json"))
    parser.add_argument("--hand-xml", type=Path, default=Path("/workspace/Dexonomy/assets/hand/shadow/right.xml"))
    args = parser.parse_args()
    selected = json.loads(args.selection.read_text())["representatives"]
    # Material small/large penetration concerns are reported first.
    selected.sort(key=lambda row: (row["diameter_mm"] not in (5, 40), row["diameter_mm"]))
    rows = []
    for row in selected:
        if not row.get("metrics") or not row.get("trace"):
            continue
        result = audit(row, args.hand_xml)
        rows.append(result)
        print(json.dumps({"diameter_mm": result["diameter_mm"], "global_max_mm": result["replayed_sample_global_maximum"]["maximum_penetration_mm"],
                          "global_max_phase": result["replayed_sample_global_maximum"]["maximum_example"]["phase"],
                          "global_max_bodies": result["replayed_sample_global_maximum"]["maximum_example"]["bodies"],
                          "hold_hand_object_mm": result["by_phase"]["postlift_hold"]["hand_object"]["maximum_penetration_mm"],
                          "lift_hand_object_mm": result["by_phase"]["lift"]["hand_object"]["maximum_penetration_mm"]}), flush=True)
    report = {"schema_version": 1, "audit_script_sha256": sha256(__file__), "selection_sha256": sha256(args.selection),
              "evaluated_representatives": len(rows), "sampled_replay_only": True, "criteria_or_results_changed": False,
              "interpretation": "Negative distances quantify compliant MuJoCo contact overlap. Global maxima may arise during released-object floor impact, so grasp/hold and release are separated. Finite overlap remains a simulation-model limitation, especially for tiny objects; no rigidity or real-hardware guarantee is inferred.",
              "representatives": sorted(rows, key=lambda row: row["diameter_mm"])}
    (args.root / "contact-diagnostics.json").write_text(json.dumps(report, indent=2) + "\n")


if __name__ == "__main__":
    main()
