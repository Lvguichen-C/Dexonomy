"""Reconstruct the missing small_cyl assets from the supplied Shadow guide.

The guide provides d20 scale=(.02,.02,.02), object center z=.04, and no
mesh. We infer a centered cylinder of unit diameter and height 4. All other
diameters preserve this aspect ratio. These are reconstructed assets, not
the unavailable originals. No repository source files are modified.
"""
from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path

import numpy as np
import trimesh


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--repo", type=Path, default=Path("/workspace/Dexonomy"))
    parser.add_argument("--sections", type=int, default=64)
    args = parser.parse_args()
    root = args.repo / "assets/object/small_cyl"
    processed = root / "processed_data/cylinder_thin"
    for name in ("mesh", "urdf", "info"):
        (processed / name).mkdir(parents=True, exist_ok=True)
    mesh = trimesh.creation.cylinder(radius=0.5, height=4.0, sections=args.sections)
    if not mesh.is_watertight or not mesh.is_winding_consistent:
        raise RuntimeError("Generated cylinder is not a closed, oriented mesh")
    (processed / "mesh/simplified.obj").write_text(mesh.export(file_type="obj"))
    (processed / "urdf/coacd.xml").write_text('''<mujoco model="reconstructed_cylinder_thin">
  <compiler angle="radian"/>
  <asset>
    <mesh name="cylinder_mesh" file="../mesh/simplified.obj"/>
  </asset>
  <worldbody>
    <geom name="cylinder_collision" type="mesh" mesh="cylinder_mesh"
          density="1000" rgba="0.95 0.65 0.12 1"/>
  </worldbody>
</mujoco>
''')
    # URDF is supplied for format completeness. Current skip_traj=True pipeline
    # loads the XML and mesh directly; URDF dimensions are canonical as well.
    inertia = np.asarray(mesh.moment_inertia) * 1000.0
    mass = float(mesh.volume * 1000.0)
    (processed / "urdf/coacd.urdf").write_text(f'''<?xml version="1.0"?>
<robot name="reconstructed_cylinder_thin">
  <link name="cylinder_thin">
    <inertial>
      <origin xyz="0 0 0" rpy="0 0 0"/>
      <mass value="{mass:.16g}"/>
      <inertia ixx="{inertia[0,0]:.16g}" iyy="{inertia[1,1]:.16g}" izz="{inertia[2,2]:.16g}" ixy="0" ixz="0" iyz="0"/>
    </inertial>
    <visual><geometry><mesh filename="../mesh/simplified.obj"/></geometry></visual>
    <collision><geometry><mesh filename="../mesh/simplified.obj"/></geometry></collision>
  </link>
</robot>
''')
    info = {
        "mass": mass,
        "density": 1000.0,
        "scale": 1.0,
        "volume": float(mesh.volume),
        "center_mass": mesh.center_mass.tolist(),
        "provenance": "Analytic reconstruction; original assets were not supplied",
    }
    (processed / "info/simplified.json").write_text(json.dumps(info, indent=2) + "\n")
    scenes = []
    for kind in ("floating", "table_top"):
        dest = root / "scene_cfg/cylinder_thin" / kind
        dest.mkdir(parents=True, exist_ok=True)
        for diameter_mm in (10, 15, 20, 30, 40):
            diameter = diameter_mm / 1000.0
            obj = {
                "type": "rigid_object",
                "file_path": "../../../processed_data/cylinder_thin/mesh/simplified.obj",
                "xml_path": "../../../processed_data/cylinder_thin/urdf/coacd.xml",
                "urdf_path": "../../../processed_data/cylinder_thin/urdf/coacd.urdf",
                "info_path": "../../../processed_data/cylinder_thin/info/simplified.json",
                "scale": np.full(3, diameter, dtype=np.float32),
                "pose": np.array([0, 0, 2.0 * diameter, 1, 0, 0, 0], dtype=np.float32),
            }
            scene_id = f"cylinder_thin_{'table' if kind == 'table_top' else 'floating'}_{diameter_mm}"
            cfg = {
                "scene": {"cylinder_thin": obj},
                "scene_id": scene_id,
                "task": {"type": "force_closure", "obj_name": "cylinder_thin"},
            }
            if kind == "table_top":
                cfg["scene"]["table"] = {
                    "type": "plane",
                    "pose": np.array([0, 0, 0, 1, 0, 0, 0], dtype=np.float32),
                    "size": np.array([0.4, 0.4, 0.01], dtype=np.float32),
                    "board": True,
                }
            path = dest / f"d{diameter_mm}.npy"
            np.save(path, cfg, allow_pickle=True)
            scenes.append({
                "path": str(path.relative_to(root)),
                "scene_id": scene_id,
                "diameter_m": diameter,
                "height_m": 4 * diameter,
                "has_table": kind == "table_top",
            })
    (root / "valid_split").mkdir(exist_ok=True)
    # The current pipeline discovers scene .npy files by cfg_path glob and does
    # not consume this split. Keep an explicit scene-path list for reproducibility.
    (root / "valid_split/all.json").write_text(json.dumps([s["path"] for s in scenes], indent=2) + "\n")
    manifest = {
        "provenance": "Reconstructed from dimensions/paths in the uploaded guide; original assets unavailable",
        "assumption": "Canonical cylinder diameter 1, height 4; uniform scaling makes height four times diameter",
        "mesh_sections": args.sections,
        "mesh_vertices": len(mesh.vertices),
        "mesh_faces": len(mesh.faces),
        "canonical_mesh_volume_m3": float(mesh.volume),
        "density_rescaling": "eval_data normalizes mass to obj_mass (default 0.1 kg) using info mass/density/scale",
        "scene_discovery": "op.object.cfg_path glob; valid_split/all.json is informational",
        "scenes": scenes,
        "sha256": {},
    }
    for path in sorted(root.rglob("*")):
        if path.is_file():
            manifest["sha256"][str(path.relative_to(root))] = hashlib.sha256(path.read_bytes()).hexdigest()
    out = Path(__file__).parent / "assets-manifest.json"
    out.write_text(json.dumps(manifest, indent=2) + "\n")
    print(json.dumps({"root": str(root), "manifest": str(out), "scenes": len(scenes)}))


if __name__ == "__main__":
    main()
