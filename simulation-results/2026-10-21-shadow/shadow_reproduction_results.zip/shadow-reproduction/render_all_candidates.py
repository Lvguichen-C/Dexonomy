#!/usr/bin/env python3
"""Render every saved Shadow grasp with continuous native MuJoCo control.

Each scene runs in a separate subprocess with one model/renderer. Each candidate
has one boundary reset, followed by native run_trajectory and a one-second hold.
The preview is unforced and has gravity disabled. PASS/FAIL refers to the native
six-axis evaluation files, not a new success criterion inferred from this video.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import traceback

os.environ.setdefault("MUJOCO_GL", "egl")
os.environ.setdefault("LP_NUM_THREADS", "2")
sys.path.insert(0, "/workspace/Dexonomy")

import mujoco
import numpy as np
from PIL import Image, ImageDraw, ImageFont

from render_validate import contact_stats, make_env, plan, prepare_scene
from video_writer import VideoWriter


WIDTH, HEIGHT = 320, 240


def sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def font(size=12):
    try:
        return ImageFont.truetype("/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf", size)
    except OSError:
        return ImageFont.load_default()


def write_json(path: Path, obj):
    path.write_text(json.dumps(obj, indent=2) + "\n")


def video_writer(path, fps):
    return VideoWriter(path, fps=fps)


class PreviewRecorder:
    mode = "preview"

    def __init__(self, env, renderer, item, camera, fps, output):
        self.env, self.renderer, self.item, self.camera = env, renderer, item, camera
        self.fps, self.output = fps, output
        self.phase = "APPROACH / CLOSE"
        self.force = np.zeros(3)
        self.next_frame = 0.0
        self.steps = 0
        self.frames = []
        self.previous_time = 0.0
        self.reset_anomalies = []
        self.finite = True
        self.max_warnings = np.zeros(len(env._data.warning), dtype=int)
        self.max_penetration = 0.0
        self.contacts = []
        self.options = mujoco.MjvOption()
        self.options.flags[mujoco.mjtVisFlag.mjVIS_CONTACTPOINT] = False
        self.title_font = font(12)
        self.small_font = font(10)

    def begin_trial(self):
        raise RuntimeError("Unexpected reset during a continuous candidate preview")

    def observe(self, initial=False):
        data = self.env._data
        now = float(data.time)
        if not initial:
            self.steps += 1
            if now <= self.previous_time:
                self.reset_anomalies.append({"step": self.steps, "previous_time_s": self.previous_time, "time_s": now})
        self.previous_time = now
        self.finite &= bool(np.isfinite(data.qpos).all() and np.isfinite(data.qvel).all())
        self.max_warnings = np.maximum(self.max_warnings, [w.number for w in data.warning])
        if now + 1e-10 >= self.next_frame:
            hp, tp, penetration = contact_stats(self.env)
            self.max_penetration = max(self.max_penetration, penetration)
            self.contacts.append({"time_s": now, "hand_object": hp, "object_table": tp})
            self.renderer.update_scene(data, camera=self.camera, scene_option=self.options)
            rgb = self.renderer.render().copy()
            im = Image.fromarray(rgb)
            draw = ImageDraw.Draw(im)
            passed = self.item["native_six_axis_pass"]
            color = (68, 220, 125) if passed else (255, 115, 110)
            draw.rectangle((0, 0, WIDTH, 38), fill=(18, 23, 31))
            short_scene = self.item["scene_id"].replace("cylinder_thin_table_", "D") + " mm"
            draw.text((7, 4), f"{short_scene} | {Path(self.item['relative_path']).stem}", font=self.title_font, fill=(245, 245, 245))
            draw.text((7, 21), f"Native 6-axis {'PASS' if passed else 'FAIL'} | {self.phase}", font=self.small_font, fill=color)
            draw.rectangle((0, HEIGHT - 25, WIDTH, HEIGHT), fill=(18, 23, 31))
            draw.text((7, HEIGHT - 23), f"Closure preview | t={now:.2f}s | contacts={hp}", font=self.small_font, fill=(235, 235, 235))
            draw.text((7, HEIGHT - 12), "Gravity OFF; no external force; continuous control", font=self.small_font, fill=(200, 205, 212))
            self.frames.append(np.asarray(im))
            self.next_frame += 1.0 / self.fps

    def finish(self):
        with video_writer(self.output, self.fps) as writer:
            for frame in self.frames:
                writer.append_data(frame)
        data = self.env._data
        return {
            **self.item,
            "clip": str(self.output),
            "video_frames": len(self.frames),
            "fps": self.fps,
            "simulation_duration_s": float(data.time),
            "video_duration_s": len(self.frames) / self.fps,
            "physics_steps": self.steps,
            "timestep_s": float(self.env._model.opt.timestep),
            "trial_boundary_resets": 1,
            "resets_during_trajectory_or_hold": len(self.reset_anomalies),
            "unexpected_time_resets": self.reset_anomalies,
            "finite_states": bool(self.finite),
            "max_warning_counts": self.max_warnings.tolist(),
            "sampled_max_penetration_m": float(self.max_penetration),
            "contacts_at_render_times": self.contacts,
            "camera": {"lookat": self.camera.lookat.tolist(), "distance": float(self.camera.distance), "azimuth": float(self.camera.azimuth), "elevation": float(self.camera.elevation)},
            "gravity_disabled": bool(self.env._model.opt.disableflags & int(mujoco.mjtDisableBit.mjDSBL_GRAVITY)),
            "external_force_norm": float(np.linalg.norm(data.qfrc_applied)),
            "render_error": None,
        }


def fitted_camera(env, azimuth, elevation):
    cam = mujoco.MjvCamera()
    mujoco.mjv_defaultCamera(cam)
    ids = [i for i in range(env._model.ngeom) if env._model.body(int(env._model.geom_bodyid[i])).name.startswith(("hand-", "obj-"))]
    centers = env._data.geom_xpos[ids]
    cam.lookat[:] = (centers.min(axis=0) + centers.max(axis=0)) / 2
    cam.lookat[2] += 0.02
    cam.distance = max(0.38, float(np.max(np.ptp(centers, axis=0))) * 2.5)
    cam.azimuth, cam.elevation = azimuth, elevation
    return cam


def placeholder(item, error):
    im = Image.new("RGB", (WIDTH, HEIGHT), (28, 22, 25))
    d = ImageDraw.Draw(im)
    d.text((8, 12), item["scene_id"], font=font(), fill="white")
    d.text((8, 32), item["candidate_id"], font=font(), fill="white")
    d.text((8, 70), "RENDER FAILED - see index JSON", font=font(), fill=(255, 130, 130))
    d.text((8, 95), error[:48], font=font(10), fill="white")
    return np.asarray(im)


def make_pages(items, clips, outdir, fps, columns=3, rows=3):
    page_size = columns * rows
    pages = []
    for start in range(0, len(items), page_size):
        page_items = items[start:start + page_size]
        page_clips = clips[start:start + page_size]
        count = max(len(frames) for frames in page_clips)
        path = outdir / f"page_{start // page_size + 1:03d}.mp4"
        with video_writer(path, fps) as writer:
            for i in range(count):
                canvas = np.zeros((HEIGHT * rows, WIDTH * columns, 3), dtype=np.uint8)
                canvas[:] = (12, 17, 24)
                for slot, frames in enumerate(page_clips):
                    row, col = divmod(slot, columns)
                    canvas[row * HEIGHT:(row + 1) * HEIGHT, col * WIDTH:(col + 1) * WIDTH] = frames[min(i, len(frames) - 1)]
                writer.append_data(canvas)
        pages.append({"path": str(path), "frames": count, "fps": fps, "candidate_keys": [v["relative_path"] for v in page_items], "padding": "Hold the last rendered frame of shorter tiles"})
    return pages


def combine_videos(paths, output, fps):
    # Every source is produced by the same encoder and uses the same geometry.
    # Concatenating the encoded packets avoids an unnecessary re-encode.
    listing = output.with_suffix(".concat.txt")
    listing.write_text("\n".join("file '" + str(path.resolve()).replace("'", "'\\''") + "'" for path in paths) + "\n")
    subprocess.run(["ffmpeg", "-hide_banner", "-loglevel", "error", "-y", "-f", "concat", "-safe", "0", "-i", str(listing), "-c", "copy", "-movflags", "+faststart", str(output)], check=True)
    probe = subprocess.run(["ffprobe", "-v", "error", "-select_streams", "v:0", "-show_entries", "stream=nb_frames,r_frame_rate", "-of", "json", str(output)], check=True, text=True, capture_output=True)
    stream = json.loads(probe.stdout)["streams"][0]
    rate_num, rate_den = map(int, stream["r_frame_rate"].split("/"))
    if abs(rate_num / rate_den - fps) > 1e-6:
        raise RuntimeError("Concatenated frame rate does not match renderer")
    return int(stream["nb_frames"])


def scene_worker(args):
    job = json.loads(args.worker_job.read_text())
    outdir = Path(job["outdir"])
    outdir.mkdir(parents=True, exist_ok=True)
    clipdir = outdir / "clips"
    clipdir.mkdir(exist_ok=True)
    items = job["candidates"]
    _, scene = prepare_scene(Path(items[0]["input"]), 0.1)
    env = make_env(scene, Path(job["hand_xml"]))
    env._model.vis.global_.offwidth = WIDTH
    env._model.vis.global_.offheight = HEIGHT
    renderer = mujoco.Renderer(env._model, height=HEIGHT, width=WIDTH)
    reports, clips = [], []
    try:
        for item in items:
            path = Path(item["input"])
            if sha256(path) != item["input_sha256"]:
                raise RuntimeError(f"Candidate changed after snapshot: {path}")
            grasp, candidate_scene = prepare_scene(path, 0.1)
            if str(candidate_scene["scene_id"]) != str(scene["scene_id"]):
                raise RuntimeError("Scene changed within worker")
            env.recorder = None
            controls, types, forces, _ = plan(env, grasp, candidate_scene)
            if any(f is not None and np.linalg.norm(f) > 0 for f in forces):
                raise RuntimeError("This preview requires an unforced force-closure trajectory")
            env.reset_qpos(controls[0])
            env._data.qfrc_applied[:] = 0
            camera = fitted_camera(env, job["azimuth"], job["elevation"])
            output = clipdir / f"{item['candidate_id']}.mp4"
            recorder = PreviewRecorder(env, renderer, item, camera, job["fps"], output)
            env.recorder = recorder
            try:
                recorder.observe(initial=True)
                env.run_trajectory(controls, types, forces)
                recorder.phase = "HOLD 1.0s"
                env.step_sim(round(1.0 / env._model.opt.timestep))
                report = recorder.finish()
                report["trajectory_intervals"] = len(controls) - 1
                report["expected_physics_steps"] = (len(controls) - 1) * 25 + round(1.0 / env._model.opt.timestep)
                if report["physics_steps"] != report["expected_physics_steps"]:
                    raise RuntimeError("Native trajectory step count mismatch")
                reports.append(report)
                clips.append(recorder.frames)
            except Exception as error:
                reports.append({**item, "render_error": str(error), "traceback": traceback.format_exc()})
                clips.append([placeholder(item, str(error))] * job["fps"])
            finally:
                env.recorder = None
            print(json.dumps({"candidate": item["relative_path"], "render_error": reports[-1]["render_error"]}), flush=True)
        pages = make_pages(items, clips, outdir, job["fps"], job["columns"], job["rows"])
        montage = outdir / "all_candidates.mp4"
        frames = combine_videos([Path(p["path"]) for p in pages], montage, job["fps"])
        report = {"scene_id": job["scene_id"], "candidates": reports, "pages": pages, "montage": str(montage), "montage_frames": frames, "fps": job["fps"], "complete": all(v["render_error"] is None for v in reports)}
        write_json(outdir / "index.json", report)
    finally:
        renderer.close()


def aggregate(args, results, items, full_count):
    montage = args.outdir / "all_candidates.mp4"
    frame_count = combine_videos([Path(v["montage"]) for v in results], montage, args.fps)
    rendered = [item for scene in results for item in scene["candidates"]]
    if len({v["input"] for v in rendered}) != len(rendered):
        raise RuntimeError("Duplicate candidates in scene indices")
    index = {"method": "Unmodified native run_trajectory (5 interpolation steps × 5 mj_steps per interval), then 1 s final-control hold; one reset per candidate, no frame-wise qpos writes", "preview_conditions": "gravity OFF, object mass 0.100 kg, no external force", "native_labels": "PASS/FAIL from matching finalized native six-axis evaluation success files; the preview does not repeat the six-axis test", "candidate_count": len(items), "native_pass_count": sum(v["native_six_axis_pass"] for v in items), "selected_count_before_smoke_limit": full_count, "smoke_limit": args.limit, "all_selected_candidates_rendered": len(rendered) == len(items) and all(v["render_error"] is None for v in rendered), "all_physics_states_finite": all(v.get("finite_states", False) for v in rendered), "unexpected_time_resets": sum(len(v.get("unexpected_time_resets", [])) for v in rendered), "warning_count": sum(sum(v.get("max_warning_counts", [])) for v in rendered), "montage": str(montage), "montage_sha256": sha256(montage), "montage_frames": frame_count, "fps": args.fps, "scene_indices": [str(Path(v["montage"]).parent / "index.json") for v in results], "candidates": rendered, "pages": [p for v in results for p in v["pages"]]}
    write_json(args.outdir / "index.json", index)
    print(json.dumps({k: index[k] for k in ("candidate_count", "native_pass_count", "all_selected_candidates_rendered", "all_physics_states_finite", "unexpected_time_resets", "warning_count", "montage")}), flush=True)
    if not index["all_selected_candidates_rendered"]:
        raise SystemExit(1)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--grasp-root", type=Path)
    parser.add_argument("--succ-root", type=Path)
    parser.add_argument("--outdir", type=Path)
    parser.add_argument("--scene-id")
    parser.add_argument("--hand-xml", type=Path, default=Path("/workspace/Dexonomy/assets/hand/shadow/right.xml"))
    parser.add_argument("--fps", type=int, default=10)
    parser.add_argument("--columns", type=int, default=3)
    parser.add_argument("--rows", type=int, default=3)
    parser.add_argument("--azimuth", type=float, default=135)
    parser.add_argument("--elevation", type=float, default=-25)
    parser.add_argument("--limit", type=int, help="Smoke-test limit; omitted for full coverage")
    parser.add_argument("--reuse-scenes", action="store_true", help="Reuse completed scenes only when their exact input/status/config snapshot matches")
    parser.add_argument("--merge-indices", type=Path, nargs="+", help="Combine completed per-scene index.json files without rerendering")
    parser.add_argument("--worker-job", type=Path, help=argparse.SUPPRESS)
    args = parser.parse_args()
    if args.worker_job:
        return scene_worker(args)
    if args.merge_indices:
        if args.outdir is None:
            parser.error("--outdir is required for merging")
        args.outdir = args.outdir.resolve()
        args.outdir.mkdir(parents=True, exist_ok=True)
        results = [json.loads(path.read_text()) for path in args.merge_indices]
        if any("scene_id" not in v or not v["complete"] or v["fps"] != args.fps for v in results):
            parser.error("Merge requires complete per-scene indices with matching FPS")
        items = [item for result in results for item in result["candidates"]]
        return aggregate(args, results, items, len(items))
    if args.grasp_root is None or args.succ_root is None or args.outdir is None:
        parser.error("--grasp-root, --succ-root, and --outdir are required")
    args.grasp_root = args.grasp_root.resolve()
    args.succ_root = args.succ_root.resolve()
    args.outdir = args.outdir.resolve()
    args.outdir.mkdir(parents=True, exist_ok=True)
    all_paths = sorted(args.grasp_root.rglob("*.npy"))
    items = []
    for path in all_paths:
        grasp, scene = prepare_scene(path, 0.1)
        scene_id = str(scene["scene_id"])
        if args.scene_id and scene_id != args.scene_id:
            continue
        rel = path.relative_to(args.grasp_root)
        succ = args.succ_root / rel
        items.append({"input": str(path), "relative_path": str(rel), "candidate_id": f"{rel.parts[0]}_{path.stem}" if len(rel.parts) > 2 else path.stem, "scene_id": scene_id, "input_sha256": sha256(path), "native_six_axis_pass": succ.is_file(), "native_success_file": str(succ) if succ.is_file() else None, "native_success_sha256": sha256(succ) if succ.is_file() else None})
    full_count = len(items)
    if args.limit:
        items = items[:args.limit]
    if not items:
        parser.error("No candidate files matched")
    groups = {}
    for item in items:
        groups.setdefault(item["scene_id"], []).append(item)
    write_json(args.outdir / "input_snapshot.json", {"grasp_root": str(args.grasp_root), "succ_root": str(args.succ_root), "selected_count_before_limit": full_count, "candidates": items, "success_label_source": "Existence of matching relative path in finalized native succ_grasp directory"})
    results = []
    for scene_id, candidates in groups.items():
        scene_out = args.outdir / scene_id
        scene_out.mkdir(exist_ok=True)
        job = {"scene_id": scene_id, "outdir": str(scene_out), "candidates": candidates, "hand_xml": str(args.hand_xml.resolve()), "fps": args.fps, "columns": args.columns, "rows": args.rows, "azimuth": args.azimuth, "elevation": args.elevation}
        job_path = scene_out / "job.json"
        prior_index = scene_out / "index.json"
        if args.reuse_scenes and job_path.is_file() and prior_index.is_file() and json.loads(job_path.read_text()) == job:
            previous = json.loads(prior_index.read_text())
            files = [Path(previous["montage"])] + [Path(v["clip"]) for v in previous["candidates"] if v.get("clip")] + [Path(v["path"]) for v in previous["pages"]]
            if previous["complete"] and all(path.is_file() for path in files):
                results.append(previous)
                print(json.dumps({"scene_id": scene_id, "reused": True, "candidates": len(candidates)}), flush=True)
                continue
        write_json(job_path, job)
        with (scene_out / "worker.log").open("w") as log:
            proc = subprocess.run([sys.executable, str(Path(__file__).resolve()), "--worker-job", str(job_path)], stdout=log, stderr=subprocess.STDOUT)
        if proc.returncode:
            raise RuntimeError(f"Scene worker failed ({proc.returncode}): {scene_out / 'worker.log'}")
        results.append(json.loads((scene_out / "index.json").read_text()))
        print(json.dumps({"scene_id": scene_id, "candidates": len(candidates), "complete": results[-1]["complete"]}), flush=True)
    aggregate(args, results, items, full_count)


if __name__ == "__main__":
    main()
