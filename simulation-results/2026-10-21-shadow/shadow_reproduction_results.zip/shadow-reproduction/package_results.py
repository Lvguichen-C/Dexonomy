#!/usr/bin/env python3
"""Package this run's own scripts, generated assets, data, and animations.

This performs local file operations only. It never uploads anything.
"""
from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path
import re
import shutil
import tempfile
import zipfile


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def safe_files(directory: Path):
    for path in sorted(directory.rglob("*")):
        if not path.is_file() or any(p in {"__pycache__", ".git", ".venv", "venv", "deliverables", "dryrun"} for p in path.relative_to(directory).parts):
            continue
        if path.suffix.lower() not in {".py", ".sh", ".md", ".json", ".yaml", ".yml", ".npy", ".npz", ".log", ".txt", ".obj", ".xml", ".urdf", ".mp4", ".gif", ".png"}:
            continue
        yield path


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root", type=Path, default=Path("/workspace/shadow-reproduction"))
    parser.add_argument("--repo", type=Path, default=Path("/workspace/Dexonomy"))
    parser.add_argument("--representative-dir", type=Path, required=True, help="Directory containing native_fc.mp4, gravity_lift.mp4, metrics.json")
    parser.add_argument("--all-candidates", type=Path, required=True, help="Final all-candidate montage MP4")
    parser.add_argument("--include", type=Path, action="append", default=[], help="Additional own result directory outside the standard folders")
    parser.add_argument("--output", type=Path)
    args = parser.parse_args()
    root, repo = args.root.resolve(), args.repo.resolve()
    output = (args.output or root / "deliverables").resolve()
    output.mkdir(parents=True, exist_ok=True)

    top_sources = {
        "SHADOW_REPRODUCTION.md": root / "SHADOW_REPRODUCTION.md",
        "results_summary.json": root / "results-summary.json",
        "representative_metrics.json": args.representative_dir / "metrics.json",
        "shadow_native_fc.mp4": args.representative_dir / "native_fc.mp4",
        "shadow_gravity_lift.mp4": args.representative_dir / "gravity_lift.mp4",
        "all_candidates.mp4": args.all_candidates,
    }
    missing = [str(path) for path in top_sources.values() if not path.is_file()]
    if missing:
        raise SystemExit("Required final artifacts missing:\n" + "\n".join(missing))
    for name, source in top_sources.items():
        shutil.copy2(source, output / name)

    # The online report lives beside flattened delivery files. Keep the original
    # directory-based report in the archive, and avoid broken online deep links.
    report_path = output / "SHADOW_REPRODUCTION.md"
    web_links = {
        "SHADOW_REPRODUCTION.md": "SHADOW_REPRODUCTION.md",
        "results-summary.json": "results_summary.json",
        "animations/d20_0_1/native_fc.mp4": "shadow_native_fc.mp4",
        "animations/d20_0_1/gravity_lift.mp4": "shadow_gravity_lift.mp4",
        "animations/d20_0_1/metrics.json": "representative_metrics.json",
        "animations/all_candidates/all_candidates.mp4": "all_candidates.mp4",
    }

    def online_link(match):
        label, target = match.groups()
        if target.startswith(("https://", "http://", "#")):
            return match.group(0)
        if target in web_links:
            return f"[{label}]({web_links[target]})"
        return f"`{target}`" if label == target else f"{label}（`{target}`）"

    report_text = re.sub(r"\[([^\]]+)\]\(([^)]+)\)", online_link, report_path.read_text())
    notice = "> 在线交付版：目录、代码和逐步轨迹见[完整结果包](shadow_reproduction_results.zip)。解压后阅读 `shadow-reproduction/SHADOW_REPRODUCTION.md`。\n\n"
    report_path.write_text(notice + report_text)

    # Explicit sources exclude attachments, credentials, Python environments, and caches.
    entries: dict[str, Path] = {}
    for path in root.iterdir():
        if path.is_file() and path.suffix in {".py", ".sh", ".md", ".json"} and path.name not in {"publication.json", "publication-plan.json"}:
            entries[f"shadow-reproduction/{path.name}"] = path
    for folder in ("runtime", "audit", "output", "animations", "render-smoke", "montages", "all-candidates"):
        directory = root / folder
        if directory.is_dir():
            for path in safe_files(directory):
                if folder == "animations":
                    parts = path.relative_to(directory).parts
                    if "representative_d20" in parts or any(part.endswith("_smoke") for part in parts):
                        continue
                entries[f"shadow-reproduction/{folder}/{path.relative_to(directory).as_posix()}"] = path
    asset_dir = repo / "assets/object/small_cyl"
    if not asset_dir.is_dir():
        raise SystemExit(f"Generated assets missing: {asset_dir}")
    for path in safe_files(asset_dir):
        entries[f"Dexonomy/assets/object/small_cyl/{path.relative_to(asset_dir).as_posix()}"] = path
    template = repo / "assets/hand/shadow/init_tmpl/24_Tip_Pinch.npy"
    if template.is_file():
        entries["Dexonomy/assets/hand/shadow/init_tmpl/24_Tip_Pinch.npy"] = template
    for directory in args.include:
        directory = directory.resolve()
        if not directory.is_dir() or directory == output or output in directory.parents:
            raise SystemExit(f"Invalid additional directory: {directory}")
        for path in safe_files(directory):
            entries[f"additional-results/{directory.name}/{path.relative_to(directory).as_posix()}"] = path
    # Top-level media are always included, even if a caller chose a custom folder.
    for name, source in top_sources.items():
        entries[f"delivery/{name}"] = output / name

    with tempfile.NamedTemporaryFile(dir=output, prefix="shadow-", suffix=".zip.tmp", delete=False) as tmp:
        temporary = Path(tmp.name)
    try:
        with zipfile.ZipFile(temporary, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=6) as archive:
            for name, source in sorted(entries.items()):
                # zipfile follows success symlinks and stores the actual NPY data.
                archive.write(source, name)
            archive.writestr("PACKAGE_README.txt", "Shadow reproduction results. The generated small_cyl assets are reconstructed analytic cylinders, not original assets from the supplied guide. Native force-closure tests disable gravity; gravity_lift is a separate gravity-on test. See SHADOW_REPRODUCTION.md and RUN_INSTRUCTIONS.md. Success NPY symlinks have been materialized. Data scene_path values refer to the original cloud workspace; relocate paths when using a different checkout. Original user attachments and credentials are excluded.\n")
        if temporary.stat().st_size >= 95_000_000:
            raise SystemExit("ZIP exceeds the 95 MB delivery cap; split archives before publishing.")
        temporary.replace(output / "shadow_reproduction_results.zip")
    finally:
        temporary.unlink(missing_ok=True)
    names = [*top_sources, "shadow_reproduction_results.zip"]
    manifest = {
        "scope": "Own generated Shadow reproduction artifacts only; no uploaded user attachments or credentials",
        "archive_entries": len(entries) + 1,
        "success_npy_symlinks_materialized": True,
        "files": [{"name": name, "bytes": (output / name).stat().st_size, "sha256": sha256(output / name)} for name in names],
    }
    (output / "delivery_manifest.json").write_text(json.dumps(manifest, indent=2, ensure_ascii=False) + "\n")
    print(json.dumps(manifest, indent=2, ensure_ascii=False))


if __name__ == "__main__":
    main()
