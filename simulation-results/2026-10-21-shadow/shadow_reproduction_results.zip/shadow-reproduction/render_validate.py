#!/usr/bin/env python3
"""Render real Shadow dynamics and audit the unchanged native force-closure test.

Only trial-boundary resets are allowed. Rendering never writes qpos or object poses.
Run from the Dexonomy checkout with its Python environment activated.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import os
from pathlib import Path
import sys

os.environ.setdefault("MUJOCO_GL", "egl")
sys.path.insert(0, "/workspace/Dexonomy")

import mujoco
import numpy as np
from PIL import Image, ImageDraw, ImageFont

from dexonomy.sim import HandCfg, MuJoCo_EvalCfg, MuJoCo_EvalEnv
from dexonomy.util.file_util import load_scene_cfg, load_json
from dexonomy.util.np_util import np_get_delta_pose
from dexonomy.util.traj_util import get_planner
from video_writer import VideoWriter


AXES = np.array([[1, 0, 0], [-1, 0, 0], [0, 1, 0], [0, -1, 0], [0, 0, 1], [0, 0, -1]], dtype=float)
AXIS_NAMES = ["+X", "-X", "+Y", "-Y", "+Z", "-Z"]


def contact_stats(env):
    """Classify actual contacts without changing margins or running mj_forward."""
    model, data = env._model, env._data
    hand_object, object_table = 0, 0
    deepest = 0.0
    for c in data.contact:
        names = [model.body(int(model.geom_bodyid[g])).name for g in (c.geom1, c.geom2)]
        if any(n.startswith("hand-") for n in names) and any(n.startswith("obj-") for n in names):
            hand_object += 1
        if any(n.startswith("obj-") for n in names) and ("world" in names):
            object_table += 1
        deepest = max(deepest, -float(c.dist))
    return hand_object, object_table, deepest


def plain(obj):
    if isinstance(obj, np.ndarray):
        return obj.tolist()
    if isinstance(obj, np.generic):
        return obj.item()
    raise TypeError(type(obj).__name__)


class ObservableEnv(MuJoCo_EvalEnv):
    """Dynamics stays in native methods; observation replaces step_sim's debug UI."""
    recorder = None

    def _add_hand(self, *args, **kwargs):
        self._add_for_visualization()
        return super()._add_hand(*args, **kwargs)

    def reset_qpos(self, hand_qpos, set_ctrl=True):
        result = super().reset_qpos(hand_qpos, set_ctrl)
        if self.recorder is not None:
            self.recorder.begin_trial()
        return result

    def set_active_obj_ext_fdir(self, ext_fdir):
        result = super().set_active_obj_ext_fdir(ext_fdir)
        if self.recorder is not None:
            self.recorder.force = np.asarray(ext_fdir, dtype=float).copy()
            self.recorder.phase = "HOLD " + AXIS_NAMES[int(np.argmin(np.linalg.norm(AXES - self.recorder.force, axis=1)))]
        return result

    def step_sim(self, substep):
        if self.recorder is None:
            return super().step_sim(substep)
        for _ in range(substep):
            mujoco.mj_step(self._model, self._data)
            self.recorder.observe()
        if self.recorder.mode == "native" and self.recorder.phase.startswith("HOLD") and substep == 50:
            self.recorder.hold_check()


class Recorder:
    def __init__(self, env, outdir, stem, target, fps=25, video=True, mode="native", azimuth=135, elevation=-25):
        self.env = env
        self.outdir = outdir
        self.stem = stem
        self.target = np.asarray(target).copy()
        self.mode = mode
        self.fps = fps
        self.phase = "APPROACH / CLOSE"
        self.force = np.zeros(3)
        self.trial = -1
        self.next_frame = 0.0
        self.previous_time = 0.0
        self.steps = 0
        self.frames = 0
        self.reset_anomalies = []
        self.trials = []
        self.rows = []
        self.finite = True
        self.max_warning_counts = np.zeros(len(env._data.warning), dtype=int)
        self.renderer = None
        self.writer = None
        try:
            self.font = ImageFont.truetype("/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf", 15)
            self.smallfont = ImageFont.truetype("/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf", 12)
        except OSError:
            self.font = self.smallfont = ImageFont.load_default()
        self.camera = mujoco.MjvCamera()
        mujoco.mjv_defaultCamera(self.camera)
        # Fit physical hand geometry at the initial pregrasp, keep the camera fixed.
        visible = [i for i in range(env._model.ngeom) if env._model.body(int(env._model.geom_bodyid[i])).name.startswith(("hand-", "obj-"))]
        centers = env._data.geom_xpos[visible]
        extent = np.max(np.ptp(centers, axis=0)) if len(centers) else 0.3
        self.camera.lookat[:] = (centers.min(axis=0) + centers.max(axis=0)) / 2 if len(centers) else target[:3]
        self.camera.lookat[2] += 0.02 if mode == "native" else 0.07
        self.camera.distance = max(0.4 if mode == "native" else 0.5, float(extent) * 2.5)
        self.camera.azimuth = azimuth
        self.camera.elevation = elevation
        self.options = mujoco.MjvOption()
        self.options.flags[mujoco.mjtVisFlag.mjVIS_CONTACTPOINT] = True
        self.options.flags[mujoco.mjtVisFlag.mjVIS_CONTACTFORCE] = False
        if video:
            env._model.vis.global_.offwidth = 640
            env._model.vis.global_.offheight = 480
            self.renderer = mujoco.Renderer(env._model, height=480, width=640)
            self.writer = VideoWriter(outdir / f"{stem}.mp4", fps=fps)
        env.recorder = self

    def begin_trial(self):
        self.trial += 1
        self.next_frame = 0.0
        self.previous_time = 0.0
        self.phase = "APPROACH / CLOSE"
        self.force[:] = 0
        self.trials.append({"index": self.trial, "axis": AXIS_NAMES[self.trial] if self.mode == "native" else "gravity lift", "checks": []})
        self.observe(initial=True)

    def observe(self, initial=False):
        env, data = self.env, self.env._data
        now = float(data.time)
        if not initial:
            self.steps += 1
            if now <= self.previous_time:
                self.reset_anomalies.append({"trial": self.trial, "step": self.steps, "previous_time": self.previous_time, "time": now})
        self.previous_time = now
        finite = bool(np.isfinite(data.qpos).all() and np.isfinite(data.qvel).all())
        self.finite &= finite
        self.max_warning_counts = np.maximum(self.max_warning_counts, np.array([w.number for w in data.warning]))
        hp, tp, penetration = contact_stats(env)
        objpose = env.get_active_obj_pose().copy()
        dt, dr = np_get_delta_pose(self.target, objpose)
        self.rows.append((self.trial, now, data.qpos.copy(), data.qvel.copy(), data.ctrl.copy(), objpose, self.force.copy(), hp, tp, penetration, float(dt), float(dr)))
        if self.renderer is not None and now + 1e-10 >= self.next_frame:
            self.renderer.update_scene(data, camera=self.camera, scene_option=self.options)
            rgb = self.renderer.render().copy()
            image = Image.fromarray(rgb)
            draw = ImageDraw.Draw(image)
            draw.rectangle((0, 0, 640, 64), fill=(20, 25, 32))
            draw.text((12, 8), f"SHADOW | {self.mode.upper()} | {self.phase}", font=self.font, fill=(245, 245, 245))
            trial_label = AXIS_NAMES[self.trial] if self.mode == "native" else "lift +100 mm"
            draw.text((12, 34), f"Trial {self.trial + 1} ({trial_label})  t={now:.2f}s  hand/object contacts={hp}", font=self.smallfont, fill=(220, 225, 230))
            draw.rectangle((0, 438, 640, 480), fill=(20, 25, 32))
            if self.mode == "native":
                msg = "Native FC: gravity OFF, mass 0.100 kg, external force 0.980 N"
                val = f"Object displacement {dt * 1000:.1f} mm / {dr:.2f} deg (limits: 50 mm / 15 deg)"
            else:
                msg = "Extra lift: gravity ON, no object pose reset, no external support"
                val = f"Object height {objpose[2] * 1000:.1f} mm | table contacts {tp}"
            draw.text((12, 444), msg, font=self.smallfont, fill=(230, 230, 230))
            draw.text((12, 462), val, font=self.smallfont, fill=(230, 230, 230))
            frame = np.array(image)
            self.writer.append_data(frame)
            if self.frames == 0:
                image.save(self.outdir / f"{self.stem}_first.png")
            self.last_frame = image
            self.frames += 1
            self.next_frame += 1 / self.fps

    def hold_check(self):
        row = self.rows[-1]
        self.trials[-1]["checks"].append({"time_s": row[1], "translation_m": row[10], "rotation_deg": row[11], "within_native_limits": bool(row[10] < 0.05 and row[11] < 15), "hand_object_contacts": row[7], "object_table_contacts": row[8]})

    def finish(self, success):
        if self.writer is not None:
            self.writer.close()
            self.last_frame.save(self.outdir / f"{self.stem}_last.png")
            self.renderer.close()
        for trial in self.trials:
            checks = trial["checks"]
            if self.mode == "native":
                trial["passed"] = len(checks) == 10 and all(c["within_native_limits"] for c in checks)
            trial["checks_completed"] = len(checks)
        arrays = {}
        names = ["trial_index", "time_s", "qpos", "qvel", "ctrl", "object_pose", "external_direction", "hand_object_contacts", "object_table_contacts", "penetration_m", "translation_m", "rotation_deg"]
        for i, name in enumerate(names):
            arrays[name] = np.array([row[i] for row in self.rows])
        np.savez_compressed(self.outdir / f"{self.stem}_trace.npz", **arrays)
        report = {"mode": self.mode, "passed": bool(success), "trials": self.trials, "physics_steps": self.steps, "video_frames": self.frames, "fps": self.fps, "dt_s": float(self.env._model.opt.timestep), "finite_states": bool(self.finite), "unexpected_time_resets": self.reset_anomalies, "max_warning_counts": self.max_warning_counts.tolist(), "max_penetration_m": float(arrays["penetration_m"].max()), "object_mass_kg": float(self.env._model.body_subtreemass[self.env._obj_active_bodyid]), "gravity_disabled": bool(self.env._model.opt.disableflags & int(mujoco.mjtDisableBit.mjDSBL_GRAVITY)), "camera": {"lookat": self.camera.lookat.tolist(), "distance": float(self.camera.distance), "azimuth": float(self.camera.azimuth), "elevation": float(self.camera.elevation)}, "animation_method": "one reset per independent trial; all subsequent motion from set_ctrl and mj_step; no frame-wise qpos writes"}
        self.env.recorder = None
        return report


def make_env(scene, hand_xml):
    env = ObservableEnv(hand_cfg=HandCfg(str(hand_xml), freejoint=True), scene_cfg=scene, sim_cfg=MuJoCo_EvalCfg(miu_coef=[0.6, 0.02]), debug_render=False, debug_view=False, hard=False)
    # Match the configured Shadow red; these arrays affect appearance only.
    for i in range(env._model.ngeom):
        if env._model.body(int(env._model.geom_bodyid[i])).name.startswith("hand-"):
            env._model.geom_matid[i] = -1
            env._model.geom_rgba[i] = [0.863157, 0.0865002, 0.0802199, 1.0]
    return env


def prepare_scene(input_path, mass):
    grasp = np.load(input_path, allow_pickle=True).item()
    scene = load_scene_cfg(grasp["scene_path"])
    for obj in scene["scene"].values():
        if obj["type"] == "rigid_object":
            info = load_json(obj["info_path"])
            volume = info["mass"] / (info["density"] * info["scale"] ** 3)
            obj["density"] = mass / (volume * np.prod(obj["scale"]))
    return grasp, scene


def plan(env, grasp, scene):
    return get_planner(scene["task"].copy()).plan_trajectory(env.get_active_obj_pose().copy(), grasp["pregrasp_qpos"], grasp["grasp_qpos"], grasp["squeeze_qpos"], grasp.get("robot_pose"))


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--input", type=Path, required=True)
    parser.add_argument("--outdir", type=Path, required=True)
    parser.add_argument("--hand-xml", type=Path, default=Path("/workspace/Dexonomy/assets/hand/shadow/right.xml"))
    parser.add_argument("--no-video", "--metrics-only", action="store_true")
    parser.add_argument("--lift", action="store_true")
    parser.add_argument("--azimuth", type=float, default=135)
    parser.add_argument("--elevation", type=float, default=-25)
    args = parser.parse_args()
    args.outdir.mkdir(parents=True, exist_ok=True)
    grasp, scene = prepare_scene(args.input, 0.1)
    env = make_env(scene, args.hand_xml)
    controls, types, forces, target = plan(env, grasp, scene)
    env.reset_qpos(controls[0])
    recorder = Recorder(env, args.outdir, "native_fc", target, video=not args.no_video, azimuth=args.azimuth, elevation=args.elevation)
    # This is the original repository method, including its early failure behavior.
    native_success, _, _ = env.eval_fc(controls, types, forces, target, 0.05, 15)
    native = recorder.finish(native_success)
    native["directions_not_attempted"] = AXIS_NAMES[len(native["trials"]):]
    native["thresholds"] = {"translation_m": 0.05, "rotation_deg": 15, "hold_s_per_axis": 2.0, "force_N": 0.98}
    report = {"input": str(args.input.resolve()), "input_sha256": hashlib.sha256(args.input.read_bytes()).hexdigest(), "native_fc": native, "source": "Dexonomy MuJoCo_EvalEnv.eval_fc (unmodified)", "mujoco_version": mujoco.__version__}
    if args.lift:
        # A separate trial. Gravity is enabled before closure, and stays enabled.
        env = make_env(scene, args.hand_xml)
        env._model.opt.disableflags &= ~int(mujoco.mjtDisableBit.mjDSBL_GRAVITY)
        env._model.opt.gravity[:] = [0, 0, -9.81]
        controls, types, forces, target = plan(env, grasp, scene)
        env.reset_qpos(controls[0])
        recorder = Recorder(env, args.outdir, "gravity_lift", target, video=not args.no_video, mode="lift", azimuth=args.azimuth, elevation=args.elevation)
        recorder.begin_trial()
        env.run_trajectory(controls, types, forces)
        env._data.qfrc_applied[:] = 0
        reference = env.get_active_obj_pose().copy()
        recorder.phase = "LIFT +100 mm"
        squeeze = np.asarray(grasp["squeeze_qpos"])[-1].copy()
        n_lift = round(1 / env._model.opt.timestep)
        for i in range(n_lift):
            t = (i + 1) / n_lift
            q = squeeze.copy()
            q[2] += 0.1 * (3 * t * t - 2 * t * t * t)
            env.set_ctrl(q, "ee_pose")
            env.step_sim(1)
        recorder.phase = "HOLD UNDER GRAVITY"
        env.step_sim(round(2 / env._model.opt.timestep))
        final = env.get_active_obj_pose().copy()
        expected = reference.copy()
        expected[2] += 0.1
        drift, rotation = np_get_delta_pose(expected, final)
        hand_contacts, table_contacts, _ = contact_stats(env)
        height_gain = float(final[2] - target[2])
        lift_success = height_gain >= 0.08 and drift < 0.02 and rotation < 15 and hand_contacts >= 2 and table_contacts == 0
        lift = recorder.finish(lift_success)
        lift.update({"closure_object_pose": reference, "final_object_pose": final, "height_gain_from_initial_m": height_gain, "drift_from_expected_lifted_pose_m": float(drift), "rotation_from_closure_deg": float(rotation), "final_hand_object_contacts": hand_contacts, "final_object_table_contacts": table_contacts, "lift_distance_m": 0.1, "lift_duration_s": 1, "hold_duration_s": 2, "criterion": "height gain >=80mm; drift <20mm; rotation <15deg; >=2 hand-object contacts; zero table contacts"})
        report["gravity_lift"] = lift
    (args.outdir / "metrics.json").write_text(json.dumps(report, indent=2, default=plain) + "\n")
    print(json.dumps({"outdir": str(args.outdir), "native_pass": bool(native_success), "lift_pass": report.get("gravity_lift", {}).get("passed"), "native_trials": len(native["trials"]), "native_frames": native["video_frames"]}))


if __name__ == "__main__":
    main()
