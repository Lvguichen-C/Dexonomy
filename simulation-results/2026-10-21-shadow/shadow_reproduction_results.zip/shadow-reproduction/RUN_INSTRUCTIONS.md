# Shadow grasp reproduction commands

This script reconstructs the missing small-cylinder assets and runs the real
upstream `tmpl -> init -> grasp -> eval` operations. It is separate from the
video renderer so candidate generation and physics validation can be repeated
without rendering overhead.

```bash
# Current cloud environment; resumes the existing tip20 result directories.
bash /workspace/shadow-reproduction/run_reproduction.sh

# Independent result directories; does not remove an existing run.
EXP_NAME=tip_pinch_fresh bash /workspace/shadow-reproduction/run_reproduction.sh
```

On another machine set `DEXONOMY_REPO` to its checkout, `DEXONOMY_ACTIVATE` to a
Bash file that activates the compatible Python environment, and optionally
`RESULT_ROOT` to an output directory. Keep these helper files together. The
existing `run_cpu.sh` convenience wrapper contains this cloud machine's absolute
paths; `run_reproduction.sh` instead resolves its own directory and accepts the
environment overrides above. Dependencies remain those in the checkout plus
the environment's installed versions; this script does not install packages.

## Parameters and preserved behavior

- Hand: Shadow right hand; template `24_Tip_Pinch`; 22 hinge coordinates and
  the model's native actuator/tendon mapping. The synthesis/evaluation code uses
  the upstream free-root hand configuration.
- Objects: reconstructed 64-section cylinders with diameters 10, 15, 20, 30,
  40 mm; height four times diameter, inferred from the supplied d20 dimensions.
  These are equivalent procedural assets, not the original unavailable meshes.
- Initialization: CPU, five epochs, 1,024 surface samples times eight rotations,
  100 matcher iterations, ten retained candidates per scene per epoch. Match the
  executed sequence with an initial d20-only pass (50 initializations), then a
  pass over all five tabletop scenes with `skip_done=True` (d20 preserved and
  50 initializations for each other diameter). Scenes run one at a time to bound
  host memory. The historical experiment name `tip20` is retained despite this
  later expansion to five diameters.
- Object sampling runs serially through `run_pipeline.py`. Only its imported
  `gen_init.get_object_dataloader` is wrapped to pass zero worker processes to
  the original implementation. The original dataset, order, collate function,
  sampler and optimization remain in use. The hand loader still has one worker.
  This avoids restricted-host local IPC failures in PyTorch multiprocessing.
- CPU Warp compatibility comes from `runtime/sitecustomize.py`; no CUDA stream
  is supplied for CPU kernels. No tracked application source is edited.
- Grasp generation, early stopping, contact/collision/limit checks, QP thresholds,
  pregrasp and squeeze generation are unchanged. `audit_grasp.py` only records
  original function outputs. Template evolution is disabled for a fixed recipe.
- Native evaluation retains upstream friction, mass normalization to 0.1 kg,
  six independent force directions and displacement/rotation limits. `skip_traj`
  means no arm planner; the native free-hand pregrasp trajectory is still run.

The upstream pipeline seeds NumPy, Torch and Python at 12. Its background hand
template loader scheduling is not guaranteed bitwise deterministic. Changing
the dataset batching/worker arrangement or loading an already populated result
folder can also change which samples are drawn or skipped. Fresh numerical
reproduction should use a new `EXP_NAME` and record the dependency/hardware
versions. This recipe preserves the actual two-pass initialization sequence;
bitwise-identical arrays, candidate totals or video frames are not guaranteed.

## Output and checks

The result tree is `$RESULT_ROOT/${EXP_NAME}_shadow/` with `init_data`,
`grasp_data`, `succ_grasp` and resolved Hydra settings in each `log` directory.
`succ_grasp` contains links to candidates that passed native evaluation.
Audit JSON is in `audit/$EXP_NAME/`. The script checks saved counts because the
upstream operations can catch an exception and return an otherwise successful
process exit code. Inspect logs if a stage produces fewer files than expected.

To call a single operation with the serial object loader, activate the same
environment and set `PYTHONPATH` to include this folder's `runtime` directory:

```bash
/workspace/shadow-reproduction/run_cpu.sh python \
  /workspace/shadow-reproduction/run_pipeline.py op=init hand=shadow \
  exp_name=tip20 tmpl_name=24_Tip_Pinch n_worker=1 op.device=cpu \
  save_root=/workspace/shadow-reproduction/output \
  'op.object.cfg_path=assets/object/small_cyl/scene_cfg/cylinder_thin/table_top/*.npy'
```

`run_pipeline.py --parallel-object-loader ...` restores the original object
DataLoader worker count on hosts where local IPC is available. This is a launch
option and is removed before passing the remaining arguments to Hydra.
