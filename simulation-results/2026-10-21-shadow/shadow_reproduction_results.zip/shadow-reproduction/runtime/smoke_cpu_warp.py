"""Exercise original mesh-query forward/backward and line collision on CPU."""

import json
from pathlib import Path

import numpy as np
import torch
import trimesh
import warp as wp

from dexonomy.util.warp_util import WarpCollisionEnv


def main():
    assert wp.stream_from_torch(torch.device("cpu")) is None
    env = WarpCollisionEnv(torch.device("cpu"))
    mesh = trimesh.creation.box(extents=[2.0, 2.0, 2.0])
    env.load(None, [("cpu_box", mesh)])
    # Generic positions outside face interiors avoid the distance gradient's
    # nonsmooth edge/corner cases. Points are shaped [objects, starts, contacts,3].
    points = torch.tensor([[[[1.4, 0.17, 0.09], [0.23, -1.7, -0.12]]]], requires_grad=True)
    cp, cn = env.query_point(points)
    cp_expected = torch.tensor([[[[1.0, 0.17, 0.09], [0.23, -1.0, -0.12]]]])
    np.testing.assert_allclose(cp.detach().numpy(), cp_expected.numpy(), atol=1e-5)
    assert torch.isfinite(cn).all()
    np.testing.assert_allclose(cn.detach().norm(dim=-1).numpy(), 1.0, atol=1e-5)
    loss = ((points - cp) ** 2).sum()
    loss.backward()
    grad_expected = 2 * (points.detach() - cp_expected)
    np.testing.assert_allclose(points.grad.numpy(), grad_expected.numpy(), atol=1e-5)

    lines = torch.tensor([[[-2.0, 0.13, 0.07], [2.0, 0.13, 0.07]],
                          [[-2.0, 3.0, 0.0], [2.0, 3.0, 0.0]]])
    valid = env.check_mesh(lines, torch.tensor([0, 0], dtype=torch.int64))
    assert valid.tolist() == [False, True], valid
    result = {"device": "cpu", "warp": wp.__version__, "torch": torch.__version__,
              "closest_points": cp.detach().tolist(), "closest_normals": cn.detach().tolist(),
              "squared_distance_loss": loss.item(), "point_gradient": points.grad.tolist(),
              "collision_free": valid.tolist(), "passed": True}
    output = Path("/workspace/shadow-reproduction/cpu_warp_smoke.json")
    output.write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
