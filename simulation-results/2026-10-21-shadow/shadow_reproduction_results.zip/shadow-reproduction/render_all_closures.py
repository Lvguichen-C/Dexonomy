#!/usr/bin/env python3
"""Render every synthesized grasp's continuous closure and assemble 3x3 pages.

The label reports the separately completed native six-axis test. These short clips
show closure and 0.6 s unforced hold, not the entire six-axis test. No per-frame
qpos writes are performed. Initializations rejected by synthesis have no grasp
trajectory and are listed separately in the manifest.
"""
from __future__ import annotations
import argparse
import gc
import json
import os
from pathlib import Path
os.environ.setdefault("MUJOCO_GL", "egl")
import mujoco
import numpy as np
from PIL import Image, ImageDraw, ImageFont
from render_validate import make_env, plan, prepare_scene, contact_stats, plain
from video_writer import VideoWriter


class TileRecorder:
    mode = "preview"
    phase = "CLOSURE"
    force = np.zeros(3)

    def __init__(self, env, name, passed):
        self.env = env
        self.frames = []
        self.rows = []
        self.next_capture = 0.0
        self.name = name
        self.passed = passed
        self.warnings = np.zeros(len(env._data.warning), dtype=int)
        self.finite = True
        self.reset_anomalies = []
        self.last_time = -1.0
        self.camera = mujoco.MjvCamera()
        mujoco.mjv_defaultCamera(self.camera)
        ids = [i for i in range(env._model.ngeom) if env._model.body(int(env._model.geom_bodyid[i])).name.startswith(("hand-", "obj-"))]
        points = env._data.geom_xpos[ids]
        self.camera.lookat[:] = (points.min(axis=0) + points.max(axis=0)) / 2
        self.camera.distance = max(0.4, float(np.max(np.ptp(points, axis=0))) * 2.5)
        self.camera.azimuth = 135
        self.camera.elevation = -25
        env._model.vis.global_.offwidth = 320
        env._model.vis.global_.offheight = 240
        self.renderer = mujoco.Renderer(env._model, width=320, height=240)
        self.option = mujoco.MjvOption()
        self.option.flags[mujoco.mjtVisFlag.mjVIS_CONTACTPOINT] = True
        try:
            self.font = ImageFont.truetype("/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf", 11)
        except OSError:
            self.font = ImageFont.load_default()
        env.recorder = self
        self.observe()

    def observe(self):
        data = self.env._data
        now = float(data.time)
        if now < self.last_time:
            self.reset_anomalies.append([self.last_time, now])
        self.last_time = now
        self.finite &= bool(np.isfinite(data.qpos).all() and np.isfinite(data.qvel).all())
        self.warnings = np.maximum(self.warnings, [w.number for w in data.warning])
        self.rows.append((now, data.qpos.copy(), data.qvel.copy(), data.ctrl.copy(), self.env.get_active_obj_pose().copy()))
        if now + 1e-10 >= self.next_capture:
            self.renderer.update_scene(data, camera=self.camera, scene_option=self.option)
            im = Image.fromarray(self.renderer.render().copy())
            draw = ImageDraw.Draw(im)
            draw.rectangle((0, 0, 320, 35), fill=(20, 25, 32))
            draw.text((7, 3), self.name, font=self.font, fill=(245, 245, 245))
            draw.text((7, 19), "Native FC PASS" if self.passed else "Native FC FAIL", font=self.font, fill=(80, 235, 135) if self.passed else (255, 120, 100))
            draw.rectangle((0, 222, 320, 240), fill=(20, 25, 32))
            draw.text((7, 224), f"Closure preview | t={now:.2f}s | gravity OFF", font=self.font, fill=(230, 230, 230))
            self.frames.append(np.array(im))
            self.next_capture += 0.08

    def close(self):
        self.env.recorder = None
        self.renderer.close()


def render_one(path, experiment, outdir):
    relative = path.relative_to(experiment / "grasp_data")
    passed = (experiment / "succ_grasp" / relative).exists()
    name = f"{relative.parts[-2]} / {path.stem.removesuffix('_grasp')}"
    grasp, scene = prepare_scene(path, 0.1)
    env = make_env(scene, Path("/workspace/Dexonomy/assets/hand/shadow/right.xml"))
    controls, types, forces, target = plan(env, grasp, scene)
    env.reset_qpos(controls[0])
    recorder = TileRecorder(env, name, passed)
    env.run_trajectory(controls, types, forces)
    env.step_sim(150)
    recorder.close()
    key = "__".join(relative.with_suffix("").parts)
    clipdir = outdir / "individual"
    clipdir.mkdir(exist_ok=True)
    clip = clipdir / f"{key}.mp4"
    with VideoWriter(clip, fps=12.5) as writer:
        for frame in recorder.frames:
            writer.append_data(frame)
    np.savez_compressed(clipdir / f"{key}_trace.npz", time_s=np.array([r[0] for r in recorder.rows]), qpos=np.array([r[1] for r in recorder.rows]), qvel=np.array([r[2] for r in recorder.rows]), ctrl=np.array([r[3] for r in recorder.rows]), object_pose=np.array([r[4] for r in recorder.rows]))
    stats = {"input": str(path), "relative_path": str(relative), "native_fc_pass": passed, "clip": str(clip.relative_to(outdir)), "frames": len(recorder.frames), "duration_s": float(env._data.time), "finite_states": recorder.finite, "max_warning_counts": recorder.warnings.tolist(), "unexpected_time_resets": recorder.reset_anomalies, "final_hand_object_contacts": contact_stats(env)[0]}
    frames = recorder.frames
    del recorder, env
    gc.collect()
    return frames, stats


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--experiment", type=Path, required=True)
    parser.add_argument("--outdir", type=Path, required=True)
    parser.add_argument("--limit", type=int, default=0)
    args = parser.parse_args()
    args.outdir.mkdir(parents=True, exist_ok=True)
    candidates = sorted((args.experiment / "grasp_data").rglob("*.npy"))
    if args.limit:
        candidates = candidates[:args.limit]
    manifest = {"experiment": str(args.experiment), "fps": 12.5, "method": "one reset at trajectory start, continuous native set_ctrl/mj_step; closure plus0.6s unforcedhold; labelsfromseparatenative6axis evaluation", "samples": [], "pages": []}
    output = args.outdir / "all_candidates_closure.mp4"
    with VideoWriter(output, fps=12.5) as writer:
        for start in range(0, len(candidates), 9):
            page = []
            for path in candidates[start:start + 9]:
                frames, stats = render_one(path, args.experiment, args.outdir)
                manifest["samples"].append(stats)
                page.append(frames)
                print(json.dumps({"completed": len(manifest["samples"]), "total": len(candidates), "sample": stats["relative_path"]}), flush=True)
            n_frames = max(len(frames) for frames in page)
            for i in range(n_frames + 5):
                canvas = np.full((720, 960, 3), 20, dtype=np.uint8)
                for cell, frames in enumerate(page):
                    row, col = divmod(cell, 3)
                    canvas[row * 240:(row + 1) * 240, col * 320:(col + 1) * 320] = frames[min(i, len(frames) - 1)]
                writer.append_data(canvas)
            manifest["pages"].append({"page": start // 9, "sample_start": start, "sample_count": len(page), "frames": n_frames + 5})
    grasp_rel = {p.relative_to(args.experiment / "grasp_data") for p in (args.experiment / "grasp_data").rglob("*.npy")}
    manifest["initializations_without_synthesized_trajectory"] = [str(p.relative_to(args.experiment / "init_data")) for p in sorted((args.experiment / "init_data").rglob("*.npy")) if p.relative_to(args.experiment / "init_data") not in grasp_rel]
    manifest["candidate_count"] = len(candidates)
    manifest["native_success_count"] = sum(s["native_fc_pass"] for s in manifest["samples"])
    (args.outdir / "manifest.json").write_text(json.dumps(manifest, indent=2, default=plain) + "\n")
    print(json.dumps({"output": str(output), "candidates": len(candidates), "native_successes": manifest["native_success_count"]}))


if __name__ == "__main__":
    main()
