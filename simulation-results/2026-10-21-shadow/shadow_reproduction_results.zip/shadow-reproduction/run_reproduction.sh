#!/usr/bin/env bash
# Reproduce the Shadow 24_Tip_Pinch pipeline without modifying tracked source.
# To keep an independent run: EXP_NAME=shadow_tip_pinch_new ./run_reproduction.sh
set -euo pipefail

REPRO_ROOT="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
DEXONOMY_REPO="${DEXONOMY_REPO:-/workspace/Dexonomy}"
DEXONOMY_ACTIVATE="${DEXONOMY_ACTIVATE:-/workspace/dexonomy-onboarding/activate.sh}"
EXP_NAME="${EXP_NAME:-tip20}"
RESULT_ROOT="${RESULT_ROOT:-$REPRO_ROOT/output}"

source "$DEXONOMY_ACTIVATE"
export PYTHONPATH="$REPRO_ROOT/runtime${PYTHONPATH:+:$PYTHONPATH}"
export MUJOCO_GL="${MUJOCO_GL:-egl}"
export LP_NUM_THREADS="${LP_NUM_THREADS:-2}"
cd "$DEXONOMY_REPO"

common=(hand=shadow "exp_name=$EXP_NAME" tmpl_name=24_Tip_Pinch
        n_worker=1 tmpl_upd_mode=disabled "save_root=$RESULT_ROOT"
        skip_traj=True skip_done=True debug_view=False debug_render=False)

python "$REPRO_ROOT/create_assets.py" --repo "$DEXONOMY_REPO"

# Template conversion uses debug_name to select the raw annotation. tmpl_name
# alone does not filter this operation in the upstream implementation.
python "$REPRO_ROOT/run_pipeline.py" op=tmpl "${common[@]}" debug_name=24_Tip_Pinch
test -s "$DEXONOMY_REPO/assets/hand/shadow/init_tmpl/24_Tip_Pinch.npy"

init_settings=(op.device=cpu op.epoch=5 op.object.n_init_point=1024
               op.object.n_init_inplane=8 op.matcher.opt_step=100
               op.object.batch_size=1 op.filter.general.n_final=10)

# Match the executed sequence: first 50 d20 initializations, then expand to all
# five diameters. skip_done preserves d20 and adds 50 for each remaining size.
python "$REPRO_ROOT/run_pipeline.py" op=init "${common[@]}" "${init_settings[@]}" \
    op.object.n_cfg=1 \
    "op.object.cfg_path=$DEXONOMY_REPO/assets/object/small_cyl/scene_cfg/cylinder_thin/table_top/d20.npy" \
    log_id=0

python "$REPRO_ROOT/run_pipeline.py" op=init "${common[@]}" "${init_settings[@]}" \
    op.object.n_cfg=5 \
    "op.object.cfg_path=$DEXONOMY_REPO/assets/object/small_cyl/scene_cfg/cylinder_thin/table_top/*.npy" \
    log_id=all_diameters

# Upstream init catches its own exceptions. Check for concrete output before
# spending time on downstream operations; counts are reported again below.
python - "$RESULT_ROOT/${EXP_NAME}_shadow/init_data" <<'PY'
import pathlib, sys
files = list(pathlib.Path(sys.argv[1]).rglob('*.npy'))
if not files:
    raise SystemExit('No initialization files were saved; inspect init log.')
print(f'Initialization files: {len(files)}')
PY

# Read-only diagnostic hooks record native filter decisions and spring steps.
python "$REPRO_ROOT/audit_grasp.py" \
    --audit-dir "$REPRO_ROOT/audit/$EXP_NAME" \
    op=grasp "${common[@]}" log_id=grasp_audited

python "$REPRO_ROOT/run_pipeline.py" op=eval "${common[@]}" log_id=eval_native

python - "$RESULT_ROOT/${EXP_NAME}_shadow" <<'PY'
import json, pathlib, sys
root = pathlib.Path(sys.argv[1])
counts = {name: len(list((root / name).rglob('*.npy')))
          for name in ('init_data', 'grasp_data', 'succ_grasp')}
print(json.dumps({'result_root': str(root), **counts}, indent=2))
if not counts['grasp_data']:
    raise SystemExit('No grasp candidates passed; inspect grasp audit and log.')
if not counts['succ_grasp']:
    raise SystemExit('No native six-direction successes; inspect eval log.')
PY
