#!/usr/bin/env python3
"""Publish a reviewed delivery manifest to the authorized result branch.

No network operation occurs without --publish. Uses gh's existing credentials;
never reads, prints, or embeds a token. GitHub Release links point to actual
immutable raw files on the result branch, not to nonexistent Release assets.
"""
from __future__ import annotations

import argparse
import base64
import hashlib
import json
from pathlib import Path
import subprocess
import tempfile
from urllib.parse import quote


def gh_json(arguments: list[str], payload=None):
    if payload is None:
        result = subprocess.run(["gh", *arguments], text=True, check=True, capture_output=True)
    else:
        with tempfile.NamedTemporaryFile("w", suffix=".json", encoding="utf-8") as stream:
            json.dump(payload, stream, ensure_ascii=False)
            stream.flush()
            result = subprocess.run(["gh", *arguments, "--input", stream.name], text=True, check=True, capture_output=True)
    return json.loads(result.stdout) if result.stdout.strip() else None


def digest(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--deliverables", type=Path, default=Path("/workspace/shadow-reproduction/deliverables"))
    parser.add_argument("--repo", default="Lvguichen-C/Dexonomy")
    parser.add_argument("--branch", default="mujoco-animation-results-20261016-assets")
    parser.add_argument("--prefix", default="simulation-results/2026-10-21-shadow")
    parser.add_argument("--release-tag", default="shadow-grasp-reproduction-20261021")
    parser.add_argument("--release-title", default="Shadow Hand 抓取复现与动画")
    parser.add_argument("--publish", action="store_true")
    parser.add_argument("--skip-release", action="store_true")
    args = parser.parse_args()
    folder = args.deliverables.resolve()
    manifest_path = folder / "delivery_manifest.json"
    manifest = json.loads(manifest_path.read_text())
    if args.branch in {"main", "master"}:
        raise SystemExit("Refusing to publish result binaries to a source branch")
    if args.prefix.startswith("/") or ".." in Path(args.prefix).parts:
        raise SystemExit("Invalid repository destination prefix")
    file_rows = list(manifest["files"])
    names = [r["name"] for r in file_rows]
    if len(names) != len(set(names)):
        raise SystemExit("Duplicate delivery names")
    for row in file_rows:
        name = row["name"]
        if Path(name).name != name:
            raise SystemExit(f"Delivery name must be a plain filename: {name}")
        path = folder / name
        if path.is_symlink() or not path.is_file():
            raise SystemExit(f"Delivery is missing or symlinked: {name}")
        if path.stat().st_size != row["bytes"] or digest(path) != row["sha256"]:
            raise SystemExit(f"Delivery changed since manifest creation: {name}")
        if path.stat().st_size >= 95_000_000:
            raise SystemExit(f"Artifact exceeds publication cap: {name}")
    file_rows.append({"name": manifest_path.name, "bytes": manifest_path.stat().st_size, "sha256": digest(manifest_path)})
    plan = {"repo": args.repo, "branch": args.branch, "prefix": args.prefix, "release_tag": args.release_tag, "files": file_rows}
    state_dir = folder.parent / "publication-state"
    state_dir.mkdir(exist_ok=True)
    (state_dir / "plan.json").write_text(json.dumps(plan, indent=2) + "\n")
    if not args.publish:
        print(json.dumps({"published": False, "plan": str(state_dir / "plan.json"), "message": "Local integrity checks passed. Add --publish to perform the authorized upload."}, indent=2))
        return

    api = f"repos/{args.repo}"
    parent = gh_json(["api", f"{api}/git/ref/heads/{quote(args.branch, safe='/')}"])["object"]["sha"]
    source_before = gh_json(["api", f"{api}/git/ref/heads/main"])["object"]["sha"]
    parent_commit = gh_json(["api", f"{api}/git/commits/{parent}"])
    tree_rows = []
    for row in file_rows:
        content = (folder / row["name"]).read_bytes()
        git_sha = hashlib.sha1(f"blob {len(content)}\0".encode() + content).hexdigest()
        blob = gh_json(["api", "--method", "POST", f"{api}/git/blobs"], {"content": base64.b64encode(content).decode("ascii"), "encoding": "base64"})
        if blob["sha"] != git_sha:
            raise SystemExit(f"Uploaded Git blob integrity mismatch: {row['name']}")
        row["git_blob_sha"] = git_sha
        tree_rows.append({"path": f"{args.prefix}/{row['name']}", "mode": "100644", "type": "blob", "sha": git_sha})
    tree = gh_json(["api", "--method", "POST", f"{api}/git/trees"], {"base_tree": parent_commit["tree"]["sha"], "tree": tree_rows})
    commit = gh_json(["api", "--method", "POST", f"{api}/git/commits"], {"message": "Add Shadow cylinder grasp reproduction and continuous MuJoCo animations", "tree": tree["sha"], "parents": [parent]})
    # Non-force advancement rejects a concurrent branch change, preserving others' work.
    gh_json(["api", "--method", "PATCH", f"{api}/git/refs/heads/{quote(args.branch, safe='/')}"], {"sha": commit["sha"], "force": False})
    source_after = gh_json(["api", f"{api}/git/ref/heads/main"])["object"]["sha"]
    for row in file_rows:
        path = quote(f"{args.prefix}/{row['name']}")
        row["raw_url"] = f"https://raw.githubusercontent.com/{args.repo}/{commit['sha']}/{path}"
        row["view_url"] = f"https://github.com/{args.repo}/blob/{commit['sha']}/{path}"
    publication = {**plan, "files": file_rows, "published": True, "parent_commit": parent, "commit": commit["sha"], "main_before": source_before, "main_after": source_after, "main_unchanged_during_publication": source_before == source_after, "release_updated": False}
    publication_path = folder.parent / "publication.json"
    publication_path.write_text(json.dumps(publication, indent=2, ensure_ascii=False) + "\n")
    if not args.skip_release:
        try:
            release = gh_json(["api", f"{api}/releases/tags/{quote(args.release_tag, safe='')}"])
        except subprocess.CalledProcessError as error:
            if "HTTP 404" not in (error.stderr or ""):
                raise
            release = None
        start, end = "<!-- shadow-reproduction:start -->", "<!-- shadow-reproduction:end -->"
        body = (release.get("body") or "") if release else ""
        if start in body:
            before, marked = body.split(start, 1)
            if end not in marked:
                raise SystemExit("Existing Shadow Release marker is incomplete; branch published, Release not edited")
            _, after = marked.split(end, 1)
            body = (before.rstrip() + "\n" + after.lstrip()).strip()
        by_name = {r["name"]: r for r in file_rows}
        links = [
            ("Shadow 重力抬升与持握动画", "shadow_gravity_lift.mp4"),
            ("原生六方向扰动测试动画", "shadow_native_fc.mp4"),
            ("全部候选连续闭合动画", "all_candidates.mp4"),
            ("完整结果、动画和复现代码 ZIP", "shadow_reproduction_results.zip"),
            ("复现报告", "SHADOW_REPRODUCTION.md"),
        ]
        block = start + "\n\n### Shadow 抓取复现（2026-10-21）\n\n"
        block += "\n".join(f"- [{label}]({by_name[name]['raw_url']})" for label, name in links)
        block += "\n\n以上链接指向结果分支中的固定提交文件。原生力闭合测试关闭重力；抬升动画来自独立的重力开启测试。\n\n" + end
        notes = (body.rstrip() + "\n\n" + block + "\n").lstrip()
        notes_path = state_dir / "release-notes.md"
        notes_path.write_text(notes)
        if release is None:
            release = gh_json(["api", "--method", "POST", f"{api}/releases"], {
                "tag_name": args.release_tag,
                "target_commitish": commit["sha"],
                "name": args.release_title,
                "body": notes,
                "draft": False,
                "prerelease": False,
            })
            publication["release_created"] = True
        else:
            subprocess.run(["gh", "release", "edit", args.release_tag, "--repo", args.repo, "--notes-file", str(notes_path)], check=True)
            publication["release_created"] = False
        publication["release_updated"] = True
        publication["release_url"] = release["html_url"]
        publication["release_id"] = release["id"]
        publication_path.write_text(json.dumps(publication, indent=2, ensure_ascii=False) + "\n")
    print(json.dumps(publication, indent=2, ensure_ascii=False))


if __name__ == "__main__":
    main()
