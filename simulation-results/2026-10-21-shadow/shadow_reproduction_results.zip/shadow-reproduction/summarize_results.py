#!/usr/bin/env python3
"""Summarize saved Shadow candidates, native successes and audit evidence.

Only files actually present are counted. An initialization is a retained
proposal; a successful native evaluation is a resolving succ_grasp symlink.
The summary can be regenerated after the pipeline finishes.
"""
from __future__ import annotations

import argparse
from collections import Counter, defaultdict
from datetime import datetime, timezone
import hashlib
import importlib.metadata
import json
import os
from pathlib import Path
import platform
import re
import subprocess


DIAMETERS = (10, 15, 20, 30, 40)
SCENE_PATTERN = re.compile(r"cylinder_thin_(table|floating)_(\d+)")


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def scene_for(path) -> tuple[str, int] | None:
    match = SCENE_PATTERN.search(str(path))
    return (match.group(1), int(match.group(2))) if match else None


def relative(path: Path, root: Path) -> str:
    try:
        return str(path.absolute().relative_to(root.absolute()))
    except ValueError:
        return str(path)


def load_json(path: Path):
    return json.loads(path.read_text())


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--experiment-dir", type=Path, default=Path("/workspace/shadow-reproduction/output/tip20_shadow"))
    parser.add_argument("--audit-dir", type=Path, default=Path("/workspace/shadow-reproduction/audit/native"))
    parser.add_argument("--artifact-root", type=Path, default=Path(__file__).resolve().parent)
    parser.add_argument("--repo", type=Path, default=Path("/workspace/Dexonomy"))
    parser.add_argument("--output", type=Path)
    parser.add_argument("--table-output", type=Path)
    args = parser.parse_args()
    output = args.output or args.artifact_root / "results-summary.json"
    table_output = args.table_output or args.artifact_root / "RESULTS_TABLE.md"

    groups = {}
    for diameter in DIAMETERS:
        groups[("table", diameter)] = {
            "scene_id": f"cylinder_thin_table_{diameter}",
            "diameter_mm": diameter,
            "height_mm": diameter * 4,
            "initializations": 0,
            "grasp_candidates": 0,
            "native_successes": 0,
            "audit_records": 0,
            "audit_filter_rejections": Counter(),
            "audit_iterations": Counter(),
            "audit_logged_warning_count": 0,
            "audit_mujoco_warning_count": 0,
            "audit_records_with_warnings": 0,
            "audit_exceptions_or_unsaved": 0,
            "passed_candidates": [],
        }

    unknown_paths = []
    broken_success_links = []
    stage_paths = {}
    for stage, count_key in (("init_data", "initializations"), ("grasp_data", "grasp_candidates"), ("succ_grasp", "native_successes")):
        paths = sorted((args.experiment_dir / stage).rglob("*.npy"))
        stage_paths[stage] = paths
        for path in paths:
            scene = scene_for(path)
            if scene not in groups:
                unknown_paths.append(relative(path, args.artifact_root))
                continue
            if not path.is_file():
                if stage == "succ_grasp":
                    broken_success_links.append(relative(path, args.artifact_root))
                continue
            groups[scene][count_key] += 1
            if stage == "succ_grasp":
                groups[scene]["passed_candidates"].append({
                    "success_path": relative(path, args.artifact_root),
                    "is_symlink": path.is_symlink(),
                    "symlink_target": os.readlink(path) if path.is_symlink() else None,
                    "candidate_path": relative(path.resolve(), args.artifact_root),
                    "bytes": path.stat().st_size,
                    "sha256": sha256(path),
                })

    audit_errors = []
    audit_count = 0
    for path in sorted(args.audit_dir.rglob("*.json")):
        if path.name == "summary.json":
            continue
        try:
            record = load_json(path)
            if "input_path" not in record:
                continue
            try:
                Path(record["input_path"]).absolute().relative_to(args.experiment_dir.absolute())
            except ValueError:
                continue
            scene = scene_for(record["input_path"])
            if scene not in groups:
                continue
            group = groups[scene]
            group["audit_records"] += 1
            audit_count += 1
            rejection = record.get("rejection")
            if rejection:
                group["audit_filter_rejections"][f"{rejection['phase']}/{rejection['filter']}"] += 1
            elif not record.get("output_exists_after"):
                group["audit_exceptions_or_unsaved"] += 1
            group["audit_iterations"][str(record.get("grasp_iterations_used", 0))] += 1
            logged_warnings = len(record.get("warnings", []))
            warning_counts = [
                int(value)
                for phase in record.get("phase_results", {}).values()
                for value in phase.get("mujoco_warning_counts", [])
            ]
            # The same simulator warning counters appear at both phase ends.
            # Count their per-category maxima once for this candidate.
            arrays = [p.get("mujoco_warning_counts", []) for p in record.get("phase_results", {}).values()]
            unique_warnings = sum(max(row[index] if index < len(row) else 0 for row in arrays) for index in range(max(map(len, arrays), default=0)))
            group["audit_logged_warning_count"] += logged_warnings
            group["audit_mujoco_warning_count"] += unique_warnings
            group["audit_records_with_warnings"] += int(logged_warnings > 0 or any(warning_counts))
        except (ValueError, OSError, KeyError, TypeError) as exc:
            audit_errors.append({"path": relative(path, args.artifact_root), "error": str(exc)})

    metrics = []
    for path in sorted(args.artifact_root.rglob("metrics.json")):
        if "render-smoke" in path.parts or "representative_d20" in path.parts:
            continue
        try:
            record = load_json(path)
            item = {"path": relative(path, args.artifact_root), "input": record.get("input"), "input_sha256": record.get("input_sha256")}
            native = record.get("native_fc")
            if native:
                checks = [check for trial in native.get("trials", []) for check in trial.get("checks", [])]
                item["native_fc"] = {
                    "passed": native.get("passed"),
                    "directions_attempted": len(native.get("trials", [])),
                    "max_translation_m": max((c["translation_m"] for c in checks), default=None),
                    "max_rotation_deg": max((c["rotation_deg"] for c in checks), default=None),
                    "finite_states": native.get("finite_states"),
                    "unexpected_time_resets": native.get("unexpected_time_resets"),
                    "max_warning_counts": native.get("max_warning_counts"),
                    "gravity_disabled": native.get("gravity_disabled"),
                }
            lift = record.get("gravity_lift")
            if lift:
                item["gravity_lift"] = {
                    key: lift.get(key) for key in (
                        "passed", "height_gain_from_initial_m", "drift_from_expected_lifted_pose_m",
                        "rotation_from_closure_deg", "final_hand_object_contacts", "final_object_table_contacts",
                        "gravity_disabled", "finite_states", "unexpected_time_resets", "max_warning_counts", "criterion",
                    )
                }
            metrics.append(item)
        except (ValueError, OSError, KeyError, TypeError) as exc:
            audit_errors.append({"path": relative(path, args.artifact_root), "error": str(exc)})

    def git(*cmd):
        return subprocess.check_output(["git", "-C", str(args.repo), *cmd], text=True).strip()

    versions = {"python": platform.python_version()}
    for package in ("mujoco", "torch", "warp-lang", "numpy", "trimesh", "qpsolvers", "clarabel", "hydra-core"):
        try:
            versions[package] = importlib.metadata.version(package)
        except importlib.metadata.PackageNotFoundError:
            versions[package] = None

    configurations = []
    for path in sorted((args.experiment_dir / "log").rglob(".hydra/config.yaml")):
        overrides = path.with_name("overrides.yaml")
        configurations.append({
            "path": relative(path, args.artifact_root), "sha256": sha256(path),
            "overrides_path": relative(overrides, args.artifact_root) if overrides.exists() else None,
            "overrides_yaml": overrides.read_text() if overrides.exists() else None,
        })

    hashes = {}
    # Exclude generated bundles and this summary/report: they would create
    # circular inventories. Candidate hashes and native configs are above.
    for path in sorted(args.artifact_root.rglob("*")):
        if not path.is_file() or "__pycache__" in path.parts:
            continue
        rel = path.relative_to(args.artifact_root)
        if rel.parts[0] in ("output", "audit", "render-smoke", "deliverables", "publication-state") or "representative_d20" in path.parts:
            continue
        if path.name == "publication.json":
            continue
        if path in (output, table_output) or path.suffix.lower() in (".zip", ".md"):
            continue
        hashes[str(rel)] = {"bytes": path.stat().st_size, "sha256": sha256(path)}

    group_list = [groups[key] for key in sorted(groups, key=lambda key: key[1])]
    total_keys = ("initializations", "grasp_candidates", "native_successes", "audit_records", "audit_logged_warning_count", "audit_mujoco_warning_count", "audit_records_with_warnings", "audit_exceptions_or_unsaved")
    totals = {key: sum(group[key] for group in group_list) for key in total_keys}
    totals["native_success_rate_of_grasp_candidates"] = totals["native_successes"] / totals["grasp_candidates"] if totals["grasp_candidates"] else None
    result = {
        "schema_version": 1,
        "generated_at_utc": datetime.now(timezone.utc).isoformat(),
        "experiment_dir": relative(args.experiment_dir, args.artifact_root),
        "source": {"commit": git("rev-parse", "HEAD"), "tracked_status": git("status", "--porcelain=v1", "--untracked-files=no"), "tracked_source_unchanged": not git("status", "--porcelain=v1", "--untracked-files=no")},
        "environment": versions,
        "semantics": {
            "initializations": "Retained proposals; InitFilter may pad invalid proposals to its quota",
            "grasp_candidates": "Saved after native grasp/pregrasp contact, collision, limit and QP filters",
            "native_successes": "Existing succ_grasp files/symlinks after unchanged six-axis native evaluation",
            "native_evaluation": "Gravity disabled; object mass 0.1 kg; +/-XYZ COM force 0.98 N; 2 s per axis; translation <0.05 m and rotation <15 deg",
            "gravity_lift": "Separate additional continuous-dynamics check; not applied to every native success unless listed in metrics",
            "random_seed": 12,
            "random_sequence_note": "First ran d20, then expanded to all five table-top diameters with skip_done. Per-process RNG and already-present scenes influence sampling consumption; reproduce the recorded command order/configs for identical inputs.",
        },
        "totals": totals,
        "per_diameter": group_list,
        "detailed_metrics": metrics,
        "configurations": configurations,
        "artifact_hashes": hashes,
        "integrity_issues": {"broken_success_links": broken_success_links, "unrecognized_scene_paths": unknown_paths, "unreadable_audit_or_metrics": audit_errors},
    }
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_text(json.dumps(result, indent=2, ensure_ascii=False) + "\n")
    lines = ["# Shadow 抓取结果统计", "", "本表从实际结果文件生成；详细候选路径和 SHA-256 见 `results-summary.json`。", "", "| 直径 / 高度（mm） | init 保留 | grasp 通过 | 原生六向通过 | grasp 拒绝 |", "|---|---:|---:|---:|---|"]
    for group in group_list:
        failures = "; ".join(f"{key}: {value}" for key, value in group["audit_filter_rejections"].items()) or "0"
        lines.append(f"| {group['diameter_mm']} / {group['height_mm']} | {group['initializations']} | {group['grasp_candidates']} | {group['native_successes']} | {failures} |")
    lines.extend([f"| 合计 | {totals['initializations']} | {totals['grasp_candidates']} | {totals['native_successes']} | |", "", "init 数为保留的初始提案数；原生六向测试关闭重力。重力开启的抬升验证单独列在动画目录的 metrics.json 中。", ""])
    table_output.write_text("\n".join(lines))
    report = args.artifact_root / "SHADOW_REPRODUCTION.md"
    if report.exists():
        table_body = "\n".join(lines[2:])
        report.write_text(re.sub(
            r"<!-- RESULTS:BEGIN -->.*?<!-- RESULTS:END -->",
            "<!-- RESULTS:BEGIN -->\n\n" + table_body + "\n<!-- RESULTS:END -->",
            report.read_text(), flags=re.DOTALL,
        ))
    print(json.dumps({"output": str(output), "table": str(table_output), "totals": totals, "integrity_issues": result["integrity_issues"]}, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
