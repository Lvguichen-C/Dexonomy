# Shadow reproduction: source audit

Audit baseline: `/workspace/Dexonomy` source at the user fork's original checkout.
The supplied guide is a specification for an experiment, not a complete saved
experiment: it omits its original custom cylinder assets and modified source.
Exact bit-for-bit reproduction and the claimed 91/11 counts cannot be promised.

## Smallest complete run

Run from `/workspace/Dexonomy` after activating
`/workspace/dexonomy-onboarding/activate.sh`. The CPU runtime shim prepared by the
parallel task must be active for initialization. Explicit paths avoid relying on
the guide's unprovided edits to base/config files.

```bash
dexrun op=tmpl hand=shadow n_worker=1 debug_name=24_Tip_Pinch

dexrun op=init hand=shadow tmpl_name=24_Tip_Pinch \
  exp_name=shadow_tip20 save_root=/workspace/shadow-reproduction/results \
  n_worker=1 op.device=cpu op.epoch=1 \
  op.object.batch_size=1 op.object.n_cfg=1 \
  op.object.n_init_point=256 op.object.n_init_inplane=4 \
  op.matcher.opt_step=100 \
  op.object.cfg_path=/workspace/Dexonomy/assets/object/small_cyl/scene_cfg/cylinder_thin/table_top/d20.npy

python /workspace/shadow-reproduction/audit_grasp.py \
  --audit-dir /workspace/shadow-reproduction/audit/native \
  op=grasp hand=shadow exp_name=shadow_tip20 \
  save_root=/workspace/shadow-reproduction/results n_worker=1

dexrun op=eval hand=shadow exp_name=shadow_tip20 \
  save_root=/workspace/shadow-reproduction/results n_worker=1 \
  skip_traj=true op.skip_pregrasp=false debug_view=false
```

This reduced discovery run changes the sampling budget only. It keeps the
original matching, collision/contact/QP filters, grasp physics and evaluation.
For the guide's full single-scene sampling budget change to `op.epoch=5`,
`op.object.n_init_point=1024`, and `op.object.n_init_inplane=8`; the number of
retained initializations remains 10 per epoch. A single-scene `n_cfg=1` and
`batch_size=1` do not change that scene's number of sampled points/rotations.

Use a fresh experiment name to compare changed budgets. Init's `skip_done=true`
skips a whole scene/epoch if even one matching result already exists.

## Interpretation and traps

- The source's default object pattern points to missing DGN assets. Override it
  explicitly to the generated table-top scene. The custom cylinder dimensions
  and mesh discretization are assumptions that must accompany the results.
- `save_dir` is `${save_root}/${exp_name}_${hand_name}`. For the example above it
  is `/workspace/shadow-reproduction/results/shadow_tip20_shadow`. Source uses
  `init_data`, `grasp_data`, `succ_grasp`, and `new_tmpl`, without `_table` suffixes.
- The unchanged source does not read `grasp.early_stop`. Merely adding a Hydra
  field with that name has no effect. Native stopping checks for stalled
  contact-error improvement, then checks collision clearance; final required
  contacts and QP quality are checked afterwards. Any optional flag requires an
  actual implementation, and its results must be compared on identical inputs.
- InitFilter intentionally pads retained samples with invalid samples when a
  filter would otherwise leave fewer than the configured quota. Its log line
  `Get N valid` therefore means N retained initializations. Only final grasp
  filtering and the native evaluation establish later success.
- Both `_single_grasp` and `_single_eval` are decorated with `safe_wrapper`,
  which logs exceptions and still returns the candidate path. A completed
  process or a processed-path log alone does not mean successful candidates.
  Inspect warnings, exceptions, saved grasp files, and successful symlinks.
- Native initialization also catches/logs BaseException. Check actual output
  files and full logs even if the process exits 0.
- `n_worker=1` makes diagnostic attribution unambiguous. Source evaluation uses
  `3*n_worker` processes when parallel, so the default 32 is unsuitable here.
- Use `HandCfg(..., freejoint=True)` for optimization and evaluation, as source
  already does. A fixed-root hand-only diagnostic has different welded-body
  collision filtering and does not diagnose this pipeline reliably.
- Retain `op.skip_pregrasp=false`: evaluation then includes the generated
  opening/approach, grasp, and squeeze. A grasp-only reset can hide failure to
  acquire the object from its original pose.

## What native force-closure success means

The evaluation environment disables gravity and keeps the object free. It uses
4 ms physics, elliptic friction with coefficients `[0.6,0.02]`, noslip iterations
2, and impratio 10. Object density is recomputed from the saved asset-volume
metadata to give mass 0.1 kg.

For each of six independently initialized trials (`+X,-X,+Y,-Y,+Z,-Z`), native
`eval_fc` resets once to the beginning of the pregrasp, runs the continuous
pregrasp→grasp→squeeze controls, then applies a COM force of magnitude `m*9.8`.
It holds that force for up to 500 physics steps (2 seconds), checking after every
50 steps. A trial passes when object translation from the original target is
below 0.05 m and rotation below 15 degrees throughout the checks; all six must
pass. A table may support the downward trial, but the upward and lateral trials
still have to pass. This benchmark is not itself a gravity-on lifting test.

Report candidate counts at each stage and actual measured object drift, contact
data, MuJoCo warnings and simulation resets. A successful file is a symlink in
`succ_grasp` that resolves to the generated `grasp_data` file. Native eval does
not save a per-axis metrics file, so instrumentation is necessary for detailed
evidence beyond that boolean.

## Animation fidelity

The guide's example renderer interpolates poses and calls `reset_qpos` at each
keyframe. That resets object state and velocities and is not a faithful record
of acquiring or holding an object. A verification video must render actual
continuous integration under `set_ctrl`/`run_trajectory`, resetting only at the
start of an independent trial. Clearly mark transitions between the six trials.
Do not put a frame-interpolated reconstruction under a continuous-dynamics label.

## Diagnostic wrapper

`audit_grasp.py` delegates to the unchanged native `_single_grasp` and original
methods. Hooks only copy values already computed: no extra contact queries,
`mj_forward`, steps or changed decisions. Its per-candidate JSON records the
iteration budget used, early-stop checks, contact distances/body sets, required
body groups, individual filter outcomes, QP residual, final qpos, warning
counts, and saved-output existence. `summary.json` groups exact rejection stages.
It requires serial generation (`n_worker=1`).
