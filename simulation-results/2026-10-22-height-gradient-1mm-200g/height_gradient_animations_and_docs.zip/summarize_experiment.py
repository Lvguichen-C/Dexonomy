#!/usr/bin/env python3
"""Reduce finalized physical trials without stepping or modifying any model."""
from __future__ import annotations
import csv
import hashlib
import json
from pathlib import Path

import numpy as np

ROOT = Path(__file__).resolve().parent


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def write(path, value):
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n")


def main():
    files = sorted((ROOT / "trials").glob("h*/*/*/metrics.json"))
    rows = []
    for path in files:
        m = json.loads(path.read_text())
        profile = m.get("comparison_profile", "original_contact")
        if profile == "force_clamp_root_micro":
            cohort = "final_policy"
        elif m["variant"].endswith("source_top_aligned"):
            cohort = "source_baseline"
        elif profile != "original_contact":
            cohort = "contact_force_sensitivity"
        else:
            cohort = "tracked_geometry"
        d = np.load(path.parent / "diagnostics.npz")
        phase_names = d["phase_names"].tolist()
        phase = d["phase_id"]
        loaded = phase == phase_names.index("loaded_hold")
        hold = phase == phase_names.index("postlift_hold")
        lift = phase == phase_names.index("lift")
        initial_z = m["initial_object_pose"][2]
        tf, ff = d["normal_thumb_contact_force_sum_N"], d["normal_index_contact_force_sum_N"]
        dual = (d["thumb_and_index_in_contact"] > 0) & (tf > 0) & (ff > 0)
        gap = m["upright_protocol"]["initial_minimum_hand_object_geom_distance"]["distance_m"] * 1000
        if not m["finite_states"] or any(m["maximum_warning_counts"]) or m["unexpected_time_resets"] or gap < 50:
            raise ValueError(f"Invalid continuous trial: {path}")
        if np.count_nonzero(hold) != 5000:
            raise ValueError(f"Incorrect hold duration: {path}")
        row = {"height_mm": int(m["height_mm"]), "fixture": m["fixture"], "cohort": cohort,
               "variant": m["variant"], "comparison_profile": profile,
               "loaded_positive_thumb_index_fraction": float(np.mean(dual[loaded])),
               "loaded_mean_total_normal_force_N": float(np.mean((tf + ff)[loaded])),
               "loaded_peak_total_normal_force_N": float(np.max((tf + ff)[loaded])),
               "loaded_mean_thumb_normal_force_N": float(np.mean(tf[loaded])),
               "loaded_mean_index_normal_force_N": float(np.mean(ff[loaded])),
               "lift_positive_thumb_index_fraction": float(np.mean(dual[lift])),
               "hold_positive_thumb_index_fraction": float(np.mean(dual[hold])),
               "hold_support_free_fraction": float(np.mean((d["object_fixture_contacts"][hold] == 0) & (d["object_plane_contacts"][hold] == 0))),
               "hold_minimum_object_rise_mm": float(np.min(d["object_z_m"][hold] - initial_z) * 1000),
               "hold_maximum_object_rise_mm": float(np.max(d["object_z_m"][hold] - initial_z) * 1000),
               "lift_peak_object_rise_mm": float(np.max(d["object_z_m"][lift] - initial_z) * 1000),
               "final_measured_object_lift_mm": m["measured_object_lift_mm"],
               "maximum_HO_penetration_um": float(np.max(d["hand_object_max_penetration_m"]) * 1e6),
               "loaded_maximum_HO_penetration_um": float(np.max(d["hand_object_max_penetration_m"][loaded]) * 1e6),
               "hold_maximum_HO_penetration_um": float(np.max(d["hand_object_max_penetration_m"][hold]) * 1e6),
               "initial_true_gap_mm": gap,
               "frozen_lift_hold_passed": bool(m["frozen_lift_hold_passed"]),
               "qualified_lift_hold_passed": bool(m["qualified_lift_hold_passed"]),
               "full_sequence_passed": bool(m["full_sequence_passed"]),
               "metrics": str(path.relative_to(ROOT)), "metrics_sha256": sha(path),
               "input": m["input"], "input_sha256": sha(m["input"]),
               "trace_sha256": sha(path.parent / "trace.npz"),
               "diagnostics_sha256": sha(path.parent / "diagnostics.npz"),
               "model_mjb_sha256": sha(path.parent / "model.mjb")}
        rows.append(row)
    if len(rows) != 32:
        raise ValueError(f"Final scope must contain exactly 32 completed formal trials, found {len(rows)}")
    selections = {}
    for cohort in ("source_baseline", "final_policy"):
        selected = [r for r in rows if r["cohort"] == cohort]
        if len(selected) != 8 or len({(r["height_mm"], r["fixture"]) for r in selected}) != 8:
            raise ValueError(f"Expected a complete 4 heights x 2 supports in {cohort}")
        selections[cohort] = selected
    summary = {"scope": "32 formal continuous physical trials; auxiliary isolated-hand optimization and support probes are excluded",
               "diameter_mm": 1, "heights_mm": [4, 6, 8, 10], "mass_kg": .2,
               "physics_timestep_s": .001, "formal_trials": len(rows),
               "cohort_counts": {c: sum(r["cohort"] == c for r in rows) for c in sorted({r["cohort"] for r in rows})},
               "qualified_full_sequence_passed": sum(r["full_sequence_passed"] for r in rows),
               "final_policy_conditions_passed": sum(r["full_sequence_passed"] for r in selections["final_policy"]),
               "final_policy_comparison": "Same micro-contact/force/root-feedback strategy, with separately fitted grasp targets for each height; not a height-only causal contrast",
               "source_baseline_comparison": "Same saved joints and orientation; all controls translated only by change in cylinder-top height",
               "ideal_minimum_normal_force_sum_N": .2 * 9.81 / .6,
               "force_budget_scope": "Ideal horizontal opposing contacts only; necessary budget is not a complete force/moment balance certificate",
               "rows": rows, "selections": selections, "summarizer_sha256": sha(__file__)}
    write(ROOT / "experiment-summary.json", summary)
    with (ROOT / "experiment-results.csv").open("w", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)
    write(ROOT / "final-selection.json", {"cohort": "force_clamp_root_micro",
          "source": "Explicit fixed-policy 4 heights x 2 supports, not maximum-score selection",
          "conditions": [{"height_mm": r["height_mm"], "fixture": r["fixture"], "variant": r["variant"],
                           "metrics": str((ROOT / r["metrics"]).resolve()), "metrics_sha256": r["metrics_sha256"]}
                          for r in selections["final_policy"]]})
    print(json.dumps({k: v for k, v in summary.items() if k not in ("rows", "selections")}, indent=2))


if __name__ == "__main__":
    main()
