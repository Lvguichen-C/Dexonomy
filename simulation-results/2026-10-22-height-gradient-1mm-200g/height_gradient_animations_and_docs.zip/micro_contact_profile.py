#!/usr/bin/env python3
"""Separate micro-contact sensitivity: explicit HO pairs, no support changes.

Declared before optimized grasp results: zero-margin 3D Coulomb contact with
mu=.6, solref=[.004,1], solimp=[.95,.99,50um,.5,2]. No torsional constraint.
No object force, pose control, gravity change or joint actuation is added.
"""
from __future__ import annotations
import argparse
from concurrent.futures import ThreadPoolExecutor
import json
from pathlib import Path
import subprocess
import sys

import mujoco
import numpy as np

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT))
import run_height_trials as runner

CONTACT = {"name": "micro_HO_dim3_4ms", "condim": 3,
           "solref": [.004, 1.], "solimp": [.95, .99, .00005, .5, 2.],
           "friction": [.6, .6, .00002, .000001, .000001], "margin": 0., "gap": 0.}


def make_env_micro(factory, *args, **kwargs):
    api = factory.fixture_module()
    original = api.with_fixture_env_class

    def make_class(base, fixture="plain"):
        parent = original(base, fixture)

        class MicroContactEnv(parent):
            def _set_friction(self, coefficients):
                result = super()._set_friction(coefficients)
                hands, objects = [], []
                for index, geom in enumerate(self._spec.geoms):
                    if not (geom.contype or geom.conaffinity):
                        continue
                    body_name = geom.parent.name
                    if body_name.startswith("hand-"):
                        if not geom.name:
                            geom.name = f"micro-hand-geom-{index:03d}"
                        hands.append(geom)
                    elif body_name.startswith("obj-"):
                        if not geom.name:
                            geom.name = f"micro-object-geom-{index:03d}"
                        objects.append(geom)
                if not hands or not objects:
                    raise RuntimeError("No eligible hand/object collision geometries")
                for i, hand in enumerate(hands):
                    for j, obj in enumerate(objects):
                        if (hand.contype & obj.conaffinity) or (obj.contype & hand.conaffinity):
                            self._spec.add_pair(name=f"micro-HO-{i:02d}-{j:02d}",
                                geomname1=hand.name, geomname2=obj.name,
                                **{k: v for k, v in CONTACT.items() if k != "name"})
                return result

        return MicroContactEnv

    api.with_fixture_env_class = make_class
    try:
        env = factory.make_env(*args, **kwargs)
    finally:
        api.with_fixture_env_class = original
    if env._model.npair < 2 or not np.all(env._model.pair_dim == 3):
        raise RuntimeError("Explicit micro hand/object contact pairs were not compiled")
    env.micro_contact_definition = {**CONTACT, "explicit_pair_count": env._model.npair,
        "adapter_sha256": runner.sha(__file__), "hand_root_and_joint_controllers_changed": False,
        "object_fixture_and_plane_contact_parameters_changed": False,
        "support_policy": "Only named hand/object pairs override the normal baseline collision material"}
    return env


def run_trial(job):
    factory = runner.load_fixture()
    original = factory.make_env
    record = {}

    def adapted(*args, **kwargs):
        # Temporarily restore the original factory to avoid recursive wrapping.
        factory.make_env = original
        try:
            env = make_env_micro(factory, *args, **kwargs)
        finally:
            factory.make_env = adapted
        record.update(env.micro_contact_definition)
        return env

    factory.make_env = adapted
    try:
        result = runner.run_trial(job)
    finally:
        factory.make_env = original
    folder = Path(job["output"])
    metrics = json.loads((folder / "metrics.json").read_text())
    metrics["micro_contact_intervention"] = record
    metrics["comparison_profile"] = CONTACT["name"]
    runner.write_json(folder / "metrics.json", metrics)
    runner.write_json(folder / "micro_contact_intervention.json", record)
    return result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--manifest", type=Path)
    parser.add_argument("--candidates", nargs="+")
    parser.add_argument("--conditions", nargs="+", choices=["plain", "shallow"], default=["plain", "shallow"])
    parser.add_argument("--outdir", type=Path, default=ROOT / "trials")
    parser.add_argument("--workers", type=int, default=2)
    parser.add_argument("--worker-job", type=Path)
    parser.add_argument("--smoke", action="store_true")
    args = parser.parse_args()
    if args.worker_job:
        run_trial(json.loads(args.worker_job.read_text()))
        return
    if args.smoke:
        factory = runner.load_fixture()
        env = make_env_micro(factory, factory.load_height_scene(10), runner.HAND_XML,
                             fixture="shallow", mass=.2, timestep=.001)
        print(json.dumps(env.micro_contact_definition, indent=2))
        return
    if args.manifest is None:
        parser.error("--manifest is required")
    variants = json.loads(args.manifest.read_text())["variants"]
    if args.candidates:
        variants = [v for v in variants if v["id"] in args.candidates]
    jobs = []
    for variant in variants:
        item = dict(variant)
        item["id"] += "_micro_contact"
        for fixture in args.conditions:
            job = {"variant": item, "fixture": fixture, "resume": False,
                   "output": str((args.outdir / f"h{int(item['height_mm']):03d}" / fixture / item["id"]).resolve())}
            path = args.outdir / "micro-jobs" / f"{fixture}__{item['id']}.json"
            path.parent.mkdir(parents=True, exist_ok=True)
            runner.write_json(path, job)
            jobs.append(path)

    def execute(path):
        result = subprocess.run([sys.executable, str(Path(__file__).resolve()), "--worker-job", str(path)], text=True, capture_output=True)
        if result.stdout:
            print(result.stdout, end="", flush=True)
        if result.stderr:
            print(result.stderr, end="", file=sys.stderr, flush=True)
        return {"job": str(path), "exit_code": result.returncode}

    with ThreadPoolExecutor(max_workers=args.workers) as pool:
        results = list(pool.map(execute, jobs))
    runner.write_json(args.outdir / "micro-contact-summary.json", {"adapter_sha256": runner.sha(__file__),
                      "profile": CONTACT, "jobs": results})
    if any(r["exit_code"] for r in results):
        raise SystemExit(1)


if __name__ == "__main__":
    main()
