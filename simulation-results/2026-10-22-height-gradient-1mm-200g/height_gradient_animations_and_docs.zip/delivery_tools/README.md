# Height-gradient delivery tools

这些工具只读取本次实验的最终文件。准备/打包完全离线；仅 `publish_delivery.py --publish` 执行 GitHub 写入，由主代理在最终审阅后调用。

```bash
python delivery_tools/prepare_delivery.py
python delivery_tools/prepare_delivery.py --build
python delivery_tools/publish_delivery.py
python delivery_tools/publish_delivery.py --publish
python delivery_tools/verify_publication.py
```

默认实验根目录是工具目录的上级。准备阶段不会自动启动物理或渲染。

打包前必须满足：`qa/final-review.json` 中 `ready_for_delivery:true`；`content_sha256` 按绝对路径绑定最终 `HEIGHT_GRADIENT_REPORT.md`、`PIPELINE.md`、`experiment-summary.json`、`experiment-results.csv`、`animations/index.json`。其他 QA 绑定文件也逐一核验。最终动画 index 必须覆盖 `trials` 下所有真实 trial，逐 trial 绑定 input/metrics/trace/diagnostics/MJB/XML SHA，并含每条 trial 动画、四高度双列及八工况总览。可通过重复 `--trials-root /absolute/path` 增加其他实际 trial 根目录。

全部正式视频进入 `height_gradient_animations_and_docs.zip`，连同报告、源码、场景、QA、拟合诊断与明确列出的公开模型资产。正式 trial 的 MJB、trace、diagnostics 等原文件仅进入 `raw_h004_plain.zip` 等八格 raw ZIP；每个 raw trial 同时包含它的原输入 NPY。任一 raw 格压缩后超过 35,000,000 bytes 时按完整 trial 子组递归拆分，保留原文件字节，不改模型或轨迹。若主 ZIP 超限则自动分 movies/support_docs，movies 仍可拆组；所有公开单文件均不得超过 35,000,000 bytes。

顶层公开文件包含总览、四高度双列、报告/管线/摘要、原动画 index、相对归档映射 `delivery-index.json`、最终 QA、所有 ZIP。单 trial 视频只在主动画 ZIP，减少上传请求。`delivery-index.json` 解释原绝对 source 路径与归档相对路径，不重写已冻结的原 index。

主 ZIP 中的五个对比/总览视频与根目录报告同级，使报告内链接解压后可直接打开；单 trial 视频保留 `animations/<trial>/...` 子目录。每个正式视频仅归档一次。

每个 ZIP 包含 `ARCHIVE_FILES_SHA256.json` 并执行完整 ZIP CRC 校验。`newdeliverables/delivery_manifest.json` 绑定公开文件 bytes/SHA。最终 QA、文档 SHA、原始模型/轨迹 SHA、所有 ZIP SHA/CRC 与 manifest SHA 另存于 `publication-state/package-validation.json`，不把包自身 hash 递归装入包内。已有非空 `newdeliverables` 会被拒绝覆盖。

默认发布目标：

- 仓库 `Lvguichen-C/Dexonomy`
- 结果分支 `mujoco-animation-results-20261016-assets`
- 父提交 `ab1e741dec733209c4d7981636c1b6e33eb2deeb`
- 路径 `simulation-results/2026-10-22-height-gradient-1mm-200g`
- tag `shadow-height-gradient-1mm-200g-20261022`

发布使用 blob/tree/commit/ref 接口，拒绝改 main/master、拒绝覆盖已有 Release，逐 blob 校验 Git SHA；Release 正文列出固定提交 raw 下载链接。发布后 `verify_publication.py` 使用无凭据 curl 匿名下载每一件公开文件并比对 bytes/SHA，核验公开 Release JSON 与全部下载链接。
