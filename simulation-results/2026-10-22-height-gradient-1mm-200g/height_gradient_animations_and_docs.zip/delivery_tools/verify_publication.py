#!/usr/bin/env python3
"""Anonymous curl downloads + SHA256 checks and public Release JSON checks."""
from __future__ import annotations
import argparse
from concurrent.futures import ThreadPoolExecutor
import json
from pathlib import Path
import subprocess
from urllib.parse import quote
from common import digest, plain_name, write_json


def download(url,path):
    if not url.startswith("https://"):
        raise ValueError("Expected an HTTPS public URL")
    # --disable is first: do not load curlrc credentials or other local headers.
    subprocess.run(["curl","--disable","--silent","--show-error","--fail","--location","--proto","=https","--retry","3","--retry-delay","1","--connect-timeout","15","--max-time","60","--output",str(path),url],check=True)


def main():
    root=Path(__file__).resolve().parent.parent
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--publication",type=Path,default=root/"publication.json")
    parser.add_argument("--outdir",type=Path,default=root/"download-verified")
    parser.add_argument("--workers",type=int,choices=(1,2,3,4),default=4)
    args=parser.parse_args()
    publication=json.loads(args.publication.read_text())
    if not publication.get("published") or not publication.get("release_created"):
        raise SystemExit("Both result branch and public Release must exist before verification")
    args.outdir.mkdir(parents=True,exist_ok=True)
    def verify(row):
        name=plain_name(row["name"])
        path=args.outdir/name
        download(row["raw_url"],path)
        if path.stat().st_size!=row["bytes"] or digest(path)!=row["sha256"]:
            raise ValueError(f"Anonymous download integrity mismatch: {name}")
        return {"name":name,"bytes":row["bytes"],"sha256":row["sha256"],"raw_url":row["raw_url"],"anonymous_download_verified":True}
    with ThreadPoolExecutor(max_workers=args.workers) as pool:
        files=list(pool.map(verify,publication["files"]))
    release_path=args.outdir/"public-release.json"
    download(f"https://api.github.com/repos/{publication['repo']}/releases/tags/{quote(publication['release_tag'],safe='')}",release_path)
    release=json.loads(release_path.read_text())
    if release.get("draft") is not False or release.get("tag_name")!=publication["release_tag"] or release.get("html_url")!=publication["release_url"]:
        raise ValueError("Anonymous Release JSON does not match the created public Release")
    if release.get("id") != publication["release_id"] or release.get("prerelease") is not False:
        raise ValueError("Public Release identity/status differs from publication")
    tag_path=args.outdir/"public-release-tag.json"
    download(f"https://api.github.com/repos/{publication['repo']}/git/ref/tags/{quote(publication['release_tag'],safe='')}",tag_path)
    tag=json.loads(tag_path.read_text())["object"]
    if tag.get("type") != "commit" or tag.get("sha") != publication["commit"]:
        raise ValueError("Public Release tag does not point to the fixed result commit")
    missing=[row["name"] for row in publication["files"] if row["raw_url"] not in (release.get("body") or "")]
    if missing:
        raise ValueError(f"Release body is missing public file links: {missing}")
    result={"commit":publication["commit"],"release_url":publication["release_url"],"release_public_anonymous_json_verified":True,"public_release_tag_commit_verified":True,"release_id":release["id"],"main_unchanged_during_publication":publication.get("main_unchanged"),"files":files}
    target=args.publication.parent/"public-download-verification.json"
    write_json(target,result)
    print(json.dumps({"anonymous_files_verified":len(files),"public_release_verified":True,"release_url":publication["release_url"],"verification":str(target)},ensure_ascii=False,indent=2))


if __name__=="__main__":
    main()
