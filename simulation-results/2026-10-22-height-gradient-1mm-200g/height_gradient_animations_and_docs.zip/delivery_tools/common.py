"""Local validation shared by the height-gradient delivery tools."""
from __future__ import annotations
import hashlib
import json
from pathlib import Path

CAP_BYTES = 35_000_000


def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def write_json(path, value):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n")


def plain_name(name):
    if not isinstance(name, str) or not name or Path(name).name != name or name in (".", "..") or "\\" in name or any(ord(c) < 32 or ord(c) == 127 for c in name):
        raise ValueError(f"Expected a plain delivery filename: {name!r}")
    return name


def validated_rows(folder):
    folder = Path(folder).resolve()
    manifest_path = folder / "delivery_manifest.json"
    manifest = json.loads(manifest_path.read_text())
    rows = [dict(row) for row in manifest["files"]]
    names = [plain_name(row["name"]) for row in rows]
    if not names or len(set(names)) != len(names) or manifest_path.name in names:
        raise ValueError("Empty, duplicate, or recursive delivery manifest")
    for row in rows:
        path = folder / row["name"]
        if path.is_symlink() or not path.is_file():
            raise ValueError(f"Missing or symlinked delivery: {path}")
        if path.stat().st_size > CAP_BYTES:
            raise ValueError(f"Delivery is over 35 MB: {path.name}")
        if type(row["bytes"]) is not int or row["bytes"] != path.stat().st_size:
            raise ValueError(f"Byte-count mismatch: {path.name}")
        expected = row["sha256"]
        if not isinstance(expected, str) or len(expected) != 64 or any(c not in "0123456789abcdef" for c in expected) or digest(path) != expected:
            raise ValueError(f"SHA256 mismatch: {path.name}")
    if manifest_path.stat().st_size > CAP_BYTES:
        raise ValueError("Delivery manifest is over 35 MB")
    rows.append({"name":manifest_path.name,"bytes":manifest_path.stat().st_size,"sha256":digest(manifest_path)})
    return manifest, rows


def safe_source(path):
    path = Path(path).resolve()
    forbidden = {"attachments", ".git", ".aws", ".codex", ".agents", "venvs", "venv", ".venv"}
    if not path.is_file() or forbidden.intersection(path.parts) or path.name in (".env", "credentials", "credentials.json", "secrets.json"):
        raise ValueError(f"Source is missing or outside this own-result scope: {path}")
    if not (path.is_relative_to("/workspace") or path.is_relative_to("/tmp")):
        raise ValueError(f"Source is outside workspace roots: {path}")
    return path
