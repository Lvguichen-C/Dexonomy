# D1 mm、200 g 高度梯度场景与无手稳定对照

本目录只负责场景和一次无手接触的静置对照。四种高度各有 plain、shallow 两种支撑，共 8 个工况；这不是抓取成功成绩。

## 冻结输入与接口

- 直径均为 1 mm；高度为 4、6、8、10 mm；质量均为实际编译的 0.200000000000 kg。
- 保留同一 64 边形圆柱网格，非均匀缩放 `[0.001, 0.001, 0.001*H/4]`。底面初始 z=0，中心初始 z=H/2，姿态为竖直 identity。
- 对象始终有 6 自由度 freejoint；没有连接对象的 equality、弹簧、手托连接或施加于对象的额外力。密度随体积改变，并用实际编译质量校准，未修改惯量数组。
- plain 地面 z=0；shallow 地面 z=−0.2 mm，托底顶面 z=0。浅托内孔最小直径 1.2 mm、外径 5 mm、壁高 0.75 mm、底厚 0.2 mm，32 段静态盒壁加一个底托。四种高度使用逐值相同的托杯，未随高度加深。
- 物理步长 1 ms，重力 `[0, 0, -9.81]` 开启；solver/integrator/contact 参数均由冻结旧实现继承。

工厂为上级目录的 `scene_factory.py`，提供：

```python
scene_path(height_mm)                       # scenes/h004.npy 等
load_height_scene(height_mm)                # 加载 base plane z=0 场景
prepare_scene(candidate_npy, mass=.2)        # 返回 candidate, scene
make_env(scene, hand_xml, fixture="plain", mass=.2, timestep=.001)
frozen_module()                             # 原 evaluator 模块，只读引用
```

`fixture` 可为 `plain` 或 `shallow`；浅托偏移仅由工厂应用一次。调用者不应提前降低 base scene 地面。

冻结工厂 SHA256：`520f96817ad6a3484b79421ab3e63280d97c6d3ed36e3a0833aa8982c475e35d`。

`scene-manifest.json` 包含四个 NPY 的 SHA、固定托杯定义与旧源码依赖 SHA。`compiled-scene-manifest.json` 记录每个工况实际编译的直径、高度、质量、惯量、初始姿态、freejoint、重力、solver、密度校准与静置结果。原 fixture、evaluator、hand XML、旧场景均未修改。

## 一次 3 s 无手静置结果

脚本 `validate_height_scenes.py` 将原候选手根目标移到 `[0,0,0.5]` m，保持其原手指状态，通过原生控制器执行 3000 个 1 ms 步。每步检查对象外力为零，并记录对象姿态、接触、支撑法向力和最大负 contact distance。

| 高度 mm | 支撑 | 最大倾角 ° | 末帧倾角 ° | 全程倾角 <15° | 最大穿透 / 半径 |
|---:|:---|---:|---:|:---:|---:|
| 4 | plain | 0.000 | 0.000 | 是 | 0.414 |
| 4 | shallow | 5.235 | 4.539 | 是 | 0.296 |
| 6 | plain | 0.000 | 0.000 | 是 | 0.414 |
| 6 | shallow | 0.466 | 0.137 | 是 | 0.251 |
| 8 | plain | 0.304 | 0.025 | 是 | 0.804 |
| 8 | shallow | 0.319 | 0.148 | 是 | 0.235 |
| 10 | plain | 0.415 | 0.195 | 是 | 0.781 |
| 10 | shallow | 0.337 | 0.087 | 是 | 0.228 |

8 个工况均无非有限状态、MuJoCo 警告或时间重置，3000 步始终没有手–对象或手–浅托接触。原始逐步数组为 `stability/h*_*.npz`，列名存于同文件 `columns`。`stability/stability-summary.json` 包含源候选、脚本与数据溯源和全部结果。

**微尺度接触限制：**半径仅 0.5 mm。plain H8、H10 的瞬时最大软接触穿透分别约为 0.402、0.391 mm，即半径的 80.4%、78.1%；plain H4、H6 约为半径的 41.4%。因此这里的“3 s 未倒”只说明当前冻结软接触模型中的稳定状态，不能证明现实毫米尺度接触精度，也不能替代动态接近、抓紧、抬升及脱离托杯的验证。本任务未为改善结果调整任何 contact 参数。

## XML 导出溯源

`stability/*.construction.xml` 保存最初 `MjSpec.to_xml()` 的原始字节。构造 spec 的 gravity flag 为 disable，而实际运行编译模型在工厂中显式开启了重力。

`stability/h*_*.xml` 已由 `finalize_stability_exports.py` 恢复实际 runtime 重力，以及记录中的完整精度对象密度、初始位置和姿态，撤销 XML 的十进制舍入。全部 8 个导出均重新编译核对质量 0.2 kg、惯量、网格尺寸、freejoint、1 ms 步长和重力；未执行任何模拟步，也未改动轨迹或成绩。

`stability/runtime-xml-finalization.json` 记录原始与修正 XML SHA、修正字段和校验值。其余 XML 字段保留普通 `MjSpec.to_xml()` 精度；动态试验应使用相应实际 trial 的 MJB/NPZ，而非把本静置构造快照当作其重放模型。
