#!/usr/bin/env python3
"""Compile and run one 3-second hand-away stability trial per height/support."""
from __future__ import annotations
import json
import math
from pathlib import Path
import sys
import mujoco
import numpy as np

ROOT=Path(__file__).resolve().parent.parent
sys.path.insert(0,str(ROOT))
import scene_factory as factory


def write(path,value):
    temp=path.with_suffix(path.suffix+".tmp")
    temp.write_text(json.dumps(value,indent=2)+"\n")
    temp.replace(path)


def object_tilt(q):
    matrix=np.empty(9)
    mujoco.mju_quat2Mat(matrix,q)
    return math.degrees(math.acos(np.clip(matrix.reshape(3,3)[2,2],-1,1)))


def main():
    factory_sha=factory.sha256(factory.__file__)
    source=next(Path("/workspace/shadow-lift-sweep-200g/output/diameter_sweep_200g_shadow/grasp_data").glob("*/cylinder_thin_table_1/*.npy"))
    candidate=np.load(source,allow_pickle=True).item()
    hand=np.asarray(candidate["pregrasp_qpos"])[0].copy()
    hand[:3]=[0,0,.5]
    records=[]
    out=ROOT/"scenes"/"stability"
    out.mkdir(exist_ok=True)
    for height in factory.HEIGHTS_MM:
        for support in ("plain","shallow"):
            condition=f"h{height:03d}_{support}"
            env=factory.make_env(factory.load_height_scene(height),"/workspace/Dexonomy/assets/hand/shadow/right.xml",fixture=support,mass=.2,timestep=.001)
            model,data=env._model,env._data
            body=env._obj_active_bodyid
            joints=[i for i in range(model.njnt) if int(model.jnt_bodyid[i])==body]
            assert len(joints)==1 and model.jnt_type[joints[0]]==mujoco.mjtJoint.mjJNT_FREE
            qadr=int(model.jnt_qposadr[joints[0]])
            dadr=int(model.jnt_dofadr[joints[0]])
            obj_geoms=[i for i in range(model.ngeom) if int(model.geom_bodyid[i])==body]
            half=model.geom_size[obj_geoms[0]].copy()
            fixture_ids=env.fixture_geom_ids
            assert all(model.geom_bodyid[i]==0 for i in fixture_ids)
            assert all(body not in (model.eq_obj1id[i],model.eq_obj2id[i]) for i in range(model.neq))
            env.reset_qpos(hand)
            initial=data.qpos[qadr:qadr+7].copy()
            compiled={"condition":condition,"height_mm":height,"diameter_mm":1,"support":support,
                "mass_kg":float(model.body_subtreemass[body]),"body_inertia_kg_m2":model.body_inertia[body].tolist(),
                "body_inertial_position_m":model.body_ipos[body].tolist(),"object_initial_qpos":initial.tolist(),
                "actual_mesh_half_extents_m":half.tolist(),"actual_diameter_mm":float(2*min(half)*1000),
                "actual_height_mm":float(2*max(half)*1000),"object_freejoint":True,
                "object_body_id":body,"object_joint_id":joints[0],"object_qpos_address":qadr,"object_dof_address":dadr,
                "nbody":model.nbody,"nq":model.nq,"nv":model.nv,"neq":model.neq,
                "gravity_m_s2":model.opt.gravity.tolist(),"gravity_disabled":bool(model.opt.disableflags&int(mujoco.mjtDisableBit.mjDSBL_GRAVITY)),
                "solver":{"timestep_s":float(model.opt.timestep),"integrator":int(model.opt.integrator),"solver":int(model.opt.solver),"iterations":int(model.opt.iterations),"tolerance":float(model.opt.tolerance),"noslip_iterations":int(model.opt.noslip_iterations),"impratio":float(model.opt.impratio)},
                "fixture_definition":env.fixture_definition,"fixture_geometry_sha256":factory.FIXTURE_SHA256,
                "fixture_geom_count":len(fixture_ids),"all_fixture_geoms_world_static":True,
                "density_calibration":env.density_calibration,
                "hand_target_far_pose":hand[:7].tolist(),"model_xml":str(out/f"{condition}.xml")}
            assert abs(compiled["mass_kg"]-.2)<1e-9
            assert abs(compiled["actual_diameter_mm"]-1)<1e-5 and abs(compiled["actual_height_mm"]-height)<1e-4
            (out/f"{condition}.xml").write_text(env._spec.to_xml())
            rows=[]
            warned=np.zeros(len(data.warning),dtype=int)
            crossings={str(value):None for value in (5,15,45,80)}
            finite=True
            resets=[]
            previous=0.0
            for step in range(3000):
                env.set_ctrl(hand,"ee_pose")
                assert np.max(np.abs(data.qfrc_applied[dadr:dadr+6]))==0 and np.max(np.abs(data.xfrc_applied[body]))==0
                mujoco.mj_step(model,data)
                finite &= bool(np.isfinite(data.qpos).all() and np.isfinite(data.qvel).all())
                if data.time<=previous:
                    resets.append(step)
                previous=float(data.time)
                warned=np.maximum(warned,[w.number for w in data.warning])
                pose=data.qpos[qadr:qadr+7].copy()
                angle=object_tilt(pose[3:])
                for threshold in crossings:
                    if crossings[threshold] is None and angle>=float(threshold):
                        crossings[threshold]=float(data.time)
                ho=hf=table=fixture=0
                normal_fixture=normal_table=0.0
                max_penetration=0.0
                for i,c in enumerate(data.contact):
                    bodies=[int(model.geom_bodyid[g]) for g in (c.geom1,c.geom2)]
                    names=[model.body(b).name for b in bodies]
                    geoms=[model.geom(int(g)).name for g in (c.geom1,c.geom2)]
                    any_hand=any(n.startswith("hand-") for n in names)
                    any_fixture=any(n.startswith("fixture-") for n in geoms)
                    if any_hand and any_fixture:
                        hf+=1
                    if body not in bodies:
                        continue
                    max_penetration=max(max_penetration,-float(c.dist))
                    force=np.zeros(6)
                    mujoco.mj_contactForce(model,data,i,force)
                    if any_hand:
                        ho+=1
                    if any_fixture:
                        fixture+=1
                        normal_fixture+=max(0,float(force[0]))
                    elif 0 in bodies:
                        table+=1
                        normal_table+=max(0,float(force[0]))
                rows.append([data.time,*pose,*data.qvel[dadr:dadr+6],angle,ho,hf,fixture,table,normal_fixture,normal_table,max_penetration])
            arr=np.array(rows)
            trace=out/f"{condition}.npz"
            np.savez_compressed(trace,rows=arr,columns=np.array(["time_s",*[f"object_qpos{i}" for i in range(7)],*[f"object_qvel{i}" for i in range(6)],"object_tilt_deg","HO_contacts","hand_fixture_contacts","object_fixture_contacts","object_table_contacts","fixture_normal_sum_N","table_normal_sum_N","max_object_contact_penetration_m"]))
            # Columns: t0, pose1..7, qvel8..13, tilt14, HO15, HF16,
            # fixture17, table18, normalfixture19, normaltable20, penetration21.
            dynamic={"duration_s":float(data.time),"physics_steps":len(arr),"finite_states":finite,"warning_counts":warned.tolist(),"unexpected_time_resets":resets,
                "all_steps_without_hand_object_contact":bool((arr[:,15]==0).all()),"all_steps_without_hand_fixture_contact":bool((arr[:,16]==0).all()),
                "first_tilt_crossings_s":crossings,"maximum_tilt_deg":float(arr[:,14].max()),"final_tilt_deg":float(arr[-1,14]),
                "stood_below15deg_throughout_3s":bool((arr[:,14]<15).all()),"final_object_pose":arr[-1,1:8].tolist(),
                "maximum_object_contact_penetration_m":float(arr[:,21].max()),"maximum_penetration_over_radius":float(arr[:,21].max()/.0005),
                "final_fixture_normal_sum_N":float(arr[-1,19]),"final_table_normal_sum_N":float(arr[-1,20]),
                "trace":str(trace),"trace_sha256":factory.sha256(trace),"not_a_grasp_trial":True,"object_external_forces_applied":False}
            records.append({**compiled,"stability":dynamic})
            write(ROOT/"scenes"/"compiled-scene-manifest.json",{"factory_sha256":factory_sha,"completed_cases":len(records),"expected_cases":8,"records":records})
            print(json.dumps({"condition":condition,"mass":compiled["mass_kg"],"max_tilt_deg":dynamic["maximum_tilt_deg"],"final_tilt_deg":dynamic["final_tilt_deg"],"stood_3s":dynamic["stood_below15deg_throughout_3s"]}),flush=True)
    assert factory.sha256(factory.__file__)==factory_sha
    summary={"scope":"One3s gravity-on hand-away stability trial per height/support, not a grasp-success score","factory_sha256":factory_sha,"source_candidate":str(source),"source_candidate_sha256":factory.sha256(source),"completed_cases":len(records),"records":records}
    write(out/"stability-summary.json",summary)


if __name__=="__main__":
    main()
