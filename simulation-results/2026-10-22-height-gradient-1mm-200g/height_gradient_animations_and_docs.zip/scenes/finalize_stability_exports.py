#!/usr/bin/env python3
"""Finalize static-probe XML artifacts without stepping or altering results.

MjSpec.to_xml serializes the construction spec. The compiled runtime enables
gravity separately and uses higher-precision density/position values. Preserve
the original bytes and restore those recorded runtime settings in the XML.
"""
from __future__ import annotations

import hashlib
import json
from pathlib import Path
import xml.etree.ElementTree as ET

import mujoco
import numpy as np

ROOT = Path(__file__).resolve().parent


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def write_json(path, value):
    temp = path.with_suffix(path.suffix + ".finalization.tmp")
    temp.write_text(json.dumps(value, indent=2) + "\n")
    temp.replace(path)


def main():
    manifest_path = ROOT / "compiled-scene-manifest.json"
    summary_path = ROOT / "stability/stability-summary.json"
    manifest = json.loads(manifest_path.read_text())
    summary = json.loads(summary_path.read_text())
    factory = ROOT.parent / "scene_factory.py"
    assert sha(factory) == manifest["factory_sha256"] == summary["factory_sha256"]
    assert manifest["completed_cases"] == summary["completed_cases"] == 8
    exports = {}
    for row in manifest["records"]:
        path = Path(row["model_xml"])
        construction = path.with_name(path.stem + ".construction.xml")
        source = construction.read_bytes() if construction.exists() else path.read_bytes()
        tree = ET.fromstring(source)
        option = tree.find("option")
        assert option is not None
        flag = option.find("flag")
        if flag is None:
            flag = ET.SubElement(option, "flag")
        option.set("gravity", "0 0 -9.81")
        flag.set("gravity", "enable")
        body = next(b for b in tree.iter("body") if b.get("name", "").startswith("obj-"))
        object_geom = next(g for g in body.iter("geom") if g.get("name", "").startswith("obj-"))
        object_geom.set("density", repr(row["density_calibration"]["effective_density_kg_m3"]))
        body.set("pos", " ".join(repr(v) for v in row["object_initial_qpos"][:3]))
        body.set("quat", " ".join(repr(v) for v in row["object_initial_qpos"][3:]))
        rendered = ET.tostring(tree, encoding="utf-8") + b"\n"
        model = mujoco.MjModel.from_xml_string(rendered.decode())
        obj = mujoco.mj_name2id(model, mujoco.mjtObj.mjOBJ_BODY, body.get("name"))
        geom = mujoco.mj_name2id(model, mujoco.mjtObj.mjOBJ_GEOM, object_geom.get("name"))
        assert not (model.opt.disableflags & int(mujoco.mjtDisableBit.mjDSBL_GRAVITY))
        assert np.array_equal(model.opt.gravity, row["gravity_m_s2"])
        assert abs(model.opt.timestep - row["solver"]["timestep_s"]) < 1e-15
        assert abs(model.body_subtreemass[obj] - row["mass_kg"]) < 1e-12
        np.testing.assert_allclose(model.body_inertia[obj], row["body_inertia_kg_m2"], rtol=1e-12, atol=1e-18)
        np.testing.assert_allclose(model.geom_size[geom], row["actual_mesh_half_extents_m"], rtol=0, atol=1e-12)
        assert model.jnt_type[int(model.body_jntadr[obj])] == mujoco.mjtJoint.mjJNT_FREE
        if not construction.exists():
            construction.write_bytes(source)
        assert hashlib.sha256(source).hexdigest() == sha(construction)
        path.write_bytes(rendered)
        result = {
            "construction_xml": str(construction), "construction_sha256": sha(construction),
            "runtime_xml": str(path), "runtime_xml_sha256": sha(path),
            "changes": {
                "gravity": "Enabled, 0 0 -9.81; matches recorded compiled runtime",
                "object_density": "Recorded full-precision effective density, undo XML decimal rounding",
                "object_initial_pose": "Recorded full-precision pose, undo XML decimal rounding",
            },
            "compile_verified": True, "verified_object_mass_kg": float(model.body_subtreemass[obj]),
            "verified_object_inertia_kg_m2": model.body_inertia[obj].tolist(),
            "verified_gravity_enabled": True,
            "no_simulation_steps_or_result_changes": True,
            "serialization_note": "Other MjSpec.to_xml fields retain normal XML serialization precision; original runtime arrays and actual trials are in NPZ/JSON and the full trial MJBs.",
        }
        exports[row["condition"]] = result
        row["model_export"] = result
    for row in summary["records"]:
        row["model_export"] = exports[row["condition"]]
    report = {
        "scope": "Artifact-only finalization of the 8 hand-away 3s stability XML exports; no mj_step and no trajectory/result modifications",
        "factory_sha256": sha(factory), "finalizer_sha256": sha(__file__),
        "mujoco_version": mujoco.__version__, "models": exports,
    }
    report_path = ROOT / "stability/runtime-xml-finalization.json"
    write_json(report_path, report)
    for document, path in ((manifest, manifest_path), (summary, summary_path)):
        document["runtime_xml_finalization"] = str(report_path)
        write_json(path, document)
    assert sha(factory) == manifest["factory_sha256"]
    print(json.dumps({"models": len(exports), "report": str(report_path), "factory_unchanged": True}))


if __name__ == "__main__":
    main()
