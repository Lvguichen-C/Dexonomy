#!/usr/bin/env python3
"""Static open-top cups for the isolated upright 1 mm / 200 g experiment.

No object joint/equality/control is added. The object remains free. All fixture
geometry is attached directly to world; hand/object body indices are unchanged.
"""
from __future__ import annotations
from dataclasses import asdict, dataclass
import importlib.util
import json
import math
from pathlib import Path
import sys

import mujoco
import numpy as np

REPO=Path("/workspace/Dexonomy")
FROZEN=Path("/workspace/shadow-lift-sweep-200g/evaluate_lifts.py")
sys.path.insert(0,str(REPO))


@dataclass(frozen=True)
class CupSpec:
    name: str="shallow"
    inner_diameter_m: float=0.0012
    outer_diameter_m: float=0.005
    wall_height_m: float=0.00075
    bottom_thickness_m: float=0.0002
    segments: int=32
    contact_margin_m: float=0.0
    contact_priority: int=1
    friction: tuple=(0.6,0.00002,0.000001)
    contact_solref: tuple=(0.01,1.0)


def cup_spec(name="shallow"):
    if isinstance(name,CupSpec):
        return name
    if name=="shallow":
        return CupSpec()
    if name=="deep":
        return CupSpec(name="deep",wall_height_m=0.0025)
    if name=="plain":
        return None
    raise ValueError(f"Unknown fixture: {name}")


def geometry_definition(fixture="shallow"):
    spec=cup_spec(fixture)
    if spec is None:
        return {"name":"plain","table_top_z_m":0.0,"object_initial_center_m":[0,0,0.002],"object_initial_quaternion_wxyz":[1,0,0,0]}
    value=asdict(spec)
    value.update(table_top_z_m=-spec.bottom_thickness_m,bottom_top_z_m=0.0,
        object_initial_center_m=[0,0,0.002],object_initial_quaternion_wxyz=[1,0,0,0],
        minimum_radial_clearance_m=(spec.inner_diameter_m-0.001)/2,
        maximum_polygon_hole_diameter_m=spec.inner_diameter_m/math.cos(math.pi/spec.segments),
        exposed_upright_object_length_m=0.004-spec.wall_height_m,
        static_world_geometry=True,object_freejoint_unchanged=True,
        object_weld_or_spring_added=False,fixture_attached_to_hand=False,
        support_policy="New scene lowers plane by bottom thickness while keeping rod center z=2mm; cup bottom top stays z=0")
    return value


def add_fixture_to_spec(spec,fixture="shallow"):
    config=cup_spec(fixture)
    if config is None:
        return []
    ri,ro=config.inner_diameter_m/2,config.outer_diameter_m/2
    names=[]
    floor=spec.worldbody.add_geom(name="fixture-bottom",type=mujoco.mjtGeom.mjGEOM_CYLINDER,
        size=[ro,config.bottom_thickness_m/2,0],pos=[0,0,-config.bottom_thickness_m/2],
        rgba=[0.25,0.40,0.55,1])
    names.append(floor.name)
    # Boxes overlap tangentially; their inner faces form a closed regular polygon
    # with apothem ri, preserving at least the stated circular opening clearance.
    for i in range(config.segments):
        angle=2*math.pi*i/config.segments
        name=f"fixture-wall-{i:02d}"
        spec.worldbody.add_geom(name=name,type=mujoco.mjtGeom.mjGEOM_BOX,
            size=[(ro-ri)/2,ro*math.tan(math.pi/config.segments)*1.002,config.wall_height_m/2],
            pos=[(ri+ro)/2*math.cos(angle),(ri+ro)/2*math.sin(angle),config.wall_height_m/2],
            quat=[math.cos(angle/2),0,0,math.sin(angle/2)],rgba=[0.25,0.40,0.55,1])
        names.append(name)
    for geom in spec.geoms:
        if geom.name.startswith("fixture-"):
            geom.contype=1
            geom.conaffinity=1
            geom.condim=3
            geom.priority=config.contact_priority
            geom.margin=config.contact_margin_m
            geom.gap=0
            geom.friction=config.friction
            geom.solref=config.contact_solref
    return names


def with_fixture_env_class(base_cls,fixture="shallow"):
    config=cup_spec(fixture)
    class FixtureEnv(base_cls):
        def _add_hand(self,*args,**kwargs):
            result=super()._add_hand(*args,**kwargs)
            add_fixture_to_spec(self._spec,config or "plain")
            return result

        def _add_plane(self,name,pose=[0,0,0,1,0,0,0],**kwargs):
            adjusted=np.asarray(pose,dtype=float).copy()
            if config is not None:
                adjusted[2]-=config.bottom_thickness_m
            return super()._add_plane(name,pose=adjusted,**kwargs)

        def _set_friction(self,miu_coef):
            result=super()._set_friction(miu_coef)
            # Native code sets friction/condim on every geom; reapply only the
            # new fixture's explicit physical material, without changing hand.
            if config is not None:
                for geom in self._spec.geoms:
                    if geom.name.startswith("fixture-"):
                        geom.condim=3
                        geom.priority=config.contact_priority
                        geom.friction=config.friction
                        geom.margin=config.contact_margin_m
                        geom.solref=config.contact_solref
            return result
    FixtureEnv.__name__=f"{base_cls.__name__}_{config.name if config else 'plain'}"
    return FixtureEnv


def frozen_module():
    name="_upright_fixture_frozen_evaluator"
    if name not in sys.modules:
        info=importlib.util.spec_from_file_location(name,FROZEN)
        module=importlib.util.module_from_spec(info)
        sys.modules[name]=module
        info.loader.exec_module(module)
    return sys.modules[name]


def make_env(scene,hand_xml,fixture="shallow",mass_kg=0.2,timestep=None):
    import copy
    from dexonomy.sim import HandCfg,MuJoCo_EvalCfg
    module=frozen_module()
    scene=copy.deepcopy(scene)
    # Keep the supplied rod orientation/center only if they describe this test.
    obj=scene["scene"][scene["task"]["obj_name"]]
    if not np.allclose(obj["scale"],[0.001]*3,atol=1e-10) or not np.allclose(obj["pose"],[0,0,0.002,1,0,0,0],atol=1e-9):
        raise ValueError("Upright fixture scene requires D1mm H4mm center=[0,0,2mm], identity orientation")
    info=json.loads(Path(obj["info_path"]).read_text())
    volume=info["mass"]/(info["density"]*info["scale"]**3)
    obj["density"]=mass_kg/(volume*np.prod(obj["scale"]))
    cfg=MuJoCo_EvalCfg(miu_coef=[0.6,0.02])
    if timestep is not None:
        cfg.timestep=float(timestep)
    env=with_fixture_env_class(module.SweepEnv,fixture)(
        hand_cfg=HandCfg(str(hand_xml),freejoint=True),scene_cfg=scene,sim_cfg=cfg,
        debug_render=False,debug_view=False)
    env._model.opt.disableflags&=~int(mujoco.mjtDisableBit.mjDSBL_GRAVITY)
    env._model.opt.gravity[:]=[0,0,-9.81]
    env.fixture_definition=geometry_definition(fixture)
    env.fixture_geom_ids=[i for i in range(env._model.ngeom) if env._model.geom(i).name.startswith("fixture-")]
    return env


def contact_log(model,data,object_body_id=None):
    rows=[]
    for index,contact in enumerate(data.contact):
        names=[model.geom(int(g)).name for g in (contact.geom1,contact.geom2)]
        bodies=[int(model.geom_bodyid[g]) for g in (contact.geom1,contact.geom2)]
        if object_body_id is not None and object_body_id not in bodies:
            continue
        value=np.zeros(6)
        mujoco.mj_contactForce(model,data,index,value)
        kind="fixture" if any(n.startswith("fixture-") for n in names) else ("table" if any(n.startswith("plane-") for n in names) else "other")
        rows.append({"kind":kind,"geom_names":names,"contact_dim":int(contact.dim),"normal_force_N":float(value[0]),"distance_m":float(contact.dist),"position_m":contact.pos.copy().tolist()})
    return rows


if __name__=="__main__":
    print(json.dumps({name:geometry_definition(name) for name in ("plain","shallow","deep")},indent=2))
