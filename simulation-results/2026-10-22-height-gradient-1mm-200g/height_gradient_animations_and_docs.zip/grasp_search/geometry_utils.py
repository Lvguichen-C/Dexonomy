"""Collision-query helpers, extracted unchanged from the earlier static scout.

The current search does not rely on an external experiment directory at runtime.
Native contact records remain authoritative for rejecting negative distances;
positive proximity output alone never certifies a pressing contact.
"""
import json
import mujoco
import numpy as np
from scipy.spatial.transform import Rotation

def encode(value):
    if isinstance(value,np.ndarray):return value.tolist()
    if isinstance(value,np.generic):return value.item()
    raise TypeError(type(value).__name__)
def quat_to_rotation(q):return Rotation.from_quat(np.r_[q[1:],q[0]])
def rotation_to_quat(r):
    q=r.as_quat();return np.r_[q[3],q[:3]]

class CollisionQueries:
    def distances(self):
        ds=[];segments=[]
        for gi in self.tips:
            s=np.zeros(6);ds.append(mujoco.mj_geomDistance(self.m,self.d,gi,self.obj,.2,s));segments.append(s.reshape(2,3))
        return np.asarray(ds),np.asarray(segments)
    def min_plane(self):
        lowest=.5
        for gi in self.hand_geoms:
            p=self.d.geom_xpos[gi];r=self.d.geom_xmat[gi].reshape(3,3);s=self.m.geom_size[gi];typ=self.m.geom_type[gi]
            if typ==mujoco.mjtGeom.mjGEOM_MESH:
                mid=self.m.geom_dataid[gi];v=self.m.mesh_vert[self.m.mesh_vertadr[mid]:self.m.mesh_vertadr[mid]+self.m.mesh_vertnum[mid]]
                z=p[2]+np.min(v@r[2])
            elif typ==mujoco.mjtGeom.mjGEOM_CAPSULE:z=p[2]-s[0]-s[1]*abs(r[2,2])
            elif typ==mujoco.mjtGeom.mjGEOM_SPHERE:z=p[2]-s[0]
            elif typ==mujoco.mjtGeom.mjGEOM_BOX:z=p[2]-np.abs(r[2])@s
            elif typ==mujoco.mjtGeom.mjGEOM_CYLINDER:z=p[2]-s[1]*abs(r[2,2])-s[0]*np.linalg.norm(r[2,:2])
            else:continue
            lowest=min(lowest,z)
        return float(lowest)
    def collisions(self):
        hh=ho=0.
        for c in self.d.contact:
            bs=[self.m.body(self.m.geom_bodyid[i]).name for i in (c.geom1,c.geom2)]
            if all(b.startswith('hand-') for b in bs):hh=min(hh,float(c.dist))
            elif any(b.startswith('hand-') for b in bs) and any(b.startswith('obj-') for b in bs):ho=min(ho,float(c.dist))
        return hh,ho
