# Independent formal trial readback

All **10 trials of the five frozen new proposals failed the registered full lift/hold/release sequence**. They are actual continuous free-object trials from the independent runner, not the auxiliary fitting oracle. The eight original top-aligned baselines are separate, giving 18 original-profile trials in the overall experiment.

| Height / version | Support | Measured object lift | Loaded dual-finger coverage | Loaded peak total normal force | Lift dual-finger coverage |
| --- | --- | ---: | ---: | ---: | ---: |
| H10 v1 | plain | -0.3873 mm | 0.0% | 0.0722 N | 0.0% |
| H10 v1 | shallow | -0.1097 mm | 100.0% | 0.0784 N | 2.5% |
| H4 new fit | plain | -0.2072 mm | 0.0% | 0.0000 N | 0.0% |
| H4 new fit | shallow | -0.1128 mm | 0.0% | 0.1262 N | 0.0% |
| H6 new fit | plain | -0.2072 mm | 0.0% | 0.0000 N | 0.0% |
| H6 new fit | shallow | -0.0888 mm | 0.0% | 0.0000 N | 0.0% |
| H8 new fit | plain | -0.3988 mm | 0.0% | 0.0504 N | 0.0% |
| H8 new fit | shallow | -0.0964 mm | 0.0% | 0.0739 N | 0.0% |
| H10 new fit | plain | -0.3867 mm | 100.0% | 0.1088 N | 2.7% |
| H10 new fit | shallow | -0.0857 mm | 100.0% | 0.1208 N | 4.0% |


The H10 buffered target now establishes both thumb and index contact for the entire 1 s loaded hold in both support conditions. This is an improvement in contact formation, but peak total force remains about 0.1 N, far below the approximately 3.27 N pressure needed to support 0.2 kg against gravity at mu=0.6 even before moment/normal-direction constraints. Contact disappears early in lifting and no 100 mm object lift occurs. Loaded contact coverage must not be described as a stable successful grasp.

H4/H6/H8 targets did not establish sustained two-sided load bearing. All raw phase forces, coverage and penetration values, with source result hashes, are preserved in `FORMAL_READBACK.json`. No source trial, input, physical threshold or model was changed by this readback. The root experiment may report separate explicitly labeled numerical/contact/controller sensitivities; those must not replace these original-profile outcomes.
