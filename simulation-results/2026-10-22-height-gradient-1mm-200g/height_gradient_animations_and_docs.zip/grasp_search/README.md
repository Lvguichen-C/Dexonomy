# Actuator-aware microscopic grasp candidates

These are new fitted control targets for free D1 mm cylinders of H4/6/8/10 mm, mass 0.2 kg. They are **uncertified dynamic proposals**, not successful grasps. The first H10 candidate and the four-height frozen batch have been sent to the independent full-sequence runner. No candidate file listed in the two frozen manifests will be changed.

## Execution and fitting

The variables are commanded root position/orientation (6), index abduction/proximal flexion (2), index FFJ2+FFJ1 tendon sum (1), and thumb position targets (5). Only the existing actuator sum is optimized for the coupled index pair; no independent finger drive, equality, actuator gain, gravity, or contact material was added. The nominal numbers written to both coupled hinges preserve their seed target split, but actual split is obtained from dynamics, rather than assumed equal to that target.

Each objective physically simulates the hand 100 mm above the rod using the unmodified 1 ms, gravity-on free-hand/free-object model: 0.5 s initial preshape, six 0.1 s opening-to-grasp intervals and a 1 s settle. The object is not grasped in this auxiliary run. After dynamics, a cloned data state translates only the hand down 100 mm for a static geometry query against the actual freely settled rod. This translated clone is a diagnostic only; formal trials do not use a pose write or reset inside the sequence.

Preshape alpha scales the original opening displacement (both root displacement and joint opening) around the new target. Alpha zero therefore starts with grasp-like hand shape at the far position; alpha 0.1/0.25 use small openings. The formal runner still starts 100 mm away, shows a 0.5 s pause, approaches vertically for 2 s, then performs closure, loaded hold, 100 mm lift over 5 s, 5 s hold and release.

The first finite solve batch tried both Palmar Pinch and Tip Pinch at H10/H8, then one finite fit at H6/H4; the H10 Palmar target had one extra 20 µm hand/hand-buffered refinement. Each solve used at most 20 least-squares evaluations with explicit central differences and real auxiliary dynamics. These auxiliary oracle calls are repeated reset-based isolated-hand diagnostics, not independent full grasp trials.

## Frozen inputs

`first-candidates.json` contains H10 v1 with old extra squeeze multiplied by 0.05. The optimized four-height batch is `optimized-candidates-frozen.json`. Those four files preserve float64 controls; after saving, the exact control arrays were physically rechecked at both grasp and squeeze auxiliary endpoints. The H10 buffered variant also has an explicitly declared +20 µm commanded root-z offset and squeeze multiplier 0.1. Other new frozen variants use squeeze multiplier 0.05.

| Height / input | Preshape alpha | Extra squeeze multiplier | Grasp geometry query, index/thumb | Squeeze geometry query, index/thumb |
| --- | ---: | ---: | ---: | ---: |
| H4 / 24_Tip_Pinch | 0.1 | 0.05 | 210.3 µm / 535.6 µm | 181.0 µm / 536.2 µm |
| H6 / 9_Palmar_Pinch | 0.1 | 0.05 | 124.7 µm / 171.5 µm | 127.4 µm / 157.5 µm |
| H8 / 24_Tip_Pinch | 0 | 0.05 | 102.3 µm / 683.4 µm | 178.0 µm / 666.4 µm |
| H10 / 9_Palmar_Pinch | 0.25 | 0.1 | 69.6 µm / 75.0 µm | 37.1 µm / 46.5 µm |


All five frozen proposals remain uncertified. In particular, the H10 buffered squeeze query returns about 37/46 µm, while native contact records show approximately −100 µm hand/object and −61 µm hand/hand distances. The original zero-negative-distance filters reject that state. Positive `mj_geomDistance` values alone are insufficient in this microscopic overlapping-mesh case: a coincident from/to segment and contradictory native contact distance must be inspected. No threshold was relaxed to make these proposals pass.

The original native threshold is still a 2 mm proximity query, zero allowed negative hand/hand or hand/object distance, required index/thumb coverage, zero joint-limit violation and QP residual <=0.001. In addition, the reported strict geometry gate requires both actual tracked tips within 50 µm, no negative native contact distance and nonnegative hand/table clearance. None passed the full strict gate. A finite unsuccessful search does not establish physical impossibility.

## What changed from the earlier pipeline

Earlier templates and saved static joint angles could be close geometrically while the actual root and tendon shape differed. Independent control diagnostics found that large extra squeeze causes distal hand/hand contact, followed by major redistribution of the uncontrolled internal tendon angle. Near-grasp preshaping and smaller squeeze were therefore included explicitly. This is a new control profile, not a change to the rod or a weaker physical test.

Fitting used the freely settled rod from each auxiliary run. This avoids silently treating the initial scene center as its loaded position: in the previous H4 plain test the rod settled by about 207 µm. Even here, small free-object tilt/drift and contact-branch sensitivity limit the mapping. Exact float64 inputs make the file and its recheck consistent; they do not imply realistic robot precision or robust success. The first H10 float32 target recheck changed from the optimizer endpoint 27.7/24.0 µm to about 48.8/93.7 µm, so the frozen record reports the remeasured values.

Actual H10 v1 formal tests are separate: the shallow condition reached both fingers during loaded hold and avoided tipping, but force was far below the approximately 3.27 N total normal pressure needed for gravity alone at mu=0.6. Neither its static query nor this contact coverage is a successful 100 mm lift. Official physical outcomes, contact force histories and animations belong to `../trials/` and the runner report.

## Reproduction and provenance

Run `fit_controlled.py --height H --template TEMPLATE --alpha ALPHA` with the prepared Dexonomy CPU environment. `freeze_candidate.py RECORD` writes a new immutable float64 payload and rechecks grasp/squeeze; optional offsets and squeeze gains are explicit arguments. `geometry_utils.py` contains the local helpers, so these scripts no longer require the earlier scout directory at runtime. They do require the unchanged Dexonomy repository, source grasp, scene factory and robot assets whose paths and hashes are stored in records.

Prototype JSON/NPY files and optimization logs preserve development endpoints; only the two frozen manifests name official test inputs. `FINAL_INPUT_SUMMARY.json` records immutable input/manifest checks and current script hashes. Source robot files, old grasp pools, old released results and the frozen physical evaluator remain unchanged.
