#!/usr/bin/env python3
"""Freeze exact float64 controls and remeasure grasp and squeeze auxiliary paths."""
from fit_controlled import *

def main():
    ap=argparse.ArgumentParser();ap.add_argument('record',type=Path);ap.add_argument('--root-z-offset-m',type=float,default=0.);ap.add_argument('--squeeze-gain',type=float,default=.05);ap.add_argument('--suffix',default='f64');args=ap.parse_args()
    src=json.loads(args.record.read_text());height=src['height_mm'];template=src['template'];alpha=src['preshape_alpha']
    c=Controlled(height,template,alpha)
    q=np.asarray(src['control_grasp_qpos'],dtype=np.float64)
    q[2]+=args.root_z_offset_m
    data=np.load(src['input'],allow_pickle=True).item()
    data['grasp_qpos']=q[None];data['pregrasp_qpos']=c.open_path(q)
    sq=q.copy();sq[7:]+=args.squeeze_gain*(c.source['squeeze_qpos'][0,7:]-c.source['grasp_qpos'][0,7:])
    for k,(lo,hi) in c.ranges.items():sq[k]=np.clip(sq[k],lo,hi)
    data['squeeze_qpos']=sq[None]
    ident=src['id']+'_'+args.suffix;path=HERE/'candidates'/f'{ident}.npy'
    if path.exists():raise RuntimeError('Frozen candidate already exists; never overwrite')
    np.save(path,data)
    measurements={}
    for stage,squeeze in [('grasp',None),('squeeze',sq)]:
        a,obj,ds,sg,hh,ho,plane=c.simulate(q,squeeze)
        native,qp,_=c.native(a,obj)
        measurements[stage]=dict(tip_gaps_m=ds,closest_segments_m=sg,hand_hand_negative_distance_m=hh,hand_object_negative_distance_m=ho,minimum_hand_z_m=plane,actual_hand_qpos=a,free_object_pose=obj,native_filter_passed=native,native_qp_residual=qp,strict_geometry_passed=bool(native and np.all((ds>=0)&(ds<.00005)) and hh>=0 and ho>=0 and plane>=0),physical_success_inferred=False)
    row=copy.deepcopy(src);row.update(id=ident,input=str(path),input_sha256=sha(path),control_dtype='float64',version_frozen=True,derived_from_record=str(args.record),derived_from_record_sha256=sha(args.record),saved_control_oracle=measurements,squeeze_source_delta_gain=args.squeeze_gain,root_z_offset_m=args.root_z_offset_m,native_filter_passed=False,actual_settled_native_filter_passed=measurements['grasp']['native_filter_passed'],strict_geometry_passed=all(m['strict_geometry_passed'] for m in measurements.values()),stage='uncertified_dynamic_proposal',oracle_precision_notice='Exact saved float64 controls were used for both remeasurements. Float64 does not assert robot precision or robustness. No real HO contact in the auxiliary hand trajectory; translated-copy geometry is diagnostic only.')
    row['tracked_tip_gaps_m']=measurements['grasp']['tip_gaps_m']
    row['tracked_hand_hand_negative_distance_m']=measurements['grasp']['hand_hand_negative_distance_m']
    write(HERE/f'{ident}.json',row)
    write(HERE/f'{ident}-manifest.json',dict(schema_version=1,candidate_count=1,variants=[row]))
    print(json.dumps(dict(id=ident,input=str(path),measurements=measurements),default=encode),flush=True)
if __name__=='__main__':main()
