#!/usr/bin/env python3
"""Label the eight-cell overview's static end-of-hold values explicitly.

Only the overview is rebuilt from final approved individual clips. The frozen
state renderer and every individual trial clip remain unchanged.
"""
from __future__ import annotations

import argparse
import json
from pathlib import Path
import subprocess

from PIL import Image, ImageDraw, ImageFont

from render_heights import FPS, OUT, make_overview, probe, selection_key, sha, write_json

PROFILE_LABELS={'micro_HO_dim3_4ms':'微接触对照','force_clamp_baseline_contact':'力反馈对照','force_clamp_micro':'微接触＋力反馈对照','force_clamp_root_micro':'微接触＋夹力/手根反馈'}


def fit_trial_captions(index):
    """Preserve complete IDs in metadata while keeping long header text in view."""
    fontfile='/usr/share/fonts/opentype/noto/NotoSansCJK-Regular.ttc'
    font=ImageFont.truetype(fontfile,16)
    updated={}
    for source in index['sources']:
        profile=source.get('controller_profile','baseline')
        suffix='' if profile=='baseline' else f' [{profile}]'
        status='全流程通过' if source['full_sequence_passed'] else '未通过；保留真实失败过程'
        original_label=f"{source['variant']}{suffix}  |  {status}"
        comparison=source['comparison_profile']
        sensitivity_label=PROFILE_LABELS.get(comparison)
        if font.getlength(original_label)<=620 and not sensitivity_label:
            continue
        prefix=source['variant']
        heading=f'{sensitivity_label} · {status}' if sensitivity_label else status
        while font.getlength(f'{heading} | {prefix}…{suffix}')>620:
            prefix=prefix[:-1]
        label=f'{heading} | {prefix}…{suffix}'
        video=source['video']
        raw=Path(video['path'])
        assert sha(raw)==video['sha256']
        target=raw.with_name('full_sequence_presented.mp4')
        assert not target.exists(),'Inspect existing presentation clip before rerun'
        temp=target.with_name('full_sequence_caption_fit.tmp.mp4')
        color='0x45d887' if source['full_sequence_passed'] else '0xff9484'
        filter_text=f'drawbox=x=0:y=26:w=640:h=23:color=0x111822:t=fill,drawtext=fontfile={fontfile}:text={label}:fontcolor={color}:fontsize=16:x=10:y=27'
        subprocess.run(['ffmpeg','-nostdin','-v','error','-y','-threads','1','-i',str(raw),'-vf',filter_text,'-an','-r','10','-fps_mode','cfr','-frames:v',str(video['frames']),'-c:v','libx264','-preset','fast','-crf','20','-pix_fmt','yuv420p','-threads','2','-movflags','+faststart',str(temp)],check=True)
        info=probe(temp,video['frames'])
        temp.replace(target)
        video.update({'path':str(target),'sha256':sha(target),'probe':info,'full_decode_passed':True,'caption_processor':str(Path(__file__).resolve()),'caption_processor_sha256':sha(__file__),'original_caption_video':str(raw),'original_caption_video_sha256':sha(raw)})
        source['caption_fit']={'display_label':label,'full_variant_id':source['variant'],'processor_sha256':sha(__file__),'modified_region_pixels':[0,26,640,49],'original_video':str(raw),'original_video_sha256':sha(raw),'physical_states_and_timestamps_changed':False}
        source['processor_chain']=[{'path':str(Path(__file__).resolve()),'sha256':sha(__file__),'purpose':'Header caption fit/profile label only','input_video':{'path':str(raw),'sha256':sha(raw)},'output_video':{'path':str(target),'sha256':sha(target)}}]
        for preview in source['previews']:
            image=Image.open(preview['path']).convert('RGB')
            draw=ImageDraw.Draw(image)
            draw.rectangle((0,26,640,49),fill=(17,24,34))
            draw.text((10,27),label,font=font,fill=(69,216,135) if source['full_sequence_passed'] else (255,148,132))
            image.save(preview['path'])
            preview['sha256']=sha(preview['path'])
        write_json(target.parent/'render-index.json',source)
        updated[str(raw)]=video
    index['videos']=[updated.get(row['path'],row) for row in index['videos']]
    index['previews']=[preview for source in index['sources'] for preview in source['previews']]
    return bool(updated)


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--selection-map',type=Path,help='Explicit same-policy8condition map for the primary comparison')
    args=parser.parse_args()
    explicit=json.loads(args.selection_map.read_text()) if args.selection_map else None
    index_path=OUT/'index.json'
    index=json.loads(index_path.read_text())
    assert sha(index['renderer'])==index['renderer_sha256']
    if explicit:
        assert len(index['sources'])==32,'Finalize only after all32formal trials are rendered'
    original_clips=[{'path':row['video']['path'],'sha256':row['video']['sha256']} for row in index['sources']]
    for row in index['sources']:
        assert sha(row['metrics'])==row['source_sha256']['metrics']
        record=json.loads(Path(row['metrics']).read_text())
        row['candidate_proposal']=record.get('candidate_proposal')
        row['comparison_profile']=record.get('comparison_profile','baseline')
        row['is_sensitivity_trial']=row['comparison_profile']!='baseline'
        row['micro_contact_intervention']=record.get('micro_contact_intervention')
        row['force_clamp_intervention']=record.get('force_clamp_intervention')
        row['root_pose_feedback_intervention']=record.get('root_pose_feedback_intervention')
        if row['micro_contact_intervention']:
            adapter=OUT.parent/'micro_contact_profile.py'
            assert sha(adapter)==row['micro_contact_intervention']['adapter_sha256']
            index['dependencies'][str(adapter)]=sha(adapter)
        if row['force_clamp_intervention']:
            intervention=row['force_clamp_intervention']
            adapter=intervention['adapter_source']
            assert sha(adapter)==intervention['adapter_sha256']
            index['dependencies'][adapter]=sha(adapter)
            row['force_feedback']=intervention['force_feedback_trace']
            assert sha(row['force_feedback'])==intervention['force_feedback_sha256']
            row['source_sha256']['force_feedback']=intervention['force_feedback_sha256']
        if row['root_pose_feedback_intervention']:
            intervention=row['root_pose_feedback_intervention']
            adapter=Path(intervention.get('adapter_source',OUT.parent/'force_clamp_root_profile.py'))
            assert sha(adapter)==intervention['adapter_sha256']
            index['dependencies'][str(adapter)]=sha(adapter)
            row['root_pose_feedback']=intervention['root_pose_feedback_trace']
            assert sha(row['root_pose_feedback'])==intervention['root_pose_feedback_sha256']
            row['source_sha256']['root_pose_feedback']=intervention['root_pose_feedback_sha256']
        row['experiment_role']='final_policy' if explicit and row['comparison_profile']==explicit['comparison_profile'] else 'contact_or_control_sensitivity' if row['is_sensitivity_trial'] else 'original_profile'
    # Keep the geometry comparison on its original physical material/control
    # protocol. Separately labelled sensitivity clips are all still delivered.
    selected=[]
    for height in (4,6,8,10):
        for condition in ('plain','shallow'):
            all_rows=[row for row in index['sources'] if row['height_mm']==height and row['fixture']==condition]
            if explicit:
                requested=next(row for row in explicit['selected_conditions'] if row['height_mm']==height and row['fixture']==condition)
                pool=[row for row in all_rows if row['comparison_profile']==explicit['comparison_profile']]
                row=next(row for row in pool if Path(row['metrics']).resolve()==Path(requested['metrics']).resolve())
            else:
                pool=[row for row in all_rows if not row['is_sensitivity_trial']]
                assert pool,(height,condition)
                row=min(pool,key=selection_key)
            selected.append({'height_mm':height,'fixture':condition,'trial_id':row['trial_id'],'tested_candidates':len(pool),'other_strategy_candidates_excluded':len(all_rows)-len(pool),'full_sequence_passed_candidates':sum(bool(item['full_sequence_passed']) for item in pool),'selection_key':list(selection_key(row)),'selection_reason':'Explicit same final control/contact strategy across8conditions' if explicit else 'Original-profile numerical ordering'})
    index['selected_conditions']=selected
    index['selection_policy']='Primary8conditions come from the explicit single final-strategy selection map; original-profile and other sensitivity trials remain separately delivered individual clips.' if explicit else index['selection_policy']+' Only original comparison_profile=baseline/default candidates enter geometry-comparison selection; all separately labelled sensitivity trials remain individual delivered videos.'
    if explicit:
        index['primary_comparison_strategy']={'label':explicit['strategy_label'],'comparison_profile':explicit['comparison_profile'],'selection_map':str(args.selection_map.resolve()),'selection_map_sha256':sha(args.selection_map),'interpretation':'Height/support comparison under one fixed final contact/control strategy. Original contact/control experiments are separate data, not pooled as a causal height-only effect.'}
        index['dependencies'][str(args.selection_map.resolve())]=sha(args.selection_map)
    captions_changed=fit_trial_captions(index)
    assert len(index['selected_conditions'])==8
    lookup={row['trial_id']:row for row in index['sources']}
    sources=[lookup[next(row['trial_id'] for row in index['selected_conditions'] if row['height_mm']==height and row['fixture']==condition)] for condition in ('plain','shallow') for height in (4,6,8,10)]
    if explicit:
        for intervention in ('force_clamp_intervention','root_pose_feedback_intervention'):
            settings={json.dumps(row[intervention]['settings'],sort_keys=True) for row in sources}
            assert len(settings)==1,f'Final strategy settings differ: {intervention}'
        index['primary_comparison_strategy']['fixed_force_and_root_feedback_settings_verified']=True
        micro_keys=('condim','solref','solimp','friction','margin','gap')
        material_settings={json.dumps({key:row['micro_contact_intervention'][key] for key in micro_keys},sort_keys=True) for row in sources}
        assert len(material_settings)==1,'Final micro-contact material settings differ acrossconditions'
        index['primary_comparison_strategy']['fixed_micro_contact_material_settings_verified']=True
    # Only final32individuals+these5new explicitly selected composites enter
    # delivery. Earlier best-selection composites remain auxiliary local files.
    index['videos']=[row['video'] for row in index['sources']]
    for height in (4,6,8,10):
        pair=[row for row in sources if row['height_mm']==height]
        pair_metadata=make_overview(pair,f'h{height:02d}_plain_vs_shallow_final.mp4')
        pair_metadata['selection']='Explicit same final policy perheight; plain then shallow'
        index['videos'].append(pair_metadata)
    target=OUT/'all_8_conditions_final_policy.mp4'
    auxiliary=OUT/'all_8_conditions_best.mp4'
    previous_hash=sha(auxiliary) if auxiliary.exists() else None
    frames=max(row['video']['frames'] for row in sources)
    args=['ffmpeg','-hide_banner','-loglevel','error','-y','-filter_complex_threads','1']
    for row in sources:
        assert sha(row['video']['path'])==row['video']['sha256']
        args.extend(['-threads','1','-i',row['video']['path']])
    filters=[]
    fontfile='/usr/share/fonts/opentype/noto/NotoSansCJK-Regular.ttc'
    for i,row in enumerate(sources):
        fixture='普通桌面' if row['fixture']=='plain' else '浅托座'
        status='全流程通过' if row['full_sequence_passed'] else '未通过'
        rise=row.get('measured_object_lift_mm')
        rise_text='未记录' if rise is None else f'{rise:.3f} mm'
        title=f'H{row["height_mm"]} mm · {fixture}'
        note=f'持握末升高 {rise_text} · {status}'
        note_color='0x45d887' if row['full_sequence_passed'] else '0xffb0a2'
        filters.append(f'[{i}:v]fps=10,scale=480:360,pad=480:480:0:0:color=0x111822,drawtext=fontfile={fontfile}:text={title}:fontcolor=white:fontsize=25:x=12:y=374,drawtext=fontfile={fontfile}:text={note}:fontcolor={note_color}:fontsize=23:x=12:y=416,tpad=stop_mode=clone:stop={frames+2},trim=end_frame={frames+2},settb=AVTB,setpts=N/(10*TB)[v{i}]')
    layout='|'.join(f'{i%4*480}_{i//4*480}' for i in range(8))
    inputs=''.join(f'[v{i}]' for i in range(8))
    header=f"直径1mm · 质量200g · {explicit['strategy_label']} · 四高度×双支撑" if explicit else '直径1mm · 质量200g · 四种高度及两种支撑 · 原接触方案精选轨迹'
    filters.append(f'{inputs}xstack=inputs=8:layout={layout}:fill=0x111822,pad=1920:1080:0:60:color=0x111822,drawtext=fontfile={fontfile}:text={header}:fontcolor=white:fontsize=30:x=20:y=10,trim=end_frame={frames},settb=AVTB,setpts=N/(10*TB)[out]')
    temp=target.with_name('all_8_conditions_best.finalizing.mp4')
    args.extend(['-filter_complex',';'.join(filters),'-map','[out]','-an','-r','10','-fps_mode','cfr','-frames:v',str(frames),'-c:v','libx264','-preset','fast','-crf','20','-pix_fmt','yuv420p','-threads','2','-movflags','+faststart',str(temp)])
    subprocess.run(args,check=True)
    info=probe(temp,frames)
    temp.replace(target)
    metadata={'path':str(target),'width':1920,'height':1080,'frames':frames,'fps':FPS,'duration_s':frames/FPS,'sha256':sha(target),'source_trial_ids':[row['trial_id'] for row in sources],'source_video_sha256':[row['video']['sha256'] for row in sources],'layout':'Four columns H4/H6/H8/H10; row1plain,row2shallow. Each original4:3 trial retained. Large per-cell numbers explicitly label final post-lift hold rise; dynamic footer retains the displayed frame reading. Shorter sequences hold their real final recorded state.','probe':info,'full_decode_passed':True,'finalizer':str(Path(__file__).resolve()),'finalizer_sha256':sha(__file__),'previous_overview_sha256':previous_hash,'individual_videos_unchanged':True}
    index['videos'].append(metadata)
    if explicit:
        assert len(index['videos'])==37
    index['overview_finalizer']={'path':str(Path(__file__).resolve()),'sha256':sha(__file__),'purpose':'Clarify static hold-end values; fit long IDs and explicitly label sensitivity clips; original-profile geometry comparison selection. Original renderer and physical states remain unchanged.'}
    for clip in original_clips:
        assert sha(clip['path'])==clip['sha256'],'An original rendered clip was overwritten'
    index['original_rendered_clips']=original_clips
    index['all_original_rendered_clips_unchanged']=True
    write_json(index_path,index)
    write_json(OUT/'overview-finalization.json',metadata)
    print(json.dumps(metadata,ensure_ascii=False,indent=2))


if __name__=='__main__':
    main()
