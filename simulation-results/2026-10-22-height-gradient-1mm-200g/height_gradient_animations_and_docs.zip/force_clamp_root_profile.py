#!/usr/bin/env python3
"""Fixed micro-contact + existing-actuator force feedback + anchored root PI.

The root correction changes only ordinary mocap target commands. Original weld,
actuators, mass, inertia, support, gravity and object freedom are preserved.
"""
from __future__ import annotations
import argparse
from concurrent.futures import ThreadPoolExecutor
import json
from pathlib import Path
import subprocess
import sys
from types import MethodType

import numpy as np
from scipy.spatial.transform import Rotation

ROOT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT))
import run_height_trials as runner
from force_clamp_profile import ForceClamp,SETTINGS as FORCE_SETTINGS
from micro_contact_profile import make_env_micro

ROOT_SETTINGS=dict(proportional_gain=.5,integral_gain_per_s=20.,
 maximum_position_correction_m=.001,maximum_rotation_correction_deg=2.,
 maximum_position_correction_rate_m_s=.01,maximum_rotation_correction_rate_rad_s=.2,
 active_phases=['loaded_hold','lift','postlift_hold'],
 reference_policy='At first loaded step, capture actual root pose relative to nominal root target; transport that relative transform by subsequent nominal target. PI corrects deviations from this anchored actual reference, retaining initial gravity/tracking bias.')

def rotation(q):return Rotation.from_quat(np.r_[q[1:],q[0]])
def quat(r):
 q=r.as_quat();return np.r_[q[3],q[:3]]
def bounded(v,limit):
 norm=np.linalg.norm(v)
 return v if norm<=limit else v*(limit/norm)

class AnchoredRootFeedback:
 def __init__(self,env):
  self.env=env;self.original_set=env.set_ctrl;self.original_step=env.step_sim
  self.nominal=np.r_[env._data.mocap_pos[0],env._data.mocap_quat[0]].copy()
  self.relative_position=None;self.relative_rotation=None
  self.position_integral=np.zeros(3);self.rotation_integral=np.zeros(3)
  self.position_correction=np.zeros(3);self.rotation_correction=np.zeros(3)
  self.logs=[];self.anchor_record=None
  self.root_qpos_address=runner.root_joint(env)['qpos_address']
 def pose(self):
  a=self.root_qpos_address;return self.env._data.qpos[a:a+7].copy()
 def install(self):
  control=self
  def set_control(env,qpos,ctrl_type='ee_pose',*args,**kwargs):
   result=control.original_set(qpos,ctrl_type,*args,**kwargs)
   if ctrl_type!='ee_pose':raise RuntimeError('Root feedback requires explicit ee_pose root command')
   control.nominal=np.asarray(qpos[:7],float).copy()
   return result
  def step(env,substep):
   dt=float(env._model.opt.timestep)
   for _ in range(substep):
    phase=getattr(env.observer,'phase','inactive');active=phase in ROOT_SETTINGS['active_phases']
    actual=control.pose();rnom=rotation(control.nominal[3:7]);ractual=rotation(actual[3:7])
    if active:
     if control.relative_position is None:
      control.relative_position=rnom.inv().apply(actual[:3]-control.nominal[:3])
      control.relative_rotation=rnom.inv()*ractual
      control.anchor_record={'time_s':float(env._data.time),'actual_root_pose':actual.copy(),'nominal_root_pose':control.nominal.copy(),'captured_relative_position_m':control.relative_position.copy(),'captured_relative_quaternion_wxyz':quat(control.relative_rotation)}
     reference_position=control.nominal[:3]+rnom.apply(control.relative_position)
     reference_rotation=rnom*control.relative_rotation
     error_position=reference_position-actual[:3]
     error_rotation=(reference_rotation*ractual.inv()).as_rotvec()
     control.position_integral=bounded(control.position_integral+ROOT_SETTINGS['integral_gain_per_s']*error_position*dt,ROOT_SETTINGS['maximum_position_correction_m'])
     rotlim=np.radians(ROOT_SETTINGS['maximum_rotation_correction_deg'])
     control.rotation_integral=bounded(control.rotation_integral+ROOT_SETTINGS['integral_gain_per_s']*error_rotation*dt,rotlim)
     goal_position=bounded(ROOT_SETTINGS['proportional_gain']*error_position+control.position_integral,ROOT_SETTINGS['maximum_position_correction_m'])
     goal_rotation=bounded(ROOT_SETTINGS['proportional_gain']*error_rotation+control.rotation_integral,rotlim)
     control.position_correction+=bounded(goal_position-control.position_correction,ROOT_SETTINGS['maximum_position_correction_rate_m_s']*dt)
     control.rotation_correction+=bounded(goal_rotation-control.rotation_correction,ROOT_SETTINGS['maximum_rotation_correction_rate_rad_s']*dt)
    else:
     control.relative_position=None;control.relative_rotation=None
     control.position_integral[:]=0;control.rotation_integral[:]=0
     control.position_correction[:]=0;control.rotation_correction[:]=0
     reference_position=control.nominal[:3].copy();reference_rotation=rnom
    mocap_command=np.r_[control.nominal[:3]+control.position_correction,quat(Rotation.from_rotvec(control.rotation_correction)*rnom)]
    env._data.mocap_pos[0]=mocap_command[:3];env._data.mocap_quat[0]=mocap_command[3:7]
    control.original_step(1)
    actual_after=control.pose()
    ref=np.r_[reference_position,quat(reference_rotation)]
    poserr=reference_position-actual_after[:3]
    roterr=(reference_rotation*rotation(actual_after[3:7]).inv()).as_rotvec()
    control.logs.append((float(env._data.time),phase,active,control.nominal.copy(),mocap_command.copy(),ref,actual_after,control.position_correction.copy(),control.rotation_correction.copy(),poserr,roterr))
  self.env.set_ctrl=MethodType(set_control,self.env);self.env.step_sim=MethodType(step,self.env)
 def finish(self,folder):
  names=['time_s','phase','feedback_active','nominal_root_pose','actual_mocap_command','anchored_actual_reference_pose','actual_root_pose','position_correction_m','rotation_correction_rotvec_rad','anchored_position_error_m','anchored_rotation_error_rotvec_rad']
  arrays={n:np.asarray([r[i] for r in self.logs]) for i,n in enumerate(names)}
  np.savez_compressed(folder/'root_pose_feedback.npz',**arrays)
  stats={}
  for phase in ROOT_SETTINGS['active_phases']:
   mask=arrays['phase']==phase
   if np.any(mask):
    pe=np.linalg.norm(arrays['anchored_position_error_m'][mask],axis=1)
    re=np.degrees(np.linalg.norm(arrays['anchored_rotation_error_rotvec_rad'][mask],axis=1))
    stats[phase]={'samples':int(np.sum(mask)),'anchored_actual_reference_position_error_max_mm':float(np.max(pe)*1000),'anchored_actual_reference_position_error_mean_mm':float(np.mean(pe)*1000),'anchored_actual_reference_rotation_error_max_deg':float(np.max(re)),'anchored_actual_reference_rotation_error_mean_deg':float(np.mean(re)),'maximum_position_correction_mm':float(np.max(np.linalg.norm(arrays['position_correction_m'][mask],axis=1))*1000),'maximum_rotation_correction_deg':float(np.max(np.degrees(np.linalg.norm(arrays['rotation_correction_rotvec_rad'][mask],axis=1))))}
  return {'adapter_source':str(Path(__file__).resolve()),'adapter_sha256':runner.sha(__file__),'settings':ROOT_SETTINGS,'initial_anchor':self.anchor_record,'model_weld_actuator_and_object_parameters_changed':False,'object_force_or_pose_control_added':False,'root_pose_feedback_trace':str((folder/'root_pose_feedback.npz').resolve()),'root_pose_feedback_sha256':runner.sha(folder/'root_pose_feedback.npz'),'phase_root_tracking_statistics':stats,'interpretation':'Anchor-tracking error measures force-induced change from the captured actual pose. Original nominal-root error need not become zero because initial gravity bias is intentionally preserved.'}

def run_trial(job):
 factory=runner.load_fixture();original=factory.make_env;controllers=[]
 def adapted(*args,**kwargs):
  factory.make_env=original
  try:env=make_env_micro(factory,*args,**kwargs)
  finally:factory.make_env=adapted
  force=ForceClamp(env);force.install()
  root=AnchoredRootFeedback(env);root.install();controllers.append((force,root))
  return env
 factory.make_env=adapted
 try:result=runner.run_trial(job)
 finally:factory.make_env=original
 folder=Path(job['output']);force,root=controllers[0]
 f_record=force.finish(folder);r_record=root.finish(folder)
 metrics=json.loads((folder/'metrics.json').read_text())
 metrics.update(force_clamp_intervention=f_record,root_pose_feedback_intervention=r_record,micro_contact_intervention=force.env.micro_contact_definition,comparison_profile='force_clamp_root_micro')
 runner.write_json(folder/'metrics.json',metrics)
 runner.write_json(folder/'force_clamp_intervention.json',f_record)
 runner.write_json(folder/'root_pose_feedback_intervention.json',r_record)
 result.update(comparison_profile='force_clamp_root_micro',force_feedback_summary=f_record['phase_force_statistics'],root_feedback_summary=r_record['phase_root_tracking_statistics'])
 runner.write_json(folder/'result.json',result);print(json.dumps(result,ensure_ascii=False),flush=True)
 return result

def main():
 parser=argparse.ArgumentParser(description=__doc__)
 parser.add_argument('--manifest',type=Path,default=ROOT/'grasp_search/first-candidates.json')
 parser.add_argument('--candidates',nargs='+')
 parser.add_argument('--conditions',nargs='+',choices=['plain','shallow'],default=['plain','shallow'])
 parser.add_argument('--workers',type=int,default=2)
 parser.add_argument('--summary-name',default='h010')
 parser.add_argument('--worker-job',type=Path)
 args=parser.parse_args()
 if args.worker_job:run_trial(json.loads(args.worker_job.read_text()));return
 variants=json.loads(args.manifest.read_text())['variants']
 if args.candidates:variants=[v for v in variants if v['id'] in args.candidates]
 paths=[]
 for variant in variants:
  for fixture in args.conditions:
   v=dict(variant);v['id']+='_force_clamp_root_micro'
   job={'variant':v,'fixture':fixture,'resume':False,'output':str((ROOT/'trials'/f"h{int(v['height_mm']):03d}"/fixture/v['id']).resolve())}
   path=ROOT/'trials/root-feedback-jobs'/f'{fixture}__{v["id"]}.json';path.parent.mkdir(exist_ok=True)
   runner.write_json(path,job);paths.append(path)
 def execute(path):
  proc=subprocess.run([sys.executable,str(Path(__file__).resolve()),'--worker-job',str(path)],capture_output=True,text=True)
  if proc.stdout:print(proc.stdout,end='',flush=True)
  if proc.stderr:print(proc.stderr,end='',file=sys.stderr,flush=True)
  job=json.loads(path.read_text());return {'job':str(path),'output':job['output'],'exit_code':proc.returncode}
 with ThreadPoolExecutor(max_workers=args.workers) as pool:results=list(pool.map(execute,paths))
 runner.write_json(ROOT/'trials'/f'force-clamp-root-summary-{args.summary_name}.json',{'adapter_sha256':runner.sha(__file__),'force_settings':FORCE_SETTINGS,'root_settings':ROOT_SETTINGS,'results':results})
 if any(r['exit_code'] for r in results):raise SystemExit(1)
if __name__=='__main__':main()
