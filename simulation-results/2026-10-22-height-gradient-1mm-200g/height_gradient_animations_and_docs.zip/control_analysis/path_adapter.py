"""Pure control-data adaptation; no model, dynamics or object-state mutation.

The default is supported only by isolated-hand tracking diagnostics. A fresh,
continuous, free-object trial is required for every claimed grasp result.
"""
from __future__ import annotations
import copy
import numpy as np


def adapt_candidate(grasp, preshape_alpha=0.0, squeeze_gain=0.1):
    """Reduce opening travel and squeezing while retaining every root pose.

    alpha=0 initializes the distant, object-free hand in the target grasp-like
    finger shape. It is a pre-shape, not object contact or a completed grasp.
    The hand still starts >100 mm away in the formal runner and approaches
    continuously. A small squeeze occurs only during the closure stage.
    """
    alpha, gain = float(preshape_alpha), float(squeeze_gain)
    if not (0 <= alpha <= 1 and 0 <= gain <= 1):
        raise ValueError("Convex control adaptation requires factors in [0,1]")
    out = copy.deepcopy(grasp)
    goal = np.asarray(out['grasp_qpos'], dtype=float)[-1]
    pre = np.asarray(out['pregrasp_qpos'], dtype=float).copy()
    sq = np.asarray(out['squeeze_qpos'], dtype=float).copy()
    pre[:, 7:] = goal[7:] + alpha * (pre[:, 7:] - goal[7:])
    sq[:, 7:] = goal[7:] + gain * (sq[:, 7:] - goal[7:])
    out['pregrasp_qpos'] = pre
    out['squeeze_qpos'] = sq
    out['control_path_adaptation'] = {
        'preshape_alpha': alpha, 'squeeze_gain': gain,
        'all_root_pose_targets_preserved': True,
        'all_model_and_object_parameters_preserved': True,
        'meaning': 'Unverified control proposal; isolated hand shape tracking is not a physical grasp certificate'
    }
    return out
