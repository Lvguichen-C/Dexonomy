#!/usr/bin/env python3
"""Isolated-hand path-dependence probe; never an object grasp experiment.

Object stays free and far below. Hand initializes once per independent probe at
pre-shape+300mm+100mm worldZ, remains far away, and follows the real .5s pause,
2s approach, native .7s closure and 1s settle. No hand/model parameter edits.
"""
import copy,hashlib,importlib.util,json,sys,time
from pathlib import Path
import mujoco
import numpy as np
ROOT=Path(__file__).resolve().parent
OLD=Path('/workspace/shadow-lift-sweep-200g/upright-1mm-20261022')
sys.path.insert(0,str(OLD/'fixtures'))
sys.path.insert(0,'/workspace/Dexonomy')
from fixture_scene import make_env,frozen_module
from dexonomy.util.np_util import np_interp_qpos,np_interp_slide
SOURCE=OLD/'grasp_search/source_grasp.npy'
HAND=Path('/workspace/Dexonomy/assets/hand/shadow/right.xml')
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
def js(p,v):Path(p).write_text(json.dumps(v,indent=2,default=lambda x:x.tolist() if isinstance(x,np.ndarray) else x.item() if isinstance(x,np.generic) else str(x))+'\n')

def apply_preshape(grasp,alpha):
    out=copy.deepcopy(grasp)
    goal=np.asarray(out['grasp_qpos'])[0]
    out['pregrasp_qpos']=np.asarray(out['pregrasp_qpos'],dtype=float).copy()
    out['pregrasp_qpos'][:,7:]=goal[7:]+float(alpha)*(out['pregrasp_qpos'][:,7:]-goal[7:])
    return out

def main():
    original=np.load(SOURCE,allow_pickle=True).item()
    frozen=frozen_module()
    _,scene=frozen.prepare_scene(SOURCE,.2)
    env=make_env(scene,HAND,'plain',.2,.001)
    model=env._model
    joint_names=['rh_FFJ4','rh_FFJ3','rh_FFJ2','rh_FFJ1']
    adr={n:int(model.jnt_qposadr[model.joint('hand-'+n).id]) for n in joint_names}
    tip_ids=[next(i for i in range(model.ngeom) if model.body(int(model.geom_bodyid[i])).name=='hand-'+name and model.geom_contype[i]) for name in ['rh_ffdistal','rh_thdistal']]
    rows=[]
    for alpha in [1.,.75,.5,.25,.1,0.]:
        proposal=apply_preshape(original,alpha)
        target_path=ROOT/'candidates'/f'preshape_a{round(alpha*100):03d}.npy'
        target_path.parent.mkdir(exist_ok=True)
        np.save(target_path,proposal)
        shifted=copy.deepcopy(proposal)
        for key in ['pregrasp_qpos','grasp_qpos','squeeze_qpos']:
            shifted[key]=np.asarray(shifted[key],float).copy();shifted[key][:,2]+=.3
        controls,types,forces,_=frozen.get_planner(scene['task'].copy()).plan_trajectory(env._obj_init_qpos[-7:].copy(),shifted['pregrasp_qpos'],shifted['grasp_qpos'],shifted['squeeze_qpos'],shifted.get('robot_pose'))
        start=np.asarray(controls[0]).copy();start[2]+=.1
        env.observer=None;env.reset_qpos(start)
        env._data.qfrc_applied[:]=0;env._data.xfrc_applied[:]=0
        for w in env._data.warning:w.number=0
        trace=[];max_ho=0;max_hh=0;min_gap=1.
        def measure(phase):
            nonlocal max_ho,max_hh,min_gap
            hp,tp,bodies,penetration=frozen.contact_stats(env);max_ho=max(max_ho,hp)
            hh=sum(model.body(int(model.geom_bodyid[c.geom1])).name.startswith('hand-') and model.body(int(model.geom_bodyid[c.geom2])).name.startswith('hand-') for c in env._data.contact);max_hh=max(max_hh,hh)
            trace.append(dict(time_s=float(env._data.time),phase=phase,qpos=env._data.qpos.copy(),ctrl=env._data.ctrl.copy(),joints={n:float(env._data.qpos[a]) for n,a in adr.items()},tip_positions_m=env._data.geom_xpos[tip_ids].copy(),hand_object_contacts=hp,hand_hand_contacts=hh))
        measure('initial_far')
        env.set_ctrl(start,'ee_pose');env.step_sim(500);measure('far_pause_end')
        frozen.move_control(env,start,np.asarray(controls[0]),2.);measure('approach_end')
        env.run_trajectory(controls,types,forces,step=5,substep=20);measure('closure_end')
        env.step_sim(1000);measure('loaded_end')
        goal=np.asarray(shifted['squeeze_qpos'])[-1]
        # Geometry counterfactual only: compare settled actual configuration with
        # requested target at same world hand pose, without stepping or contacts.
        actual=env._data.qpos.copy();actual_tips=env._data.geom_xpos[tip_ids].copy()
        actualj={n:float(actual[a]) for n,a in adr.items()}
        targetj={n:float(goal[a]) for n,a in adr.items()}
        # root-normalized shape difference isolates joint distribution from weld.
        env._data.qpos[:29]=goal;env._data.qpos[:7]=actual[:7];mujoco.mj_forward(model,env._data)
        target_tips=env._data.geom_xpos[tip_ids].copy()
        shape_error_mm=np.linalg.norm(actual_tips-target_tips,axis=1)*1000
        # Target qpos write is diagnostic FK after the completed isolated probe;
        # no physics follows and no physical-grasp claim is made.
        row=dict(alpha=alpha,input=str(target_path),input_sha256=sha(target_path),diagnostic_only=True,
            actual_joint_angles_rad=actualj,squeeze_target_joint_angles_rad=targetj,
            actual_index_sum_rad=actualj['rh_FFJ2']+actualj['rh_FFJ1'],target_index_sum_rad=targetj['rh_FFJ2']+targetj['rh_FFJ1'],
            index_shape_error_mm=float(shape_error_mm[0]),thumb_shape_error_mm=float(shape_error_mm[1]),
            sampled_hand_object_contacts_max=max_ho,sampled_hand_hand_contacts_max=max_hh,
            warning_counts=[int(w.number) for w in env._data.warning],duration_s=float(trace[-1]['time_s']),
            trace=trace)
        rows.append(row);js(ROOT/'preshape-results.json',dict(source_sha256=sha(SOURCE),physics_scope='Isolated hand 300mm above original object; not formal grasp trial',rows=rows))
        print(json.dumps({k:row[k] for k in ['alpha','actual_joint_angles_rad','index_shape_error_mm','thumb_shape_error_mm','sampled_hand_object_contacts_max','sampled_hand_hand_contacts_max','warning_counts']}),flush=True)
    js(ROOT/'preshape-manifest.json',dict(source=str(SOURCE),source_sha256=sha(SOURCE),proposals=[{k:r[k] for k in ['alpha','input','input_sha256','index_shape_error_mm','thumb_shape_error_mm']} for r in rows],diagnostic_scope='Only isolated hand shape tracking; object geometry is original H4. Height trial proposals must change scene_path/root translation explicitly.'))

if __name__=='__main__':main()
