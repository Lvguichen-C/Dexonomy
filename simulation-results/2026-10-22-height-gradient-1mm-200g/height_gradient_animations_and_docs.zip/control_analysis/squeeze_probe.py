#!/usr/bin/env python3
"""Finite isolated-hand squeeze-gain path probe; not a grasp trial."""
import copy,json,sys
from pathlib import Path
import mujoco,numpy as np
from preshape_probe import ROOT,OLD,SOURCE,HAND,make_env,frozen_module,sha,js,apply_preshape

def apply_squeeze_gain(grasp,gain):
    out=copy.deepcopy(grasp)
    goal=np.asarray(out['grasp_qpos'])[-1]
    out['squeeze_qpos']=np.asarray(out['squeeze_qpos'],float).copy()
    out['squeeze_qpos'][:,7:]=goal[7:]+float(gain)*(out['squeeze_qpos'][:,7:]-goal[7:])
    return out

class ProbeObserver:
    def __init__(self,env):self.env=env;self.phase='pause';self.first_hh=None;self.max_hh_pen=0.;self.max_ho=0;self.step_count=0
    def observe(self):
        self.step_count+=1
        m,d=self.env._model,self.env._data
        for c in d.contact:
            bs=[m.body(int(m.geom_bodyid[g])).name for g in (c.geom1,c.geom2)]
            if any(b.startswith('hand-') for b in bs) and any(b.startswith('obj-') for b in bs):self.max_ho=max(self.max_ho,1)
            if set(bs)=={'hand-rh_ffdistal','hand-rh_thdistal'}:
                self.max_hh_pen=max(self.max_hh_pen,-float(c.dist))
                if self.first_hh is None:self.first_hh={'time_s':float(d.time),'phase':self.phase,'distance_m':float(c.dist)}

def main():
    original=np.load(SOURCE,allow_pickle=True).item();frozen=frozen_module();_,scene=frozen.prepare_scene(SOURCE,.2)
    env=make_env(scene,HAND,'plain',.2,.001);m=env._model
    names=['rh_FFJ4','rh_FFJ3','rh_FFJ2','rh_FFJ1'];adr={n:int(m.jnt_qposadr[m.joint('hand-'+n).id]) for n in names}
    tips=[next(i for i in range(m.ngeom) if m.body(int(m.geom_bodyid[i])).name=='hand-'+name and m.geom_contype[i]) for name in ['rh_ffdistal','rh_thdistal']]
    rows=[]
    for alpha in [1.,0.]:
      for gain in [0.,.1,.25,.5,1.]:
        proposal=apply_squeeze_gain(apply_preshape(original,alpha),gain)
        path=ROOT/'candidates'/f'pres{round(alpha*100):03d}_sq{round(gain*100):03d}.npy';np.save(path,proposal)
        shifted=copy.deepcopy(proposal)
        for key in ['pregrasp_qpos','grasp_qpos','squeeze_qpos']:
            shifted[key]=np.asarray(shifted[key],float).copy();shifted[key][:,2]+=.3
        controls,types,forces,_=frozen.get_planner(scene['task'].copy()).plan_trajectory(env._obj_init_qpos[-7:].copy(),shifted['pregrasp_qpos'],shifted['grasp_qpos'],shifted['squeeze_qpos'],shifted.get('robot_pose'))
        start=np.asarray(controls[0]).copy();start[2]+=.1
        env.observer=None;env.reset_qpos(start);env._data.qfrc_applied[:]=0;env._data.xfrc_applied[:]=0
        for w in env._data.warning:w.number=0
        observer=ProbeObserver(env);env.observer=observer
        env.set_ctrl(start,'ee_pose');env.step_sim(500)
        observer.phase='approach';frozen.move_control(env,start,np.asarray(controls[0]),2.)
        observer.phase='close';env.run_trajectory(controls,types,forces,step=5,substep=20)
        closurej={n:float(env._data.qpos[a]) for n,a in adr.items()}
        observer.phase='loaded';env.step_sim(1000)
        actual=env._data.qpos.copy();actual_tips=env._data.geom_xpos[tips].copy();actualj={n:float(actual[a]) for n,a in adr.items()}
        goal=np.asarray(shifted['squeeze_qpos'])[-1];targetj={n:float(goal[a]) for n,a in adr.items()}
        env.observer=None;env._data.qpos[:29]=goal;env._data.qpos[:7]=actual[:7];mujoco.mj_forward(m,env._data)
        errors=np.linalg.norm(actual_tips-env._data.geom_xpos[tips],axis=1)*1000
        row=dict(alpha=alpha,squeeze_gain=gain,input=str(path),input_sha256=sha(path),isolated_diagnostic_only=True,
            closure_actual_joints_rad=closurej,loaded_actual_joints_rad=actualj,squeeze_target_joint_angles_rad=targetj,
            shape_errors_mm=errors,first_thumb_index_hand_hand_contact=observer.first_hh,
            maximum_thumb_index_hh_penetration_m=observer.max_hh_pen,hand_object_contact_any_step=bool(observer.max_ho),
            physics_steps=observer.step_count,warning_counts=[int(w.number) for w in env._data.warning])
        rows.append(row);js(ROOT/'squeeze-results.json',dict(scope='High air hand closure + loaded settle, no HO; not a physical grasp',source_sha256=sha(SOURCE),rows=rows))
        print(json.dumps(row,default=lambda x:x.tolist() if isinstance(x,np.ndarray) else str(x)),flush=True)
    js(ROOT/'squeeze-manifest.json',dict(source_sha256=sha(SOURCE),variants=[{k:r[k] for k in ['alpha','squeeze_gain','input','input_sha256']} for r in rows]))
if __name__=='__main__':main()
