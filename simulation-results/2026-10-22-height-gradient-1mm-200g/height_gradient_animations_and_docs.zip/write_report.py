#!/usr/bin/env python3
"""Write the reviewed height comparison from finalized physical measurements."""
from pathlib import Path
import json
import math

ROOT = Path(__file__).resolve().parent


def main():
    s = json.loads((ROOT / "experiment-summary.json").read_text())
    final = sorted(s["selections"]["final_policy"], key=lambda r: (r["height_mm"], r["fixture"]))
    baseline = {(r["height_mm"], r["fixture"]): r for r in s["selections"]["source_baseline"]}
    table = ["| 高度 | 支撑 | 加载阶段双指承载覆盖 | 平均／峰值总法向力 | 5秒阶段最小实际升高 | 严格全流程 |",
             "|---|---|---:|---:|---:|---|"]
    for r in final:
        support = "无托" if r["fixture"] == "plain" else "浅托"
        result = "通过" if r["full_sequence_passed"] else "未通过"
        table.append(f"| {r['height_mm']} mm | {support} | {100*r['loaded_positive_thumb_index_fraction']:.1f}% | {r['loaded_mean_total_normal_force_N']:.3f} / {r['loaded_peak_total_normal_force_N']:.3f} N | {r['hold_minimum_object_rise_mm']:+.3f} mm | {result} |")
    btable = ["| 高度 | 原动作无托 | 原动作浅托 | 最终策略无托 | 最终策略浅托 |",
              "|---|---:|---:|---:|---:|"]
    by_cell = {(r["height_mm"], r["fixture"]): r for r in final}
    for h in (4, 6, 8, 10):
        numbers = [baseline[(h, f)]["final_measured_object_lift_mm"] for f in ("plain", "shallow")]
        numbers += [by_cell[(h, f)]["final_measured_object_lift_mm"] for f in ("plain", "shallow")]
        btable.append(f"| {h} mm | " + " | ".join(f"{v:+.3f} mm" for v in numbers) + " |")
    root_stats = []
    for row in final:
        m = json.loads((ROOT / row["metrics"]).read_text())
        root_stats.append(m["root_pose_feedback_intervention"]["phase_root_tracking_statistics"]["loaded_hold"])
    posmax = max(r["anchored_actual_reference_position_error_max_mm"] for r in root_stats)
    rotmax = max(r["anchored_actual_reference_rotation_error_max_deg"] for r in root_stats)
    rot_upper = math.ceil(rotmax * 10000) / 10000
    h10 = by_cell[(10, "shallow")]
    report = f'''# Φ1 mm、200 g 圆柱：4／6／8／10 mm 高度梯度与无托／浅托抓取对比

**已完成32次正式连续仿真及优化。最终统一控制策略的8个高度／支撑工况，通过{s['final_policy_conditions_passed']}/8；全部正式试验严格通过{s['qualified_full_sequence_passed']}/32。** 本轮尚未实现实际提升100 mm后悬空持握5秒。

- [八工况最终策略总览动画](all_8_conditions_final_policy.mp4)
- [4 mm对比](h04_plain_vs_shallow_final.mp4) · [6 mm对比](h06_plain_vs_shallow_final.mp4) · [8 mm对比](h08_plain_vs_shallow_final.mp4) · [10 mm对比](h10_plain_vs_shallow_final.mp4)
- [全部37段动画、文档与源码主包](height_gradient_animations_and_docs.zip)
- [32次完整结果CSV](experiment-results.csv) · [带源哈希的结果JSON](experiment-summary.json) · [管线说明](PIPELINE.md)

原始模型和1000 Hz诊断按高度／支撑另行分包，准确下载文件名与SHA见交付清单及Release正文。只观看全部动画和阅读报告，下载主包即可。

## 对比条件

直径固定 **1 mm**，高度 **4 / 6 / 8 / 10 mm**，质量全部 **200 g**。圆柱初始竖直、底面z=0；各高度重新计算密度和惯量，实际编译尺寸、质量、自由关节均已核验。没有更换为长杆以外的组合体、加配重或减少质量。

浅托在四个高度中保持同一几何：孔径至少1.2 mm、外径5 mm、壁高0.75 mm、底厚0.2 mm，向上开放、固定于world。所有圆柱均可自由运动，重力持续开启，没有物体weld、弹簧、吸附、位姿回写或额外物体外力。

所有正式试验都从手根上方100 mm的无接触位置开始，实际几何间距至少50 mm，保留可见0.5 s远离静置。然后 **垂直接近2 s → 闭合夹紧0.7 s → 受力保持1 s → 手根目标提升100 mm / 5 s → 到位持握5 s → 松指、退离、观察**。部分候选在接近末段已经触到物体，这是连续接近产生的接触，初始远处仍无接触。

## 最终8工况：同一控制策略下的表现

下表采用同一微接触、夹力反馈、手根位姿反馈参数，各高度使用分别拟合的抓型目标。因此它比较优化策略在各高度的任务表现；抓取输入也变化，不能把差异全部归因于高度。

{chr(10).join(table)}

“加载阶段双指承载覆盖”只统计抬升前1秒中，拇指、食指同时有正法向力的比例，不能替代5秒悬空持握。平均／峰值总法向力来自同一物理步两指实际力之和，不是指令值。负升高来自倒伏或接触下沉；本表不是已抓起后的小幅高度误差。

所有最终8工况的5秒阶段都没有保持有效双指承载，也没有完成持续脱离桌面／托座的目标高度持握。

## 原动作平移与优化后的区别

基线8次保留原关节角和手根朝向，仅按杆顶高度差平移动作；这是本轮对高度变化更直接的固定动作对照。下表比较持握阶段末的实际物体升高，目标为100 mm：

{chr(10).join(btable)}

仅提高物体高度并平移旧动作，8次都未通过。部分优化样本改善了倒伏或过大软接触重叠，但最终H4无托例仍完全抓空。H10在低夹紧量下可实现抬升前持续双指接触；这种接触改善没有转化为可承载且持续的抓取。

## 本轮做了哪些优化

1. **按真实运动后指尖拟合。** 原Shadow执行器控制部分耦合关节的角度和，保存的独立关节姿态不一定被实际执行。新优化使用隔离手部真实重力开合后的几何，压缩远处预整形的张开幅度，并减小原过大夹紧增量。静态／孤立手部提案与正式提升试验分别记录；新候选没有被冒称原生认证成功。
2. **明确微尺度接触。** 最终方案仅覆盖31个真实手物碰撞对：dim3、切向摩擦0.6、solref=4 ms、阻抗过渡宽50 μm、零margin/gap，没有扭转约束。桌面／浅托、手根weld及执行器参数保持原值。原接触方案另列，不能混称只改变了高度。
3. **实际夹力反馈。** 每指目标2.5 N，使用原位置执行器的有界控制偏置；实际夹力、指令夹力分开记录。单侧先接触时限制已触侧的加压力，试图让另一侧跟上。
4. **夹紧扰动下的手根反馈。** 在受力开始时捕获实际手根参考，再通过普通mocap目标补偿新增扰动，原weld参数不改。最终8例加载阶段相对这个锚定参考的最大位置误差≤{posmax:.4f} mm、朝向误差≤{rot_upper:.4f}°，仍未建立持续承载抓取。因此本轮失败不能只归结为根部角度偏转造成的高度测量误差。

## 为什么H10有接触仍没抬起

200 g重力约 **1.962 N**。在理想水平对向接触、切向摩擦0.6的假设下，总法向力的条件下限约 **3.27 N**。实际接触方向和力矩平衡仍需另验，超过这个数值不是抓取成功的充分条件。

H10最终浅托例加载阶段平均总法向力约 **{h10['loaded_mean_total_normal_force_N']:.3f} N**，峰值约 **{h10['loaded_peak_total_normal_force_N']:.3f} N**，双指正载荷覆盖 **{100*h10['loaded_positive_thumb_index_fraction']:.1f}%**。峰值一度超过理想下限，但没有持续到提升和5秒持握；不能用单个峰值证明承载。

另对前一版H10微接触＋夹力试验做了记录状态的几何查询：部分加载快照两指法线偏离理想对向约37–42°，拇指法线还带向下分量。这个只读查询没有重做物理步，也不将重建力当作实测。它说明双指接触位置、方向和持续力矩平衡仍需同时满足；只增大法向力目标并不能保证抓牢。

## 预先冻结的成功判据与限制

- 实际物体升高 **95–105 mm**，到位后连续 **5秒、5000步** 无托／桌支撑。
- 每个持握步都由拇指、食指两个不同刚体提供正法向承载。
- 杆半径0.5 mm：持握手物穿透≤50 μm，加载／提升≤100 μm；释放前任一步手物穿透≥500 μm直接拒绝。
- 通过原位置／朝向／漂移、实际释放和零数值警告、零意外重置判据。原冻结判据与本轮严格判据分开保存。

无手接触的3秒对照中，全部4高度×2支撑都没有倒伏；但原桌面软接触在部分高度的压入深度达到半径的约80%，所以“站住”不能代表真实微尺度接触已校准。本轮保持用户指定的200 g统一质量，不能将这些数值结果直接当作普通材料实物样品或Shadow硬件极限。

最终32次正式试验全部完成、无运行异常。32次包括8个原动作基线、10个运动后几何拟合试验、6个H10接触／夹力敏感性试验和8个最终统一策略工况。辅助拟合与静置探针不计入正式成功率。有限候选未通过不能证明这些物体不可抓；本轮证明的是这些明确记录的候选和控制策略尚未完成目标任务。

## 动画与数据

交付 **32段完整单次动画＋4段高度双列对比＋1段八工况总览，共37段**。每段从远离起点开始，保留接近、受力、提升／持握指令及释放全过程，失败明确标注。全景与物体近景来自同一记录状态，物理几何没有放大；只用相机放大观察。

状态以25 Hz保存、视频10 fps，回放仅mj_forward、无状态插值；受力、支撑和成功判定来自每1 ms诊断。实际MJB、完整轨迹、控制／力／手根反馈、输入候选、源码、独立QA及模型许可证分别在主包和按工况原始数据包中提供。按相对路径解压到同一目录即可合并；跨机器重跑需安装相同依赖并重定位工作区绝对路径。
'''
    (ROOT / "HEIGHT_GRADIENT_REPORT.md").write_text(report)
    print(json.dumps({"report": str(ROOT / "HEIGHT_GRADIENT_REPORT.md"), "conditions": len(final),
                      "final_passed": s["final_policy_conditions_passed"], "formal_trials": s["formal_trials"]}, ensure_ascii=False))


if __name__ == "__main__":
    main()
