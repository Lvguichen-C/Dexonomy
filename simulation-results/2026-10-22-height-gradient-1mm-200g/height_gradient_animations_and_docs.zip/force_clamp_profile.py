#!/usr/bin/env python3
"""Bounded thumb/index normal-force feedback via existing position actuators.

No model parameters, object force, object state or additional actuator is used.
Only position-actuator target offsets are added during loaded/lift/hold phases.
"""
from __future__ import annotations
import argparse
from concurrent.futures import ThreadPoolExecutor
import json
from pathlib import Path
import subprocess
import sys
from types import MethodType

import mujoco
import numpy as np

ROOT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT))
import run_height_trials as runner
from micro_contact_profile import make_env_micro

SETTINGS=dict(target_each_finger_N=2.5,maximum_force_command_N=6.,
    feedback_period_s=.005,ramp_s=.5,proportional_force_gain=.5,integral_force_gain_per_s=8.,
    integral_limit_N=3.,maximum_actuator_offset_rad=.15,
    maximum_offset_change_per_update_rad=.002,
    unilateral_contact_side_force_cap_N=.1,
    active_phases=['loaded_hold','lift','postlift_hold'])

class ForceClamp:
    def __init__(self,env):
        self.env=env;self.m=env._model;self.d=env._data
        self.nominal=self.d.ctrl.copy();self.offset=np.zeros(self.m.nu)
        self.goal_offset=np.zeros(self.m.nu);self.integral=np.zeros(2)
        self.desired=np.zeros(2);self.command=np.zeros(2);self.forces=np.zeros(2)
        self.counts=np.zeros(2,dtype=int);self.directions=np.zeros((2,3))
        self.steps=0;self.active_start=None;self.logs=[]
        self.original_set=env.set_ctrl;self.original_step=env.step_sim
        self.hand_nv=int(env._hand_nv)
        self.B=np.asarray(env._hand_qpos2ctrl_mat[:,6:],float)
        self.actuator_ids=[];self.tip_geoms=[];self.finger_body_ids=[]
        self.obj_geoms=[]
        for finger in ['th','ff']:
            acts=[i for i in range(self.m.nu) if f'_A_{finger.upper()}J' in self.m.actuator(i).name]
            if not acts:raise RuntimeError(f'No existing {finger} actuator')
            self.actuator_ids.append(np.asarray(acts,dtype=int))
            geoms=[i for i in range(self.m.ngeom) if self.m.body(int(self.m.geom_bodyid[i])).name==f'hand-rh_{finger}distal' and (self.m.geom_contype[i] or self.m.geom_conaffinity[i])]
            if not geoms:raise RuntimeError(f'No {finger} distal collision geometry')
            self.tip_geoms.append(geoms)
            self.finger_body_ids.append(int(self.m.geom_bodyid[geoms[0]]))
        self.obj_geoms=[i for i in range(self.m.ngeom) if self.m.body(int(self.m.geom_bodyid[i])).name.startswith('obj-') and (self.m.geom_contype[i] or self.m.geom_conaffinity[i])]
        if not self.obj_geoms:raise RuntimeError('No object collision geometry')
        self.kp=self.m.actuator_gainprm[:,0].copy()
        if np.any(self.kp[np.concatenate(self.actuator_ids)]<=0):raise RuntimeError('Expected positive existing position gains')

    def contact_state(self):
        forces=np.zeros(2);counts=np.zeros(2,dtype=int);points=np.zeros((2,3));weights=np.zeros(2)
        obj=set(self.obj_geoms)
        for ci,c in enumerate(self.d.contact):
            gs=[int(c.geom1),int(c.geom2)]
            if not set(gs)&obj:continue
            for gi in gs:
                name=self.m.body(int(self.m.geom_bodyid[gi])).name
                fi=0 if name.startswith('hand-rh_th') else 1 if name.startswith('hand-rh_ff') else None
                if fi is None:continue
                f=np.zeros(6);mujoco.mj_contactForce(self.m,self.d,ci,f)
                normal=max(0.,float(f[0]));forces[fi]+=normal;counts[fi]+=1
                weight=max(normal,1e-6);points[fi]+=weight*c.pos;weights[fi]+=weight
        for fi in range(2):
            if weights[fi]>0:points[fi]/=weights[fi]
            else:
                best=np.inf;nearest=None
                for hi in self.tip_geoms[fi]:
                    for oi in self.obj_geoms:
                        segment=np.zeros(6)
                        distance=float(mujoco.mj_geomDistance(self.m,self.d,hi,oi,.5,segment))
                        if distance<best:best=distance;nearest=segment[:3].copy()
                points[fi]=nearest if nearest is not None else self.d.geom_xpos[self.tip_geoms[fi][0]]
        return forces,counts,points

    def update(self,phase):
        forces,counts,points=self.contact_state();self.forces,self.counts=forces,counts
        now=float(self.d.time)
        if self.active_start is None:self.active_start=now
        ramp=np.clip((now-self.active_start)/SETTINGS['ramp_s'],0.,1.)
        ramp=ramp*ramp*(3-2*ramp)
        desired=np.full(2,.05+(SETTINGS['target_each_finger_N']-.05)*ramp)
        unilateral=bool(np.count_nonzero(counts>0)==1)
        if unilateral:desired[counts>0]=np.minimum(desired[counts>0],SETTINGS['unilateral_contact_side_force_cap_N'])
        error=desired-forces
        self.integral=np.clip(self.integral+SETTINGS['integral_force_gain_per_s']*error*SETTINGS['feedback_period_s'],-SETTINGS['integral_limit_N'],SETTINGS['integral_limit_N'])
        command=np.clip(desired+SETTINGS['proportional_force_gain']*error+self.integral,0.,SETTINGS['maximum_force_command_N'])
        if unilateral:
            command[counts>0]=np.minimum(command[counts>0],SETTINGS['unilateral_contact_side_force_cap_N'])
            self.integral[counts>0]=np.minimum(self.integral[counts>0],0.)
        obj_center=self.d.xpos[self.env._obj_active_bodyid]
        axis=self.d.xmat[self.env._obj_active_bodyid].reshape(3,3)[:,2]
        target_offset=np.zeros(self.m.nu);directions=np.zeros((2,3))
        for fi in range(2):
            inward=obj_center-points[fi];inward-=axis*np.dot(inward,axis)
            norm=np.linalg.norm(inward)
            if norm<1e-10:
                inward=obj_center-self.d.geom_xpos[self.tip_geoms[fi][0]]
                inward-=axis*np.dot(inward,axis);norm=np.linalg.norm(inward)
            if norm<1e-10:continue
            inward/=norm;directions[fi]=inward
            jp=np.zeros((3,self.m.nv));jr=np.zeros((3,self.m.nv))
            mujoco.mj_jac(self.m,self.d,jp,jr,points[fi],self.finger_body_ids[fi])
            torque=jp[:,6:self.hand_nv].T@(inward*command[fi])
            ids=self.actuator_ids[fi]
            actuator_force=np.linalg.lstsq(self.B[ids].T,torque,rcond=None)[0]
            target_offset[ids]=actuator_force/self.kp[ids]
        target_offset=np.clip(target_offset,-SETTINGS['maximum_actuator_offset_rad'],SETTINGS['maximum_actuator_offset_rad'])
        self.goal_offset=target_offset
        self.offset+=np.clip(target_offset-self.offset,-SETTINGS['maximum_offset_change_per_update_rad'],SETTINGS['maximum_offset_change_per_update_rad'])
        self.desired,self.command,self.directions=desired,command,directions

    def install(self):
        controller=self
        def set_control(env,qpos,ctrl_type='ee_pose',*args,**kwargs):
            result=controller.original_set(qpos,ctrl_type,*args,**kwargs)
            controller.nominal=env._data.ctrl.copy()
            phase=getattr(env.observer,'phase',None)
            if phase in SETTINGS['active_phases']:env._data.ctrl[:]=controller.nominal+controller.offset
            return result
        def step(env,substep):
            for _ in range(substep):
                phase=getattr(env.observer,'phase','inactive')
                active=phase in SETTINGS['active_phases']
                if active:
                    if controller.steps%5==0:controller.update(phase)
                    env._data.ctrl[:]=controller.nominal+controller.offset
                else:
                    controller.offset[:]=0;controller.goal_offset[:]=0;controller.integral[:]=0
                    controller.desired[:]=0;controller.command[:]=0;controller.active_start=None
                    env._data.ctrl[:]=controller.nominal
                controller.original_step(1)
                force,counts,_=controller.contact_state()
                controller.logs.append((float(env._data.time),phase,active,controller.desired.copy(),controller.command.copy(),force,counts,controller.offset.copy(),controller.goal_offset.copy(),controller.nominal.copy(),env._data.ctrl.copy(),controller.directions.copy()))
                controller.steps+=1
        self.env.set_ctrl=MethodType(set_control,self.env)
        self.env.step_sim=MethodType(step,self.env)

    def finish(self,folder):
        names=['time_s','phase','feedback_active','desired_normal_force_N','commanded_inward_force_N','actual_normal_force_N','finger_contact_count','actuator_target_offset_rad','actuator_target_offset_goal_rad','nominal_actuator_ctrl','actual_actuator_ctrl','inward_direction_world']
        arrays={name:np.asarray([row[i] for row in self.logs]) for i,name in enumerate(names)}
        arrays['finger_names']=np.asarray(['thumb','index'])
        arrays['actuator_names']=np.asarray([self.m.actuator(i).name for i in range(self.m.nu)])
        np.savez_compressed(folder/'force_feedback.npz',**arrays)
        summaries={}
        for phase in SETTINGS['active_phases']:
            mask=arrays['phase']==phase
            if np.any(mask):
                summaries[phase]={'samples':int(np.sum(mask)),'actual_force_mean_N':np.mean(arrays['actual_normal_force_N'][mask],axis=0).tolist(),'actual_force_max_N':np.max(arrays['actual_normal_force_N'][mask],axis=0).tolist(),'actual_force_min_N':np.min(arrays['actual_normal_force_N'][mask],axis=0).tolist(),'thumb_index_contact_fraction':float(np.mean(np.all(arrays['finger_contact_count'][mask]>0,axis=1))),'maximum_actuator_offset_rad':float(np.max(np.abs(arrays['actuator_target_offset_rad'][mask])))}
        return {'adapter_source':str(Path(__file__).resolve()),'adapter_sha256':runner.sha(__file__),'settings':SETTINGS,
            'method':'5ms radial virtual-work Jacobian torque feedforward plus bounded normal-force PI; existing position actuator ctrl offsets only',
            'actuator_ids_thumb_index':[a.tolist() for a in self.actuator_ids],
            'model_and_actuator_parameters_changed':False,'object_force_or_pose_control_added':False,
            'force_feedback_trace':str((folder/'force_feedback.npz').resolve()),'force_feedback_sha256':runner.sha(folder/'force_feedback.npz'),
            'phase_force_statistics':summaries,'physics_steps':self.steps,
            'offset_cleared_outside_active_phases':bool(np.max(np.abs(arrays['actuator_target_offset_rad'][~arrays['feedback_active']]))==0),
            'maximum_offset_rad':float(np.max(np.abs(arrays['actuator_target_offset_rad'])))}

def run_trial(job):
    factory=runner.load_fixture();original=factory.make_env;controllers=[]
    def adapted(*args,**kwargs):
        factory.make_env=original
        try:
            env=make_env_micro(factory,*args,**kwargs) if job.get('micro') else original(*args,**kwargs)
        finally:factory.make_env=adapted
        controller=ForceClamp(env);controller.install();controllers.append(controller)
        return env
    factory.make_env=adapted
    try:result=runner.run_trial(job)
    finally:factory.make_env=original
    folder=Path(job['output']);record=controllers[0].finish(folder)
    metrics=json.loads((folder/'metrics.json').read_text())
    metrics['force_clamp_intervention']=record
    metrics['comparison_profile']='force_clamp_micro' if job.get('micro') else 'force_clamp_baseline_contact'
    if job.get('micro'):metrics['micro_contact_intervention']=controllers[0].env.micro_contact_definition
    runner.write_json(folder/'metrics.json',metrics);runner.write_json(folder/'force_clamp_intervention.json',record)
    result['comparison_profile']=metrics['comparison_profile'];result['force_feedback_summary']=record['phase_force_statistics']
    runner.write_json(folder/'result.json',result)
    print(json.dumps(result,ensure_ascii=False),flush=True)
    return result

def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--manifest',type=Path,default=ROOT/'grasp_search/first-candidates.json')
    parser.add_argument('--candidate',default='h010_palmar_oracle_v1_squeeze005')
    parser.add_argument('--profiles',nargs='+',choices=['micro','baseline'],default=['micro'])
    parser.add_argument('--conditions',nargs='+',choices=['plain','shallow'],default=['plain','shallow'])
    parser.add_argument('--workers',type=int,default=2)
    parser.add_argument('--worker-job',type=Path)
    args=parser.parse_args()
    if args.worker_job:
        run_trial(json.loads(args.worker_job.read_text()));return
    variant=next(v for v in json.loads(args.manifest.read_text())['variants'] if v['id']==args.candidate)
    paths=[]
    for profile in args.profiles:
      for fixture in args.conditions:
        v=dict(variant);v['id']+='_force_clamp_micro' if profile=='micro' else '_force_clamp'
        job={'variant':v,'fixture':fixture,'micro':profile=='micro','resume':False,'output':str((ROOT/'trials'/f"h{int(v['height_mm']):03d}"/fixture/v['id']).resolve())}
        path=ROOT/'trials'/'force-clamp-jobs'/f'{fixture}__{v["id"]}.json';path.parent.mkdir(exist_ok=True)
        runner.write_json(path,job);paths.append(path)
    def execute(path):
        proc=subprocess.run([sys.executable,str(Path(__file__).resolve()),'--worker-job',str(path)],capture_output=True,text=True)
        if proc.stdout:print(proc.stdout,end='',flush=True)
        if proc.stderr:print(proc.stderr,end='',file=sys.stderr,flush=True)
        job=json.loads(path.read_text());return {'job':str(path),'output':job['output'],'exit_code':proc.returncode}
    with ThreadPoolExecutor(max_workers=args.workers) as pool:results=list(pool.map(execute,paths))
    runner.write_json(ROOT/'trials'/f'force-clamp-summary-{"-".join(args.profiles)}.json',{'adapter_sha256':runner.sha(__file__),'results':results,'settings':SETTINGS})
    if any(r['exit_code'] for r in results):raise SystemExit(1)
if __name__=='__main__':main()
