#!/usr/bin/env python3
"""Final source binding and one independent full decode per final animation."""
from pathlib import Path
import csv
import hashlib
import json
import subprocess
import numpy as np
from PIL import Image

ROOT = Path(__file__).resolve().parents[1]
QA = ROOT / 'qa'


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def read(path):
    return json.loads(Path(path).read_text())


def main():
    index_path = ROOT / 'animations/index.json'; index = read(index_path)
    actual_metrics = {str(p) for p in (ROOT / 'trials').rglob('metrics.json')}
    assert {s['metrics'] for s in index['sources']} == actual_metrics
    assert sha(index['renderer']) == index['renderer_sha256']
    for path, digest in index['dependencies'].items(): assert sha(path) == digest
    assert sha(index['overview_finalizer']['path']) == index['overview_finalizer']['sha256']
    for clip in index['original_rendered_clips']: assert sha(clip['path']) == clip['sha256']
    assert len(index['original_rendered_clips']) == len(index['sources']) == 32
    sources = []
    for s in index['sources']:
        r = read(s['metrics'])
        assert s['full_sequence_passed'] == r['full_sequence_passed']
        assert s['lift_hold_passed'] == r['qualified_lift_hold_passed']
        for key, digest in s['source_sha256'].items(): assert sha(s[key]) == digest
        assert sha(s['numerical_output']['path']) == s['numerical_output']['sha256']
        for preview in s['previews']: assert sha(preview['path']) == preview['sha256']
        for processor in s.get('processor_chain', []):
            assert sha(processor['path']) == processor['sha256']
            for field in ['input_video', 'output_video']:
                assert sha(processor[field]['path']) == processor[field]['sha256']
        if s.get('caption_fit'):
            assert s['caption_fit']['physical_states_and_timestamps_changed'] is False
        for name in ['force_feedback', 'root_pose_feedback']:
            item = s.get(name)
            if isinstance(item, dict) and 'path' in item and 'sha256' in item: assert sha(item['path']) == item['sha256']
        with Path(s['numerical_output']['path']).open(newline='') as f: frames = list(csv.DictReader(f))
        with np.load(s['trace'], allow_pickle=False) as trace:
            t = trace['time_s']; grid = np.arange(0, float(t[-1]) + .05, .1)
            indices = np.clip(np.searchsorted(t, grid + 1e-5, side='right') - 1, 0, len(t) - 1); indices[-1] = len(t) - 1
            assert len(frames) == len(indices) == s['video_frames']
            phases = set()
            for f, frame in enumerate(frames):
                i = int(frame['trace_index']); assert i == int(indices[f])
                assert abs(float(frame['recorded_time_s']) - float(t[i])) < 1e-10
                assert frame['phase'] == str(trace['phase_names'][trace['phase_id'][i]])
                phases.add(frame['phase'])
                assert abs(float(frame['object_rise_mm']) - (trace['object_pose'][i, 2] - r['initial_object_pose'][2]) * 1000) < 1e-9
                assert float(frame['height_mm']) == r['height_mm']
                for field, key in [('hand_object_contacts', 'hand_object_contacts'), ('object_fixture_contacts', 'object_fixture_contacts'), ('object_table_contacts', 'object_plane_contacts'), ('hand_fixture_contacts', 'hand_fixture_contacts'), ('normal_hand_force_N', 'normal_hand_contact_force_sum_N'), ('normal_fixture_force_N', 'normal_fixture_contact_force_sum_N'), ('rod_tilt_deg', 'rod_tilt_deg')]:
                    assert abs(float(frame[field]) - float(trace[key][i])) < 1e-10
            assert phases == set(trace['phase_names']) and len(phases) == 9
            assert int(frames[0]['trace_index']) == 0 and int(frames[-1]['trace_index']) == len(t) - 1 == s['final_trace_index']
            assert all(float(frame['hand_object_contacts']) == 0 for frame in frames if frame['phase'] == 'start_pause')
            sources.append({'trial_id': s['trial_id'], 'metrics_sha256': sha(s['metrics']), 'height_mm': r['height_mm'], 'all_csv_rows_match_original_trace': True, 'all9_phases_and_real_initial_terminal_states_included': True, 'qualified_full_sequence_pass': r['full_sequence_passed']})
    media = []
    for v in index['videos']:
        assert sha(v['path']) == v['sha256']
        probe = json.loads(subprocess.check_output(['ffprobe', '-v', 'error', '-select_streams', 'v:0', '-show_entries', 'stream=codec_name,pix_fmt,width,height,r_frame_rate,avg_frame_rate,nb_frames:format=duration', '-of', 'json', v['path']]))
        p = probe['streams'][0]
        assert p['codec_name'] == 'h264' and p['pix_fmt'] == 'yuv420p'
        assert (p['width'], p['height']) == (v['width'], v['height'])
        assert p['r_frame_rate'] == p['avg_frame_rate'] == '10/1' and int(p['nb_frames']) == v['frames']
        assert abs(float(probe['format']['duration']) - v['frames'] / 10) < 1e-6
        completed = subprocess.run(['ffmpeg', '-nostdin', '-v', 'error', '-xerror', '-threads', '1', '-i', v['path'], '-nostats', '-progress', 'pipe:1', '-f', 'null', '-'], check=True, capture_output=True, text=True)
        decoded = int([line.split('=', 1)[1] for line in completed.stdout.splitlines() if line.startswith('frame=')][-1])
        assert decoded == v['frames']
        media.append({'path': v['path'], 'sha256': v['sha256'], 'probe': probe, 'independent_full_decode': 'passed', 'actual_decoded_frame_count': decoded})
        print('PASS independent full decode:', Path(v['path']).name, flush=True)
    lookup = {s['trial_id']: s for s in index['sources']}
    fixed_overviews = [v for v in index['videos'] if len(v.get('source_trial_ids', [])) == 8 and all(read(lookup[t]['metrics']).get('comparison_profile') == 'force_clamp_root_micro' for t in v['source_trial_ids'])]
    assert fixed_overviews, 'Missing final same-controller eight-condition comparison'
    overview = fixed_overviews[0]
    assert {(lookup[t]['height_mm'], lookup[t]['fixture']) for t in overview['source_trial_ids']} == {(h, f) for h in [4, 6, 8, 10] for f in ['plain', 'shallow']}
    expected = {item['metrics'] for item in read(ROOT / 'final-selection.json')['conditions']}
    assert {lookup[t]['metrics'] for t in overview['source_trial_ids']} == expected
    assert {lookup[item['trial_id']]['metrics'] for item in index['selected_conditions']} == expected
    optimized = [s for s in index['sources'] if s['fixture'] == 'shallow' and read(s['metrics']).get('comparison_profile') == 'force_clamp_root_micro']
    chosen = [overview]
    if optimized:
        s = sorted(optimized, key=lambda x: (x['full_sequence_passed'], x['height_mm'], x['trial_id']))[-1]
        chosen.append(s['video'])
    extracted = []
    for j, v in enumerate(chosen):
        positions = [0, v['frames'] // 2, v['frames'] - 1]
        expression = '+'.join(f'eq(n\\,{i})' for i in positions)
        raw = subprocess.check_output(['ffmpeg', '-nostdin', '-v', 'error', '-threads', '1', '-i', v['path'], '-vf', 'select=' + expression, '-fps_mode', 'vfr', '-pix_fmt', 'rgb24', '-f', 'rawvideo', '-'])
        images = np.frombuffer(raw, dtype=np.uint8).reshape(3, v['height'], v['width'], 3)
        for label, im in zip(['first', 'mid', 'last'], images):
            target = QA / f'decoded_review{j}_{label}.png'; Image.fromarray(im).save(target); extracted.append(str(target))
    old = read(QA / 'previous-results-key-baseline.json')
    assert all(sha(row['path']) == row['sha256'] for row in old['files'])
    assert subprocess.check_output(['git', '-C', '/workspace/Dexonomy', 'rev-parse', 'HEAD'], text=True).strip() == old['git_head']
    assert not subprocess.check_output(['git', '-C', '/workspace/Dexonomy', 'status', '--porcelain', '--untracked-files=no'], text=True)
    report = {'schema_version': 1, 'all_automated_checks_passed': True, 'physics_trials_covered': len(sources), 'final_media_files': len(media), 'source_index_sha256': sha(index_path), 'sources': sources, 'media': media, 'main_eight_conditions_use_one_final_controller_profile': True, 'main_overview': overview['path'], 'previous_key_result_sha256_unchanged': True, 'tracked_repository_clean_and_head_unchanged': True, 'extracted_decoded_review_frames': extracted, 'assistant_actual_visual_review': 'pending'}
    (QA / 'independent-media-audit.json').write_text(json.dumps(report, indent=2, ensure_ascii=False) + '\n')


if __name__ == '__main__':
    main()
