#!/usr/bin/env python3
"""Independent read-only actual-model and complete force/root log check."""
from pathlib import Path
import hashlib
import json
import mujoco
import numpy as np
from scipy.spatial.transform import Rotation as R
ROOT = Path(__file__).resolve().parents[1]
sha = lambda p: hashlib.sha256(Path(p).read_bytes()).hexdigest()
rot = lambda q: R.from_quat(np.concatenate([q[..., 1:], q[..., :1]], axis=-1))
FIELDS = ['body_mass','body_inertia','body_ipos','body_iquat','body_mocapid','geom_type','geom_size','geom_pos','geom_quat','geom_bodyid','geom_friction','geom_condim','geom_priority','geom_margin','geom_gap','geom_solref','geom_solimp','geom_contype','geom_conaffinity','jnt_type','jnt_bodyid','jnt_range','jnt_stiffness','dof_damping','actuator_gainprm','actuator_biasprm','actuator_dynprm','actuator_forcelimited','actuator_forcerange','actuator_ctrllimited','actuator_ctrlrange','actuator_trnid','actuator_gear','eq_type','eq_obj1id','eq_obj2id','eq_data','eq_solref','eq_solimp']


def main():
    rows = []
    for path in sorted((ROOT / 'trials').rglob('metrics.json')):
        x = json.loads(path.read_text())
        if x.get('comparison_profile') != 'force_clamp_root_micro': continue
        h = x['height_mm']; model = mujoco.MjModel.from_binary_path(x['upright_protocol']['model_mjb'])
        baseline = mujoco.MjModel.from_binary_path(str(ROOT / f"trials/h{h:03d}/{x['fixture']}/h{h:03d}_source_top_aligned/model.mjb"))
        for field in FIELDS: assert np.array_equal(getattr(model, field), getattr(baseline, field)), (path, field)
        assert np.array_equal(model.opt.gravity, baseline.opt.gravity) and model.opt.timestep == baseline.opt.timestep
        assert model.npair == 31 and np.all(model.pair_dim == 3) and np.all(model.pair_margin == 0) and np.all(model.pair_gap == 0)
        assert np.all(model.pair_friction == [.6,.6,.00002,.000001,.000001])
        assert np.all(model.pair_solref == [.004,1]) and np.all(model.pair_solimp == [.95,.99,.00005,.5,2])
        for a, b in zip(model.pair_geom1, model.pair_geom2):
            names = [model.body(int(model.geom_bodyid[k])).name for k in [a, b]]
            assert any(n.startswith('hand-') for n in names) and any(n.startswith('obj-') for n in names)
        fp, rp, mp = x['force_clamp_intervention'], x['root_pose_feedback_intervention'], x['micro_contact_intervention']
        for adapter in [fp, rp]: assert sha(adapter['adapter_source']) == adapter['adapter_sha256']
        assert mp['adapter_sha256'] == sha(ROOT / 'micro_contact_profile.py')
        assert sha(fp['force_feedback_trace']) == fp['force_feedback_sha256'] and sha(rp['root_pose_feedback_trace']) == rp['root_pose_feedback_sha256']
        with np.load(fp['force_feedback_trace'], allow_pickle=False) as f, np.load(rp['root_pose_feedback_trace'], allow_pickle=False) as q, np.load(x['upright_protocol']['diagnostics'], allow_pickle=False) as d, np.load(x['trace'], allow_pickle=False) as z:
            assert len(q['time_s']) == len(f['time_s']) == x['physics_steps']
            assert np.array_equal(q['time_s'], d['time_s']) and np.array_equal(f['time_s'], d['time_s'])
            assert np.array_equal(f['actual_actuator_ctrl'], d['actuator_ctrl'])
            assert np.allclose(f['actual_actuator_ctrl'], f['nominal_actuator_ctrl'] + f['actuator_target_offset_rad'], rtol=0, atol=1e-12)
            assert np.allclose(f['actual_normal_force_N'], np.stack([d['normal_thumb_contact_force_sum_N'], d['normal_index_contact_force_sum_N']], axis=1), rtol=0, atol=1e-12)
            active, offset = f['feedback_active'], f['actuator_target_offset_rad']
            assert np.max(np.abs(offset)) <= .15 + 1e-12 and not np.any(offset[~active])
            assert np.max(np.abs(np.diff(offset, axis=0)[active[1:] & active[:-1]])) <= .002 + 1e-12
            ids = np.concatenate([np.asarray(a) for a in fp['actuator_ids_thumb_index']])
            assert not np.any(offset[:, np.setdiff1d(np.arange(model.nu), ids)])
            assert np.max(f['commanded_inward_force_N']) <= 6 and np.min(f['commanded_inward_force_N']) >= 0
            limited = model.actuator_ctrllimited.astype(bool); cr = model.actuator_ctrlrange[limited]
            raw = f['actual_actuator_ctrl'][:, limited]
            overflow = max(0., float(np.max(np.maximum(raw - cr[:, 1], cr[:, 0] - raw)))) if len(cr) else None
            active = q['feedback_active']; assert np.array_equal(active, f['feedback_active'])
            assert np.array_equal(active, np.isin(q['phase'], ['loaded_hold','lift','postlift_hold']))
            assert np.array_equal(q['actual_root_pose'], d['actual_hand_qpos'][:, :7])
            nominal, actual, ref, command = q['nominal_root_pose'], q['actual_root_pose'], q['anchored_actual_reference_pose'], q['actual_mocap_command']
            pc, rc = q['position_correction_m'], q['rotation_correction_rotvec_rad']
            rn, ra, rr = rot(nominal[:, 3:]), rot(actual[:, 3:]), rot(ref[:, 3:])
            anchor = rp['initial_anchor']; relative_position = np.asarray(anchor['captured_relative_position_m']); relative_rotation = rot(np.asarray(anchor['captured_relative_quaternion_wxyz']))
            assert np.allclose(ref[active, :3], nominal[active, :3] + rn[active].apply(relative_position), rtol=0, atol=1e-12)
            assert np.max(np.linalg.norm((rr[active] * (rn[active] * relative_rotation).inv()).as_rotvec(), axis=1)) < 1e-12
            assert np.allclose(command[:, :3], nominal[:, :3] + pc, rtol=0, atol=1e-12)
            assert np.max(np.linalg.norm((rot(command[:, 3:]) * (R.from_rotvec(rc) * rn).inv()).as_rotvec(), axis=1)) < 1e-12
            assert np.allclose(q['anchored_position_error_m'], ref[:, :3] - actual[:, :3], rtol=0, atol=1e-12)
            assert np.allclose(q['anchored_rotation_error_rotvec_rad'], (rr * ra.inv()).as_rotvec(), rtol=0, atol=1e-12)
            assert np.max(np.linalg.norm(pc, axis=1)) <= .001 + 1e-12 and np.max(np.linalg.norm(rc, axis=1)) <= np.radians(2) + 1e-12
            continuous_active = active[1:] & active[:-1]
            assert np.max(np.linalg.norm(np.diff(pc, axis=0)[continuous_active], axis=1)) <= .00001 + 1e-12
            assert np.max(np.linalg.norm(np.diff(rc, axis=0)[continuous_active], axis=1)) <= .0002 + 1e-12
            assert not np.any(pc[~active]) and not np.any(rc[~active])
            trace_indices = np.searchsorted(q['time_s'], z['time_s'][1:])
            assert np.allclose(q['time_s'][trace_indices], z['time_s'][1:], rtol=0, atol=1e-12)
            assert np.allclose(command[trace_indices, :3], z['mocap_pos'][1:, 0], rtol=0, atol=1e-12)
            assert np.max(np.linalg.norm((rot(command[trace_indices, 3:]) * rot(z['mocap_quat'][1:, 0]).inv()).as_rotvec(), axis=1)) < 1e-12
            stats = {}
            for phase in ['loaded_hold','lift','postlift_hold']:
                selected = q['phase'] == phase
                position = np.linalg.norm(q['anchored_position_error_m'][selected], axis=1)
                angle = np.degrees(np.linalg.norm(q['anchored_rotation_error_rotvec_rad'][selected], axis=1))
                sr = rp['phase_root_tracking_statistics'][phase]
                assert abs(float(np.max(position)) * 1000 - sr['anchored_actual_reference_position_error_max_mm']) < 1e-10
                assert abs(float(np.max(angle)) - sr['anchored_actual_reference_rotation_error_max_deg']) < 1e-10
                stats[phase] = {'max_anchor_error_mm': float(np.max(position) * 1000), 'max_anchor_error_deg': float(np.max(angle)), 'peak_finger_normal_forces_N': np.max(f['actual_normal_force_N'][selected], axis=0).tolist()}
            rows.append({'metrics': str(path), 'metrics_sha256': sha(path), 'height_mm': h, 'fixture': x['fixture'], 'model_sha256': sha(x['upright_protocol']['model_mjb']), 'all_compiled_baseline_body_geometry_support_weld_actuator_and_limits_unchanged': True, 'only31_HO_dim3_micro_pairs_added': True, 'force_feedback_sha256': fp['force_feedback_sha256'], 'root_pose_feedback_sha256': rp['root_pose_feedback_sha256'], 'all1ms_force_root_logs_and_trace_synchronized': True, 'anchored_reference_errors_and_actual_mocap_recomputed': True, 'amplitude_rate_and_inactive_clear_limits_verified': True, 'enabled_ctrlrange_count': int(np.count_nonzero(limited)), 'maximum_enabled_ctrlrange_excess': overflow, 'phase_tracking_and_force': stats, 'qualified_full_sequence_pass': x['full_sequence_passed']})
        print('QA profile passed:', h, x['fixture'], flush=True)
    assert len(rows) == 8
    (ROOT / 'qa/independent-final-controller-profile-audit.json').write_text(json.dumps({'schema_version': 1, 'all_checks_passed': True, 'trial_count': 8, 'scope': 'Read-only compiled MJB and every1ms force/root feedback audit; no physics reintegration', 'interpretation': 'Anchor tracking retains initial nominal-root gravity bias. Original actuator force limits remain; ctrlrange is not enabled, and control bounds are explicit offset/rate limits.', 'rows': rows}, indent=2, ensure_ascii=False) + '\n')


if __name__ == '__main__': main()
