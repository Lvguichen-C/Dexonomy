# Adaptive synthesis preparation

`reuse_existing.py` copied 200 initialization proposals and 182 synthesis-filtered grasps from the previous 4:1 cylinders at diameters 10, 20, 30 and 40 mm. No force-closure success file, old lift outcome, or old trajectory was copied. `reuse-manifest.json` records all 382 files, source/destination SHA-256 values, the changed scene path, and exact preservation of every other nested value and ndarray dtype. The canonical mesh/XML/URDF/info and overlapping scene NPY files passed byte-identical SHA-256 checks before copying.

This reuse is valid only while the geometry remains identical. A different height policy requires a fresh experiment and new candidates. Reused Tip_Pinch pools contain 50 proposals per diameter; newly generated jobs use 10 proposals each in the current adaptive plan. This unequal allocation must be retained in reported denominators.

`run_synthesis.py` reads the flat `jobs` list in `adaptive-plan.json`. Both `template` and `tmpl_name` keys are accepted. Job settings override plan defaults; explicit CLI budget overrides take priority over both. At most two independent initializer subprocesses run at once, each with a serial object DataLoader, one hand-template worker, its own Hydra log ID, and one or two Torch/BLAS threads. Template feedback is disabled.

```bash
python /workspace/shadow-lift-sweep/run_synthesis.py \
  --plan /workspace/shadow-lift-sweep/adaptive-plan.json \
  --workers 2 --threads-per-worker 1 \
  --epoch 1 --n-init-point 1024 --n-init-inplane 8 \
  --matcher-opt-step 100 --n-final 10
```

Pass `--dry-run` to prepare and validate commands without starting initialization. `--only-job 24_Tip_Pinch:20` selects one template/diameter pair. The latter was smoke-tested against the already-reused d20 pool: the original init operation skipped its complete epoch, returned 10 proposals in epoch 0, and preserved all 50 existing files. No recomputation was needed.

Per-job command, configuration, asset/template hashes, logs and concrete output counts are saved under `synthesis-status/`. `progress.json` and `summary.json` show completed/failed jobs. A zero source process exit code alone is insufficient: the runner also requires the expected per-epoch file count and no logged Python traceback, because upstream initialization catches exceptions internally.

After initializer jobs finish, run `audit_grasp.py` serially over the whole experiment. The requested gravity-on loading, five-second lift, five-second post-lift hold and release tests are performed by `evaluate_lifts.py`; the original gravity-off `eval_fc` is not used as their success gate. `run_sweep.sh` wires these stages together using already-validated assets and templates. Its default does not repeat candidate reuse.

The repository's tracked source remains unchanged.
