#!/usr/bin/env python3
"""Create the isolated 12-diameter Shadow cylinder sweep.

Canonical mesh/XML/URDF/info are copied byte-for-byte from the previous analytic
reconstruction when available. Scene IDs intentionally match the earlier naming
for d10/d20/d30/d40, enabling exact-geometry candidate reuse after scene_path
relocation. No old scene, result, or tracked source is modified.
"""
from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path
import shutil

import numpy as np
import trimesh


DIAMETERS_MM = (1, 5, 10, 20, 30, 40, 50, 60, 70, 80, 90, 100)


def digest(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--repo", type=Path, default=Path("/workspace/Dexonomy"))
    parser.add_argument("--asset-name", default="cylinder_sweep_20261022")
    parser.add_argument("--mass-kg", type=float, default=0.1)
    parser.add_argument("--height-mm", type=float, help="Fix cylinder height in mm; omitted preserves height=4*diameter")
    parser.add_argument("--manifest", type=Path, default=Path(__file__).parent / "assets-manifest.json")
    args = parser.parse_args()
    if args.height_mm is not None and (not np.isfinite(args.height_mm) or args.height_mm <= 0):
        parser.error("--height-mm must be a finite positive length")
    if not np.isfinite(args.mass_kg) or args.mass_kg <= 0:
        parser.error("--mass-kg must be finite and positive")
    root = args.repo / "assets/object" / args.asset_name
    baseline = args.repo / "assets/object/small_cyl"
    canonical_files = (
        "processed_data/cylinder_thin/mesh/simplified.obj",
        "processed_data/cylinder_thin/urdf/coacd.xml",
        "processed_data/cylinder_thin/urdf/coacd.urdf",
        "processed_data/cylinder_thin/info/simplified.json",
    )
    if not all((baseline / name).is_file() for name in canonical_files):
        raise RuntimeError("Previous canonical analytic cylinder missing; run its documented generator first")
    copied = []
    for name in canonical_files:
        source, target = baseline / name, root / name
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(source, target)
        assert digest(source) == digest(target)
        copied.append({"path": name, "source": str(source), "sha256": digest(target)})
    mesh = trimesh.load(root / canonical_files[0], force="mesh")
    assert mesh.is_watertight and mesh.is_winding_consistent
    assert np.allclose(mesh.extents, [1, 1, 4])
    info = json.loads((root / canonical_files[-1]).read_text())
    volume = info["mass"] / (info["density"] * info["scale"] ** 3)
    scenes = []
    dest = root / "scene_cfg/cylinder_thin/table_top"
    dest.mkdir(parents=True, exist_ok=True)
    for diameter_mm in DIAMETERS_MM:
        diameter = diameter_mm / 1000.0
        height_mm = 4 * diameter_mm if args.height_mm is None else args.height_mm
        height = height_mm / 1000.0
        scale = (np.full(3, diameter, dtype=np.float32) if args.height_mm is None
                 else np.array([diameter, diameter, height / 4.0], dtype=np.float32))
        cfg = {
            "scene": {
                "cylinder_thin": {
                    "type": "rigid_object",
                    "file_path": "../../../processed_data/cylinder_thin/mesh/simplified.obj",
                    "xml_path": "../../../processed_data/cylinder_thin/urdf/coacd.xml",
                    "urdf_path": "../../../processed_data/cylinder_thin/urdf/coacd.urdf",
                    "info_path": "../../../processed_data/cylinder_thin/info/simplified.json",
                    "scale": scale,
                    "pose": np.array([0, 0, height / 2.0, 1, 0, 0, 0], dtype=np.float32),
                },
                "table": {
                    "type": "plane",
                    "pose": np.array([0, 0, 0, 1, 0, 0, 0], dtype=np.float32),
                    "size": np.array([0.4, 0.4, 0.01], dtype=np.float32),
                    "board": True,
                },
            },
            "scene_id": f"cylinder_thin_table_{diameter_mm}",
            "task": {"type": "force_closure", "obj_name": "cylinder_thin"},
        }
        target = dest / f"d{diameter_mm}.npy"
        np.save(target, cfg, allow_pickle=True)
        old = baseline / "scene_cfg/cylinder_thin/table_top" / target.name
        byte_identical = old.is_file() and digest(old) == digest(target)
        scenes.append({
            "path": str(target),
            "relative_path": str(target.relative_to(root)),
            "scene_id": cfg["scene_id"],
            "diameter_mm": diameter_mm,
            "height_mm": height_mm,
            "center_height_mm": height_mm / 2.0,
            "scale": scale.tolist(),
            "target_mass_kg": args.mass_kg,
            "required_density_kg_m3": args.mass_kg / (volume * diameter ** 2 * height / 4.0),
            "baseline_scene_exists": old.is_file(),
            "scene_byte_identical_to_baseline": byte_identical,
        })
    (root / "valid_split").mkdir(exist_ok=True)
    (root / "valid_split/all.json").write_text(json.dumps([s["relative_path"] for s in scenes], indent=2) + "\n")
    manifest = {
        "asset_root": str(root),
        "diameters_mm": list(DIAMETERS_MM),
        "height_policy": "aspect_ratio_4" if args.height_mm is None else "fixed_height",
        "height_to_diameter_ratio": 4 if args.height_mm is None else None,
        "fixed_height_mm": args.height_mm,
        "target_mass_kg": args.mass_kg,
        "mass_policy": "The same 0.1 kg mass is used at every diameter; density varies with size, not a common real material.",
        "mass_applied_by": "Native eval/lift loader using info mass/density/scale and product of scene scale",
        "table_top_z_m": 0,
        "canonical_mesh_sections": 64,
        "canonical_mesh_volume_m3": volume,
        "canonical_mesh_bounds": mesh.bounds.tolist(),
        "canonical_files_identical_to_previous_run": copied,
        "scenes": scenes,
        "sha256": {str(p.relative_to(root)): digest(p) for p in sorted(root.rglob("*")) if p.is_file()},
    }
    manifest_path = args.manifest
    manifest_path.parent.mkdir(parents=True, exist_ok=True)
    manifest_path.write_text(json.dumps(manifest, indent=2) + "\n")
    print(json.dumps({"asset_root": str(root), "scenes": len(scenes), "manifest": str(manifest_path)}))


if __name__ == "__main__":
    main()
