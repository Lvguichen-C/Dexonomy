#!/usr/bin/env python3
"""Validate actual manifest cylinder dimensions and equal-mass compiled models."""
from __future__ import annotations

import argparse
from concurrent.futures import ThreadPoolExecutor
import json
from pathlib import Path
import subprocess
import sys


ROOT = Path(__file__).parent
DIAMETERS = (1, 5, 10, 20, 30, 40, 50, 60, 70, 80, 90, 100)


def worker(diameter_mm: int, repo: Path, manifest_path: Path):
    import numpy as np
    import trimesh
    from dexonomy.sim import HandCfg, MuJoCo_EvalCfg, MuJoCo_EvalEnv
    from dexonomy.util.file_util import load_scene_cfg

    manifest = json.loads(manifest_path.read_text())
    scene_info = next(row for row in manifest["scenes"] if row["diameter_mm"] == diameter_mm)
    target_mass = float(scene_info.get("target_mass_kg", manifest["target_mass_kg"]))
    path = repo / "assets/object" / Path(manifest["asset_root"]).name / scene_info["relative_path"]
    scene = load_scene_cfg(str(path))
    obj = scene["scene"]["cylinder_thin"]
    info = json.loads(Path(obj["info_path"]).read_text())
    volume = info["mass"] / (info["density"] * info["scale"] ** 3)
    obj["density"] = float(target_mass / (volume * np.prod(obj["scale"])))
    mesh = trimesh.load(obj["file_path"], force="mesh")
    expected = np.array([diameter_mm, diameter_mm, scene_info["height_mm"]]) / 1000
    extent = mesh.extents * obj["scale"]
    assert np.allclose(extent, expected, atol=3e-8, rtol=1e-6), (extent, expected)
    assert abs(float(mesh.bounds[0, 2] * obj["scale"][2] + obj["pose"][2])) < 1e-7
    env = MuJoCo_EvalEnv(
        hand_cfg=HandCfg(str(repo / "assets/hand/shadow/right.xml"), freejoint=True),
        scene_cfg=scene,
        sim_cfg=MuJoCo_EvalCfg(miu_coef=[0.6, 0.02]),
        debug_view=False,
        debug_render=False,
    )
    model, data = env._model, env._data
    mass = float(model.body_subtreemass[env._obj_active_bodyid])
    assert np.isfinite(data.qpos).all() and np.isfinite(data.qvel).all()
    assert np.isclose(mass, target_mass, rtol=1e-5, atol=1e-8), mass
    assert np.allclose(env.get_active_obj_pose()[:3], [0, 0, scene_info["center_height_mm"] / 1000], atol=1e-7)
    output = {
        "diameter_mm": diameter_mm,
        "height_mm": scene_info["height_mm"],
        "scene": str(path),
        "expected_extent_m": expected.tolist(),
        "actual_mesh_extent_m": extent.tolist(),
        "target_mass_kg": target_mass,
        "compiled_object_mass_kg": mass,
        "density_kg_m3": obj["density"],
        "object_pose": env.get_active_obj_pose().tolist(),
        "nq": model.nq,
        "nv": model.nv,
        "initial_state_finite": True,
        "model_compile_passed": True,
        "note": "Default zero hand configuration only; compilation is not a grasp-success test.",
    }
    dest = ROOT / "asset-validation"
    dest.mkdir(exist_ok=True)
    (dest / f"d{diameter_mm}.json").write_text(json.dumps(output, indent=2) + "\n")
    return output


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--repo", type=Path, default=Path("/workspace/Dexonomy"))
    parser.add_argument("--diameter", type=int)
    parser.add_argument("--manifest", type=Path, default=ROOT / "assets-manifest.json")
    args = parser.parse_args()
    if args.diameter is not None:
        worker(args.diameter, args.repo, args.manifest)
        return

    def run(d):
        proc = subprocess.run([sys.executable, str(Path(__file__).resolve()), "--repo", str(args.repo), "--manifest", str(args.manifest), "--diameter", str(d)], text=True, capture_output=True)
        if proc.returncode:
            raise RuntimeError(f"d{d} validation failed: {proc.stdout}\n{proc.stderr}")
        return json.loads((ROOT / "asset-validation" / f"d{d}.json").read_text())

    with ThreadPoolExecutor(max_workers=3) as pool:
        rows = list(pool.map(run, DIAMETERS))
    manifest = json.loads(args.manifest.read_text())
    output = {"diameters_mm": list(DIAMETERS), "all_passed": len(rows) == 12 and all(r["model_compile_passed"] for r in rows), "target_mass_kg": manifest["target_mass_kg"], "height_policy": manifest.get("height_policy", "aspect_ratio_4"), "fixed_height_mm": manifest.get("fixed_height_mm"), "source_manifest": str(args.manifest), "mass_policy": "Equal test mass at all sizes, not equal material density", "scenes": rows}
    dest = ROOT / "assets-validation.json"
    dest.write_text(json.dumps(output, indent=2) + "\n")
    print(json.dumps({"all_passed": output["all_passed"], "scene_count": len(rows), "validation": str(dest)}))


if __name__ == "__main__":
    main()
