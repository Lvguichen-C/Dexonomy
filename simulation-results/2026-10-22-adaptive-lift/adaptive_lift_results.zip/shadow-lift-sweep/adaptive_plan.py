#!/usr/bin/env python3
"""Rank actual Shadow contact annotations against finite cylinder geometry.

This is a geometric proposal policy, never a physics success label. The native
init/grasp pipeline and the fresh lift/hold/release trials remain decisive.
"""
from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path

import numpy as np
from scipy.optimize import least_squares
import trimesh


DIAMETERS = [1, 5, 10, 20, 30, 40, 50, 60, 70, 80, 90, 100]
BASELINE = "24_Tip_Pinch"


def family(name):
    prefix = name.split("_", 1)[0]
    if prefix in {"1", "2", "3", "4", "5", "17", "29", "30", "32"}:
        return "cylindrical_wrap"
    if prefix in {"14", "20", "21", "25", "27", "28"}:
        return "tripod_or_multi_tip"
    if prefix in {"6", "7", "8", "10", "11", "12", "13", "26"}:
        return "prismatic_or_multi_surface"
    if prefix in {"16", "23", "31"}:
        return "lateral_or_adduction"
    return "pinch"


def load_templates(directory):
    result = []
    for path in sorted(directory.glob("*.npy")):
        data = np.load(path, allow_pickle=True).item()
        cpn = data.get("hand_cpn_w")
        if cpn is None or len(cpn) < 2:
            continue
        cpn = np.asarray(cpn, dtype=float)
        normals = cpn[:, 3:]
        normals /= np.maximum(np.linalg.norm(normals, axis=1, keepdims=True), 1e-12)
        points = cpn[:, :3]
        pair_dot = normals @ normals.T
        opposition = float(-np.min(pair_dot))
        pair_dist = np.linalg.norm(points[:, None] - points[None, :], axis=-1)
        opposed_dist = pair_dist[pair_dot < -0.5]
        result.append({
            "name": path.stem,
            "family": family(path.stem),
            "points": points,
            "normals": normals,
            "n_contact_points": len(points),
            "required_contact_groups": data.get("required_cbody", []),
            "contact_span_mm": float(pair_dist.max() * 1000),
            "opposed_contact_span_median_mm": float(np.median(opposed_dist) * 1000) if len(opposed_dist) else None,
            "maximum_normal_opposition": opposition,
            "source_sha256": hashlib.sha256(path.read_bytes()).hexdigest(),
            # Object-specific annotations retained in the complete ranking but
            # not used in the generic cylinder proposal pool.
            "eligible": opposition > 0.25 and path.stem not in {"19_Distal", "21_Tripod_Variation", "mug", "15_Fixed_Hook"},
        })
    return result


def fit(template, diameter_mm, height_mm):
    points, normals = template["points"], template["normals"]
    radius, height = diameter_mm / 2000, height_mm / 1000
    origin = points.mean(axis=0)
    points = points - origin
    _, _, vh = np.linalg.svd(normals, full_matrices=True)
    _, _, pv = np.linalg.svd(points, full_matrices=True)
    starts = [vh[-1], pv[0], np.array([0., 0., 1.])]
    scale = 0.01  # metre-valued position residuals relative to 10 mm

    def components(x):
        center = x[:3]
        axis = x[3:] / max(np.linalg.norm(x[3:]), 1e-10)
        delta = points - center
        axial = delta @ axis
        radial = delta - axial[:, None] * axis
        distance = np.linalg.norm(radial, axis=1)
        radial_unit = radial / np.maximum(distance[:, None], 1e-10)
        return axis, axial, distance, radial_unit

    def residual(x):
        axis, axial, distance, radial_unit = components(x)
        # The hand contact normal points into the object, opposite to the
        # outward cylinder radial normal. Longitudinal extent is finite.
        return np.concatenate([
            (distance - radius) / scale,
            0.35 * (normals + radial_unit).ravel(),
            np.maximum(np.abs(axial) - height / 2, 0) / scale,
            [np.linalg.norm(x[3:]) - 1],
        ])

    best = None
    for axis in starts:
        axis = axis / max(np.linalg.norm(axis), 1e-10)
        initial_center = (points + radius * normals).mean(axis=0)
        fitted = least_squares(residual, np.r_[initial_center, axis], max_nfev=55,
                               ftol=1e-6, xtol=1e-6, gtol=1e-6)
        score = float(np.mean(residual(fitted.x) ** 2))
        if best is None or score < best[0]:
            best = score, fitted
    score, result = best
    axis, axial, distances, radial_unit = components(result.x)
    normal_cosine = np.clip(np.sum(-normals * radial_unit, axis=1), -1, 1)
    radial_error = distances - radius
    overflow = np.maximum(np.abs(axial) - height / 2, 0)
    # Lack of opposite normals receives a strong penalty rather than allowing
    # one-sided surface matches to dominate a geometrical ranking.
    score += max(0, 0.5 - template["maximum_normal_opposition"]) ** 2
    return {
        "template": template["name"], "family": template["family"],
        "eligible": template["eligible"], "geometric_score": score,
        "radial_rms_error_mm": float(np.sqrt(np.mean(radial_error ** 2)) * 1000),
        "max_radial_error_mm": float(np.max(np.abs(radial_error)) * 1000),
        "normal_rms_error_deg": float(np.sqrt(np.mean(np.arccos(normal_cosine) ** 2)) * 180 / np.pi),
        "longitudinal_overflow_rms_mm": float(np.sqrt(np.mean(overflow ** 2)) * 1000),
        "axis_in_template_hand_frame": axis.tolist(),
        "center_in_template_hand_frame_m": (result.x[:3] + origin).tolist(),
        "contact_span_mm": template["contact_span_mm"],
        "opposed_contact_span_median_mm": template["opposed_contact_span_median_mm"],
        "maximum_normal_opposition": template["maximum_normal_opposition"],
        "n_contact_points": template["n_contact_points"],
    }


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--template-dir", type=Path, default=Path("/workspace/Dexonomy/assets/hand/shadow/init_tmpl"))
    parser.add_argument("--outdir", type=Path, default=Path("/workspace/shadow-lift-sweep"))
    args = parser.parse_args()
    args.outdir.mkdir(parents=True, exist_ok=True)
    templates = load_templates(args.template_dir)
    jobs, scenes = [], []
    for diameter in DIAMETERS:
        scene_path = Path(f"/workspace/Dexonomy/assets/object/cylinder_sweep_20261022/scene_cfg/cylinder_thin/table_top/d{diameter}.npy")
        scene_data = np.load(scene_path, allow_pickle=True).item()
        obj = scene_data["scene"][scene_data["task"]["obj_name"]]
        mesh_path = Path(obj["file_path"])
        if not mesh_path.is_absolute():
            mesh_path = scene_path.parent / mesh_path
        extents = np.asarray(trimesh.load(mesh_path, force="mesh").extents) * np.asarray(obj["scale"])
        height_mm = float(extents[2] * 1000)
        ranked = sorted([fit(t, diameter, height_mm) for t in templates], key=lambda v: v["geometric_score"])
        eligible = [row for row in ranked if row["eligible"]]
        # Two measured best fits from distinct contact topologies, plus the
        # established 24_Tip_Pinch reference. If the baseline is one of those
        # two, add the next distinct proposal, maintaining three choices.
        selected, families = [], set()
        for row in eligible:
            if row["family"] not in families:
                selected.append(row["template"])
                families.add(row["family"])
            if len(selected) == 2:
                break
        if BASELINE not in selected:
            selected.append(BASELINE)
        else:
            selected.append(next(row["template"] for row in eligible if row["template"] not in selected))
        fallback = [row["template"] for row in eligible if row["template"] not in selected][:5]
        scene = {
            "diameter_mm": diameter, "height_mm": height_mm,
            "scene_id": f"cylinder_thin_table_{diameter}",
            "scene_path": str(scene_path),
            "selected_templates": selected, "fallback_templates": fallback,
            "ranked_templates": ranked,
        }
        scenes.append(scene)
        for template in selected:
            jobs.append({"diameter_mm": diameter, "tmpl_name": template, "template": template,
                         "scene_path": scene["scene_path"], "scene_id": scene["scene_id"]})
        print(json.dumps({"diameter_mm": diameter, "selected": selected,
                          "top_geometry": [(r["template"], round(r["radial_rms_error_mm"], 2), round(r["normal_rms_error_deg"], 1)) for r in ranked[:3]]}), flush=True)
    output = {
        "selection_method": "Measured hand contact points/normals fitted to each finite cylinder; radius, length, surface-normal agreement and opposite contacts are scored. Two best distinct contact families plus a fixed Tip_Pinch reference. Actual success is decided by fresh continuous dynamics, never this geometric rank.",
        "geometry_fit_limitations": "Static side-surface fit excludes joint retargeting, collision, table reachability and actuation. Native init/grasp and gravity-on lift/hold/release tests resolve those limitations. No diameter is declared impossible from this rank.",
        "object": {"diameters_mm": DIAMETERS, "height_source": "Actual canonical mesh z extent multiplied by each scene scale", "mass_kg": 0.1},
        "defaults": {"exp_name": "diameter_sweep", "epoch": 1, "n_init_point": 1024, "n_init_inplane": 8, "matcher_opt_step": 100, "n_final": 10},
        "templates": [{k: v for k, v in t.items() if k not in {"points", "normals"}} for t in templates],
        "scenes": scenes, "jobs": jobs,
        "recommended_budget": {
            "initial_scout": {"epoch": 1, "n_init_point": 128, "n_init_inplane": 4, "opt_step": 60, "n_final": 5},
            "normal_run": {"epoch": 1, "n_init_point": 1024, "n_init_inplane": 8, "opt_step": 100, "n_final": 10},
            "fallback": "If no selected template has a successful fresh lift/5s-hold/release trial, run the next three eligible ranked templates with the same normal budget. Preserve all failures and selection outcomes.",
            "notes": "Old Tip_Pinch init/grasp data may be reused only for exact matching geometry. Old force-closure/lift successes never substitute for the new 5s lift +5s hold +release test.",
        },
    }
    (args.outdir / "adaptive-plan.json").write_text(json.dumps(output, indent=2) + "\n")
    (args.outdir / "adaptive-jobs.json").write_text(json.dumps(jobs, indent=2) + "\n")


if __name__ == "__main__":
    main()
