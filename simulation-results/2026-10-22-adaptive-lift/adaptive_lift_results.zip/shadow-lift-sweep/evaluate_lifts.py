#!/usr/bin/env python3
"""Continuous Shadow loaded hold, 100 mm lift, five-second hold, and release.

The object is free and gravity is enabled for the whole trial. Reset occurs only
at each candidate boundary. Saved NPZ traces contain actual simulated states;
they can be displayed later without claiming an additional physical execution.
"""
from __future__ import annotations

import argparse
from dataclasses import asdict, dataclass
from concurrent.futures import ThreadPoolExecutor
import hashlib
import json
import math
import os
from pathlib import Path
import subprocess
import sys
import traceback

os.environ.setdefault("MUJOCO_GL", "egl")
os.environ.setdefault("LP_NUM_THREADS", "2")
sys.path.insert(0, "/workspace/Dexonomy")
sys.path.insert(0, "/workspace/shadow-reproduction")

import mujoco
import numpy as np

from dexonomy.sim import HandCfg, MuJoCo_EvalCfg, MuJoCo_EvalEnv
from dexonomy.util.file_util import load_json, load_scene_cfg
from dexonomy.util.traj_util import get_planner


PHASES = ["approach", "approach_close_squeeze", "loaded_hold", "lift", "postlift_hold", "release_open", "release_retreat", "release_settle"]


@dataclass
class TestConfig:
    mass_kg: float = 0.1
    lift_m: float = 0.1
    approach_s: float = 2.0
    approach_offset_m: float = 0.1
    loaded_hold_s: float = 1.0
    lift_s: float = 5.0
    postlift_hold_s: float = 5.0
    release_open_s: float = 1.5
    release_retreat_s: float = 1.0
    release_settle_s: float = 3.0
    retreat_m: float = 0.1
    minimum_height_gain_m: float = 0.08
    target_lift_tolerance_m: float = 0.005
    position_tolerance_m: float = 0.02
    rotation_tolerance_deg: float = 15.0
    minimum_final_hand_contacts: int = 2
    trace_fps: int = 10


def jsonable(value):
    if isinstance(value, np.ndarray):
        return value.tolist()
    if isinstance(value, np.generic):
        return value.item()
    raise TypeError(type(value).__name__)


def write_json(path, value):
    Path(path).write_text(json.dumps(value, indent=2, default=jsonable, ensure_ascii=False) + "\n")


def sha256(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def rotation_distance_deg(a, b):
    """Shortest physical quaternion angle, independent of quaternion sign."""
    a, b = np.asarray(a), np.asarray(b)
    cosine = abs(float(np.dot(a, b))) / max(1e-30, float(np.linalg.norm(a) * np.linalg.norm(b)))
    return math.degrees(2 * math.acos(np.clip(cosine, 0.0, 1.0)))


def pose_difference(a, b):
    return float(np.linalg.norm(np.asarray(a[:3]) - b[:3])), rotation_distance_deg(a[3:7], b[3:7])


def contact_stats(env):
    model, data = env._model, env._data
    hand_object = table_object = 0
    hand_bodies = set()
    penetration = 0.0
    for contact in data.contact:
        b1 = model.body(int(model.geom_bodyid[contact.geom1])).name
        b2 = model.body(int(model.geom_bodyid[contact.geom2])).name
        for hand, obj in ((b1, b2), (b2, b1)):
            if hand.startswith("hand-") and obj.startswith("obj-"):
                hand_object += 1
                hand_bodies.add(hand)
        if (b1.startswith("obj-") and b2 == "world") or (b2.startswith("obj-") and b1 == "world"):
            table_object += 1
        penetration = max(penetration, -float(contact.dist))
    return hand_object, table_object, sorted(hand_bodies), penetration


def normal_contact_forces(env):
    """Actual solved normal contact forces at hand/object pairs, in newtons."""
    result = []
    for index, contact in enumerate(env._data.contact):
        names = [env._model.body(int(env._model.geom_bodyid[g])).name for g in (contact.geom1, contact.geom2)]
        if any(n.startswith("hand-") for n in names) and any(n.startswith("obj-") for n in names):
            force = np.zeros(6)
            mujoco.mj_contactForce(env._model, env._data, index, force)
            result.append(abs(float(force[0])))
    return float(sum(result)), max(result, default=0.0)


class SweepEnv(MuJoCo_EvalEnv):
    observer = None

    def _add_hand(self, *args, **kwargs):
        self._add_for_visualization()
        return super()._add_hand(*args, **kwargs)

    def reset_qpos(self, *args, **kwargs):
        if self.observer is not None:
            raise RuntimeError("Reset inside an active continuous trial is forbidden")
        return super().reset_qpos(*args, **kwargs)

    def step_sim(self, substep):
        for _ in range(substep):
            mujoco.mj_step(self._model, self._data)
            if self.observer is not None:
                self.observer.observe()


def prepare_scene(input_path, mass=0.1):
    grasp = np.load(input_path, allow_pickle=True).item()
    scene = load_scene_cfg(grasp["scene_path"])
    for obj in scene["scene"].values():
        if obj["type"] == "rigid_object":
            info = load_json(obj["info_path"])
            volume = info["mass"] / (info["density"] * info["scale"] ** 3)
            obj["density"] = mass / (volume * np.prod(obj["scale"]))
    return grasp, scene


def make_env(scene, hand_xml):
    env = SweepEnv(hand_cfg=HandCfg(str(hand_xml), freejoint=True), scene_cfg=scene,
                   sim_cfg=MuJoCo_EvalCfg(miu_coef=[0.6, 0.02]), debug_render=False, debug_view=False)
    env._model.opt.disableflags &= ~int(mujoco.mjtDisableBit.mjDSBL_GRAVITY)
    env._model.opt.gravity[:] = [0, 0, -9.81]
    for i in range(env._model.ngeom):
        if env._model.body(int(env._model.geom_bodyid[i])).name.startswith("hand-"):
            env._model.geom_matid[i] = -1
            env._model.geom_rgba[i] = [0.863157, 0.0865002, 0.0802199, 1]
    return env


class TrialObserver:
    def __init__(self, env, config, initial_pose, output, render=False, fps=25, width=640, height=480):
        self.env, self.config, self.initial, self.output = env, config, np.copy(initial_pose), Path(output)
        self.phase = PHASES[0]
        self.steps = 0
        self.previous_time = 0.0
        self.finite = True
        self.time_resets = []
        self.max_warnings = np.zeros(len(env._data.warning), dtype=int)
        self.max_penetration = 0.0
        self.trace = []
        self.next_trace = 0.0
        self.trace_fps = config.trace_fps
        self.closure_pose = None
        self.expected_pose = None
        self.hold_start_pose = None
        self.hold_checks = []
        self.loaded_checks = []
        self.phase_boundaries = []
        self.renderer = self.writer = None
        self.render_fps, self.next_frame = fps, 0.0
        self.width, self.height = width, height
        if render:
            from PIL import ImageFont
            from video_writer import VideoWriter
            env._model.vis.global_.offwidth = max(width, env._model.vis.global_.offwidth)
            env._model.vis.global_.offheight = max(height, env._model.vis.global_.offheight)
            self.renderer = mujoco.Renderer(env._model, height=height, width=width)
            self.writer = VideoWriter(self.output / "trial.mp4", fps=fps)
            self.camera = self.camera_for_trial()
            self.option = mujoco.MjvOption()
            try:
                self.font = ImageFont.truetype("/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf", max(12, width // 42))
            except OSError:
                self.font = ImageFont.load_default()

    def camera_for_trial(self):
        env = self.env
        camera = mujoco.MjvCamera()
        mujoco.mjv_defaultCamera(camera)
        indices = [i for i in range(env._model.ngeom) if env._model.body(int(env._model.geom_bodyid[i])).name.startswith(("hand-", "obj-"))]
        centers = env._data.geom_xpos[indices]
        lo, hi = centers.min(axis=0), centers.max(axis=0)
        lo = np.minimum(lo, self.initial[:3] - [0.03, 0.03, self.initial[2]])
        hi += [0.02, 0.02, self.config.lift_m + 0.06]
        camera.lookat[:] = (lo + hi) / 2
        camera.distance = max(0.48, float(np.max(hi - lo)) * 2.2)
        camera.azimuth, camera.elevation = 135, -20
        return camera

    def begin_phase(self, phase):
        self.phase = phase
        self.phase_boundaries.append({"phase": phase, "time_s": float(self.env._data.time), "step": self.steps})
        self.capture_trace(force=True)

    def observe(self):
        data = self.env._data
        now = float(data.time)
        self.steps += 1
        if now <= self.previous_time:
            self.time_resets.append({"step": self.steps, "previous_time_s": self.previous_time, "time_s": now})
        self.previous_time = now
        self.finite &= bool(np.isfinite(data.qpos).all() and np.isfinite(data.qvel).all())
        self.max_warnings = np.maximum(self.max_warnings, [w.number for w in data.warning])
        if self.phase in ("loaded_hold", "postlift_hold"):
            pose = self.env.get_active_obj_pose().copy()
            hp, tp, bodies, penetration = contact_stats(self.env)
            self.max_penetration = max(self.max_penetration, penetration)
            if self.phase == "loaded_hold":
                drift, angle = pose_difference(self.closure_pose, pose)
                normal_sum, normal_max = normal_contact_forces(self.env)
                self.loaded_checks.append((now, drift, angle, hp, tp, normal_sum, normal_max))
            else:
                drift, angle = pose_difference(self.expected_pose, pose)
                hold_drift, hold_angle = pose_difference(self.hold_start_pose, pose)
                self.hold_checks.append((now, float(pose[2] - self.initial[2]), drift, angle, hold_drift, hold_angle, hp, tp))
        self.capture_trace()
        if self.renderer is not None and now + 1e-10 >= self.next_frame:
            self.capture_frame()
            self.next_frame += 1 / self.render_fps

    def capture_trace(self, force=False):
        data = self.env._data
        now = float(data.time)
        if not force and now + 1e-10 < self.next_trace:
            return
        hp, tp, bodies, penetration = contact_stats(self.env)
        self.max_penetration = max(self.max_penetration, penetration)
        self.trace.append((now, PHASES.index(self.phase), data.qpos.copy(), data.ctrl.copy(),
                           self.env.get_active_obj_pose().copy(), data.mocap_pos.copy(), data.mocap_quat.copy(), hp, tp,
                           normal_contact_forces(self.env)[0]))
        if not force:
            self.next_trace += 1 / self.trace_fps
        elif now == 0 and self.next_trace == 0:
            self.next_trace = 1 / self.trace_fps

    def capture_frame(self):
        from PIL import Image, ImageDraw
        data = self.env._data
        self.renderer.update_scene(data, camera=self.camera, scene_option=self.option)
        image = Image.fromarray(self.renderer.render().copy())
        draw = ImageDraw.Draw(image)
        top = max(46, self.height // 8)
        draw.rectangle((0, 0, self.width, top), fill=(17, 22, 29))
        draw.text((10, 7), f"SHADOW | {self.phase.upper().replace('_', ' ')}", font=self.font, fill=(245, 245, 245))
        pose = self.env.get_active_obj_pose()
        hp, tp, _, _ = contact_stats(self.env)
        draw.text((10, top // 2), f"t={data.time:.2f}s | rise={(pose[2]-self.initial[2])*1000:.1f} mm | contacts={hp}/{tp}", font=self.font, fill=(235, 235, 235))
        draw.rectangle((0, self.height - 28, self.width, self.height), fill=(17, 22, 29))
        draw.text((10, self.height - 23), "Gravity ON | Lift 100 mm / 5 s | Hold 5 s | Release", font=self.font, fill=(235, 235, 235))
        self.writer.append_data(np.asarray(image))
        if not (self.output / "first.png").exists():
            image.save(self.output / "first.png")
        self.last_frame = image

    def finish(self):
        self.capture_trace(force=True)
        if self.writer is not None:
            self.writer.close()
            self.last_frame.save(self.output / "last.png")
            self.renderer.close()
        columns = ["time_s", "phase_id", "qpos", "ctrl", "object_pose", "mocap_pos", "mocap_quat", "hand_object_contacts", "object_table_contacts", "normal_hand_contact_force_sum_N"]
        arrays = {name: np.asarray([row[i] for row in self.trace], dtype=np.int16 if name in ("phase_id", "hand_object_contacts", "object_table_contacts") else np.float32)
                  for i, name in enumerate(columns)}
        arrays["phase_names"] = np.asarray(PHASES)
        np.savez_compressed(self.output / "trace.npz", **arrays)
        self.env.observer = None


def smooth(x):
    return x * x * (3 - 2 * x)


def move_control(env, start, end, seconds):
    steps = round(seconds / env._model.opt.timestep)
    if steps < 1:
        raise ValueError("Phase must have at least one simulation step")
    for i in range(steps):
        qpos = np.asarray(start) + smooth((i + 1) / steps) * (np.asarray(end) - start)
        env.set_ctrl(qpos, "ee_pose")
        env.step_sim(1)


def evaluate_candidate(env, input_path, output, config=None, render=False, fps=25, width=640, height=480):
    config = config or TestConfig()
    input_path, output = Path(input_path), Path(output)
    output.mkdir(parents=True, exist_ok=True)
    grasp, scene = prepare_scene(input_path, config.mass_kg)
    if scene["task"]["type"] != "force_closure":
        raise ValueError("This gravity-only lift test requires a force_closure scene, without prescribed external forces")
    controls, types, forces, target = get_planner(scene["task"].copy()).plan_trajectory(
        env._obj_init_qpos[-7:].copy(), grasp["pregrasp_qpos"], grasp["grasp_qpos"], grasp["squeeze_qpos"], grasp.get("robot_pose"))
    env.observer = None
    approach_start = np.asarray(controls[0]).copy()
    outward = approach_start[:3] - np.asarray(scene["scene"][scene["task"]["obj_name"]]["pose"][:3])
    outward[2] = max(0.0, outward[2])
    outward = outward / np.linalg.norm(outward) if np.linalg.norm(outward) > 1e-6 else np.array([-1., 0., 0.])
    approach_start[:3] += config.approach_offset_m * outward
    env.reset_qpos(approach_start)
    env._data.qfrc_applied[:] = 0
    env._data.xfrc_applied[:] = 0
    for warning in env._data.warning:
        warning.number = 0
        warning.lastinfo = 0
    initial_pose = env.get_active_obj_pose().copy()
    observer = TrialObserver(env, config, initial_pose, output, render=render, fps=fps, width=width, height=height)
    env.observer = observer
    observer.begin_phase("approach")
    move_control(env, approach_start, np.asarray(controls[0]), config.approach_s)
    observer.begin_phase("approach_close_squeeze")
    env.run_trajectory(controls, types, forces)
    closure_pose = env.get_active_obj_pose().copy()
    observer.closure_pose = closure_pose
    observer.begin_phase("loaded_hold")
    env.step_sim(round(config.loaded_hold_s / env._model.opt.timestep))
    loaded_pose = env.get_active_obj_pose().copy()
    squeeze = np.asarray(grasp["squeeze_qpos"])[-1].copy()
    lifted = squeeze.copy()
    lifted[2] += config.lift_m
    observer.expected_pose = closure_pose.copy()
    observer.expected_pose[2] += config.lift_m
    observer.begin_phase("lift")
    move_control(env, squeeze, lifted, config.lift_s)
    lift_end_pose = env.get_active_obj_pose().copy()
    observer.hold_start_pose = lift_end_pose.copy()
    observer.begin_phase("postlift_hold")
    env.step_sim(round(config.postlift_hold_s / env._model.opt.timestep))
    held_pose = env.get_active_obj_pose().copy()
    final_hp, final_tp, final_bodies, penetration = contact_stats(env)
    hold = np.asarray(observer.hold_checks)
    loaded = np.asarray(observer.loaded_checks)
    expected_error, closure_rotation = pose_difference(observer.expected_pose, held_pose)
    hold_end_drift, hold_end_rotation = pose_difference(lift_end_pose, held_pose)
    hold_criteria = {
        "minimum_height_gain_throughout_hold": bool(np.min(hold[:, 1]) >= config.minimum_height_gain_m),
        "actual_object_lift_within_tolerance_throughout_hold": bool(np.max(np.abs(hold[:, 1] - config.lift_m)) <= config.target_lift_tolerance_m),
        "expected_position_error_throughout_hold": bool(np.max(hold[:, 2]) < config.position_tolerance_m),
        "closure_rotation_throughout_hold": bool(np.max(hold[:, 3]) < config.rotation_tolerance_deg),
        "position_drift_throughout_hold": bool(np.max(hold[:, 4]) < config.position_tolerance_m),
        "orientation_drift_throughout_hold": bool(np.max(hold[:, 5]) < config.rotation_tolerance_deg),
        "no_table_contacts_throughout_hold": bool(np.max(hold[:, 7]) == 0),
        "at_least_two_final_hand_object_contacts": final_hp >= config.minimum_final_hand_contacts,
        "finite_states_before_release": observer.finite,
        "no_warnings_before_release": bool(np.max(observer.max_warnings) == 0),
        "no_unexpected_resets_before_release": not observer.time_resets,
        "completed_five_second_hold": len(hold) == round(config.postlift_hold_s / env._model.opt.timestep),
    }
    lift_pass = all(hold_criteria.values())
    steps_before_release = observer.steps
    before_release_warning_counts = observer.max_warnings.copy()
    release_start_time = float(env._data.time)
    release_start_pose = held_pose.copy()
    opened = lifted.copy()
    opened[7:] = np.asarray(grasp["pregrasp_qpos"])[0, 7:]
    observer.begin_phase("release_open")
    move_control(env, lifted, opened, config.release_open_s)
    retreat = opened.copy()
    away = opened[:2] - held_pose[:2]
    away = away / np.linalg.norm(away) if np.linalg.norm(away) > 1e-6 else np.array([-1., 0.])
    retreat[:2] += config.retreat_m * away
    observer.begin_phase("release_retreat")
    move_control(env, opened, retreat, config.release_retreat_s)
    observer.begin_phase("release_settle")
    env.step_sim(round(config.release_settle_s / env._model.opt.timestep))
    released_pose = env.get_active_obj_pose().copy()
    released_hp, released_tp, released_bodies, _ = contact_stats(env)
    release_drop = float(release_start_pose[2] - released_pose[2])
    release_pass = bool(released_hp == 0 and released_tp > 0 and release_drop >= 0.02 and observer.finite and not observer.time_resets and np.max(observer.max_warnings) == 0)
    observer.finish()
    report = {
        "schema_version": 1, "input": str(input_path.resolve()), "input_sha256": sha256(input_path),
        "evaluator_sha256": sha256(__file__), "scene_path": grasp["scene_path"],
        "scene_id": scene["scene_id"], "template": grasp.get("tmpl_name"), "passed": lift_pass,
        "lift_hold_passed": lift_pass, "release_passed": release_pass, "full_sequence_passed": lift_pass and release_pass,
        "config": asdict(config), "dt_s": float(env._model.opt.timestep),
        "gravity_enabled": not bool(env._model.opt.disableflags & int(mujoco.mjtDisableBit.mjDSBL_GRAVITY)),
        "object_mass_kg": float(env._model.body_subtreemass[env._obj_active_bodyid]),
        "friction": [0.6, 0.02], "hand_root": "freejoint with mocap weld", "object_freejoint": True,
        "object_external_force_N": [0, 0, 0], "object_gravitational_weight_N": float(env._model.body_subtreemass[env._obj_active_bodyid]) * 9.81,
        "hold_criteria": hold_criteria, "initial_object_pose": initial_pose, "closure_object_pose": closure_pose,
        "loaded_object_pose": loaded_pose, "expected_lifted_object_pose": observer.expected_pose,
        "lift_end_object_pose": lift_end_pose, "held_object_pose": held_pose,
        "height_gain_from_initial_m": float(held_pose[2] - initial_pose[2]),
        "commanded_hand_root_lift_mm": config.lift_m * 1000,
        "measured_object_lift_mm": float(held_pose[2] - initial_pose[2]) * 1000,
        "approach_initial_root_offset_m": config.approach_offset_m * outward,
        "minimum_hold_height_gain_m": float(np.min(hold[:, 1])),
        "maximum_hold_height_gain_m": float(np.max(hold[:, 1])),
        "actual_lift_error_final_mm": float(held_pose[2] - initial_pose[2] - config.lift_m) * 1000,
        "maximum_absolute_lift_error_during_hold_mm": float(np.max(np.abs(hold[:, 1] - config.lift_m))) * 1000,
        "expected_lift_position_error_final_m": expected_error,
        "maximum_expected_position_error_during_hold_m": float(np.max(hold[:, 2])),
        "closure_rotation_final_deg": closure_rotation,
        "maximum_closure_rotation_during_hold_deg": float(np.max(hold[:, 3])),
        "postlift_hold_final_drift_m": hold_end_drift, "postlift_hold_final_rotation_deg": hold_end_rotation,
        "postlift_hold_maximum_drift_m": float(np.max(hold[:, 4])),
        "postlift_hold_maximum_rotation_deg": float(np.max(hold[:, 5])),
        "loaded_hold_maximum_drift_m": float(np.max(loaded[:, 1])),
        "loaded_hold_maximum_rotation_deg": float(np.max(loaded[:, 2])),
        "loaded_hold_contact_force_sum_mean_N": float(np.mean(loaded[:, 5])),
        "loaded_hold_contact_force_sum_min_N": float(np.min(loaded[:, 5])),
        "loaded_hold_contact_force_sum_max_N": float(np.max(loaded[:, 5])),
        "loaded_hold_peak_single_contact_normal_force_N": float(np.max(loaded[:, 6])),
        "loaded_hold_final_hand_object_contacts": int(loaded[-1, 3]),
        "loaded_hold_final_object_table_contacts": int(loaded[-1, 4]),
        "loaded_hold_label": "Clamp-force settle, gravity ON; table may support the object before lift; no added lateral forces",
        "final_hand_object_contacts": final_hp, "final_object_table_contacts": final_tp,
        "final_contact_body_names": final_bodies,
        "release": {"start_time_s": release_start_time, "final_object_pose": released_pose,
                    "drop_m": release_drop, "final_hand_contacts": released_hp, "final_table_contacts": released_tp,
                    "final_hand_contact_body_names": released_bodies,
                    "criterion": "No hand/object contacts, table contact, >=20 mm fall since opening; finite and warning/reset free"},
        "physics_steps": observer.steps, "steps_before_release": steps_before_release,
        "simulation_duration_s": float(env._data.time), "phase_boundaries": observer.phase_boundaries,
        "finite_states": observer.finite, "unexpected_time_resets": observer.time_resets,
        "warning_counts_before_release": before_release_warning_counts,
        "maximum_warning_counts": observer.max_warnings,
        "maximum_observed_penetration_m": max(observer.max_penetration, penetration),
        "trace": str((output / "trace.npz").resolve()), "trace_fps": config.trace_fps,
        "trace_source": "Actual continuous set_ctrl/mj_step execution; one reset before trial, none within phases",
        "video": str((output / "trial.mp4").resolve()) if render else None,
        "mujoco_version": mujoco.__version__,
    }
    write_json(output / "metrics.json", report)
    return report


def run_scene(job):
    config = TestConfig(**job["config"])
    paths = [Path(p) for p in job["paths"]]
    _, scene = prepare_scene(paths[0], config.mass_kg)
    env = make_env(scene, job["hand_xml"])
    scene_out = Path(job["outdir"])
    scene_out.mkdir(parents=True, exist_ok=True)
    (scene_out / "model.xml").write_text(env._spec.to_xml())
    results = []
    for input_path in paths:
        grasp = np.load(input_path, allow_pickle=True).item()
        tmpl = str(grasp.get("tmpl_name", input_path.parent.parent.name))
        output = scene_out / tmpl / input_path.stem
        try:
            old_metrics = output / "metrics.json"
            cached = json.loads(old_metrics.read_text()) if job.get("resume") and old_metrics.exists() else None
            cache_matches = cached and cached.get("input_sha256") == sha256(input_path) and cached.get("evaluator_sha256") == sha256(__file__) and cached.get("config") == asdict(config) and (output / "trace.npz").exists() and (not job["render"] or (output / "trial.mp4").exists())
            report = cached if cache_matches else evaluate_candidate(env, input_path, output, config, render=job["render"], fps=job["fps"], width=job["width"], height=job["height"])
            result = {"input": str(input_path), "metrics": str(output / "metrics.json"), "trace": str(output / "trace.npz"),
                      "passed": report["passed"], "release_passed": report["release_passed"], "full_sequence_passed": report["full_sequence_passed"],
                      "height_gain_m": report["height_gain_from_initial_m"], "hold_max_drift_m": report["postlift_hold_maximum_drift_m"],
                      "template": tmpl, "reused": bool(cache_matches), "error": None}
        except Exception:
            env.observer = None
            error = traceback.format_exc()
            output.mkdir(parents=True, exist_ok=True)
            write_json(output / "error.json", {"input": str(input_path), "traceback": error})
            result = {"input": str(input_path), "passed": False, "release_passed": False, "full_sequence_passed": False, "error": error}
        results.append(result)
        print(json.dumps({"scene": scene["scene_id"], "completed": len(results), "total": len(paths), "lift_pass": sum(r["passed"] for r in results)}), flush=True)
    summary = {"scene_id": scene["scene_id"], "config": asdict(config), "candidates": results,
               "tested": len(results), "lift_hold_passed": sum(r["passed"] for r in results),
               "release_passed": sum(r["release_passed"] for r in results), "full_sequence_passed": sum(r["full_sequence_passed"] for r in results),
               "exceptions": sum(r["error"] is not None for r in results)}
    write_json(scene_out / "summary.json", summary)
    return summary


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--grasp-root", type=Path)
    parser.add_argument("--input", type=Path)
    parser.add_argument("--outdir", type=Path)
    parser.add_argument("--scene-id")
    parser.add_argument("--hand-xml", type=Path, default=Path("/workspace/Dexonomy/assets/hand/shadow/right.xml"))
    parser.add_argument("--mass", type=float, default=0.1)
    parser.add_argument("--lift-duration", type=float, default=5.0)
    parser.add_argument("--approach-duration", type=float, default=2.0)
    parser.add_argument("--hold-duration", type=float, default=5.0)
    parser.add_argument("--loaded-hold-duration", type=float, default=1.0)
    parser.add_argument("--trace-fps", type=int, default=10)
    parser.add_argument("--render", action="store_true")
    parser.add_argument("--metrics-only", action="store_true", help="Explicit alias for the default no-video mode")
    parser.add_argument("--fps", type=int, default=25)
    parser.add_argument("--width", type=int, default=640)
    parser.add_argument("--height", type=int, default=480)
    parser.add_argument("--limit", type=int)
    parser.add_argument("--resume", action="store_true", help="Reuse only exact input/config/evaluator-hash matching completed trials")
    parser.add_argument("--workers", type=int, default=1, help="Independent scene subprocesses; model reuse remains serial within each scene")
    parser.add_argument("--worker-job", type=Path, help=argparse.SUPPRESS)
    args = parser.parse_args()
    if args.worker_job:
        return run_scene(json.loads(args.worker_job.read_text()))
    if args.outdir is None or (args.input is None and args.grasp_root is None):
        parser.error("--outdir and either --input or --grasp-root are required")
    if args.render and args.metrics_only:
        parser.error("--render and --metrics-only are mutually exclusive")
    paths = [args.input.resolve()] if args.input else sorted(args.grasp_root.resolve().rglob("*.npy"))
    if args.limit:
        paths = paths[:args.limit]
    groups = {}
    for path in paths:
        _, scene = prepare_scene(path, args.mass)
        if args.scene_id and scene["scene_id"] != args.scene_id:
            continue
        groups.setdefault(scene["scene_id"], []).append(str(path))
    if not groups:
        parser.error("No grasp candidates matched")
    config = TestConfig(mass_kg=args.mass, lift_s=args.lift_duration, postlift_hold_s=args.hold_duration,
                        approach_s=args.approach_duration, loaded_hold_s=args.loaded_hold_duration, trace_fps=args.trace_fps)
    args.outdir.mkdir(parents=True, exist_ok=True)
    jobs = []
    for scene_id, inputs in groups.items():
        output = args.outdir / scene_id
        output.mkdir(exist_ok=True)
        job = {"paths": inputs, "outdir": str(output.resolve()), "hand_xml": str(args.hand_xml.resolve()),
               "config": asdict(config), "render": args.render, "fps": args.fps, "width": args.width, "height": args.height, "resume": args.resume}
        write_json(output / "job.json", job)
        jobs.append((scene_id, output))

    def launch_scene(item):
        scene_id, output = item
        with (output / "worker.log").open("w") as log:
            proc = subprocess.run([sys.executable, str(Path(__file__).resolve()), "--worker-job", str((output / "job.json").resolve())], stdout=log, stderr=subprocess.STDOUT)
        if proc.returncode:
            raise RuntimeError(f"Scene worker exit {proc.returncode}: {output / 'worker.log'}")
        result = json.loads((output / "summary.json").read_text())
        print(json.dumps({"scene_id": scene_id, "tested": result["tested"], "passed": result["lift_hold_passed"], "exceptions": result["exceptions"]}), flush=True)
        return result

    with ThreadPoolExecutor(max_workers=max(1, args.workers)) as pool:
        summaries = list(pool.map(launch_scene, jobs))
    write_json(args.outdir / "summary.json", {"config": asdict(config), "scenes": summaries,
               "tested": sum(s["tested"] for s in summaries), "lift_hold_passed": sum(s["lift_hold_passed"] for s in summaries),
               "release_passed": sum(s["release_passed"] for s in summaries), "full_sequence_passed": sum(s["full_sequence_passed"] for s in summaries),
               "exceptions": sum(s["exceptions"] for s in summaries)})


if __name__ == "__main__":
    main()
