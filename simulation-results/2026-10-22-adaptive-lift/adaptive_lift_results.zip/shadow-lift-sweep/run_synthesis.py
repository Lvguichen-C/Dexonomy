#!/usr/bin/env python3
"""Run template/diameter initialization jobs and validate concrete outputs.

Plan format: {"defaults": {...}, "jobs": [{"tmpl_name": "...",
"diameter_mm": 20, "epoch": 1, ...}, ...]}. Each subprocess runs the original
init operation through the external CPU/serial-object-loader compatibility.
No grasp filter or optimization objective is changed. Grasp synthesis is a
separate serial bulk step after initialization completes.
"""
from __future__ import annotations

import argparse
from concurrent.futures import ThreadPoolExecutor, as_completed
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import time


DIAMETERS = (1, 5, 10, 20, 30, 40, 50, 60, 70, 80, 90, 100)


def write_json(path: Path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_suffix(path.suffix + ".tmp")
    temporary.write_text(json.dumps(value, indent=2) + "\n")
    temporary.replace(path)


def digest(path: Path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def job_config(raw, defaults):
    config = {
        "epoch": 5, "n_init_point": 1024, "n_init_inplane": 8,
        "matcher_opt_step": 100, "n_final": 10,
        **defaults, **raw,
    }
    # Accept source key spellings as well as the compact plan names.
    aliases = {"epochs": "epoch", "opt_step": "matcher_opt_step"}
    for source, destination in aliases.items():
        if source in config:
            config[destination] = config[source]
    if "tmpl_name" not in config and "template" in config:
        config["tmpl_name"] = config["template"]
    if "tmpl_name" not in config:
        raise ValueError("Each job requires tmpl_name")
    if "/" in config["tmpl_name"] or ".." in config["tmpl_name"]:
        raise ValueError("Template must be a basename")
    config["diameter_mm"] = int(config["diameter_mm"])
    if config["diameter_mm"] not in DIAMETERS:
        raise ValueError(f"Unexpected diameter: {config['diameter_mm']}")
    for key in ("epoch", "n_init_point", "n_init_inplane", "matcher_opt_step", "n_final"):
        config[key] = int(config[key])
        if config[key] < 1:
            raise ValueError(f"Invalid {key}: {config[key]}")
    return config


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--plan", type=Path, default=Path(__file__).parent / "adaptive-plan.json")
    parser.add_argument("--repo", type=Path, default=Path("/workspace/Dexonomy"))
    parser.add_argument("--previous-root", type=Path, default=Path("/workspace/shadow-reproduction"))
    parser.add_argument("--python", type=Path, default=Path("/workspace/venvs/dexonomy/bin/python"))
    parser.add_argument("--save-root", type=Path, default=Path(__file__).parent / "output")
    parser.add_argument("--exp-name", default=None)
    parser.add_argument("--asset-name", default="cylinder_sweep_20261022")
    parser.add_argument("--workers", type=int, choices=(1, 2), default=2)
    parser.add_argument("--threads-per-worker", type=int, choices=(1, 2), default=1)
    parser.add_argument("--budget", default="normal_run", help="Named recommended_budget entry, if present in the plan")
    parser.add_argument("--epoch", type=int)
    parser.add_argument("--n-init-point", type=int)
    parser.add_argument("--n-init-inplane", type=int)
    parser.add_argument("--matcher-opt-step", type=int)
    parser.add_argument("--n-final", type=int)
    parser.add_argument("--dry-run", action="store_true")
    parser.add_argument("--only-job", help="Run one template:diameter key, e.g. 24_Tip_Pinch:20")
    parser.add_argument("--status-dir", type=Path, default=Path(__file__).parent / "synthesis-status")
    args = parser.parse_args()
    plan = json.loads(args.plan.read_text())
    recommended = plan.get("recommended_budget", {}).get(args.budget, {})
    if not isinstance(recommended, dict):
        raise SystemExit("Selected recommended budget must be a dictionary")
    defaults = {**recommended, **plan.get("defaults", {})}
    exp_name = args.exp_name or defaults.get("exp_name", "diameter_sweep")
    configs = [job_config(raw, defaults) for raw in plan["jobs"]]
    forced = {key:getattr(args, key) for key in ("epoch", "n_init_point", "n_init_inplane", "matcher_opt_step", "n_final") if getattr(args, key) is not None}
    if any(value < 1 for value in forced.values()):
        raise SystemExit("Global budget overrides must be positive integers")
    for config in configs:
        config.update(forced)
    if args.only_job:
        configs = [c for c in configs if f"{c['tmpl_name']}:{c['diameter_mm']}" == args.only_job]
    if not configs:
        raise SystemExit("No initialization jobs selected")
    keys = [f"{c['tmpl_name']}:{c['diameter_mm']}" for c in configs]
    if len(keys) != len(set(keys)):
        raise SystemExit("Plan repeats a template/diameter; concurrent writes would be unsafe")
    args.status_dir.mkdir(parents=True, exist_ok=True)
    experiment = args.save_root.resolve() / f"{exp_name}_shadow"
    environment = os.environ.copy()
    environment["PYTHONPATH"] = str(args.previous_root / "runtime") + (os.pathsep + environment["PYTHONPATH"] if environment.get("PYTHONPATH") else "")
    environment.setdefault("MUJOCO_GL", "egl")
    environment["OMP_NUM_THREADS"] = str(args.threads_per_worker)
    environment["OPENBLAS_NUM_THREADS"] = str(args.threads_per_worker)
    environment["MKL_NUM_THREADS"] = str(args.threads_per_worker)
    environment.setdefault("LP_NUM_THREADS", "1")
    environment.setdefault("WARP_CACHE_PATH", "/workspace/.cache/warp")
    prepared = []
    for index, config in enumerate(configs):
        template, diameter = config["tmpl_name"], config["diameter_mm"]
        scene = Path(config.get("scene_path", args.repo / f"assets/object/{args.asset_name}/scene_cfg/cylinder_thin/table_top/d{diameter}.npy"))
        template_file = args.repo / f"assets/hand/shadow/init_tmpl/{template}.npy"
        if not scene.is_file() or not template_file.is_file():
            raise SystemExit(f"Missing asset/template: {scene} or {template_file}")
        log_id = f"sweep_{index:03d}_d{diameter}_{template}"
        command = [str(args.python), str(args.previous_root / "run_pipeline.py"),
            "op=init", "hand=shadow", f"exp_name={exp_name}",
            f"tmpl_name={template}", "n_worker=1", "tmpl_upd_mode=disabled",
            f"save_root={args.save_root.resolve()}", "skip_traj=True", "skip_done=True",
            "debug_view=False", "debug_render=False", "obj_mass=0.1",
            "op.device=cpu", f"op.epoch={config['epoch']}",
            f"op.object.n_init_point={config['n_init_point']}",
            f"op.object.n_init_inplane={config['n_init_inplane']}",
            f"op.matcher.opt_step={config['matcher_opt_step']}",
            f"op.filter.general.n_final={config['n_final']}",
            "op.object.batch_size=1", "op.object.n_cfg=1",
            f"op.object.cfg_path={scene.resolve()}", f"log_id={log_id}"]
        scene_id = config.get("scene_id", f"cylinder_thin_table_{diameter}")
        output = experiment / "init_data" / template / scene_id
        prepared.append({"key": keys[index], "config": config, "command": command,
            "cwd": str(args.repo.resolve()), "output": str(output),
            "stdout_log": str(args.status_dir / f"{index:03d}_d{diameter}_{template}.stdout.log"),
            "status_file": str(args.status_dir / f"{index:03d}_d{diameter}_{template}.json"),
            "scene_sha256": digest(scene), "template_sha256": digest(template_file)})
    manifest = {"plan": str(args.plan.resolve()), "plan_sha256": digest(args.plan),
        "experiment": str(experiment), "created_at_utc": datetime.now(timezone.utc).isoformat(),
        "workers": args.workers, "threads_per_worker": args.threads_per_worker,
        "budget": args.budget, "global_budget_overrides": forced,
        "object_loader_workers": 0, "hand_template_workers": 1,
        "dry_run": args.dry_run, "jobs": prepared}
    write_json(args.status_dir / "launch-manifest.json", manifest)
    if args.dry_run:
        print(json.dumps({"dry_run": True, "jobs": len(prepared), "launch_manifest": str(args.status_dir / "launch-manifest.json")}, indent=2))
        return

    def execute(job):
        started = time.monotonic()
        output = Path(job["output"])
        before = len(list(output.glob("*.npy")))
        print(json.dumps({"event": "start", "key": job["key"], "existing_initializations": before}), flush=True)
        with Path(job["stdout_log"]).open("w") as log:
            proc = subprocess.run(job["command"], cwd=job["cwd"], env=environment, stdout=log, stderr=subprocess.STDOUT)
        text = Path(job["stdout_log"]).read_text(errors="replace")
        counts = {str(epoch):len(list(output.glob(f"{epoch}_*_grasp.npy"))) for epoch in range(job["config"]["epoch"])}
        expected = job["config"]["n_final"]
        complete = all(n >= expected for n in counts.values())
        has_traceback = "Traceback (most recent call last)" in text
        success = proc.returncode == 0 and complete and not has_traceback
        status = {**job, "returncode": proc.returncode, "wall_time_s": time.monotonic()-started,
            "initializations_before": before, "initializations_after": len(list(output.glob("*.npy"))),
            "per_epoch_counts": counts, "expected_min_per_epoch": expected,
            "contains_traceback": has_traceback, "successful": success,
            "completed_at_utc": datetime.now(timezone.utc).isoformat()}
        write_json(Path(job["status_file"]), status)
        print(json.dumps({"event": "complete", "key": job["key"], "successful": success,
                          "per_epoch_counts": counts, "wall_time_s": round(status["wall_time_s"], 2)}), flush=True)
        return status

    results = []
    with ThreadPoolExecutor(max_workers=args.workers) as pool:
        futures = [pool.submit(execute, job) for job in prepared]
        for future in as_completed(futures):
            results.append(future.result())
            write_json(args.status_dir / "progress.json", {"total_jobs":len(prepared), "completed_jobs":len(results), "successful_jobs":sum(r["successful"] for r in results), "results":results})
    summary = {"total_jobs":len(prepared), "successful_jobs":sum(r["successful"] for r in results),
               "failed_jobs":[r["key"] for r in results if not r["successful"]], "results":results}
    write_json(args.status_dir / "summary.json", summary)
    print(json.dumps({k:v for k,v in summary.items() if k!="results"}, indent=2))
    if summary["failed_jobs"]:
        raise SystemExit(1)


if __name__ == "__main__":
    main()
