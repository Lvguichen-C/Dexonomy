# Model export provenance

`construction_model.xml` preserves the original MjSpec construction snapshot byte-for-byte. That snapshot disabled gravity before `evaluate_lifts.make_env` enabled gravity on the compiled runtime model.

`model.xml` now records the actual runtime gravity setting (`0 0 -9.81`, enabled). It has been recompiled and checked for 4 ms timestep and 0.1 kg object mass. No trajectory was re-simulated or reclassified by this export operation. The hand's runtime red recoloring is visual only and is not required for the physical configuration. Per-candidate poses and controls remain in the recorded NPZ traces.
