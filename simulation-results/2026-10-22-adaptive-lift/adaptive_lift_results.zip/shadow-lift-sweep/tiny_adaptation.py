#!/usr/bin/env python3
"""Controlled tiny-object optimization trials; native filters stay unchanged.

Only this process receives the optimization adapter. It never edits tracked
Dexonomy source, the main sweep pool, physical evaluation, or stored inputs.
"""
from __future__ import annotations

import argparse
import atexit
from collections import Counter
from dataclasses import replace
import hashlib
import json
from pathlib import Path
import runpy
import shutil
import subprocess
import sys

import numpy as np


ROOT = Path("/workspace/shadow-lift-sweep")
MODES = ["baseline", "scaled_plane", "scaled_plane_full20"]


def hash_file(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def worker(args):
    import dexonomy.op.gen_grasp as module

    evidence = []
    native_env = module.MuJoCo_OptEnv
    original_early_stop = module.GraspFilter.early_stop

    class AdaptedOptEnv(native_env):
        def __init__(self, *positional, **kwargs):
            scene = kwargs["scene_cfg"]
            obj = scene["scene"][scene["task"]["obj_name"]]
            # The canonical model has height4. The current generated scene
            # metadata and geometry manifest record this exact extent.
            height = 4 * float(np.asarray(obj["scale"])[2])
            config = kwargs["sim_cfg"]
            old_plane = float(config.plane_margin)
            if args.worker != "baseline":
                config = replace(config, plane_margin=min(old_plane, 0.1 * height))
                kwargs["sim_cfg"] = config
            if args.worker == "scaled_all_full200":
                assert scene["scene_id"] == "cylinder_thin_table_1"
                config = replace(config, hand_margin=0.0001)
                kwargs["sim_cfg"] = config
            evidence.append({
                "scene_id": scene["scene_id"], "object_height_m": height,
                "old_plane_margin_m": old_plane,
                "new_plane_margin_m": float(config.plane_margin),
                "hand_margin_m": float(config.hand_margin),
                "initial_object_margin_m": float(config.obj_margin),
                "timestep_s": float(config.timestep),
            })
            super().__init__(*positional, **kwargs)

    module.MuJoCo_OptEnv = AdaptedOptEnv
    full_budget = args.worker in {"scaled_plane_full20", "scaled_plane_full200", "scaled_all_full200"}
    step_budget = 200 if args.worker in {"scaled_plane_full200", "scaled_all_full200"} else 20
    if full_budget:
        def early_stop(self):
            if "contact" in self.cfg:
                return False
            return original_early_stop(self)
        module.GraspFilter.early_stop = early_stop

    audit_dir = args.outdir / args.worker / "audit"
    audit_dir.mkdir(parents=True, exist_ok=True)

    @atexit.register
    def save_settings():
        (args.outdir / args.worker / "optimization-settings.json").write_text(json.dumps({
            "mode": args.worker, "native_filters_unchanged": True,
            "grasp_early_stop_disabled": full_budget,
            "grasp_step_budget": step_budget, "pregrasp_early_stop_unchanged": True,
            "environments": evidence,
        }, indent=2) + "\n")

    sys.argv = ["audit_grasp.py", "--audit-dir", str(audit_dir),
        "op=grasp", "hand=shadow", f"exp_name={args.worker}", "n_worker=1",
        "tmpl_upd_mode=disabled", "skip_done=False",
        f"save_root={args.outdir / 'output'}", f"op.grasp.step={step_budget}",
        "debug_view=False", "debug_render=False"]
    if args.worker == "scaled_all_full200":
        sys.argv.append("op.grasp.cdist=0.0001")
    runpy.run_path("/workspace/shadow-reproduction/audit_grasp.py", run_name="__main__")


def summarize(args):
    summary = {"source_experiment": str(args.source_exp), "diameters_mm": args.diameters,
               "same_initial_proposals": True, "native_filter_thresholds_unchanged": True,
               "physical_eval_parameters_unchanged": True, "modes": {}}
    for mode in MODES:
        audit_dir = args.outdir / mode / "audit"
        records = []
        for path in audit_dir.glob("*.json"):
            if path.name != "summary.json":
                records.append(json.loads(path.read_text()))
        groups = {}
        for diameter in args.diameters:
            subset = [r for r in records if f"cylinder_thin_table_{diameter}/" in r["input_path"]]
            final_diff = [float(np.max(r["contact_force_iterations"][-1]["contact_differences"]))
                          for r in subset if r["contact_force_iterations"]]
            ho_counts = [r["contacts"][-1]["hand_object"]["count"] for r in subset if r["contacts"]]
            groups[str(diameter)] = {
                "trials": len(subset),
                "saved_grasps": sum(bool(r["output_exists_after"]) for r in subset),
                "rejection_counts": dict(Counter(
                    f"{r['rejection']['phase']}/{r['rejection']['filter']}" if r["rejection"] else "saved"
                    for r in subset)),
                "iterations": dict(Counter(str(r["grasp_iterations_used"]) for r in subset)),
                "median_final_target_gap_m": float(np.median(final_diff)) if final_diff else None,
                "minimum_final_target_gap_m": float(np.min(final_diff)) if final_diff else None,
                "maximum_actual_contact_count": max(ho_counts, default=0),
                "qp_residuals": [q["wrench_error"] for r in subset for q in r["qp_solves"]],
                "warnings": sum(len(r["warnings"]) for r in subset),
                "valid_grasp_paths": [r["output_path"] for r in subset if r["output_exists_after"]],
            }
        summary["modes"][mode] = groups
    (args.outdir / "comparison.json").write_text(json.dumps(summary, indent=2) + "\n")
    print(json.dumps(summary, indent=2))


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--source-exp", type=Path, default=ROOT / "output/diameter_sweep_shadow")
    parser.add_argument("--outdir", type=Path, default=ROOT / "tiny-adaptation")
    parser.add_argument("--diameters", type=int, nargs="+", default=[1, 5])
    parser.add_argument("--worker", choices=MODES + ["scaled_plane_full200", "scaled_all_full200"])
    parser.add_argument("--summarize-only", action="store_true")
    args = parser.parse_args()
    if args.worker:
        return worker(args)
    args.outdir.mkdir(parents=True, exist_ok=True)
    if args.summarize_only:
        return summarize(args)
    source = args.source_exp / "init_data"
    inputs = sorted(p for diameter in args.diameters
                    for p in source.glob(f"*/cylinder_thin_table_{diameter}/*.npy"))
    if not inputs:
        raise SystemExit("No complete initial proposals matched")
    snapshots = []
    for mode in MODES:
        dest = args.outdir / "output" / f"{mode}_shadow/init_data"
        for path in inputs:
            target = dest / path.relative_to(source)
            target.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(path, target)
            assert hash_file(path) == hash_file(target)
            snapshots.append({"mode": mode, "input": str(path), "copy": str(target), "sha256": hash_file(path)})
    (args.outdir / "input-snapshot.json").write_text(json.dumps(snapshots, indent=2) + "\n")
    for mode in MODES:
        logfile = args.outdir / mode / "process.log"
        logfile.parent.mkdir(parents=True, exist_ok=True)
        with logfile.open("w") as stream:
            subprocess.run([sys.executable, str(Path(__file__).resolve()), "--worker", mode,
                            "--outdir", str(args.outdir)], stdout=stream, stderr=subprocess.STDOUT,
                           check=True, cwd="/workspace/Dexonomy")
        print(json.dumps({"mode_completed": mode, "initial_proposals": len(inputs)}), flush=True)
    summarize(args)


if __name__ == "__main__":
    main()
