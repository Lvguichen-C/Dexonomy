#!/usr/bin/env python3
"""Validate sweep deliverables locally; publish only with explicit --publish.

Uses gh's existing credential provider, never reads or prints secret values.
The authorized result branch is advanced without force; source main is untouched.
"""
from __future__ import annotations

import argparse
import base64
import hashlib
import json
from pathlib import Path
import subprocess
import tempfile
from urllib.parse import quote


def sha256(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def gh_json(arguments, payload=None):
    if payload is None:
        result = subprocess.run(["gh", *arguments], capture_output=True, text=True, check=True)
    else:
        with tempfile.NamedTemporaryFile("w", suffix=".json", encoding="utf-8") as stream:
            json.dump(payload, stream, ensure_ascii=False)
            stream.flush()
            result = subprocess.run(["gh", *arguments, "--input", stream.name], capture_output=True, text=True, check=True)
    return json.loads(result.stdout) if result.stdout.strip() else None


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--deliverables", type=Path, default=Path("/workspace/shadow-lift-sweep/deliverables"))
    parser.add_argument("--repo", default="Lvguichen-C/Dexonomy")
    parser.add_argument("--branch", default="mujoco-animation-results-20261016-assets")
    parser.add_argument("--prefix", default="simulation-results/2026-10-22-adaptive-lift")
    parser.add_argument("--release-tag", default="shadow-adaptive-lift-sweep-20261022")
    parser.add_argument("--release-title", default="Shadow 自适应圆柱抓取、抬升与释放：12 种直径")
    parser.add_argument("--publish", action="store_true")
    parser.add_argument("--skip-release", action="store_true")
    args = parser.parse_args()
    folder = args.deliverables.resolve()
    manifest_path = folder / "delivery_manifest.json"
    manifest = json.loads(manifest_path.read_text())
    if args.branch in {"main", "master"}:
        raise SystemExit("Result files must not be published to the source branch")
    if args.prefix.startswith("/") or ".." in Path(args.prefix).parts:
        raise SystemExit("Invalid destination prefix")
    rows = list(manifest["files"])
    if len({row["name"] for row in rows}) != len(rows):
        raise SystemExit("Duplicate delivery filenames")
    for row in rows:
        name = row["name"]
        if name != Path(name).name:
            raise SystemExit("Deliveries must have plain filenames")
        path = folder / name
        if path.is_symlink() or not path.is_file() or path.stat().st_size != row["bytes"] or sha256(path) != row["sha256"]:
            raise SystemExit(f"Delivery integrity failure: {name}")
        if path.stat().st_size >= 95_000_000:
            raise SystemExit(f"Delivery exceeds the 95 MB upload cap: {name}")
    rows.append({"name": manifest_path.name, "bytes": manifest_path.stat().st_size, "sha256": sha256(manifest_path)})
    state = folder.parent / "publication-state"
    state.mkdir(exist_ok=True)
    plan = {"repo": args.repo, "branch": args.branch, "prefix": args.prefix, "release_tag": args.release_tag, "files": rows}
    (state / "plan.json").write_text(json.dumps(plan, ensure_ascii=False, indent=2) + "\n")
    if not args.publish:
        print(json.dumps({"published": False, "local_validation": "passed", "plan": str(state / "plan.json"), "files": len(rows), "total_bytes": sum(row["bytes"] for row in rows)}, ensure_ascii=False, indent=2))
        return
    api = f"repos/{args.repo}"
    parent = gh_json(["api", f"{api}/git/ref/heads/{quote(args.branch, safe='/')}"])["object"]["sha"]
    before_main = gh_json(["api", f"{api}/git/ref/heads/main"])["object"]["sha"]
    parent_commit = gh_json(["api", f"{api}/git/commits/{parent}"])
    tree_rows = []
    for row in rows:
        content = (folder / row["name"]).read_bytes()
        expected = hashlib.sha1(f"blob {len(content)}\0".encode() + content).hexdigest()
        blob = gh_json(["api", "--method", "POST", f"{api}/git/blobs"], {"content": base64.b64encode(content).decode("ascii"), "encoding": "base64"})
        if blob["sha"] != expected:
            raise SystemExit(f"Remote blob integrity mismatch: {row['name']}")
        row["git_blob_sha"] = expected
        tree_rows.append({"path": f"{args.prefix}/{row['name']}", "mode": "100644", "type": "blob", "sha": expected})
    tree = gh_json(["api", "--method", "POST", f"{api}/git/trees"], {"base_tree": parent_commit["tree"]["sha"], "tree": tree_rows})
    commit = gh_json(["api", "--method", "POST", f"{api}/git/commits"], {"message": "Add adaptive Shadow cylinder lift-hold-release sweep and all diameter animations", "tree": tree["sha"], "parents": [parent]})
    gh_json(["api", "--method", "PATCH", f"{api}/git/refs/heads/{quote(args.branch, safe='/')}"], {"sha": commit["sha"], "force": False})
    after_main = gh_json(["api", f"{api}/git/ref/heads/main"])["object"]["sha"]
    for row in rows:
        path = quote(f"{args.prefix}/{row['name']}")
        row["raw_url"] = f"https://raw.githubusercontent.com/{args.repo}/{commit['sha']}/{path}"
        row["view_url"] = f"https://github.com/{args.repo}/blob/{commit['sha']}/{path}"
    publication = {**plan, "published": True, "parent_commit": parent, "commit": commit["sha"], "main_before": before_main, "main_after": after_main, "main_unchanged": before_main == after_main, "release_updated": False}
    publication_path = folder.parent / "publication.json"
    publication_path.write_text(json.dumps(publication, ensure_ascii=False, indent=2) + "\n")
    if not args.skip_release:
        try:
            release = gh_json(["api", f"{api}/releases/tags/{quote(args.release_tag, safe='')}"])
        except subprocess.CalledProcessError as error:
            if "HTTP 404" not in (error.stderr or ""):
                raise
            release = None
        body = (release.get("body") or "") if release else ""
        begin, end = "<!-- adaptive-lift:start -->", "<!-- adaptive-lift:end -->"
        if begin in body:
            before, marked = body.split(begin, 1)
            if end not in marked:
                raise SystemExit("Existing release marker is incomplete; branch published, release not changed")
            _, after = marked.split(end, 1)
            body = (before.rstrip() + "\n" + after.lstrip()).strip()
        by_name = {row["name"]: row for row in rows}
        block = begin + "\n\n## 自适应抓取、提升 100 mm、持握 5 秒与释放\n\n"
        block += "重力全程开启。每个尺寸按物体几何提出多种抓型，再根据实际仿真结果选择展示样本；全部候选统计和失败保存在完整包中。\n\n"
        main_links = [("12 种直径总览动画", "all_12_diameters.mp4"), ("复现方法与实际结果报告", "ADAPTIVE_LIFT_REPORT.md"), ("完整数值结果 JSON", "adaptive_lift_summary.json"), ("方法与协议审查", "PROTOCOL_REVIEW.md"), ("提升阶段采样复核", "motion-protocol-summary.json")]
        for label, name in main_links:
            if name in by_name:
                block += f"- [{label}]({by_name[name]['raw_url']})\n"
        archive_rows = [row for row in rows if row["name"].endswith(".zip")]
        for row in archive_rows:
            block += f"- [完整结果包：{row['name']}]({row['raw_url']})\n"
        block += "\n### 各直径动画\n\n"
        for d in [1, 5, 10, 20, 30, 40, 50, 60, 70, 80, 90, 100]:
            name = f"d{d:03d}_full_sequence.mp4"
            if name in by_name:
                block += f"- [直径 {d} mm]({by_name[name]['raw_url']})\n"
        block += "\n以上链接指向固定提交中的真实文件。无可执行轨迹的直径会显示诊断卡片；实际成功判据以 JSON 为准。5 秒提升稳定性按保存轨迹样本（通常 10 Hz 加阶段边界）复核；到位后 5 秒持握按每个 4 ms 物理步（250 Hz）检查。采样门不证明未保存提升子步。原评价器结果仍保留，最终通过数另需通过提升采样门。动画为实际物理状态的回放，不以逐帧渲染代替动力学验证。\n\n" + end
        notes = (body.rstrip() + "\n\n" + block + "\n").lstrip()
        notes_path = state / "release-notes.md"
        notes_path.write_text(notes)
        if release is None:
            release = gh_json(["api", "--method", "POST", f"{api}/releases"], {"tag_name": args.release_tag, "target_commitish": commit["sha"], "name": args.release_title, "body": notes, "draft": False, "prerelease": False})
        else:
            subprocess.run(["gh", "release", "edit", args.release_tag, "--repo", args.repo, "--notes-file", str(notes_path)], check=True)
        publication.update({"release_updated": True, "release_url": release["html_url"], "release_id": release["id"]})
        publication_path.write_text(json.dumps(publication, ensure_ascii=False, indent=2) + "\n")
    print(json.dumps({"published": True, "commit": publication["commit"], "files": len(rows), "main_unchanged": publication["main_unchanged"], "release_url": publication.get("release_url"), "publication": str(publication_path)}, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
