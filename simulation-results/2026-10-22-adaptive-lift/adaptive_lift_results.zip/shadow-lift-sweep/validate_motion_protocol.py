#!/usr/bin/env python3
"""Audit sampled physical lift trajectories, without re-running simulation.

Run after evaluation workers finish. Without --apply this only writes an audit
summary and an asset-dependency fingerprint. With --apply it preserves the
frozen evaluator's outcomes and adds a sampled-lift gate to final outcome flags.
The stored traces normally have 10 Hz samples plus exact phase boundaries;
these checks do not claim to observe unsaved 250 Hz physics states.
"""
from __future__ import annotations

import argparse
from collections import Counter
from dataclasses import asdict, dataclass
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import subprocess

import numpy as np


@dataclass(frozen=True)
class AuditConfig:
    maximum_position_error_m: float = 0.02
    maximum_rotation_deg: float = 15.0
    maximum_downward_excursion_m: float = 0.002
    minimum_hand_object_contact_points: int = 2
    position_numerical_allowance_m: float = 1e-6
    rotation_numerical_allowance_deg: float = 1e-3
    boundary_time_allowance_s: float = 1e-4


def sha256(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def read(path):
    return json.loads(Path(path).read_text())


def write(path, value):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_name(path.name + ".motion-audit.tmp")
    temporary.write_text(json.dumps(value, indent=2, ensure_ascii=False) + "\n")
    temporary.replace(path)


def fingerprint(root, repo, metrics):
    dependencies = {}
    manifest = root / "assets-manifest.json"
    if manifest.is_file():
        dependencies[str(manifest.resolve())] = sha256(manifest)
    hand = repo / "assets/hand/shadow/right.xml"
    if hand.is_file():
        dependencies[str(hand.resolve())] = sha256(hand)
    seen_scenes = set()
    for record in metrics:
        scene_path = record.get("scene_path")
        if not scene_path and Path(record["input"]).is_file():
            scene_path = np.load(record["input"], allow_pickle=True).item().get("scene_path")
        if not scene_path:
            continue
        scene_path = Path(scene_path).resolve()
        if scene_path in seen_scenes:
            continue
        seen_scenes.add(scene_path)
        dependencies[str(scene_path)] = sha256(scene_path)
        scene = np.load(scene_path, allow_pickle=True).item()

        def visit(value):
            if isinstance(value, dict):
                for key, item in value.items():
                    if isinstance(item, (dict, list, tuple)):
                        visit(item)
                    elif key.endswith("_path") and isinstance(item, str):
                        path = (scene_path.parent / item).resolve()
                        if path.is_file():
                            dependencies[str(path)] = sha256(path)
            elif isinstance(value, (list, tuple)):
                for item in value:
                    visit(item)

        visit(scene)
    try:
        menagerie = subprocess.check_output(
            ["git", "-C", str(repo / "third_party/mujoco_menagerie"), "rev-parse", "HEAD"],
            text=True, stderr=subprocess.DEVNULL,
        ).strip()
    except subprocess.CalledProcessError:
        menagerie = None
    content = {"files": dict(sorted(dependencies.items())), "mujoco_menagerie_commit": menagerie}
    content["fingerprint_sha256"] = hashlib.sha256(json.dumps(content, sort_keys=True).encode()).hexdigest()
    return content


def quat_angles_deg(quaternions, reference):
    quaternions = np.asarray(quaternions, dtype=np.float64)
    reference = np.asarray(reference, dtype=np.float64)
    denominator = np.linalg.norm(quaternions, axis=1) * np.linalg.norm(reference)
    cosine = np.abs(quaternions @ reference) / np.maximum(denominator, 1e-30)
    return np.degrees(2 * np.arccos(np.clip(cosine, 0.0, 1.0)))


def finite_float(value):
    value = float(value)
    return value if np.isfinite(value) else None


def audit_record(record, config):
    trace_path = Path(record["trace"])
    with np.load(trace_path, allow_pickle=False) as archive:
        times = np.asarray(archive["time_s"], dtype=np.float64)
        poses = np.asarray(archive["object_pose"], dtype=np.float64)
        contacts = np.asarray(archive["hand_object_contacts"], dtype=np.int64)
        table_contacts = np.asarray(archive["object_table_contacts"], dtype=np.int64)
        qpos_finite = bool(np.isfinite(archive["qpos"]).all())
    boundaries = record["phase_boundaries"]
    start = next(float(row["time_s"]) for row in boundaries if row["phase"] == "lift")
    end = next(float(row["time_s"]) for row in boundaries if row["phase"] == "postlift_hold")
    allowance = config.boundary_time_allowance_s
    selected = (times >= start - allowance) & (times <= end + allowance)
    index = np.flatnonzero(selected)
    if len(index) < 2:
        raise ValueError("Lift trace has fewer than two states")
    lift_times, lift_poses = times[index], poses[index]
    relative_time = np.clip((lift_times - start) / float(record["config"]["lift_s"]), 0.0, 1.0)
    fraction = relative_time * relative_time * (3.0 - 2.0 * relative_time)
    reference = np.asarray(record["closure_object_pose"], dtype=np.float64)
    desired = np.repeat(reference[None, :3], len(index), axis=0)
    desired[:, 2] += float(record["config"]["lift_m"]) * fraction
    position_errors = np.linalg.norm(lift_poses[:, :3] - desired, axis=1)
    rotation_errors = quat_angles_deg(lift_poses[:, 3:7], reference[3:7])
    z = lift_poses[:, 2]
    downward_steps = np.maximum(0.0, -np.diff(z))
    # Drawdown measures total slip from any previously reached height. It is
    # meaningful across trace rates; a per-frame velocity threshold would not be.
    downward_excursions = np.maximum.accumulate(z) - z
    finite = bool(qpos_finite and np.isfinite(times).all() and np.isfinite(poses).all()
                  and np.isfinite(position_errors).all() and np.isfinite(rotation_errors).all())
    positive_gaps = np.diff(lift_times)
    positive_gaps = positive_gaps[positive_gaps > allowance]
    source_hz = float(record.get("trace_fps", record["config"].get("trace_fps", 10)))
    maximum_gap = float(positive_gaps.max()) if len(positive_gaps) else float("inf")
    checks = {
        "sampled_states_finite": finite,
        "sampled_time_nondecreasing": bool(np.all(np.diff(times) >= -allowance)),
        "lift_start_boundary_recorded": bool(np.min(np.abs(lift_times - start)) <= allowance),
        "lift_end_boundary_recorded": bool(np.min(np.abs(lift_times - end)) <= allowance),
        "sampled_full_five_second_lift": abs((end - start) - float(record["config"]["lift_s"])) <= allowance,
        "sample_spacing_matches_declared_rate": maximum_gap <= 1.0 / source_hz + 2 * allowance,
        "smooth_lift_position_tracking": bool(np.max(position_errors) <= config.maximum_position_error_m + config.position_numerical_allowance_m),
        "lifting_orientation_stable": bool(np.max(rotation_errors) <= config.maximum_rotation_deg + config.rotation_numerical_allowance_deg),
        "no_downward_excursion_above_tolerance": bool(np.max(downward_excursions) <= config.maximum_downward_excursion_m + config.position_numerical_allowance_m),
        "at_least_two_hand_object_contact_points_in_lift_samples": bool(np.min(contacts[index]) >= config.minimum_hand_object_contact_points),
    }
    return {
        "schema_version": 1,
        "passed": all(checks.values()),
        "checks": checks,
        "thresholds": asdict(config),
        "trace_sha256": sha256(trace_path),
        "sampled_scope": "Recorded physical states at trace_fps plus phase boundaries; unsaved physics substeps are not reclassified",
        "trace_fps": source_hz,
        "lift_sample_count_including_boundary_duplicates": len(index),
        "lift_start_time_s": start,
        "lift_end_time_s": end,
        "maximum_time_gap_s": finite_float(maximum_gap),
        "maximum_smoothstep_position_error_mm": finite_float(np.max(position_errors) * 1000),
        "maximum_closure_relative_rotation_deg": finite_float(np.max(rotation_errors)),
        "largest_adjacent_sample_downward_step_mm": finite_float(np.max(downward_steps) * 1000),
        "maximum_downward_excursion_from_reached_height_mm": finite_float(np.max(downward_excursions) * 1000),
        "minimum_lift_hand_object_contact_points": int(np.min(contacts[index])),
        "lift_table_contact_samples": int(np.count_nonzero(table_contacts[index])),
        "contact_semantics": "Contact points, not unique fingers; table contacts may occur at the start before liftoff",
    }


def original_outcomes(record):
    if "base_evaluator_outcomes" in record:
        return record["base_evaluator_outcomes"]
    return {key: bool(record.get(key)) for key in ("passed", "lift_hold_passed", "release_passed", "full_sequence_passed")}


def update_summaries(evaluation, updates):
    scenes = []
    for path in sorted(evaluation.glob("*/summary.json")):
        scene = read(path)
        for row in scene.get("candidates", []):
            update = updates.get(str(Path(row["input"]).resolve()))
            if not update:
                continue
            row.setdefault("base_evaluator_outcomes", update["base_evaluator_outcomes"])
            row.update({key: update[key] for key in ("passed", "release_passed", "full_sequence_passed")})
            row["sampled_lift_stability_passed"] = update["sampled_lift_stability_passed"]
        scene["lift_hold_passed"] = sum(bool(row.get("passed")) for row in scene.get("candidates", []))
        scene["release_passed"] = sum(bool(row.get("release_passed")) for row in scene.get("candidates", []))
        scene["full_sequence_passed"] = sum(bool(row.get("full_sequence_passed")) for row in scene.get("candidates", []))
        scene["motion_protocol_postprocessed"] = True
        write(path, scene)
        scenes.append(scene)
    aggregate = evaluation / "summary.json"
    if aggregate.is_file():
        value = read(aggregate)
        value["scenes"] = scenes
        for key in ("tested", "lift_hold_passed", "release_passed", "full_sequence_passed", "exceptions"):
            value[key] = sum(int(scene.get(key, 0)) for scene in scenes)
        value["motion_protocol_postprocessed"] = True
        write(aggregate, value)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root", type=Path, default=Path("/workspace/shadow-lift-sweep"))
    parser.add_argument("--evaluation-root", type=Path, default=Path("/workspace/shadow-lift-sweep/lift-evaluation"))
    parser.add_argument("--repo", type=Path, default=Path("/workspace/Dexonomy"))
    parser.add_argument("--apply", action="store_true", help="Only use after evaluation workers have finished")
    parser.add_argument("--maximum-position-error-mm", type=float, default=20.0)
    parser.add_argument("--maximum-rotation-deg", type=float, default=15.0)
    parser.add_argument("--maximum-downward-excursion-mm", type=float, default=2.0)
    parser.add_argument("--minimum-contact-points", type=int, default=2)
    args = parser.parse_args()
    config = AuditConfig(maximum_position_error_m=args.maximum_position_error_mm / 1000,
                         maximum_rotation_deg=args.maximum_rotation_deg,
                         maximum_downward_excursion_m=args.maximum_downward_excursion_mm / 1000,
                         minimum_hand_object_contact_points=args.minimum_contact_points)
    loaded, loading_errors = [], []
    for path in sorted(args.evaluation_root.rglob("metrics.json")):
        try:
            record = read(path)
            if record.get("schema_version") == 1 and "hold_criteria" in record:
                loaded.append((path, record))
        except Exception as error:
            loading_errors.append({"metrics": str(path), "error": str(error)})
    dependencies = fingerprint(args.root, args.repo, [record for _, record in loaded])
    baseline_path = args.root / "motion-protocol-dependency-baseline.json"
    if baseline_path.exists():
        baseline = read(baseline_path)
        # New scene files may be added as later diameters are evaluated. Check
        # every dependency already recorded, rather than rejecting safe growth.
        unchanged = (baseline.get("mujoco_menagerie_commit") == dependencies["mujoco_menagerie_commit"]
                     and all(dependencies["files"].get(path) == value for path, value in baseline.get("files", {}).items()))
    else:
        baseline, unchanged = dependencies, True
    if args.apply and not unchanged:
        raise SystemExit("Asset dependencies changed since the audit baseline. Invalidate affected simulation caches and re-evaluate in a fresh evaluation directory before applying.")
    if unchanged:
        write(baseline_path, dependencies)
    rows, updates, failures = [], {}, Counter()
    for path, record in loaded:
        base = original_outcomes(record)
        try:
            result = audit_record(record, config)
        except Exception as error:
            result = {"schema_version": 1, "passed": False, "error": str(error), "checks": {"trace_audit_completed": False}, "thresholds": asdict(config)}
        for key, value in result.get("checks", {}).items():
            if not value:
                failures[key] += 1
        final_lift = base["lift_hold_passed"] and result["passed"]
        final_full = base["full_sequence_passed"] and result["passed"]
        record["base_evaluator_outcomes"] = base
        record["base_lift_hold_passed"] = base["lift_hold_passed"]
        record["base_full_sequence_passed"] = base["full_sequence_passed"]
        record["motion_protocol"] = result
        record["sampled_lift_stability_passed"] = result["passed"]
        record["passed"] = record["lift_hold_passed"] = final_lift
        record["release_passed"] = base["release_passed"]
        record["full_sequence_passed"] = final_full
        if args.apply:
            write(path, record)
        updates[str(Path(record["input"]).resolve())] = record
        rows.append({"input": record["input"], "metrics": str(path.resolve()), "base_lift_hold_passed": base["lift_hold_passed"],
                     "base_full_sequence_passed": base["full_sequence_passed"], "sampled_lift_stability_passed": result["passed"],
                     "lift_hold_passed": final_lift, "full_sequence_passed": final_full, **result})
    if args.apply:
        update_summaries(args.evaluation_root, updates)
    summary = {
        "schema_version": 1, "generated_at_utc": datetime.now(timezone.utc).isoformat(), "applied": args.apply,
        "evaluation_root": str(args.evaluation_root.resolve()), "postprocessor_sha256": sha256(__file__),
        "thresholds": asdict(config), "candidate_count": len(rows),
        "base_lift_hold_passed": sum(row["base_lift_hold_passed"] for row in rows),
        "base_full_sequence_passed": sum(row["base_full_sequence_passed"] for row in rows),
        "sampled_lift_stability_passed": sum(row["sampled_lift_stability_passed"] for row in rows),
        "final_lift_hold_passed": sum(row["lift_hold_passed"] for row in rows),
        "final_full_sequence_passed": sum(row["full_sequence_passed"] for row in rows),
        "failed_sampled_criteria": dict(failures), "unreadable_metrics": loading_errors,
        "dependency_baseline_unchanged": unchanged, "dependencies": dependencies,
        "scope": "Sampled lift gate at recorded trace rate; original every-physics-step postlift hold and release outcomes remain preserved",
        "downward_tolerance_interpretation": "At most 2 mm total retreat from an already reached height during lift (default 2% of 100 mm command). This is an operational monotonicity tolerance, not a universal physical velocity limit.",
        "dependency_limit": "Fingerprint records dependencies at audit time. The evaluator cache itself does not hash referenced scene/mesh/hand files; it must be invalidated if these dependencies change. This fingerprint cannot retroactively prove an earlier unseen asset state.",
        "candidates": rows,
    }
    write(args.root / "motion-protocol-summary.json", summary)
    print(json.dumps({key: value for key, value in summary.items() if key not in ("candidates", "dependencies")}, indent=2))


if __name__ == "__main__":
    main()
