#!/usr/bin/env python3
"""Finalize archived model XML after all evaluation workers have finished.

Evaluation correctly enables gravity on the compiled MuJoCo model. Its original
model.xml was a construction-spec snapshot taken before that runtime setting.
This tool preserves the construction snapshot byte-for-byte, writes the runtime
gravity setting into model.xml, and compiles/validates the resulting artifact.
It does not execute simulation or change any recorded result.
"""
from __future__ import annotations

import argparse
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import xml.etree.ElementTree as ET

import mujoco
import numpy as np


def digest(content):
    return hashlib.sha256(content).hexdigest()


def write_json(path, value):
    temporary = path.with_name(path.name + ".xml-finalization.tmp")
    temporary.write_text(json.dumps(value, indent=2, ensure_ascii=False) + "\n")
    temporary.replace(path)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root", type=Path, default=Path("/workspace/shadow-lift-sweep"))
    parser.add_argument("--evaluation-root", type=Path, default=Path("/workspace/shadow-lift-sweep/lift-evaluation"))
    parser.add_argument("--mass", type=float, default=0.1)
    parser.add_argument("--timestep", type=float, default=0.004)
    parser.add_argument("--apply", action="store_true", help="Write only after evaluation workers finish")
    args = parser.parse_args()
    rows = []
    for path in sorted(args.evaluation_root.glob("*/model.xml")):
        current = path.read_bytes()
        construction = path.with_name("construction_model.xml")
        original = construction.read_bytes() if construction.exists() else current
        tree = ET.fromstring(current)
        option = tree.find("option")
        if option is None:
            option = ET.SubElement(tree, "option")
        before_option = dict(option.attrib)
        flag = option.find("flag")
        if flag is None:
            flag = ET.SubElement(option, "flag")
        before_flag = dict(flag.attrib)
        option.set("gravity", "0 0 -9.81")
        flag.set("gravity", "enable")
        patched = ET.tostring(tree, encoding="utf-8") + b"\n"
        model = mujoco.MjModel.from_xml_string(patched.decode())
        assert not (model.opt.disableflags & int(mujoco.mjtDisableBit.mjDSBL_GRAVITY)), path
        assert np.allclose(model.opt.gravity, [0, 0, -9.81], rtol=0, atol=1e-12), path
        assert abs(float(model.opt.timestep) - args.timestep) < 1e-12, path
        active_bodies = [index for index in range(model.nbody) if model.body(index).name.startswith("obj-")]
        if not active_bodies:
            raise ValueError(f"No object body found in {path}")
        masses = [{"body": model.body(index).name, "subtree_mass_kg": float(model.body_subtreemass[index])}
                  for index in active_bodies]
        assert any(abs(item["subtree_mass_kg"] - args.mass) < 1e-6 for item in masses), (path, masses)
        row = {
            "scene_id": path.parent.name,
            "model_path": str(path.resolve()),
            "construction_model_path": str(construction.resolve()),
            "construction_sha256": digest(original),
            "pre_finalization_sha256": digest(current),
            "runtime_model_sha256": digest(patched),
            "previous_option_attributes": before_option,
            "previous_flag_attributes": before_flag,
            "changes": {"option.gravity": "0 0 -9.81", "option.flag.gravity": "enable"},
            "validated_gravity_enabled": True,
            "validated_gravity_m_s2": model.opt.gravity.tolist(),
            "validated_timestep_s": float(model.opt.timestep),
            "validated_object_bodies": masses,
        }
        if args.apply:
            if not construction.exists():
                construction.write_bytes(original)
            assert digest(construction.read_bytes()) == row["construction_sha256"]
            temporary = path.with_name("model.runtime-finalization.tmp")
            temporary.write_bytes(patched)
            temporary.replace(path)
            path.with_name("MODEL_EXPORT_README.md").write_text(
                "# Model export provenance\n\n"
                "`construction_model.xml` preserves the original MjSpec construction snapshot byte-for-byte. "
                "That snapshot disabled gravity before `evaluate_lifts.make_env` enabled gravity on the compiled runtime model.\n\n"
                "`model.xml` now records the actual runtime gravity setting (`0 0 -9.81`, enabled). "
                "It has been recompiled and checked for 4 ms timestep and 0.1 kg object mass. "
                "No trajectory was re-simulated or reclassified by this export operation. "
                "The hand's runtime red recoloring is visual only and is not required for the physical configuration. "
                "Per-candidate poses and controls remain in the recorded NPZ traces.\n"
            )
        rows.append(row)
        del model
    report = {
        "schema_version": 1, "generated_at_utc": datetime.now(timezone.utc).isoformat(),
        "applied": args.apply, "evaluation_root": str(args.evaluation_root.resolve()),
        "finalizer_sha256": digest(Path(__file__).read_bytes()), "mujoco_version": mujoco.__version__,
        "model_count": len(rows),
        "semantics": "Artifact-only gravity correction to reflect the actual compiled runtime; original construction snapshots are retained, no physical evaluation is altered",
        "models": rows,
    }
    if args.apply:
        write_json(args.root / "runtime-model-finalization.json", report)
    print(json.dumps({key: value for key, value in report.items() if key != "models"}, indent=2))


if __name__ == "__main__":
    main()
