#!/usr/bin/env bash
# Run the reviewed adaptive plan using already-validated cylinder assets.
set -euo pipefail
SWEEP_ROOT="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
DEXONOMY_REPO="${DEXONOMY_REPO:-/workspace/Dexonomy}"
DEXONOMY_ACTIVATE="${DEXONOMY_ACTIVATE:-/workspace/dexonomy-onboarding/activate.sh}"
PREVIOUS_ROOT="${PREVIOUS_ROOT:-/workspace/shadow-reproduction}"
EXP_NAME="${EXP_NAME:-diameter_sweep}"
RESULT_ROOT="${RESULT_ROOT:-$SWEEP_ROOT/output}"
REUSE_PREVIOUS="${REUSE_PREVIOUS:-0}"
PLAN="${PLAN:-$SWEEP_ROOT/adaptive-plan.json}"
SYNTHESIS_WORKERS="${SYNTHESIS_WORKERS:-2}"
THREADS_PER_WORKER="${THREADS_PER_WORKER:-1}"
source "$DEXONOMY_ACTIVATE"
export PYTHONPATH="$PREVIOUS_ROOT/runtime${PYTHONPATH:+:$PYTHONPATH}"
export MUJOCO_GL="${MUJOCO_GL:-egl}"
export LP_NUM_THREADS="${LP_NUM_THREADS:-2}"
cd "$DEXONOMY_REPO"
common=(hand=shadow "exp_name=$EXP_NAME" tmpl_name=24_Tip_Pinch
        n_worker=1 tmpl_upd_mode=disabled "save_root=$RESULT_ROOT"
        skip_traj=True skip_done=True debug_view=False debug_render=False obj_mass=0.1)
# Geometry and template selection belong to the reviewed plan. Avoid silently
# regenerating a different height policy or overwriting the chosen assets.
test -s "$PLAN"
test -s "$SWEEP_ROOT/assets-manifest.json"
if [[ "$REUSE_PREVIOUS" == 1 ]]; then
    python "$SWEEP_ROOT/reuse_existing.py" --repo "$DEXONOMY_REPO" \
      --source "$PREVIOUS_ROOT/output/tip20_shadow" \
      --destination "$RESULT_ROOT/${EXP_NAME}_shadow"
fi
python "$SWEEP_ROOT/run_synthesis.py" --plan "$PLAN" --repo "$DEXONOMY_REPO" \
    --previous-root "$PREVIOUS_ROOT" --save-root "$RESULT_ROOT" --exp-name "$EXP_NAME" \
    --workers "$SYNTHESIS_WORKERS" --threads-per-worker "$THREADS_PER_WORKER" \
    --epoch "${INIT_EPOCHS:-1}" --n-init-point "${INIT_POINTS:-1024}" \
    --n-init-inplane "${INIT_INPLANE:-8}" --matcher-opt-step "${INIT_OPT_STEPS:-100}" \
    --n-final "${INIT_N_FINAL:-10}"
# New experiment's grasp directory contains only proposals passing the exact
# source filters. Replaying reused initializations also records current audit.
python "$PREVIOUS_ROOT/audit_grasp.py" --audit-dir "$SWEEP_ROOT/audit/native" \
    op=grasp "${common[@]}" log_id=diameter_sweep
# Native eval_fc disables gravity and does not implement the requested hold.
# Evaluate every synthesis-filtered candidate using the new dedicated utility.
python "$SWEEP_ROOT/evaluate_lifts.py" \
    --grasp-root "$RESULT_ROOT/${EXP_NAME}_shadow/grasp_data" \
    --outdir "$SWEEP_ROOT/lift-results"
