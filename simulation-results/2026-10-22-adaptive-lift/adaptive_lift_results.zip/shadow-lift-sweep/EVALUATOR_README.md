# 连续抬升、持握与释放测试器

`evaluate_lifts.py` 使用原生 MuJoCo 控制执行每个已合成的抓取候选，不以关闭重力的六向力闭合结果预筛选候选。物体自由运动，全程开启重力，质量默认归一化为 0.1 kg。

默认阶段：

1. 预抓取姿态向外平移 100 mm 作为起点，连续接近 2 秒。向外方向取物体中心至手根方向，竖直分量不得向下。
2. 原生 `pregrasp → grasp → squeeze` 轨迹；关节与根位姿使用候选中优化得到的控制目标。
3. 夹持力稳定 1 秒，记录真实求解的手物法向接触力。此时桌面可能支撑物体，不施加额外横向外力。
4. 手根目标用三次 smoothstep 在 5 秒内上移 100 mm。
5. 维持目标姿态 5 秒。
6. 保持抬升后的根位姿，关节向原预抓取姿态连续张开 1.5 秒；手根向外退 100 mm、用时 1 秒；再等待物体在重力下自由落下并在桌面稳定 3 秒。

一个典型轨迹为 19.2 秒、4800 个 4 ms 物理步。原生预抓取节点数不同会改变闭合阶段时长。每个候选开始只重置一次，阶段之间不重置手或物体状态，不改变物体速度或位置。

## 判据

`passed` / `lift_hold_passed` 在释放开始前确定，要求后抬升持握的全部 5 秒中：

- 物体相对于试验初始位置的升高在 **100±5 mm** 内；手根控制目标严格上移 100 mm。
- 相对于预期抬升位置（闭合后物体位置上移 100 mm）的误差小于 20 mm。
- 相对于闭合后物体朝向的旋转小于 15°。
- 相对于抬升结束时物体位姿的持握漂移小于 20 mm、旋转小于 15°。
- 没有物桌接触，结束时至少有 2 个手物接触点。
- 状态有限、没有 MuJoCo 警告或非预期时间重置，并实际完成全部 1250 个持握物理步。

继承的升高至少 80 mm 条件也会记录，但 100±5 mm 条件更严格，最终判定不会把只升高 80 mm 的样本列为通过。

`release_passed` 单独要求张开、退让和等待后手物接触为零、物桌接触大于零，物体相对张开前实际下降至少 20 mm，且全程有限、无警告或重置。`full_sequence_passed` 需要抬升持握和释放同时通过；释放结果不会倒过来更改先前的抬升判定。

## 运行

```bash
/workspace/shadow-reproduction/run_cpu.sh python \
  /workspace/shadow-lift-sweep/evaluate_lifts.py \
  --grasp-root /path/to/grasp_data \
  --outdir /path/to/evaluation \
  --workers 2 --resume --trace-fps 10
```

每个场景在独立进程内编译一次模型，并串行处理该场景所有模板和候选。`--workers` 只控制场景进程的数量。`--resume` 仅复用输入 SHA256、测试配置和测试器源码 SHA256 全部匹配，且轨迹存在的结果。

指定一个候选并实时渲染：

```bash
/workspace/shadow-reproduction/run_cpu.sh python \
  /workspace/shadow-lift-sweep/evaluate_lifts.py \
  --input /path/to/grasp.npy \
  --outdir /path/to/representative \
  --trace-fps 25 --render --fps 25
```

## 输出

每个候选位于 `<outdir>/<scene_id>/<tmpl_name>/<candidate_stem>/`：

- `metrics.json`：输入与代码哈希、各阶段时刻、100 mm 指令和实际升高差、5 秒内最大漂移、接触与夹持力、警告和全部判据。
- `trace.npz`：真实连续积分得到的 `time_s`、`phase_id` / `phase_names`、`qpos`、`ctrl`、`mocap_pos` / `mocap_quat`、`object_pose`、手物/物桌接触数及法向夹持力总和。
- `trial.mp4`、首尾 PNG：仅 `--render` 时生成。物理过程与默认无视频执行相同。

每场景另有 `model.xml`、`job.json`、`worker.log` 和 `summary.json`；顶层 `summary.json` 汇总此次匹配的所有场景。重放保存的 qpos 做可视化应明确标注“已记录物理状态重放”，不能把展示用的 `mj_forward` 当作另一次动态验证。

## 已执行的验证

20 mm 的 `24_Tip_Pinch/0_1_grasp` 在完整序列中实际升高 98.167 mm；5 秒持握最大位置漂移约 0.02245 mm，闭合参考最大转角约 7.01°；夹持力稳定阶段的法向接触力总和均值 5.61 N。释放后手物接触为零、物桌接触 3 个，物体下降 128.37 mm；无警告或时间重置。

另验证同一模型中先执行候选 `0_0` 再执行 `0_1`，与单独执行 `0_1` 的物体升高、持握漂移、朝向变化和夹持力均完全一致，未发现候选间的状态泄漏。该验证的模拟发生在增加严格 100±5 mm 判据之前；增加判据没有改变控制和动力学过程，该样本的升高仍在严格容差内。
