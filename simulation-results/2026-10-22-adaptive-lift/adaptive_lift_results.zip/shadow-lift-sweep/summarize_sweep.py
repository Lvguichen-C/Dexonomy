#!/usr/bin/env python3
"""Summarize actual adaptive-cylinder trial files without inferring video success."""
from __future__ import annotations

import argparse
from collections import Counter
from datetime import datetime, timezone
import hashlib
import importlib.metadata
import json
from pathlib import Path
import platform
import re
import subprocess

DIAMETERS = [1, 5, 10, 20, 30, 40, 50, 60, 70, 80, 90, 100]


def sha256(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def diameter(scene_id):
    match = re.search(r"_(\d+)$", str(scene_id))
    return int(match.group(1)) if match else None


def read(path, default=None):
    return json.loads(Path(path).read_text()) if Path(path).is_file() else default


def count_files(root):
    result = Counter()
    if Path(root).is_dir():
        for path in Path(root).rglob("*.npy"):
            for part in path.parts:
                d = diameter(part) if part.startswith("cylinder_thin_table_") else None
                if d in DIAMETERS:
                    result[d] += 1
                    break
    return result


def provenance_accounting(root, experiment):
    """Keep proposal identities, optimization runs and copied pool files distinct."""
    main_init = {str(path.resolve()) for path in (experiment / "init_data").rglob("*.npy")}
    main_grasp = {str(path.resolve()) for path in (experiment / "grasp_data").rglob("*.npy")}
    reuse_path, ledger_path, merge_path = root / "reuse-manifest.json", root / "grasp-attempt-ledger.json", root / "merge/provenance.json"
    reuse = read(reuse_path, {})
    ledger = read(ledger_path, {})
    merge = read(merge_path, {})
    reused_init = {str(Path(row["destination"]).resolve()) for row in reuse.get("files", []) if row.get("stage") == "init_data"}
    reused_grasp = {str(Path(row["destination"]).resolve()) for row in reuse.get("files", []) if row.get("stage") == "grasp_data"}
    attempts = list(ledger.get("attempts", {}).values())
    saved_native = {str(Path(row["output_path"]).resolve()) for row in attempts if row.get("status") == "grasp_saved"}
    merged_rows = merge.get("candidates", [])
    merged = {str(Path(row["merged_grasp"]).resolve()) for row in merged_rows}
    controlled = read(root / "tiny-adaptation/input-snapshot.json", [])
    controlled_sources = {str(Path(row["input"]).resolve()) for row in controlled}
    fallback = read(root / "tiny-fallback-adaptation/input-snapshot.json", [])
    fallback_sources = {str(Path(row["original_initialization"]).resolve()) for row in fallback}
    audits_by_mode = {}
    for directory in (root / "tiny-adaptation", root / "tiny-fallback-adaptation"):
        if directory.is_dir():
            for audit in sorted(directory.glob("*/audit")):
                records = [path for path in audit.glob("*.json") if path.name != "summary.json"]
                audits_by_mode[str(audit.relative_to(root))] = len(records)
    controlled_runs = sum(count for name, count in audits_by_mode.items() if name.startswith("tiny-adaptation/") and name.split("/")[1] in {"baseline", "scaled_plane", "scaled_plane_full20"})
    targeted_runs = sum(count for name, count in audits_by_mode.items() if name.startswith("tiny-adaptation/") and name.split("/")[1] not in {"baseline", "scaled_plane", "scaled_plane_full20"})
    fallback_runs = sum(count for name, count in audits_by_mode.items() if name.startswith("tiny-fallback-adaptation/"))
    merge_hash_mismatches = []
    for row in merged_rows:
        target = Path(row["merged_grasp"])
        if not target.is_file() or sha256(target) != row.get("grasp_sha256"):
            merge_hash_mismatches.append(str(target))
    pool_union = reused_grasp | saved_native | merged
    overlaps = {"reused_and_native": sorted(reused_grasp & saved_native), "reused_and_tiny": sorted(reused_grasp & merged), "native_and_tiny": sorted(saved_native & merged)}
    status_counts = dict(Counter(row.get("status", "unknown") for row in attempts))
    return {
        "scope": "Path identities of stored proposals, native optimizer ledger attempts, supplemental variant reruns, and copied valid grasp candidates are separate accounting units. A padded initialization file is not a certified grasp or necessarily a unique numerical pose.",
        "main_pool_initial_proposal_files": len(main_init),
        "main_pool_reused_initial_proposals": len(main_init & reused_init),
        "main_pool_new_initial_proposals": len(main_init - reused_init),
        "native_optimizer_ledger_attempts": len(attempts),
        "native_optimizer_scientific_completed_attempts": sum(bool(row.get("scientific_attempt_completed")) for row in attempts),
        "native_optimizer_status_counts": status_counts,
        "native_optimizer_reused_proposal_retries": sum(str(Path(row["source"]).resolve()) in reused_init for row in attempts),
        "native_optimizer_new_proposal_attempts": sum(str(Path(row["source"]).resolve()) not in reused_init for row in attempts),
        "main_pool_grasp_candidate_files": len(main_grasp),
        "pool_partition": {"reused_valid_grasps": len(reused_grasp), "new_native_valid_grasps": len(saved_native), "supplemental_tiny_valid_grasps": len(merged)},
        "tiny_diagnostics": {"distinct_controlled_input_paths": len(controlled_sources), "controlled_inputs_already_in_main_pool": len(controlled_sources & main_init), "new_fallback_input_paths_outside_main_pool": len(fallback_sources - main_init), "distinct_input_paths_total": len(controlled_sources | fallback_sources), "controlled_three_variant_optimizer_runs": controlled_runs, "targeted_long_budget_optimizer_runs": targeted_runs, "fresh_fallback_optimizer_runs": fallback_runs, "optimizer_runs_total": controlled_runs + targeted_runs + fallback_runs, "audit_records_by_mode": audits_by_mode, "merged_valid_grasps": len(merged), "declared_merge_optimization_runs": merge.get("optimization_runs"), "declared_merge_distinct_proposals": merge.get("independent_initial_proposals")},
        "budget_interpretation": "Reused Tip_Pinch reference scenes retain 50 proposals each, while new main template/diameter jobs normally retain 10 each; tiny fallback jobs retain 5 each. Counts describe this finite uneven search budget, not equal-budget statistical success rates across diameters.",
        "integrity": {"pool_partition_disjoint": not any(overlaps.values()), "pool_partition_matches_actual_grasp_files": pool_union == main_grasp, "overlaps": overlaps, "unattributed_grasp_files": sorted(main_grasp - pool_union), "attributed_grasp_files_missing": sorted(pool_union - main_grasp), "merged_payload_hash_mismatches": merge_hash_mismatches},
        "sources": {str(path.relative_to(root)): sha256(path) for path in (reuse_path, ledger_path, merge_path, root / "tiny-fallback-summary.json", root / "TINY_ADAPTATION.md") if path.is_file()},
    }


def summarize(args):
    root, evaluation = args.root.resolve(), args.evaluation_root.resolve()
    asset = read(root / "assets-manifest.json", {})
    planned = read(root / "adaptive-plan.json", {})
    motion_path = root / "motion-protocol-summary.json"
    motion_summary = read(motion_path, {})
    assets_by_d = {int(row["diameter_mm"]): row for row in asset.get("scenes", [])}
    records, unreadable, errors = [], [], []
    for path in sorted(evaluation.rglob("metrics.json")):
        try:
            item = read(path)
            if item.get("schema_version") == 1 and "hold_criteria" in item:
                item = {**item, "metrics_path": str(path.resolve()), "metrics_sha256": sha256(path)}
                trace = Path(item.get("trace", path.with_name("trace.npz")))
                item["trace_exists"] = trace.is_file()
                item["trace_sha256"] = sha256(trace) if trace.is_file() else None
                records.append(item)
        except (ValueError, OSError, TypeError) as error:
            unreadable.append({"path": str(path), "error": str(error)})
    for path in sorted(evaluation.glob("*/summary.json")):
        scene = read(path, {})
        for row in scene.get("candidates", []):
            if row.get("error"):
                errors.append({"scene_id": scene.get("scene_id"), **row})
    init_counts = count_files(args.experiment / "init_data")
    grasp_counts = count_files(args.experiment / "grasp_data")
    initial_budgets = Counter()
    for path in (args.experiment / "init_data").rglob("*.npy"):
        relative = path.relative_to(args.experiment / "init_data")
        if len(relative.parts) >= 3:
            initial_budgets[(diameter(relative.parts[1]), relative.parts[0])] += 1
    per_diameter = []
    for d in DIAMETERS:
        group = [r for r in records if diameter(r["scene_id"]) == d]
        group_errors = [e for e in errors if diameter(e.get("scene_id")) == d]
        templates = sorted({r.get("template", "unknown") for r in group})
        per_template = []
        for template in templates:
            rows = [r for r in group if r.get("template", "unknown") == template]
            per_template.append({"template": template, "tested": len(rows), "lift_hold_passed": sum(bool(r.get("lift_hold_passed")) for r in rows), "release_passed": sum(bool(r.get("release_passed")) for r in rows), "full_sequence_passed": sum(bool(r.get("full_sequence_passed")) for r in rows)})
        failed_criteria = Counter(key for r in group for key, valid in r.get("hold_criteria", {}).items() if not valid)
        sampled_failures = Counter(key for r in group for key, valid in r.get("motion_protocol", {}).get("checks", {}).items() if not valid)
        per_diameter.append({
            "diameter_mm": d, "height_mm": assets_by_d.get(d, {}).get("height_mm"),
            "initializations": init_counts[d], "grasp_candidates": grasp_counts[d],
            "tested": len(group), "exceptions": len(group_errors),
            "lift_hold_passed": sum(bool(r.get("lift_hold_passed")) for r in group),
            "release_passed": sum(bool(r.get("release_passed")) for r in group),
            "full_sequence_passed": sum(bool(r.get("full_sequence_passed")) for r in group),
            "base_evaluator_lift_hold_passed": sum(bool(r.get("base_evaluator_outcomes", {}).get("lift_hold_passed", r.get("lift_hold_passed"))) for r in group),
            "base_evaluator_full_sequence_passed": sum(bool(r.get("base_evaluator_outcomes", {}).get("full_sequence_passed", r.get("full_sequence_passed"))) for r in group),
            "motion_protocol_audited": sum("motion_protocol" in r for r in group),
            "sampled_lift_stability_passed": sum(bool(r.get("motion_protocol", {}).get("passed")) for r in group),
            "failed_sampled_lift_criteria": dict(sampled_failures),
            "templates": per_template, "failed_hold_criteria": dict(failed_criteria),
            "main_initial_proposals_by_template": {template: count for (value, template), count in initial_budgets.items() if value == d},
            "status": "no_synthesized_grasp" if not grasp_counts[d] else "no_evaluated_trial" if not group else "evaluated",
        })
    totals = {key: sum(row[key] for row in per_diameter) for key in ("initializations", "grasp_candidates", "tested", "exceptions", "lift_hold_passed", "release_passed", "full_sequence_passed", "base_evaluator_lift_hold_passed", "base_evaluator_full_sequence_passed", "motion_protocol_audited", "sampled_lift_stability_passed")}
    config = records[0].get("config", {}) if records else read(evaluation / "summary.json", {}).get("config", {})
    evaluated_inputs = {str(Path(r["input"]).resolve()) for r in records} | {str(Path(e["input"]).resolve()) for e in errors if e.get("input")}
    expected_inputs = {str(path.resolve()) for path in (args.experiment / "grasp_data").rglob("*.npy")}
    motion_inputs = {str(Path(row["input"]).resolve()) for row in motion_summary.get("candidates", [])}
    metric_inputs = {str(Path(row["input"]).resolve()) for row in records}
    motion_trace_mismatches = [r["metrics_path"] for r in records if r.get("motion_protocol", {}).get("trace_sha256") != r.get("trace_sha256")]
    motion_complete = bool(motion_summary.get("applied") and motion_summary.get("candidate_count") == len(records)
                           and totals["motion_protocol_audited"] == len(records) and motion_inputs == metric_inputs
                           and not motion_trace_mismatches
                           and motion_summary.get("final_lift_hold_passed") == totals["lift_hold_passed"]
                           and motion_summary.get("final_full_sequence_passed") == totals["full_sequence_passed"])
    inventory = {str(path.relative_to(root)): {"bytes": path.stat().st_size, "sha256": sha256(path)} for path in root.iterdir() if path.is_file() and path.suffix in {".py", ".sh", ".json"} and path.name not in {"adaptive_lift_summary.json", "publication.json", "public-download-verification.json"}}
    versions = {"python": platform.python_version()}
    for package in ("mujoco", "torch", "warp-lang", "numpy", "trimesh", "qpsolvers"):
        try:
            versions[package] = importlib.metadata.version(package)
        except importlib.metadata.PackageNotFoundError:
            versions[package] = None
    def git(*values):
        return subprocess.check_output(["git", "-C", str(args.repo), *values], text=True).strip()
    source_status = git("status", "--porcelain=v1", "--untracked-files=no")
    result = {
        "schema_version": 1, "generated_at_utc": datetime.now(timezone.utc).isoformat(),
        "evaluation_root": str(evaluation), "experiment": str(args.experiment.resolve()),
        "diameters_mm": DIAMETERS, "config": config,
        "assets": {"height_to_diameter_ratio": asset.get("height_to_diameter_ratio"), "fixed_height_mm": asset.get("fixed_height_mm", asset.get("height_mm")), "mass_policy": asset.get("mass_policy"), "target_mass_kg": asset.get("target_mass_kg"), "canonical_mesh_sections": asset.get("canonical_mesh_sections")},
        "adaptive_selection": {"method": planned.get("selection_method"), "limitations": planned.get("geometry_fit_limitations")},
        "provenance_accounting": provenance_accounting(root, args.experiment),
        "totals": totals, "per_diameter": per_diameter,
        "semantics": {"lift_hold_passed": "Final flag: original evaluator lift/hold pass AND sampled five-second-lift protocol gate. LIFT stability uses saved trace samples (normally 10 Hz plus exact phase boundaries); POSTLIFT HOLD uses every 4 ms physics step (250 Hz), including actual rise 95-105 mm throughout 5 s. Neither video replay nor sampled audit observes unsaved lift substeps.", "base_evaluator_outcomes": "Frozen original evaluator outcomes are preserved per record before sampled-lift gating; compare them to final flags rather than overwriting their meaning.", "release_passed": "Recorded release criterion is evaluated separately; a failed grip that simply leaves the object on the table is not a full-sequence pass.", "full_sequence_passed": "base_evaluator full-sequence pass AND sampled-lift stability pass; equivalent to final lift_hold_passed AND release_passed", "representative_videos": "Representative selection uses final audited results; the report retains every tested outcome. Video state replay does not compute success."},
        "motion_protocol_audit": {"summary_path": str(motion_path), "summary_sha256": sha256(motion_path) if motion_path.is_file() else None,
                                  **{key: value for key, value in motion_summary.items() if key not in ("candidates", "dependencies")},
                                  "record_trace_rates_hz": dict(Counter(str(r.get("motion_protocol", {}).get("trace_fps")) for r in records if "motion_protocol" in r)),
                                  "coverage_and_final_counts_verified": motion_complete},
        "source": {"commit": git("rev-parse", "HEAD"), "tracked_status": source_status, "tracked_source_unchanged": not source_status},
        "environment": versions, "records": records, "evaluation_exceptions": errors,
        "integrity": {"unreadable_metrics": unreadable, "missing_trace": [r["metrics_path"] for r in records if not r["trace_exists"]], "grasp_inputs_not_evaluated": sorted(expected_inputs - evaluated_inputs), "evaluated_inputs_outside_grasp_root": sorted(evaluated_inputs - expected_inputs), "candidate_accounting_complete": expected_inputs == evaluated_inputs,
                      "motion_protocol_applied_and_complete": motion_complete, "motion_protocol_trace_hash_mismatches": motion_trace_mismatches},
        "script_and_manifest_hashes": inventory,
    }
    return result


def report(summary, animation):
    config, assets = summary["config"], summary["assets"]
    target_mm = 1000 * config.get("lift_m", .1)
    tolerance_mm = 1000 * config.get("target_lift_tolerance_m", .005)
    target_requirement = f"实际物体升高在 {target_mm - tolerance_mm:g}–{target_mm + tolerance_mm:g} mm 内"
    lines = ["# Shadow 自适应圆柱抓取、抬升持握与释放测试", "", "本报告来自实际 MuJoCo 连续积分的测试结果，包含成功、失败和未合成出有效候选的直径。", "", "## 实际结果", "", "| 直径 / 高度 mm | 主池初始提案 | 合成候选 | 已测试 | 抬升持握通过 | 释放通过 | 全流程通过 |", "|---|---:|---:|---:|---:|---:|---:|"]
    for row in summary["per_diameter"]:
        lines.append(f"| {row['diameter_mm']} / {row['height_mm']} | {row['initializations']} | {row['grasp_candidates']} | {row['tested']} | {row['lift_hold_passed']} | {row['release_passed']} | {row['full_sequence_passed']} |")
    t = summary["totals"]
    lines += [f"| 合计 | {t['initializations']} | {t['grasp_candidates']} | {t['tested']} | {t['lift_hold_passed']} | {t['release_passed']} | {t['full_sequence_passed']} |", "", f"原评价器的抬升持握通过数为 {t['base_evaluator_lift_hold_passed']}，全流程通过数为 {t['base_evaluator_full_sequence_passed']}；附加提升过程采样复核后，最终对应为 {t['lift_hold_passed']} 和 {t['full_sequence_passed']}。原评价器结果保存在每个候选的 base_evaluator_outcomes 中，没有被丢弃。", "", "0 个候选表示在当前资产、模板集合和优化预算下没有得到满足合成筛选条件的轨迹，不能据此宣称 Shadow 对该直径绝对无法抓取。释放通过数独立统计；完整流程要求抬升持握与释放同时通过。", "", "## 测试流程与判据", "", f"所有测试开启重力，物体质量为 {config.get('mass_kg', assets.get('target_mass_kg'))} kg。流程为：接近 {config.get('approach_s')} s → 模板匹配后的闭合和夹紧 → 夹紧目标受力保持 {config.get('loaded_hold_s')} s → 手根目标在 {config.get('lift_s')} s 内平稳提高 {1000 * config.get('lift_m', .1):g} mm → 到位持握 {config.get('postlift_hold_s')} s → 松指 {config.get('release_open_s')} s → 手部退离 {config.get('release_retreat_s')} s → 释放后观察 {config.get('release_settle_s')} s。", "", f"100 mm 是手根提升指令。实际物体升高单独测量；到位后的 5 s 持握条件在每个 4 ms 物理子步（250 Hz）检查：{target_requirement}，相对预期位姿的平移误差与持握期间的平移漂移均小于 20 mm，相关旋转误差与漂移均小于 15°，持握期间不接触桌面，末端至少 2 个手物接触点，并且完成整段 5 s、状态有限、无 MuJoCo 警告或意外时间重置。", "", "受力保持阶段维持夹紧目标并记录实际法向接触力；该阶段物体可能仍由桌面承重，未额外添加未指定的侧向外力。释放判据是手物接触清零、实际落回桌面、相对开始松指时下降至少 20 mm，并保持数值正常。", "", "## 物体与自适应抓型", ""]
    if assets.get("fixed_height_mm") is not None:
        lines += [f"所有圆柱采用固定高度 {assets['fixed_height_mm']} mm。"]
    else:
        lines += [f"圆柱高度采用直径的 {assets.get('height_to_diameter_ratio')} 倍，具体高度见结果表。"]
    lines += ["", "质量保持一致，密度因此随尺寸变化；这是等质量对比，不是同一材料密度的圆柱。资产使用 64 边封闭圆柱重建，并验证实际尺寸、模型编译和归一化质量。", "", "根据模板接触点和法向，拟合圆柱半径、长度及对向接触，综合表面距离、法向一致性和轴向位置评分；每个尺寸取两个不同接触家族的优先模板，并保留 Tip_Pinch 参考模板。完整排名见 adaptive-plan.json。", "", "自适应方案按已知物体几何产生模板候选，再通过原生合成与离线物理评价选择抓型。视频从起点执行已选抓型，不声称实现了在线视觉识别或强化学习控制。真实接触、碰撞、限位、QP 与完整的重力抬升/释放测试决定有效性。选中动画按全部已测结果中的完整流程通过、抬升持握通过、约束满足数和测量安全余量确定，保留所有候选统计，未把展示样本当作总体成功率。", "", "## 动画与完整数据", "", "- [12 种直径总览](animations/all_12_diameters.mp4)", "- [完整数值汇总](adaptive_lift_summary.json)"]
    for row in animation.get("representatives", []):
        d = row["diameter_mm"]
        status_label = {"full_sequence_pass": "全流程通过", "failed_trial": "未通过（真实试验）"}.get(row.get("status"), row.get("status"))
        lines.append(f"- [直径 {d} mm 的流程动画](animations/d{d:03d}/d{d:03d}_full_sequence.mp4)：{status_label}")
    lines += ["", "动画展示已记录的实际物理状态，回放只做几何显示，不重新积分或根据画面计算成功。未得到可执行候选的直径显示明确的诊断卡片，不伪造抓取轨迹。每段画面标注抓型、阶段、物体升高、实际接触与夹紧法向力。", "", "完整包保留初始化、合成候选、全部测试指标与轨迹、诊断日志、资产、计划和复现脚本。包内保存的 scene_path、input 等字段来自本云环境，移到另一台机器后需要按新目录修正。", "", "## 环境与实现边界", "", f"基线源码提交：`{summary['source']['commit']}`；统计时 Git 跟踪的源码是否保持原样：`{summary['source']['tracked_source_unchanged']}`。", "", "CPU 兼容层只把 Warp 的 CPU 查询流设为 None；未更改原查询核或抓取过滤条件。MuJoCo 采用自由物体、自由根 Shadow 手与 mocap 控制。详细版本：", "", "```json", json.dumps(summary["environment"], ensure_ascii=False, indent=2), "```", "", "如因几何、动力学或优化预算未能完成某个尺寸，失败仍计入结果。全流程通过也不等于已验证现实硬件上的可靠性。", ""]
    audit = summary.get("motion_protocol_audit", {})
    lines += ["## 提升过程的采样复核与数据范围", "",
              "完整 5 s 提升过程另外按保存的实际物理状态复核，通常为 10 Hz，另包含准确阶段边界；它与到位后持握阶段的 250 Hz 逐物理步检查不同。提升采样门要求：跟踪三维 smoothstep 目标位置的误差不超过 20 mm、相对闭合姿态的旋转不超过 15°、从已到达高度向下回滑不超过 2 mm、每个提升样本至少有 2 个手物接触点，且状态有限、边界与整段 5 s 覆盖完整。这里的接触数是接触点数，不是独立手指数；刚离桌前允许仍有桌面接触。", "",
              "采样复核无法证明未保存的 4 ms 提升子步同样满足这些条件。2 mm 是本次 100 mm 提升的操作性回滑容差，不是通用物理速度上限。最终抬升持握与全流程通过标志均要求原评价器条件和这个采样提升门同时通过；释放指标仍保留原评价器结果。", "",
              f"复核实际覆盖 {summary['totals']['motion_protocol_audited']} 个候选；最终应用与候选覆盖/轨迹哈希/统计核对：`{audit.get('coverage_and_final_counts_verified')}`。复核汇总文件 SHA-256：`{audit.get('summary_sha256')}`。", "",
              "- [提升轨迹采样复核汇总](motion-protocol-summary.json)",
              "- [方法与协议审查](PROTOCOL_REVIEW.md)", "",
              "资产依赖指纹记录复核时的场景、网格、手模型及 menagerie 提交；若依赖变化，应清空受影响的评价缓存并重新仿真。该指纹不能倒推证明更早未记录的资产状态。", ""]
    accounting = summary.get("provenance_accounting", {})
    pool = accounting.get("pool_partition", {})
    tiny = accounting.get("tiny_diagnostics", {})
    lines += ["## 提案、优化运行与候选来源的统计口径", "",
              f"结果表的“主池初始提案”是主实验初始化目录中的 {accounting.get('main_pool_initial_proposal_files')} 个提案文件：其中 {accounting.get('main_pool_reused_initial_proposals')} 个从上一轮复用，{accounting.get('main_pool_new_initial_proposals')} 个为本轮新增。文件身份不意味着数值姿态绝不重复；初始化配额补齐也不保证物理可行。", "",
              f"本轮原生优化台账记录 {accounting.get('native_optimizer_ledger_attempts')} 次已记录运行，其中 {accounting.get('native_optimizer_new_proposal_attempts')} 次使用新增提案、{accounting.get('native_optimizer_reused_proposal_retries')} 次重试已复用提案；运行次数不等于独立新增提案数。状态分布：`{accounting.get('native_optimizer_status_counts')}`。", "",
              f"最终物理候选池的 {accounting.get('main_pool_grasp_candidate_files')} 个文件由互斥来源组成：复用有效抓取 {pool.get('reused_valid_grasps')} 个 + 本轮原生优化新增有效抓取 {pool.get('new_native_valid_grasps')} 个 + 小物体补充优化合并 {pool.get('supplemental_tiny_valid_grasps')} 个。来源路径与合并载荷 SHA 均保留，分区和实际主候选池是否一致：`{accounting.get('integrity', {}).get('pool_partition_matches_actual_grasp_files')}`。", "",
              f"小物体诊断涉及 {tiny.get('distinct_input_paths_total')} 个不同输入路径，其中 {tiny.get('controlled_inputs_already_in_main_pool')} 个已属于主池、{tiny.get('new_fallback_input_paths_outside_main_pool')} 个是主池之外的追加回退提案。前一部分不能再次算作新增提案。诊断优化共 {tiny.get('optimizer_runs_total')} 次：三个受控变体 {tiny.get('controlled_three_variant_optimizer_runs')} 次 + 定向长预算探针 {tiny.get('targeted_long_budget_optimizer_runs')} 次 + 新回退提案优化 {tiny.get('fresh_fallback_optimizer_runs')} 次。合并的 {tiny.get('merged_valid_grasps')} 个补充候选已经包含在主物理候选池中，不能再加一次。", "",
              "旧的 Tip_Pinch 参考场景各保留 50 个提案，新主模板/尺寸任务通常各保留 10 个，追加回退模板各 5 个；这是一轮预算不均的有限搜索。逐尺寸候选数与通过数是对这些已测文件的统计，不是相同搜索预算下可直接比较的总体成功概率。", "",
              "- 小物体优化参数、194 次补充运行及边界：`TINY_ADAPTATION.md`", "- 原生优化运行台账：`grasp-attempt-ledger.json`", "- 复用来源：`reuse-manifest.json`；27 个合并候选来源：`merge/provenance.json`", ""]
    contact = summary.get("selected_contact_diagnostics", {})
    if contact:
        rows = contact.get("representatives", [])
        passed = [row for row in rows if row.get("full_sequence_passed")]
        held_max = max((row["by_phase"]["postlift_hold"]["hand_object"]["maximum_penetration_mm"] for row in passed), default=0)
        lift_max = max((row["by_phase"]["lift"]["hand_object"]["maximum_penetration_mm"] for row in passed), default=0)
        lines += ["## 接触重叠与落地碰撞的数值局限", "",
                  f"已按保存的物理状态对全部 {len(rows)} 个展示样本复核接触类型和阶段。{len(passed)} 个通过展示样本在提升阶段的最大手物重叠为 {lift_max:.3f} mm，到位持握阶段为 {held_max:.3f} mm；这是 10 Hz 状态回放的几何检查，不是新的仿真或更高频率观测。", "",
                  "MuJoCo 使用软接触，不能把负接触距离解释为严格刚性几何下的无穿透。5 mm 展示样本在持握阶段的手物重叠约 0.378 mm，约占其半径的 15%；原指标中约 7.07 mm 的全流程最大值来自释放落地碰撞。40 mm 样本约 9.27 mm 的全流程最大值同样来自释放落地，其持握手物重叠约 0.440 mm。整体最大值不应直接当作夹持阶段的手物重叠量。", "",
                  "软接触误差对小物体的相对影响更大，本结果说明的是所记录接触参数下的仿真完成情况。逐阶段、逐接触类型及源轨迹哈希见 `contact-diagnostics.json`，解释见 `CONTACT_REVIEW.md`；未据此修改通过判据或原始结果。", ""]
    return "\n".join(lines)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root", type=Path, default=Path("/workspace/shadow-lift-sweep"))
    parser.add_argument("--evaluation-root", type=Path, required=True)
    parser.add_argument("--experiment", type=Path, default=Path("/workspace/shadow-lift-sweep/output/diameter_sweep_shadow"))
    parser.add_argument("--repo", type=Path, default=Path("/workspace/Dexonomy"))
    parser.add_argument("--animation-root", type=Path, default=Path("/workspace/shadow-lift-sweep/animations"))
    args = parser.parse_args()
    summary = summarize(args)
    animation = read(args.animation_root / "index.json", {})
    summary["representative_animations"] = animation
    summary["selected_contact_diagnostics"] = read(args.root / "contact-diagnostics.json", {})
    (args.root / "adaptive_lift_summary.json").write_text(json.dumps(summary, ensure_ascii=False, indent=2) + "\n")
    (args.root / "ADAPTIVE_LIFT_REPORT.md").write_text(report(summary, animation))
    print(json.dumps({"totals": summary["totals"], "candidate_accounting_complete": summary["integrity"]["candidate_accounting_complete"], "report": str(args.root / "ADAPTIVE_LIFT_REPORT.md")}, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
