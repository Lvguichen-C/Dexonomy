#!/usr/bin/env python3
"""Reuse exact-geometry initializations/grasps; never reuse evaluation outcomes.

Every canonical asset and overlapping scene must be byte-identical before any
candidate is copied. Only the top-level scene_path changes. Numeric arrays and
all other nested values are checked recursively before and after serialization.
"""
from __future__ import annotations

import argparse
from collections import Counter
from datetime import datetime, timezone
import hashlib
import json
import math
from pathlib import Path

import numpy as np


DIAMETERS = (10, 20, 30, 40)
EXPECTED_GRASPS = {10: 33, 20: 50, 30: 50, 40: 49}
CANONICAL = (
    "processed_data/cylinder_thin/mesh/simplified.obj",
    "processed_data/cylinder_thin/urdf/coacd.xml",
    "processed_data/cylinder_thin/urdf/coacd.urdf",
    "processed_data/cylinder_thin/info/simplified.json",
)


def digest(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def assert_equal(left, right, path="root"):
    """Strict nested comparison, including ndarray dtype and exact float values."""
    if isinstance(left, dict):
        assert isinstance(right, dict) and left.keys() == right.keys(), path
        for key in left:
            assert_equal(left[key], right[key], f"{path}.{key}")
    elif isinstance(left, np.ndarray):
        assert isinstance(right, np.ndarray), path
        assert left.dtype == right.dtype and left.shape == right.shape, path
        if left.dtype.hasobject:
            for i, (a, b) in enumerate(zip(left.flat, right.flat)):
                assert_equal(a, b, f"{path}[{i}]")
        else:
            if left.dtype.kind in "fc":
                assert np.array_equal(left, right, equal_nan=True), path
            else:
                assert np.array_equal(left, right), path
    elif isinstance(left, (tuple, list)):
        assert type(left) is type(right) and len(left) == len(right), path
        for i, (a, b) in enumerate(zip(left, right)):
            assert_equal(a, b, f"{path}[{i}]")
    elif isinstance(left, (float, np.floating)) and math.isnan(left):
        assert isinstance(right, (float, np.floating)) and math.isnan(right), path
    else:
        assert type(left) is type(right), (path, type(left), type(right))
        assert left == right, path


def load(path: Path):
    return np.load(path, allow_pickle=True).item()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--repo", type=Path, default=Path("/workspace/Dexonomy"))
    parser.add_argument("--source", type=Path, default=Path("/workspace/shadow-reproduction/output/tip20_shadow"))
    parser.add_argument("--destination", type=Path, default=Path("/workspace/shadow-lift-sweep/output/diameter_sweep_shadow"))
    parser.add_argument("--asset-name", default="cylinder_sweep_20261022")
    parser.add_argument("--manifest", type=Path, default=Path(__file__).parent / "reuse-manifest.json")
    parser.add_argument("--validate-only", action="store_true")
    args = parser.parse_args()
    old_assets = args.repo / "assets/object/small_cyl"
    new_assets = args.repo / "assets/object" / args.asset_name
    asset_checks = []
    # Preflight all source assets/scenes/counts before writing any results.
    check_paths = list(CANONICAL) + [f"scene_cfg/cylinder_thin/table_top/d{d}.npy" for d in DIAMETERS]
    for relative in check_paths:
        old, new = old_assets / relative, new_assets / relative
        if not old.is_file() or not new.is_file():
            raise SystemExit(f"Exact-geometry reuse requires both asset files: {old}, {new}")
        old_hash, new_hash = digest(old), digest(new)
        if old_hash != new_hash:
            raise SystemExit(f"Asset mismatch: {relative}; refusing candidate reuse")
        asset_checks.append({"relative_path": relative, "sha256": old_hash, "byte_identical": True})
    tasks = []
    for diameter in DIAMETERS:
        scene = f"cylinder_thin_table_{diameter}"
        for stage in ("init_data", "grasp_data"):
            source_dir = args.source / stage / "24_Tip_Pinch" / scene
            files = sorted(source_dir.glob("*.npy"))
            expected = 50 if stage == "init_data" else EXPECTED_GRASPS[diameter]
            if len(files) != expected:
                raise SystemExit(f"Unexpected {stage} count for d{diameter}: {len(files)} != {expected}")
            new_scene = (new_assets / f"scene_cfg/cylinder_thin/table_top/d{diameter}.npy").resolve()
            for source in files:
                tasks.append((diameter, stage, source, args.destination / source.relative_to(args.source), new_scene))
    records, counts = [], Counter()
    for diameter, stage, source, destination, scene in tasks:
        original = load(source)
        if "scene_path" not in original:
            raise SystemExit(f"Source candidate has no scene_path: {source}")
        expected = dict(original)
        expected["scene_path"] = str(scene)
        # The scene itself has already been verified byte-identical, not merely
        # approximately equal in shape or nominal diameter.
        assert_equal({k: v for k, v in original.items() if k != "scene_path"},
                     {k: v for k, v in expected.items() if k != "scene_path"})
        if not args.validate_only:
            if destination.exists():
                assert_equal(expected, load(destination), str(destination))
            else:
                destination.parent.mkdir(parents=True, exist_ok=True)
                np.save(destination, expected, allow_pickle=True)
            actual = load(destination)
            assert_equal(expected, actual, str(destination))
            destination_hash = digest(destination)
        else:
            destination_hash = digest(destination) if destination.is_file() else None
        counts[f"d{diameter}/{stage}"] += 1
        records.append({
            "diameter_mm": diameter, "stage": stage,
            "source": str(source.resolve()), "source_sha256": digest(source),
            "destination": str(destination.resolve()), "destination_sha256": destination_hash,
            "old_scene_path": str(original["scene_path"]), "new_scene_path": str(scene),
            "changed_fields": ["scene_path"], "all_other_values_exactly_preserved": True,
        })
    manifest = {
        "generated_at_utc": datetime.now(timezone.utc).isoformat(),
        "mode": "validate_only" if args.validate_only else "copied_or_verified",
        "source_experiment": str(args.source.resolve()),
        "destination_experiment": str(args.destination.resolve()),
        "diameters_reused_mm": list(DIAMETERS),
        "asset_checks": asset_checks,
        "counts": dict(counts), "file_count": len(records),
        "evaluation_results_reused": False,
        "scope": "Only initialization proposals and synthesis-filtered grasps; all lift/hold outcomes are new tests",
        "files": records,
    }
    args.manifest.parent.mkdir(parents=True, exist_ok=True)
    args.manifest.write_text(json.dumps(manifest, indent=2) + "\n")
    print(json.dumps({"manifest": str(args.manifest), "file_count": len(records), "counts": dict(counts), "evaluation_results_reused": False}, indent=2))


if __name__ == "__main__":
    main()
