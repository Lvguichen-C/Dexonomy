#!/usr/bin/env python3
"""Synthesize only completed init jobs without overwriting evaluated grasps.

An input-path plus SHA256 ledger records native filter rejections as completed
attempts. Exceptions are recorded separately and are retried only when the
caller explicitly passes --retry-errors. All physical/filter behavior remains
in the unchanged original _single_grasp, through audit_grasp.py.
"""
from __future__ import annotations

import argparse
from datetime import datetime, timezone
import fcntl
import hashlib
import json
import os
from pathlib import Path
import subprocess
import time
import uuid


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def write_json(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_suffix(path.suffix + ".tmp")
    temporary.write_text(json.dumps(value, indent=2) + "\n")
    temporary.replace(path)


def main():
    root = Path(__file__).parent
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root", type=Path, default=root)
    parser.add_argument("--experiment", type=Path, default=root / "output/diameter_sweep_shadow")
    parser.add_argument("--progress", type=Path, default=root / "synthesis-status/progress.json")
    parser.add_argument("--repo", type=Path, default=Path("/workspace/Dexonomy"))
    parser.add_argument("--previous-root", type=Path, default=Path("/workspace/shadow-reproduction"))
    parser.add_argument("--python", type=Path, default=Path("/workspace/venvs/dexonomy/bin/python"))
    parser.add_argument("--batch-id")
    parser.add_argument("--dry-run", action="store_true")
    parser.add_argument("--retry-errors", action="store_true")
    args = parser.parse_args()
    args.root = args.root.resolve()
    args.experiment = args.experiment.resolve()
    args.root.mkdir(parents=True, exist_ok=True)
    # One helper at a time, so no two batches can select the same pending input.
    with (args.root / "pending-grasps.lock").open("a") as lock:
        try:
            fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except BlockingIOError:
            raise SystemExit("Another pending-grasp batch is active; retry after it completes")
        progress = json.loads(args.progress.read_text())
        ledger_path = args.root / "grasp-attempt-ledger.json"
        ledger = json.loads(ledger_path.read_text()) if ledger_path.is_file() else {
            "schema_version": 1,
            "key_policy": "Resolved actual initialization path + # + source SHA256",
            "exception_retry_policy": "Exceptions/unknown outcomes are not completed scientific attempts and are retried only with --retry-errors",
            "attempts": {},
        }
        batch_id = args.batch_id or (datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ") + "_" + uuid.uuid4().hex[:6])
        if Path(batch_id).name != batch_id or ".." in batch_id:
            raise SystemExit("batch-id must be a plain basename")
        pending = args.root / "pending_initializations" / f"batch_{batch_id}"
        audit = args.root / "audit" / f"batch_{batch_id}"
        metadata = args.root / "grasp-batches" / f"batch_{batch_id}.json"
        chosen, skipped = {}, {"existing_grasp":0, "completed_attempt":0, "previous_error":0}
        completed_jobs = []
        init_root = args.experiment / "init_data"
        grasp_root = args.experiment / "grasp_data"
        for job in progress.get("results", []):
            if not job.get("successful"):
                continue
            completed_jobs.append(job["key"])
            folder = Path(job["output"]).resolve()
            if not folder.is_relative_to(init_root):
                raise SystemExit(f"Job output is outside this experiment: {folder}")
            for epoch in range(int(job["config"]["epoch"])):
                for source in sorted(folder.glob(f"{epoch}_*_grasp.npy")):
                    actual = source.resolve()
                    source_hash = digest(actual)
                    relative = source.relative_to(init_root)
                    output = grasp_root / relative
                    key = f"{actual}#{source_hash}"
                    if output.is_file():
                        skipped["existing_grasp"] += 1
                        continue
                    prior = ledger["attempts"].get(key)
                    if prior and prior["status"] in ("grasp_saved", "filter_rejected"):
                        skipped["completed_attempt"] += 1
                        continue
                    if prior and not args.retry_errors:
                        skipped["previous_error"] += 1
                        continue
                    chosen[key] = {
                        "ledger_key": key, "source": str(actual), "source_sha256": source_hash,
                        "relative_path": str(relative), "output_path": str(output),
                        "pending_path": str(pending / relative), "job_key": job["key"],
                    }
        manifest = {"batch_id": batch_id, "created_at_utc":datetime.now(timezone.utc).isoformat(),
            "progress_snapshot_sha256":digest(args.progress), "completed_jobs":completed_jobs,
            "experiment":str(args.experiment), "pending_tree":str(pending),
            "audit_dir":str(audit), "selected_inputs":list(chosen.values()),
            "selected_count":len(chosen), "skipped":skipped, "dry_run":args.dry_run,
            "retry_errors":args.retry_errors}
        write_json(metadata, manifest)
        if args.dry_run or not chosen:
            print(json.dumps({"manifest":str(metadata),"selected":len(chosen),"skipped":skipped,"dry_run":args.dry_run},indent=2))
            return
        if pending.exists() or audit.exists():
            raise SystemExit("Batch pending/audit directory already exists; choose a new batch-id")
        for item in chosen.values():
            target = Path(item["pending_path"])
            target.parent.mkdir(parents=True, exist_ok=True)
            target.symlink_to(item["source"])
        environment = os.environ.copy()
        runtime = str(args.previous_root / "runtime")
        environment["PYTHONPATH"] = runtime + (os.pathsep + environment["PYTHONPATH"] if environment.get("PYTHONPATH") else "")
        environment.update(OMP_NUM_THREADS="1", OPENBLAS_NUM_THREADS="1", MKL_NUM_THREADS="1")
        environment.setdefault("MUJOCO_GL", "egl")
        command = [str(args.python),str(args.previous_root / "audit_grasp.py"),"--audit-dir",str(audit),
            "op=grasp","hand=shadow","n_worker=1","tmpl_upd_mode=disabled","skip_traj=True",
            "skip_done=False","debug_view=False","debug_render=False","obj_mass=0.1",
            f"save_dir={args.experiment}",f"init_dir={pending}",f"grasp_dir={grasp_root}",
            f"log_id=pending_{batch_id}"]
        manifest["command"] = command
        write_json(metadata, manifest)
        stdout_log = metadata.with_suffix(".stdout.log")
        started = time.monotonic()
        with stdout_log.open("w") as stream:
            proc = subprocess.run(command,cwd=args.repo,env=environment,stdout=stream,stderr=subprocess.STDOUT)
        # Read individual audits too: they survive even if the child is stopped
        # before its atexit summary can be written.
        records = {}
        if audit.exists():
            for path in audit.glob("*.json"):
                if path.name=="summary.json":
                    continue
                record=json.loads(path.read_text())
                records[record.get("input_path")]=(path,record)
        outcomes=[]
        for key,item in chosen.items():
            audit_pair=records.get(item["pending_path"])
            status="missing_audit"
            rejection=None
            warnings=[]
            audit_path=None
            if audit_pair:
                path,record=audit_pair
                audit_path=str(path)
                warnings=record.get("warnings",[])
                rejection=record.get("rejection")
                exception=any("Traceback (most recent call last)" in message for message in warnings)
                if digest(Path(item["source"]))!=item["source_sha256"]:
                    status="source_changed_during_attempt"
                elif exception:
                    status="exception"
                elif record.get("output_exists_after") and Path(item["output_path"]).is_file():
                    status="grasp_saved"
                elif rejection:
                    status="filter_rejected"
                else:
                    status="unknown_unsaved"
            outcome={**item,"status":status,"scientific_attempt_completed":status in ("grasp_saved","filter_rejected"),
                "batch_id":batch_id,"audit_path":audit_path,"rejection":rejection,"warnings":warnings,
                "updated_at_utc":datetime.now(timezone.utc).isoformat()}
            previous=ledger["attempts"].get(key)
            if previous:
                outcome["previous_attempt"]={k:previous.get(k) for k in ("batch_id","status","audit_path")}
            ledger["attempts"][key]=outcome
            outcomes.append(outcome)
        ledger["updated_at_utc"]=datetime.now(timezone.utc).isoformat()
        write_json(ledger_path,ledger)
        counts={status:sum(item["status"]==status for item in outcomes) for status in sorted({item["status"] for item in outcomes})}
        manifest.update(returncode=proc.returncode,wall_time_s=time.monotonic()-started,
            stdout_log=str(stdout_log),counts=counts,outcomes=outcomes,ledger=str(ledger_path))
        write_json(metadata,manifest)
        print(json.dumps({"batch_id":batch_id,"selected":len(chosen),"counts":counts,
            "returncode":proc.returncode,"wall_time_s":round(manifest["wall_time_s"],2),
            "manifest":str(metadata),"ledger":str(ledger_path)},indent=2))
        if proc.returncode!=0 or any(not item["scientific_attempt_completed"] for item in outcomes):
            raise SystemExit(1)


if __name__=="__main__":
    main()
