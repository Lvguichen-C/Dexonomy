#!/usr/bin/env bash
set -euo pipefail
source /workspace/dexonomy-onboarding/activate.sh
export PYTHONPATH="/workspace/shadow-reproduction/runtime${PYTHONPATH:+:$PYTHONPATH}"
export MUJOCO_GL="${MUJOCO_GL:-egl}"
export LP_NUM_THREADS="${LP_NUM_THREADS:-2}"
cd /workspace/Dexonomy
exec "$@"

