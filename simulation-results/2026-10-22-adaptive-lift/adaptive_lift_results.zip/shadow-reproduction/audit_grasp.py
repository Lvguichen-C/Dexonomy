#!/usr/bin/env python3
"""Run unchanged Dexonomy grasp generation with read-only diagnostic hooks.

Example (from the Dexonomy checkout with its venv active)::

    python /workspace/shadow-reproduction/audit_grasp.py \
      --audit-dir /workspace/shadow-reproduction/audit/native \
      op=grasp hand=shadow exp_name=shadow_tip20 n_worker=1 \
      save_root=/workspace/shadow-reproduction/results

All simulation, iteration, early-stop and filter decisions use the original
methods. Hooks only copy values those methods already compute. This script
requires serial generation so each record has an unambiguous candidate.
"""

import argparse
import atexit
from collections import Counter
from functools import wraps
import hashlib
import json
import logging
from pathlib import Path
import sys
import time

import numpy as np


parser = argparse.ArgumentParser(add_help=False)
parser.add_argument("--audit-dir", type=Path, required=True)
args, remaining = parser.parse_known_args()
sys.argv = [sys.argv[0], *remaining]
args.audit_dir.mkdir(parents=True, exist_ok=True)

import dexonomy.op.gen_grasp as grasp_module
from dexonomy.qp.qp_single import ContactQP
from dexonomy.sim import MuJoCo_OptEnv


current = None
records = []


def plain(value):
    if isinstance(value, np.ndarray):
        return value.tolist()
    if isinstance(value, np.generic):
        return value.item()
    raise TypeError(type(value).__name__)


def contact_stats(contacts):
    distances = contacts["dist"]
    return {
        "count": len(distances),
        "min_distance_m": float(np.min(distances)) if len(distances) else None,
        "max_distance_m": float(np.max(distances)) if len(distances) else None,
        "body_names": sorted(set(contacts["bn1"])),
        "distances_m": np.asarray(distances).tolist(),
    }


class CandidateWarnings(logging.Handler):
    def emit(self, record):
        if current is not None and record.levelno >= logging.WARNING:
            current["warnings"].append(record.getMessage())


logging.getLogger().addHandler(CandidateWarnings())


def patch_filter(name):
    original = getattr(grasp_module.GraspFilter, name)

    @wraps(original)
    def wrapped(self, *positional, **kwargs):
        result = original(self, *positional, **kwargs)
        if current is not None:
            current["filter_calls"].append({
                "phase": current.get("phase"),
                "filter": name.removeprefix("_").removesuffix("_filter"),
                "passed": bool(result),
                "silent": bool(kwargs.get("slience", False)),
            })
        return result

    setattr(grasp_module.GraspFilter, name, wrapped)


for method in ("_limit_filter", "_collision_filter", "_contact_filter", "_qp_filter"):
    patch_filter(method)


original_forward = grasp_module.GraspFilter.forward


@wraps(original_forward)
def filter_forward(self, info):
    phase = "grasp" if "contact" in self.cfg else "pregrasp"
    if current is not None:
        current["phase"] = phase
        current["required_contact_groups"] = info.get("required_cbody", []) if info else current.get("required_contact_groups", [])
    result = original_forward(self, info)
    if current is not None:
        current["phase_results"][phase] = {
            "passed": bool(result[0]),
            "hand_qpos": self.sim_env.get_hand_qpos().copy(),
            "mujoco_warning_counts": self.sim_env._data.warning.number.copy(),
            "time_s": float(self.sim_env._data.time),
        }
        if not result[0] and current.get("rejection") is None:
            failed = [f for f in current["filter_calls"] if f["phase"] == phase and not f["passed"] and not f["silent"]]
            current["rejection"] = {"phase": phase, "filter": failed[-1]["filter"] if failed else "unknown"}
        current["phase"] = None
    return result


grasp_module.GraspFilter.forward = filter_forward
original_early_stop = grasp_module.GraspFilter.early_stop


@wraps(original_early_stop)
def early_stop(self):
    phase = "grasp_early_stop" if "contact" in self.cfg else "pregrasp_early_stop"
    if current is not None:
        current["phase"] = phase
    result = original_early_stop(self)
    if current is not None:
        current["early_stop_calls"].append({
            "phase": phase,
            "iteration": len(current["contact_force_iterations"]),
            "passed_collision_check": bool(result),
            "time_s": float(self.sim_env._data.time),
        })
        current["phase"] = None
    return result


grasp_module.GraspFilter.early_stop = early_stop
original_contacts = MuJoCo_OptEnv.get_contacts


@wraps(original_contacts)
def get_contacts(self, *positional, **kwargs):
    result = original_contacts(self, *positional, **kwargs)
    if current is not None:
        current["contacts"].append({
            "phase": current.get("phase"),
            "hand_object": contact_stats(result[0]),
            "hand_hand": contact_stats(result[1]),
        })
    return result


MuJoCo_OptEnv.get_contacts = get_contacts
original_force = MuJoCo_OptEnv.apply_contact_forces


@wraps(original_force)
def apply_contact_forces(self, *positional, **kwargs):
    result = original_force(self, *positional, **kwargs)
    if current is not None:
        current["contact_force_iterations"].append({
            "iteration": len(current["contact_force_iterations"]) + 1,
            "time_before_step_s": float(self._data.time),
            "contact_differences": np.array(result, copy=True),
        })
    return result


MuJoCo_OptEnv.apply_contact_forces = apply_contact_forces
original_solve = ContactQP.solve


@wraps(original_solve)
def solve(self, *positional, **kwargs):
    result = original_solve(self, *positional, **kwargs)
    if current is not None:
        current["qp_solves"].append({
            "phase": current.get("phase"),
            "wrench_error": float(result[1]),
            "has_solution": result[0] is not None,
            "n_contacts": int(self.num_contact),
        })
    return result


ContactQP.solve = solve
original_single = grasp_module._single_grasp


@wraps(original_single)
def single_grasp(param):
    global current
    path, cfg = param
    if cfg.n_worker != 1:
        raise ValueError("audit_grasp.py requires n_worker=1")
    # Hydra replaces the root logging configuration after importing this file.
    if not any(isinstance(h, CandidateWarnings) for h in logging.getLogger().handlers):
        logging.getLogger().addHandler(CandidateWarnings())
    output = path.replace(cfg.init_dir, cfg.grasp_dir)
    current = {
        "input_path": path,
        "output_path": output,
        "output_existed_before": Path(output).exists(),
        "grasp_step_budget": int(cfg.op.grasp.step),
        "grasp_substep": int(cfg.op.grasp.substep),
        "phase": None,
        "phase_results": {},
        "filter_calls": [],
        "contacts": [],
        "contact_force_iterations": [],
        "early_stop_calls": [],
        "qp_solves": [],
        "rejection": None,
        "warnings": [],
    }
    started = time.monotonic()
    try:
        return original_single(param)
    finally:
        current["wall_time_s"] = time.monotonic() - started
        current["grasp_iterations_used"] = len(current["contact_force_iterations"])
        current["output_exists_after"] = Path(output).exists()
        key = hashlib.sha256(path.encode()).hexdigest()[:12]
        filename = args.audit_dir / f"{Path(path).stem}_{key}.json"
        filename.write_text(json.dumps(current, indent=2, default=plain) + "\n")
        records.append({
            "input_path": path,
            "audit_path": str(filename),
            "saved": current["output_exists_after"],
            "iterations": current["grasp_iterations_used"],
            "rejection": current["rejection"],
            "warning_count": len(current["warnings"]),
        })
        current = None


grasp_module._single_grasp = single_grasp


@atexit.register
def summarize():
    counts = Counter(
        f"{r['rejection']['phase']}/{r['rejection']['filter']}" if r["rejection"] else "saved" if r["saved"] else "exception_or_other"
        for r in records
    )
    result = {"counts": dict(counts), "candidates": records}
    (args.audit_dir / "summary.json").write_text(json.dumps(result, indent=2) + "\n")


from dexonomy.main import main


if __name__ == "__main__":
    main()
