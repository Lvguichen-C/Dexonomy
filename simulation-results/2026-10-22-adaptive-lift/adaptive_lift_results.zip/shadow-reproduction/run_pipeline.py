#!/usr/bin/env python3
"""Launch upstream operations with a serial object loader on restricted hosts.

This changes only the object DataLoader's worker count, not cfg.n_worker.
HandTemplateLoader still receives n_worker=1, while Torch avoids the local IPC
used by multiprocessing DataLoader workers. Pass --parallel-object-loader to
retain the original object loader behavior. Other CLI arguments go to Hydra.
"""

import argparse
import sys


parser = argparse.ArgumentParser(add_help=False)
parser.add_argument("--parallel-object-loader", action="store_true")
args, remaining = parser.parse_known_args()
sys.argv = [sys.argv[0], *remaining]

if not args.parallel_object_loader:
    import dexonomy.op.gen_init as gen_init

    original_get_object_dataloader = gen_init.get_object_dataloader

    def serial_object_dataloader(cfg, n_worker):
        return original_get_object_dataloader(cfg, 0)

    gen_init.get_object_dataloader = serial_object_dataloader

from dexonomy.main import main


if __name__ == "__main__":
    main()
