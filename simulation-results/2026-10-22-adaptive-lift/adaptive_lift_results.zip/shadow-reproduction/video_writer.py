"""Small RGB-to-H264 pipe using the already installed ffmpeg binary."""
import subprocess
import numpy as np


class VideoWriter:
    def __init__(self, path, fps=25, **_unused):
        self.path = str(path)
        self.fps = fps
        self.proc = None
        self.shape = None

    def append_data(self, frame):
        frame = np.asarray(frame, dtype=np.uint8)
        if self.proc is None:
            self.shape = frame.shape
            height, width, channels = self.shape
            assert channels == 3
            self.proc = subprocess.Popen([
                "ffmpeg", "-hide_banner", "-loglevel", "error", "-y",
                "-f", "rawvideo", "-pix_fmt", "rgb24", "-s", f"{width}x{height}",
                "-r", str(self.fps), "-i", "-", "-an", "-c:v", "libx264",
                "-threads", "2", "-preset", "fast", "-crf", "21", "-pix_fmt", "yuv420p",
                "-movflags", "+faststart", self.path,
            ], stdin=subprocess.PIPE)
        assert frame.shape == self.shape
        self.proc.stdin.write(frame.tobytes())

    def close(self):
        if self.proc is not None:
            self.proc.stdin.close()
            code = self.proc.wait(timeout=60)
            if code:
                raise RuntimeError(f"ffmpeg exit {code}: {self.path}")
            self.proc = None

    def __enter__(self):
        return self

    def __exit__(self, *_args):
        self.close()
