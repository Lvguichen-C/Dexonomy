"""Add CPU execution support to the upstream Warp/Torch stream bridge.

Dexonomy passes an explicit Torch device to ``wp.stream_from_torch`` at three
kernel launch sites. Warp 1.8 only accepts CUDA devices there. CPU kernels do
not have CUDA streams and are launched with stream=None. No kernel, objective,
filter, trajectory, or simulator settings are changed by this compatibility shim.

Enable by prepending this directory to PYTHONPATH before starting Python.
"""

import torch
import warp as wp
import warp.torch as warp_torch


_cuda_stream_from_torch = wp.stream_from_torch


def _cpu_compatible_stream_from_torch(stream_or_device=None):
    if isinstance(stream_or_device, (str, torch.device)):
        if torch.device(stream_or_device).type == "cpu":
            return None
    return _cuda_stream_from_torch(stream_or_device)


wp.stream_from_torch = _cpu_compatible_stream_from_torch
warp_torch.stream_from_torch = _cpu_compatible_stream_from_torch

