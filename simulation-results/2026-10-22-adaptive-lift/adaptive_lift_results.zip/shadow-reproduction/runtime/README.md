# CPU runtime compatibility

The checkout remains the upstream `d561ff9` source. Its three Warp launches in
`dexonomy/util/warp_util.py` call `wp.stream_from_torch(points.device)` (or the
line segment device) even for CPU tensors. Warp 1.8's bridge supports CUDA
streams only and calls `torch.cuda.current_stream`, which fails with CPU Torch.

`sitecustomize.py` supplies `None` for an explicitly requested CPU stream, the
normal Warp CPU launch convention. All other calls retain Warp's original
implementation. Python automatically loads this module because `run_cpu.sh`
prepends its directory to `PYTHONPATH`; spawned Python processes inherit it.
It changes no optimization objectives, contact filters, or dynamics settings.

Usage from any directory:

```bash
/workspace/shadow-reproduction/run_cpu.sh dexrun op=init hand=shadow op.device=cpu ...
/workspace/shadow-reproduction/run_cpu.sh python /workspace/shadow-reproduction/runtime/smoke_cpu_warp.py
```

The smoke test calls the original `WarpCollisionEnv`: closest surface points on
a known box, finite normalized normals, analytic squared-distance gradients
through its custom backward kernel, and intersecting/nonintersecting ray tests.
Its result is saved to `/workspace/shadow-reproduction/cpu_warp_smoke.json`.
CUDA driver warnings during Warp initialization are expected on this CPU host;
the smoke asserts actual kernel outputs rather than treating import as success.
